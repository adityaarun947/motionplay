/* =====================================================================
   GAME OVER
   ===================================================================== */
scenes.over = {
  hint:'Hold a hand over Play again or Menu',
  enter(d){
    this.d = d; const key = 'mp-best-' + d.game;
    const prev = +store.get(key, 0);
    this.best = Math.max(prev, d.score); this.newBest = d.score > prev && d.score > 0; store.set(key, this.best);
    this.focus = 0; this.parts = [];
    if (this.newBest) { SFX.combo(); for (let i = 0; i < 5; i++) burst(this.parts, W * rand(0.2, 0.8), H * rand(0.2, 0.4), 18, ['#ffe14a', '#4fd27a', '#5b8cff', '#ff6b5a'], H * 0.8, H * 0.01, 1.4, 0.6); }
    const r = i => () => { const w = Math.min(W * 0.26, H * 0.5), h = H * 0.16, gap = W * 0.04; return [W / 2 - w - gap / 2 + i * (w + gap), H * 0.64, w, h]; };
    this.buttons = [ HoverButton('Play again', '', r(0), () => go(d.game), '#4fd27a'), HoverButton('Menu', '', r(1), () => go('menu'), '#5b8cff') ];
    if (d.game === 'runner') this.buttons.push(HoverButton('Customize & shop', '', () => { const w = Math.min(W * 0.26, H * 0.5); return [W / 2 - w / 2, H * 0.82, w, H * 0.1]; }, () => go('locker'), '#ffb36b'));
  },
  keys(k){ if (k === 'ArrowLeft') this.focus = 0; if (k === 'ArrowRight') this.focus = 1; if (k === 'ArrowDown' && this.buttons[2]) this.focus = 2; if (k === 'Enter') { SFX.select(); this.buttons[this.focus].action(); } },
  update(dt){ this.parts = stepParts(this.parts, dt); this.buttons.forEach((b, i) => b.focus = I.kb.active && i === this.focus); updateButtons(this.buttons, dt, sceneT); },
  draw(){
    ctx.fillStyle = '#12163a'; ctx.fillRect(0, 0, W, H);
    drawGhost(0.14);
    text(this.d.game === 'zombie' ? 'Overrun!' : 'Game over', W / 2, H * 0.15, H * 0.08, '#fff');
    const k = Math.min(1, sceneT / 0.8);
    text(String(Math.round(this.d.score * (1 - Math.pow(1 - k, 3)))), W / 2, H * 0.33, H * 0.16, '#ffe14a');
    text(this.d.detail, W / 2, H * 0.45, H * 0.04, '#c9d2ff', 'center', 600);
    text(this.newBest ? '★ New best!' : `Best: ${this.best}`, W / 2, H * 0.53, H * 0.045, this.newBest ? '#4fd27a' : '#c9d2ff', 'center', 700);
    if (this.d.coins !== undefined) text(`+${this.d.coins} coins saved  ·  wallet ● ${WALLET.coins}`, W / 2, H * 0.6, H * 0.032, '#ffd23f', 'center', 700);
    drawParts(this.parts);
    drawButtons(this.buttons);
  }
};
