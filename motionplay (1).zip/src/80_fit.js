/* =====================================================================
   FIT ZONE — a guided workout. The TV tells you what to do, shows a coach,
   and counts your reps from the body measurements the tablet sends (I.ex).
   Two programmes: Kids (energetic, jumpy) and Seniors (gentle, always standing, no real jumping).
   ===================================================================== */

/* Thresholds — all in "torso lengths" (shoulder-to-hip), so they work for any body size and distance.
   If a move isn't being counted, lower its number a little; if it counts too easily, raise it. */
const FITCFG = {
  kids:   { reach:-0.55, out:0.95, clapNear:0.40, kneeOn:0.30, kneeOff:0.15, jumpOn:0.10, jumpOff:0.04, squatOn:0.28, squatOff:0.12, shuffle:0.50, lean:0.26, jackSep:1.5, sprintMv:1.3, mvRep:0.70, holdKnee:0.30 },
  senior: { reach:-0.40, out:0.85, clapNear:0.50, kneeOn:0.18, kneeOff:0.09, jumpOn:0.05, jumpOff:0.02, squatOn:0.25, squatOff:0.12, shuffle:0.40, lean:0.18, jackSep:1.35, sprintMv:0.90, mvRep:0.40, holdKnee:0.15 },
};
// kind = which detector counts it · demo = which animation the coach shows · cap = seconds before we move on kindly
const FIT_EX = {
  kids: [
    { id:'jacks',   name:'Jumping Jacks',       tip:'Jump your feet apart and arms up — then back together!', target:10, kind:'jacks',   demo:'jacks',   cap:45, easy:true },
    { id:'knees',   name:'High Knees',          tip:'Run on the spot and lift those knees up high!',          target:20, kind:'knees',   demo:'knees',   cap:40 },
    { id:'jump',    name:'Big Jumps',           tip:'Crouch… then jump as high as you can!',                  target:8,  kind:'jump',    demo:'jump',    cap:40 },
    { id:'dash',    name:'Side Dash',           tip:'Dash to the left… dash to the right!',                   target:10, kind:'shuffle', demo:'shuffle', cap:40 },
    { id:'frog',    name:'Frog Squats',         tip:'Squat down low like a frog, then pop back up!',          target:8,  kind:'squat',   demo:'squat',   cap:45 },
    { id:'stars',   name:'Reach for the Stars', tip:'Stretch both arms way up high!',                         target:10, kind:'reach',   demo:'reach',   cap:40, easy:true },
    { id:'clap',    name:'Clap Overhead',       tip:'Clap your hands high above your head!',                  target:12, kind:'clap',    demo:'clap',    cap:40, easy:true },
    { id:'wipers',  name:'Windshield Wipers',   tip:'Lean to the left… and to the right!',                    target:10, kind:'lean',    demo:'lean',    cap:40 },
    { id:'windmill',name:'Windmill Arms',       tip:'Make big circles with both arms!',                       target:6,  kind:'circles', demo:'circles', cap:40 },
    { id:'sprint',  name:'Super Sprint',        tip:'Run on the spot as FAST as you can!',                    target:12, kind:'sprint',  demo:'knees',   cap:30, time:true },
    { id:'flamingo',name:'Flamingo Balance',    tip:'Lift one knee and stand tall like a flamingo!',          target:6,  kind:'balance', demo:'balance', cap:40, time:true, legs:true },
  ],
  senior: [
    { id:'reach',   name:'Reach Up Slowly',     tip:'Lift both arms up high, then lower them gently.',        target:8,  kind:'reach',   demo:'reach',   cap:80, easy:true },
    { id:'march',   name:'Gentle Marching',     tip:'Lift each knee a little, like a slow march.',            target:16, kind:'march',   demo:'march',   cap:80 },
    { id:'lift',    name:'Arm Lifts',           tip:'Raise both arms out to the sides, then lower them.',     target:10, kind:'armsout', demo:'armsout', cap:80, easy:true },
    { id:'circles', name:'Slow Arm Circles',    tip:'Hold your arms out and make small, slow circles.',       target:6,  kind:'circles', demo:'circles', cap:80 },
    { id:'bend',    name:'Gentle Side Bends',   tip:'Lean slowly to one side, then the other.',               target:8,  kind:'lean',    demo:'lean',    cap:80 },
    { id:'step',    name:'Side Steps',          tip:'Take a small step to the side, then step back.',         target:10, kind:'shuffle', demo:'shuffle', cap:80 },
    { id:'clap',    name:'Clap Up High',        tip:'Bring both hands together above your head.',             target:10, kind:'clap',    demo:'clap',    cap:80, easy:true },
    { id:'bounce',  name:'Easy Toe Bounce',     tip:'Tiny, gentle bounces on your toes. Keep it small.',      target:8,  kind:'bounce',  demo:'bounce',  cap:80 },
    { id:'balance', name:'Balance Hold',        tip:'Hold a chair or wall. Lift one foot a little.',          target:6,  kind:'balance', demo:'balance', cap:80, time:true, legs:true },
  ],
};
const FIT_TIPS = {
  kids:   ['You are doing AMAZING!', 'Shake out your arms and legs!', 'Take a big breath in… and out!', 'Almost there, champion!', 'Great energy!'],
  senior: ['Breathe in slowly… and out.', 'Take a sip of water if you like.', 'There is no rush — go at your own pace.', 'Lovely. You are doing really well.', 'Stand tall and relax your shoulders.'],
};

/* ---------------- rep counters: one small state machine per move ---------------- */
function makeDet(kind, C, legsOK){
  const st = { s:'lo', side:0, base:0, last:-9, apart:true, kl:false, kr:false, t:0 };
  const slowBase = f => { if (Math.abs(f.drop - st.base) < 0.1) st.base += (f.drop - st.base) * 0.01; return f.drop - st.base; };   // follows slow drift, not jumps
  const sideCount = (v, thr) => { if (v > thr && st.side !== 1) { st.side = 1; return 1; } if (v < -thr && st.side !== -1) { st.side = -1; return 1; } return 0; };
  switch (kind) {
    case 'reach': return { step(f){ const up = Math.max(f.wly, f.wry) < C.reach, down = Math.min(f.wly, f.wry) > 0; if (st.s === 'lo' && up) { st.s = 'hi'; return 1; } if (st.s === 'hi' && down) st.s = 'lo'; return 0; } };
    case 'armsout': return { step(f){ const out = Math.min(Math.abs(f.wlx), Math.abs(f.wrx)) > C.out && Math.max(Math.abs(f.wly), Math.abs(f.wry)) < 0.45, down = Math.max(Math.abs(f.wlx), Math.abs(f.wrx)) < 0.7 && Math.min(f.wly, f.wry) > 0.5;
      if (st.s === 'lo' && out) { st.s = 'hi'; return 1; } if (st.s === 'hi' && down) st.s = 'lo'; return 0; } };
    case 'clap': return { step(f){ const dx = Math.abs(f.wlx - f.wrx), together = dx < C.clapNear && Math.max(f.wly, f.wry) < -0.3;
      if (dx > 0.9) st.apart = true; if (st.apart && together) { st.apart = false; return 1; } return 0; } };
    case 'jump': case 'bounce': return { step(f, dt, now){ const rel = slowBase(f);
      if (st.s === 'lo' && rel < -C.jumpOn && now - st.last > 0.25) { st.s = 'hi'; st.last = now; return 1; } if (st.s === 'hi' && rel > -C.jumpOff) st.s = 'lo'; return 0; } };
    case 'squat': return { step(f){ const rel = slowBase(f); if (st.s === 'lo' && rel > C.squatOn) { st.s = 'hi'; return 1; } if (st.s === 'hi' && rel < C.squatOff) st.s = 'lo'; return 0; } };
    case 'shuffle': return { step(f){ return sideCount(f.hdx, C.shuffle); } };
    case 'lean': return { step(f){ return sideCount(f.lean, C.lean); } };
    case 'jacks': return { step(f){
      const armsUp = Math.max(f.wly, f.wry) < -0.45, armsDown = Math.min(f.wly, f.wry) > 0.2;
      const open = armsUp && (!legsOK || f.sep > C.jackSep), closed = armsDown && (!legsOK || f.sep < C.jackSep * 0.85);
      if (st.s === 'lo' && open) { st.s = 'hi'; return 0; } if (st.s === 'hi' && closed) { st.s = 'lo'; return 1; } return 0; } };
    case 'circles': { const prev = { l:null, r:null }, acc = { l:0, r:0 }, turn = TAU * 0.8;
      return { step(f){
        for (const [k, x, y] of [['l', f.wlx, f.wly], ['r', f.wrx, f.wry]]) {
          const r = Math.hypot(x, y), a = Math.atan2(y, x);
          if (r > 0.5) { if (prev[k] !== null) { let d = a - prev[k]; if (d > Math.PI) d -= TAU; if (d < -Math.PI) d += TAU; if (Math.abs(d) < 1.2) acc[k] += d; } prev[k] = a; } else { prev[k] = null; acc[k] *= 0.9; }
          if (Math.abs(acc[k]) >= turn) { acc.l = acc.r = 0; return 1; }
        } return 0; } }; }
    case 'knees': case 'march':
      if (!legsOK) return { step(f, dt){ if (f.mv > C.mvRep) st.t += dt; if (st.t > 0.6) { st.t -= 0.6; return 1; } return 0; } };   // legs not in view: count by movement
      return { step(f, dt, now){ let n = 0;
        if (!st.kl && f.kuL > C.kneeOn && now - st.last > 0.14) { st.kl = true; st.last = now; n++; } if (st.kl && f.kuL < C.kneeOff) st.kl = false;
        if (!st.kr && f.kuR > C.kneeOn && now - st.last > 0.14) { st.kr = true; st.last = now; n++; } if (st.kr && f.kuR < C.kneeOff) st.kr = false; return n; } };
    case 'sprint': return { step(f, dt){ return f.mv > C.sprintMv ? dt : 0; } };
    case 'balance': return { step(f, dt){ return Math.max(f.kuL, f.kuR) > C.holdKnee ? dt : 0; } };
  }
  return { step(){ return 0; } };
}
const exF = ex => ({ wlx:ex[0], wly:ex[1], wrx:ex[2], wry:ex[3], kuL:ex[4], kuR:ex[5], auL:ex[6], auR:ex[7], sep:ex[8], lean:ex[9], hdx:ex[10], drop:ex[11], mv:ex[12], legs:ex[13], arms:ex[14] });

/* ---------------- the coach (a friendly figure that shows each move) ---------------- */
const ease = p => (1 - Math.cos(TAU * p)) / 2;
function coachPose(demo, t, senior){
  const per = { jacks:1.2, knees:0.9, jump:1.5, shuffle:1.6, squat:2.0, reach:2.2, clap:1.4, lean:2.6, circles:3.0, armsout:2.6, march:1.8, balance:3, bounce:1.0 }[demo] * (senior ? 1.5 : 1);
  const p = (t / per) % 1, e = ease(p), s = Math.sin(TAU * p), P = { aL:8, aR:8, kL:0, kR:0, spread:3, up:0, dx:0, lean:0, squat:0, circ:null, clap:0 };
  switch (demo) {
    case 'jacks': P.aL = P.aR = 8 + 165 * e; P.spread = 3 + 20 * e; P.up = e * 0.7; break;
    case 'knees': P.kL = Math.max(0, s) * 0.95; P.kR = Math.max(0, -s) * 0.95; P.aL = 35 + 25 * s; P.aR = 35 - 25 * s; P.up = Math.abs(s) * 0.15; break;
    case 'march': P.kL = Math.max(0, s) * 0.6; P.kR = Math.max(0, -s) * 0.6; P.aL = 20 + 12 * s; P.aR = 20 - 12 * s; break;
    case 'jump': P.up = Math.max(0, s) * 2.2; P.squat = Math.max(0, -s) * 0.45; P.aL = P.aR = 15 + 150 * Math.max(0, s); P.spread = 4 + 8 * Math.max(0, s); break;
    case 'bounce': P.up = Math.abs(s) * 0.3; P.aL = P.aR = 18; break;
    case 'shuffle': P.dx = s * 3.2; P.spread = 6; P.aL = P.aR = 25; break;
    case 'squat': P.squat = e; P.aL = P.aR = 15 + 45 * e; P.spread = 3 + 6 * e; break;
    case 'reach': P.aL = P.aR = 8 + 168 * e; break;
    case 'armsout': P.aL = P.aR = 8 + 84 * e; break;
    case 'clap': P.aL = P.aR = 158 + 20 * (1 + Math.cos(2 * TAU * p)) / 2; P.clap = (1 + Math.cos(2 * TAU * p)) / 2; break;
    case 'lean': P.lean = s * 18; P.aL = P.aR = 165; P.dx = -s * 0.6; break;
    case 'circles': P.aL = P.aR = 90; P.circ = p; break;
    case 'balance': P.kR = 0.6; P.aL = P.aR = 55; P.dx = Math.sin(t * 1.2) * 0.2; break;
  }
  return P;
}
function ik(hx, hy, ax, ay, l1, l2, dir){      // two-bone limb: returns the knee/elbow position
  let dx = ax - hx, dy = ay - hy, d = Math.min(Math.hypot(dx, dy), (l1 + l2) * 0.999); if (d < 0.001) d = 0.001;
  const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d), h = Math.sqrt(Math.max(0, l1 * l1 - a * a)), ux = dx / Math.hypot(dx, dy || 0.001), uy = dy / Math.hypot(dx, dy || 0.001);
  return [hx + ux * a + -uy * h * dir, hy + uy * a + ux * h * dir];
}
function drawCoach(cx, fy, h, P, sty){
  const u = h / 10, up = P.up * u * 1.1, hipY = fy - 4.6 * u * (1 - 0.3 * P.squat) - up, hipX = cx + P.dx * u;
  const tr = P.lean * Math.PI / 180, rot = (x, y) => [hipX + x * Math.cos(tr) - y * Math.sin(tr), hipY + x * Math.sin(tr) + y * Math.cos(tr)];
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(cx + P.dx * u, fy, u * 2.2 * (1 - P.up * 0.1), u * 0.45, 0, 0, TAU); ctx.fill();
  const limb = (x1, y1, x2, y2, w, col) => { ctx.strokeStyle = col; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); };
  // legs
  for (const s of [-1, 1]) {
    const k = s < 0 ? P.kL : P.kR, hx = hipX + s * 0.55 * u, hy = hipY + 0.2 * u;
    const ax = hipX + s * (0.75 * u + Math.sin(P.spread * Math.PI / 180) * 4.2 * u) + s * P.squat * 0.4 * u, ay = fy - up - k * 2.6 * u;
    const [kx, ky] = ik(hx, hy, ax, ay, 2.3 * u, 2.3 * u, -s);
    limb(hx, hy, kx, ky, u * 1.05, sty.pants); limb(kx, ky, ax, ay, u * 0.95, sty.pants);
    ctx.fillStyle = sty.shoe; ctx.beginPath(); ctx.ellipse(ax + s * 0.25 * u, ay + 0.1 * u, u * 0.85, u * 0.42, 0, 0, TAU); ctx.fill();
  }
  // torso
  const [tx, ty] = rot(0, -3.2 * u), [bx, by] = rot(0, 0.2 * u);
  limb(bx, by, tx, ty, u * 2.5, sty.shirt);
  limb(bx, by + u * 0.1, bx, by + u * 0.1, u * 2.6, sty.pants);
  // arms
  const hands = [];
  for (const s of [-1, 1]) {
    const [sx, sy] = rot(s * 1.35 * u, -2.7 * u), a = (s < 0 ? P.aL : P.aR) * Math.PI / 180;
    let ex, ey;
    if (P.hips) { const [elx, ely] = rot(s * 2.7 * u, -1.1 * u), [hx0, hy0] = rot(s * 1.15 * u, 0.0 * u); limb(sx, sy, elx, ely, u * 0.85, sty.shirt); limb(elx, ely, hx0, hy0, u * 0.8, sty.shirt); ctx.fillStyle = sty.skin; ctx.beginPath(); ctx.arc(hx0, hy0, u * 0.6, 0, TAU); ctx.fill(); hands.push([hx0, hy0]); continue; }
    if (P.circ !== null) { const ph = P.circ * TAU * (s < 0 ? -1 : 1); ex = sx + s * 3.0 * u * 0.95 + Math.cos(ph) * u * 0.9; ey = sy + Math.sin(ph) * u * 1.0; }
    else { ex = sx + s * Math.sin(a) * 3.2 * u; ey = sy + Math.cos(a) * 3.2 * u; if (P.clap > 0.5) ex -= s * u * 0.25 * P.clap; }
    limb(sx, sy, ex, ey, u * 0.85, sty.shirt);
    ctx.fillStyle = sty.skin; ctx.beginPath(); ctx.arc(ex, ey, u * 0.65, 0, TAU); ctx.fill(); hands.push([ex, ey]);
  }
  if (P.clap > 0.85) { ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = '#ffe14a'; for (let i = 0; i < 6; i++) { const a = i / 6 * TAU; ctx.beginPath(); ctx.arc((hands[0][0] + hands[1][0]) / 2 + Math.cos(a) * u * 1.1, hands[0][1] + Math.sin(a) * u * 1.1, u * 0.18, 0, TAU); ctx.fill(); } ctx.globalCompositeOperation = 'source-over'; }
  // head
  const [nx, ny] = rot(0, -3.5 * u), hr = u * 1.15, hx = nx + Math.sin(tr) * 0.3 * u, hy2 = ny - hr * 0.95;
  limb(tx, ty, nx, ny, u * 0.9, sty.skin);
  ctx.fillStyle = sty.skin; ctx.beginPath(); ctx.arc(hx, hy2, hr, 0, TAU); ctx.fill();
  ctx.fillStyle = sty.hair; ctx.beginPath(); ctx.arc(hx, hy2 - hr * 0.1, hr * 1.04, Math.PI * 1.02, Math.PI * 1.98); ctx.fill();
  ctx.fillStyle = '#2a1b12'; ctx.beginPath(); ctx.arc(hx - hr * 0.38, hy2 + hr * 0.08, hr * 0.1, 0, TAU); ctx.arc(hx + hr * 0.38, hy2 + hr * 0.08, hr * 0.1, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#2a1b12'; ctx.lineWidth = Math.max(2, hr * 0.09); ctx.beginPath(); ctx.arc(hx, hy2 + hr * 0.28, hr * 0.36, 0.2, Math.PI - 0.2); ctx.stroke();
  if (sty.band) { ctx.fillStyle = sty.band; ctx.fillRect(hx - hr * 1.02, hy2 - hr * 0.42, hr * 2.04, hr * 0.2); }
}
const COACH_STYLE = {
  kids:   { shirt:'#ff7a2f', pants:'#2b3a67', shoe:'#f4f4fa', skin:'#f2c9a0', hair:'#6b4a35', band:'#2f7cf6' },
  senior: { shirt:'#4aa3a0', pants:'#4b5576', shoe:'#e9e4d8', skin:'#f0cfae', hair:'#d8d8d8' },
};
function drawMascot(x, y, r, mode, t, joy){
  ctx.save(); ctx.translate(x, y - Math.abs(Math.sin(t * 6)) * r * 0.35 * joy);
  if (mode === 'kids') {
    ctx.rotate(Math.sin(t * 2) * 0.12 + joy * Math.sin(t * 14) * 0.15);
    ctx.fillStyle = '#ffd23f'; ctx.strokeStyle = '#ff9a1f'; ctx.lineWidth = r * 0.12; ctx.lineJoin = 'round'; ctx.beginPath();
    for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.58 : r * 1.12; ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
    ctx.closePath(); ctx.fill(); ctx.stroke();
  } else {
    ctx.strokeStyle = '#ffd98a'; ctx.lineWidth = r * 0.12; ctx.lineCap = 'round';
    for (let i = 0; i < 12; i++) { const a = i / 12 * TAU + t * 0.3; ctx.beginPath(); ctx.moveTo(Math.cos(a) * r * 1.05, Math.sin(a) * r * 1.05); ctx.lineTo(Math.cos(a) * r * 1.35, Math.sin(a) * r * 1.35); ctx.stroke(); }
    ctx.fillStyle = '#ffcf5a'; ctx.beginPath(); ctx.arc(0, 0, r * 0.95, 0, TAU); ctx.fill();
  }
  ctx.fillStyle = '#3a2410'; ctx.beginPath(); ctx.arc(-r * 0.3, -r * 0.1, r * 0.1, 0, TAU); ctx.arc(r * 0.3, -r * 0.1, r * 0.1, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#3a2410'; ctx.lineWidth = r * 0.08; ctx.beginPath(); ctx.arc(0, r * 0.1, r * (0.28 + 0.12 * joy), 0.15, Math.PI - 0.15); ctx.stroke();
  ctx.fillStyle = 'rgba(255,120,120,0.45)'; ctx.beginPath(); ctx.arc(-r * 0.5, r * 0.15, r * 0.14, 0, TAU); ctx.arc(r * 0.5, r * 0.15, r * 0.14, 0, TAU); ctx.fill();
  ctx.restore();
}

/* ---------------- shared look ---------------- */
function fitBackground(mode, t){
  ctx.drawImage(cachedLayer('fit-' + mode, g => {
    const gr = g.createLinearGradient(0, 0, 0, H);
    if (mode === 'kids') { gr.addColorStop(0, '#34227a'); gr.addColorStop(0.55, '#1c5a8c'); gr.addColorStop(1, '#0e7a78'); }
    else { gr.addColorStop(0, '#24566b'); gr.addColorStop(0.6, '#3b7a86'); gr.addColorStop(1, '#6a9a8f'); }
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
    const sx = W * 0.88, sy = H * 0.14, sr = H * 0.1, gl = g.createRadialGradient(sx, sy, 0, sx, sy, sr * 4);
    gl.addColorStop(0, mode === 'kids' ? 'rgba(255,230,120,0.35)' : 'rgba(255,225,160,0.5)'); gl.addColorStop(1, 'rgba(255,225,160,0)'); g.fillStyle = gl; g.fillRect(sx - sr * 4, sy - sr * 4, sr * 8, sr * 8);
  }), 0, 0);
  if (mode === 'kids') {
    for (let i = 0; i < 16; i++) {   // bouncing colourful blobs
      const x = ((i * 0.137 + t * 0.012 * (1 + i % 3)) % 1.1 - 0.05) * W, y = H * (0.2 + 0.7 * ((i * 0.31) % 1)) + Math.sin(t * 1.6 + i) * H * 0.03, r = H * (0.012 + 0.012 * (i % 4));
      ctx.globalAlpha = 0.28; ctx.fillStyle = ['#ff7a2f', '#ffd23f', '#5be3a8', '#ff6b9a', '#7ab8ff'][i % 5]; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    }
  } else {
    for (let i = 0; i < 5; i++) {   // slow soft clouds
      const x = ((i * 0.27 + t * 0.006) % 1.3 - 0.15) * W, y = H * (0.12 + 0.12 * i), r = H * 0.05;
      ctx.globalAlpha = 0.12; ctx.fillStyle = '#fff';
      for (const [dx, dy, rr] of [[0, 0, 1], [1.2, 0.2, 0.8], [-1.2, 0.2, 0.8], [0.5, -0.5, 0.8]]) { ctx.beginPath(); ctx.arc(x + dx * r, y + dy * r, r * rr, 0, TAU); ctx.fill(); }
    }
  }
  ctx.globalAlpha = 1;
}
function confetti(arr, n = 40){ for (let i = 0; i < n; i++) burst(arr, W * rand(0.1, 0.9), H * rand(0.05, 0.3), 1, [pick(['#ffd23f', '#ff6b9a', '#5be3a8', '#7ab8ff', '#ffffff', '#ff7a2f'])], H * rand(0.1, 0.5), H * rand(0.006, 0.012), rand(1.5, 2.6), 0.35); }
function drawStar(x, y, r, col, fill = 1){
  ctx.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r; ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } ctx.closePath();
  ctx.fillStyle = fill ? col : 'rgba(255,255,255,0.15)'; ctx.fill(); ctx.lineWidth = r * 0.1; ctx.strokeStyle = fill ? '#c98a00' : 'rgba(255,255,255,0.3)'; ctx.stroke();
}

/* =====================================================================
   HUB — pick Kids or Seniors, and how long
   ===================================================================== */
scenes.fithub = {
  music:'menu', hint:'Hold a hand over Kids or Seniors to choose a workout',
  enter(){
    this.len = +store.get('mp-fitlen', 1); this.focus = 0; this.mode = null;
    const card = i => () => { const w = Math.min(W * 0.3, H * 0.62), h = H * 0.5, gap = W * 0.04; return [W / 2 - w - gap / 2 + i * (w + gap), H * 0.18, w, h]; };
    const icon = mode => (x, y, w, h) => { const P = coachPose(mode === 'kids' ? 'jacks' : 'reach', sceneT, mode === 'senior'); drawCoach(x + w / 2, y + h * 0.6, h * 0.5, P, COACH_STYLE[mode]); };
    const chip = i => () => { const w = Math.min(W * 0.19, H * 0.36), gap = W * 0.015; return [W / 2 - (w * 3 + gap * 2) / 2 + i * (w + gap), H * 0.765, w, H * 0.11]; };
    const setLen = i => () => { this.len = i; store.set('mp-fitlen', String(i)); };
    this.buttons = [
      HoverButton('Kids', 'Energetic · jumping · running', card(0), () => go('fit', { mode:'kids', len:this.len }), '#ff7a2f', { draw:icon('kids'), best:'fitkids' }),
      HoverButton('Seniors', 'Gentle · standing · no jumping', card(1), () => go('fit', { mode:'senior', len:this.len }), '#4aa3a0', { draw:icon('senior'), best:'fitsenior' }),
      HoverButton('Quick', '4 moves · ~3 min', chip(0), setLen(0), '#8f9bd6'),
      HoverButton('Normal', '6 moves · ~6 min', chip(1), setLen(1), '#8f9bd6'),
      HoverButton('Long', '8 moves · ~10 min', chip(2), setLen(2), '#8f9bd6'),
      HoverButton('Back', '', () => [W * 0.03, H * 0.88, Math.min(W * 0.14, H * 0.3), H * 0.08], () => go('menu'), '#5b8cff'),
    ];
    this.buttons.forEach(b => { if (b.label === 'Back') b.small = true; });
  },
  keys(k){
    if (k === 'ArrowLeft') this.focus = 0; if (k === 'ArrowRight') this.focus = 1;
    if (k === 'ArrowUp') this.len = Math.max(0, this.len - 1); if (k === 'ArrowDown') this.len = Math.min(2, this.len + 1);
    if (k === 'Enter') { SFX.select(); this.buttons[this.focus].action(); }
  },
  update(dt){
    this.buttons.forEach((b, i) => { b.focus = (i < 2 && I.kb.active && i === this.focus) || (i >= 2 && i < 5 && i - 2 === this.len); });
    updateButtons(this.buttons, dt, sceneT);
  },
  draw(){
    fitBackground('kids', sceneT);
    text('Fit Zone', W / 2, H * 0.09, H * 0.085);
    text('Pick your workout — the TV will coach you through it', W / 2, H * 0.155, H * 0.032, '#d6defc', 'center', 600);
    drawButtons(this.buttons);
    text('How long?', W / 2, H * 0.735, H * 0.028, '#d6defc', 'center', 700);
    text('Stand about 2–3 metres from the tablet so your whole body fits in view', W / 2, H * 0.935, H * 0.027, '#c9d2ff', 'center', 600);
  }
};

/* =====================================================================
   THE WORKOUT
   ===================================================================== */
scenes.fit = {
  game:true, hint:'Follow the coach! Your reps are counted automatically',
  music(d){ return d && d.mode === 'senior' ? 'fitsenior' : 'fitkids'; },
  enter(d){
    d = d || { mode:'kids', len:1 }; this.d = d;
    const mode = d.mode, C = FITCFG[mode], senior = mode === 'senior';
    Object.assign(this, { mode, senior, C, sty:COACH_STYLE[mode], parts:[], pops:[], state:'check', stateT:0, idx:0, results:[], list:[], legsOK:true, legsVotes:[], calStart:0,
                          reps:0, workT:0, det:null, joy:0, ringPulse:0, shake:0, flash:0, tipI:0, stars:0, ex:null, restLen:6, bpm:senior ? 80 : 140, totalReps:0, lastBeat:0 });
    this.buildList(d.len);
    this.fs = senior ? 1.12 : 1;
    this.layout();
    this.buttons = [
      HoverButton('Start workout', '', () => [W * 0.5 - Math.min(W * 0.2, H * 0.4) / 2 * 1.4, H * 0.8, Math.min(W * 0.2, H * 0.4) * 1.4, H * 0.1], () => this.beginCal(), '#4fd27a'),
      HoverButton('Back', '', () => [W * 0.03, H * 0.88, Math.min(W * 0.14, H * 0.3), H * 0.08], () => go('fithub'), '#5b8cff'),
    ];
    this.workButtons = [
      HoverButton('Skip', '', () => [W * 0.03, H * 0.9, Math.min(W * 0.11, H * 0.2), H * 0.065], () => this.skip(), '#8f9bd6'),
      HoverButton('Quit', '', () => [W * 0.97 - Math.min(W * 0.11, H * 0.2), H * 0.9, Math.min(W * 0.11, H * 0.2), H * 0.065], () => go('fithub'), '#ff6b6b'),
    ];
    for (const b of this.workButtons) b.dwell = 1.4;
    sendTracker({ t:'mode', fb:false });
    Music.setLevel(0.3);
  },
  exit(){ Music.setLevel(1); Music.setTempo(1); },
  layout(){},
  buildList(len){
    const pool = FIT_EX[this.mode].slice(), n = [4, 6, 8][len] || 6;
    const easy = pool.filter(e => e.easy), rest = pool.filter(e => !e.easy);
    rest.sort(() => Math.random() - 0.5); easy.sort(() => Math.random() - 0.5);
    const list = [easy[0]];                         // gentle warm-up first
    const mid = rest.concat(easy.slice(1));
    mid.sort(() => Math.random() - 0.5);
    while (list.length < n - 1 && mid.length) list.push(mid.shift());
    list.push(easy[1] || mid.shift() || easy[0]);   // calm finisher
    this.list = list.filter(Boolean);
  },
  // ----- flow -----
  beginCal(){
    if (this.state !== 'check') return;
    this.state = 'cal'; this.stateT = 0; this.legsVotes = [];
    if (motionLive()) sendTracker({ t:'calibrate' });
  },
  startRest(){
    this.state = 'rest'; this.stateT = 0;
    const first = this.idx === 0;
    this.restLen = first ? 6 : this.senior ? 10 : 7; this.tipI = (this.tipI + 1) % 5;
    this.cur = this.list[this.idx]; Music.setLevel(0.15); Music.setTempo(0.95);
    if (!first) SFX.swoosh();
  },
  startWork(){
    this.state = 'work'; this.stateT = 0; this.workT = 0; this.reps = 0; this.last = 0;
    const ex = this.cur, legs = this.legsOK;
    this.det = makeDet(ex.kind, this.C, legs); this.target = ex.time ? ex.target : ex.target;
    Music.setLevel(this.senior ? 0.6 : 0.7); Music.setTempo(1); SFX.go();
  },
  addRep(n = 1, fx = true){
    const ex = this.cur; this.reps += n;
    if (!ex.time) {
      this.totalReps += n;
      if (fx) {
        this.joy = 1; this.ringPulse = 1;
        const k = this.reps / ex.target; tone(520 + k * 520, 0.09, 'triangle', 0.1); setTimeout(() => tone(780 + k * 520, 0.12, 'triangle', 0.09), 60);
        const rx = W * 0.835, ry = H * 0.4;
        burst(this.parts, rx, ry, 14, ['#ffd23f', '#5be3a8', '#ff6b9a', '#ffffff'], H * 0.5, H * 0.007, 0.8, 0.5);
        pop(this.pops, W * 0.5 + rand(-0.12, 0.12) * W, H * 0.3, '+1', '#ffe14a', 0.05, 0.8);
        if (this.mode === 'kids' && this.reps % 5 === 0) { SFX.combo(); pop(this.pops, W * 0.5, H * 0.22, pick(['Awesome!', 'Yes!', 'Go go go!', 'Super!']), '#ff9a3f', 0.06, 1.1); }
        if (this.senior && this.reps % 4 === 0) pop(this.pops, W * 0.5, H * 0.22, pick(['Lovely!', 'Well done!', 'Nice and steady']), '#9be3d0', 0.055, 1.2);
      }
    }
  },
  finishWork(){
    const ex = this.cur, ratio = this.reps / ex.target, used = this.workT, cap = ex.cap;
    let stars = 0;
    if (this.senior) stars = ratio >= 1 ? 3 : ratio >= 0.7 ? 2 : ratio >= 0.4 ? 1 : 0;
    else if (ratio >= 1) stars = 1 + (used < cap * 0.75 ? 1 : 0) + (used < cap * 0.5 ? 1 : 0);
    else if (ratio >= 0.5) stars = 1;
    this.stars = stars;
    this.results.push({ ex, reps:Math.min(this.reps, ex.target * 2), stars, done:ratio >= 1 });
    this.state = 'cheer'; this.stateT = 0;
    if (ratio >= 1) { SFX.setDone(); confetti(this.parts, this.senior ? 22 : 50); this.flash = 0.5; }
    else SFX.nope();
    Music.setLevel(0.3);
  },
  skip(){ if (this.state === 'work') { this.finishWork(); } else if (this.state === 'rest') { this.stateT = Math.max(this.stateT, this.restLen - 3.01); } },
  next(){
    this.idx++;
    if (this.idx >= this.list.length) return this.finish();
    this.startRest();
  },
  finish(){
    const stars = this.results.reduce((s, r) => s + r.stars, 0), reps = this.results.reduce((s, r) => s + (r.ex.time ? 0 : r.reps), 0);
    go('fitdone', { mode:this.mode, len:this.d.len, stars, maxStars:this.list.length * 3, reps, results:this.results, score:stars * 100 + reps });
  },
  keys(k){
    if (k === 'r' || k === 'R') { if (this.state === 'work') this.addRep(1); }
    if (k === 's' || k === 'S') { if (this.state === 'work') this.finishWork(); else if (this.state === 'rest') this.stateT = Math.max(this.stateT, this.restLen - 3.01); }
    if (k === 'Enter' && this.state === 'check') this.beginCal();
    if (k === 'q' || k === 'Q') go('fithub');
  },
  // ----- update -----
  update(dt){
    this.stateT += dt; this.parts = stepParts(this.parts, dt); this.pops = stepPops(this.pops, dt);
    this.joy = Math.max(0, this.joy - dt * 2); this.ringPulse = Math.max(0, this.ringPulse - dt * 3); this.flash = Math.max(0, this.flash - dt * 2);
    const f = I.ex && motionLive() ? exF(I.ex) : null;
    if (this.state === 'check') { updateButtons(this.buttons, dt, sceneT); return; }
    if (this.state === 'cal') {
      if (f) this.legsVotes.push(f.legs);
      const need = motionLive() ? 3.6 : 0.6;
      if (this.stateT >= need) {
        const v = this.legsVotes; this.legsOK = !motionLive() || (v.length > 5 && v.reduce((a, b) => a + b, 0) / v.length > 0.5);
        if (!this.legsOK) this.list = this.list.filter(e => !e.legs);
        if (this.list.length < 3) this.buildList(this.d.len);
        this.startRest();
      } return;
    }
    if (this.state === 'rest') {
      this.cur = this.list[this.idx];
      const p = this.restLen - this.stateT; if (Math.ceil(p) !== Math.ceil(p + dt) && p > 0 && p < 3) SFX.beep();
      if (this.stateT >= this.restLen) this.startWork();
      updateButtons(this.workButtons, dt, sceneT); return;
    }
    if (this.state === 'work') {
      this.workT += dt;
      if (f && this.det) { const add = this.det.step(f, dt, this.workT); if (add > 0) { if (this.cur.time) this.reps += add; else this.addRep(Math.round(add), true); } }
      if (this.reps >= this.cur.target || this.workT >= this.cur.cap) this.finishWork();
      updateButtons(this.workButtons, dt, sceneT); return;
    }
    if (this.state === 'cheer') {
      if (this.stateT > 0.5 && Math.floor((this.stateT - dt) * 4) !== Math.floor(this.stateT * 4) && Math.floor(this.stateT * 4) <= this.stars + 1) { SFX.star(); }
      if (this.stateT > 2.2) this.next();
    }
  },
  // ----- drawing -----
  draw(now){
    const t = sceneT, mode = this.mode;
    fitBackground(mode, t);
    if (this.flash) { ctx.fillStyle = `rgba(255,255,255,${this.flash * 0.25})`; ctx.fillRect(0, 0, W, H); }
    if (this.state === 'check') this.drawCheck();
    else if (this.state === 'cal') this.drawCal();
    else if (this.state === 'rest') this.drawRest();
    else this.drawWork(now);
    drawParts(this.parts); drawPops(this.pops);
    if (this.state === 'check') drawButtons(this.buttons);
    if (this.state === 'rest' || this.state === 'work') drawButtons(this.workButtons);
    if (this.state !== 'check') this.drawSessionBar();
    if (!(this.state === 'check') && motionLive() && !I.present) text('Step back into view', W / 2, H * 0.95, H * 0.035, '#ffc24a');
  },
  panel(x, y, w, h, a = 0.35){ roundRect(x, y, w, h, H * 0.025); ctx.fillStyle = `rgba(8,12,40,${a})`; ctx.fill(); },
  bodyBox(){ const s = Math.min(W * 0.4, H * 0.7); return [W * 0.5 - s * 0.5 + W * 0.02, H * 0.17, s, s * 1.03]; },
  drawPlayer(box, alpha = 0.95){
    this.panel(box[0], box[1], box[2], box[3], 0.3);
    ctx.save(); roundRect(box[0], box[1], box[2], box[3], H * 0.025); ctx.clip();
    ctx.globalCompositeOperation = 'lighter'; drawGhost(0.3, [box[0] - box[2] * 0.0, box[1], box[2], box[3]], this.senior ? '#9be3d0' : '#7ab8ff'); ctx.globalCompositeOperation = 'source-over';
    drawGhost(alpha, box, this.senior ? '#d9fff3' : '#ffffff'); ctx.restore();
    if (!(motionLive() && I.present)) text(motionLive() ? 'I can’t see you' : 'Keyboard mode: press R to count a rep', box[0] + box[2] / 2, box[1] + box[3] / 2, H * 0.03, '#ffc24a', 'center', 700);
  },
  drawCheck(){
    const fs = this.fs;
    text(this.senior ? 'Seniors Workout' : 'Kids Workout', W / 2, H * 0.08, H * 0.07 * fs, this.senior ? '#9be3d0' : '#ffb36b');
    text('Let’s check the camera can see all of you', W / 2, H * 0.145, H * 0.032 * fs, '#d6defc', 'center', 600);
    const box = this.bodyBox(); box[0] = W * 0.08; box[2] = Math.min(W * 0.3, H * 0.55); box[3] = box[2] * 1.15;
    this.drawPlayer(box);
    // what the camera can see
    const sk = I.sk, vis = (...ids) => !!(sk && motionLive() && ids.every(i => sk[i * 3 + 2] > 0.5 && sk[i * 3] > 0.01 && sk[i * 3] < 0.99 && sk[i * 3 + 1] > 0.01 && sk[i * 3 + 1] < 0.99));
    const items = [['Head', vis(0)], ['Shoulders and arms', vis(11, 12, 13, 14)], ['Hips', vis(23, 24)], ['Knees', vis(25, 26)], ['Feet', vis(27, 28)]];
    this.allSeen = items.every(i => i[1]); this.upperSeen = items.slice(0, 3).every(i => i[1]);
    const lx = W * 0.46; let y = H * 0.24;
    this.panel(lx - W * 0.02, y - H * 0.04, W * 0.5, H * 0.43, 0.3);
    items.forEach(([n, ok]) => { text(ok ? '✓' : '○', lx + H * 0.03, y, H * 0.045 * fs, ok ? '#4fd27a' : '#ffc24a', 'center'); text(n, lx + H * 0.09, y, H * 0.04 * fs, '#fff', 'left', 700); y += H * 0.075; });
    const msg = !motionLive() ? 'No tablet connected — you can still try it with the keyboard (R = count a rep).'
      : this.allSeen ? 'Perfect — all of you is in view!' : this.upperSeen ? 'Step back a little so your knees and feet fit — or just start: I’ll use arm moves only.' : 'Step back until your head, shoulders and hips are in view.';
    this.wrap(msg, lx, y - H * 0.015, W * 0.44, H * 0.026 * fs, this.allSeen ? '#9be3a8' : '#ffd98a');
    if (this.senior) this.wrap('Please stand near a sturdy chair or wall. Go at your own pace and stop if you feel unwell.', W * 0.08, H * 0.74, W * 0.84, H * 0.03 * fs, '#fff1c9');
    else this.wrap('Clear some space around you — you’ll be moving a lot!', W * 0.08, H * 0.74, W * 0.84, H * 0.03, '#fff1c9');
    this.buttons[0].label = this.allSeen || !motionLive() ? 'Start workout' : 'Start anyway';
    drawMascot(W * 0.91, H * 0.1, H * 0.06 * fs, this.mode, sceneT, 0.3);
  },
  drawCal(){
    const k = Math.min(1, this.stateT / 3.6);
    text('Stand tall and relax', W / 2, H * 0.3, H * 0.07 * this.fs);
    text('Hold still for a moment so I can learn your body', W / 2, H * 0.4, H * 0.034 * this.fs, '#d6defc', 'center', 600);
    ctx.lineWidth = H * 0.025; ctx.strokeStyle = 'rgba(255,255,255,0.2)'; ctx.beginPath(); ctx.arc(W / 2, H * 0.62, H * 0.12, 0, TAU); ctx.stroke();
    ctx.strokeStyle = '#4fd27a'; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(W / 2, H * 0.62, H * 0.12, -Math.PI / 2, -Math.PI / 2 + TAU * k); ctx.stroke();
    drawMascot(W / 2, H * 0.62, H * 0.07, this.mode, sceneT, 0.2);
  },
  drawSessionBar(){
    const n = this.list.length, bw = W * 0.5, x0 = W / 2 - bw / 2, y = H * 0.935, seg = bw / n;
    for (let i = 0; i < n; i++) {
      const r = this.results[i], cur = i === this.idx && this.state !== 'cal';
      roundRect(x0 + i * seg + 3, y, seg - 6, H * 0.016, H * 0.008); ctx.fillStyle = r ? (r.done ? '#4fd27a' : '#ffc24a') : cur ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.2)'; ctx.fill();
    }
    const total = this.results.reduce((s, r) => s + r.stars, 0);
    drawStar(W * 0.97 - H * 0.12, H * 0.055, H * 0.03, '#ffd23f'); text(String(total), W * 0.97 - H * 0.07, H * 0.057, H * 0.04, '#ffe14a', 'left');
  },
  drawCoachPanel(x, y, w, h, ex, label){
    this.panel(x, y, w, h, 0.28);
    const P = coachPose(ex.demo, sceneT, this.senior);
    ctx.save(); roundRect(x, y, w, h, H * 0.025); ctx.clip();
    drawCoach(x + w / 2, y + h * 0.9, Math.min(h * 0.72, w * 1.15), P, this.sty); ctx.restore();
    text(label, x + w / 2, y + h * 0.07, H * 0.028 * this.fs, '#d6defc', 'center', 700);
  },
  drawRest(){
    const ex = this.list[this.idx], left = Math.max(0, this.restLen - this.stateT), fs = this.fs, first = this.idx === 0;
    text(first ? 'Get ready!' : this.senior ? 'Rest and breathe' : 'Quick break!', W / 2, H * 0.09, H * 0.07 * fs, this.senior ? '#9be3d0' : '#ffd98a');
    const cw = Math.min(W * 0.3, H * 0.62); this.drawCoachPanel(W * 0.08, H * 0.17, cw, H * 0.68, ex, 'Next up');
    const rx = W * 0.08 + cw + W * 0.05;
    text(ex.name, rx, H * 0.27, H * 0.065 * fs, '#fff', 'left');
    this.wrap(ex.tip, rx, H * 0.37, W * 0.33, H * 0.036 * fs, '#d6defc');
    text(ex.time ? `Goal: ${ex.target} seconds` : `Goal: ${ex.target} ${ex.id === 'jacks' ? 'jumping jacks' : 'reps'}`, rx, H * 0.55, H * 0.04 * fs, '#ffe14a', 'left');
    if (ex.legs || (!this.legsOK && /knee|march/.test(ex.kind))) text(this.legsOK ? '' : 'Arms-only mode: I’ll count your movement', rx, H * 0.61, H * 0.026, '#ffd98a', 'left', 600);
    if (ex.id === 'balance') text('Hold on to a sturdy chair or wall!', rx, H * 0.61, H * 0.03 * fs, '#fff1c9', 'left', 700);
    text(FIT_TIPS[this.mode][this.tipI], rx, H * 0.7, H * 0.03 * fs, '#9be3d0', 'left', 600);
    const cx = W * 0.86, cy = H * 0.5, rr = H * 0.1, k = this.stateT / this.restLen;
    ctx.lineWidth = H * 0.02; ctx.strokeStyle = 'rgba(255,255,255,0.2)'; ctx.beginPath(); ctx.arc(cx, cy, rr, 0, TAU); ctx.stroke();
    ctx.strokeStyle = '#ffe14a'; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(cx, cy, rr, -Math.PI / 2, -Math.PI / 2 + TAU * k); ctx.stroke();
    text(String(Math.ceil(left)), cx, cy, H * 0.11, left < 3.2 ? '#ff9a6b' : '#fff');
    if (left < 3.2) text(left < 0.6 ? 'GO!' : 'Get set…', cx, cy + rr * 1.55, H * 0.04, '#ffb36b');
    drawMascot(cx, cy - rr * 1.9, H * 0.07, this.mode, sceneT, 0.3);
  },
  wrap(str, x, y, maxW, size, col){
    ctx.font = `600 ${Math.round(size)}px system-ui, sans-serif`; const words = str.split(' '); let line = '', yy = y;
    for (const w of words) { const test = line ? line + ' ' + w : w; if (ctx.measureText(test).width > maxW && line) { text(line, x, yy, size, col, 'left', 600); line = w; yy += size * 1.3; } else line = test; }
    if (line) text(line, x, yy, size, col, 'left', 600);
  },
  drawWork(now){
    const ex = this.cur, fs = this.fs, cheer = this.state === 'cheer';
    text(ex.name, W / 2, H * 0.065, H * 0.062 * fs, '#fff');
    this.wrap(ex.tip, W * 0.5 - W * 0.3, H * 0.125, W * 0.6, H * 0.027 * fs, '#d6defc');
    if (!cheer) { const k = clamp(this.workT / ex.cap, 0, 1); roundRect(W * 0.3, H * 0.15, W * 0.4, H * 0.008, H * 0.004); ctx.fillStyle = 'rgba(255,255,255,0.15)'; ctx.fill(); roundRect(W * 0.3, H * 0.15, Math.max(H * 0.008, W * 0.4 * (1 - k)), H * 0.008, H * 0.004); ctx.fillStyle = k > 0.8 ? '#ffb36b' : 'rgba(255,255,255,0.5)'; ctx.fill(); }
    this.drawCoachPanel(W * 0.03, H * 0.18, W * 0.22, H * 0.68, ex, 'Follow me!');
    const box = this.bodyBox(); this.drawPlayer(box);
    // beat ring (pulses with the music)
    const beat = (sceneT * this.bpm / 60) % 1;
    ctx.globalAlpha = 0.12 * (1 - beat); ctx.strokeStyle = '#fff'; ctx.lineWidth = H * 0.01; ctx.beginPath(); ctx.arc(box[0] + box[2] / 2, box[1] + box[3] / 2, box[2] * (0.5 + beat * 0.12), 0, TAU); ctx.stroke(); ctx.globalAlpha = 1;
    // counter ring
    const cx = W * 0.835, cy = H * 0.4, rr = H * 0.14 * (1 + this.ringPulse * 0.08), prog = clamp(this.reps / ex.target, 0, 1);
    ctx.lineWidth = H * 0.028; ctx.lineCap = 'round'; ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.beginPath(); ctx.arc(cx, cy, rr, 0, TAU); ctx.stroke();
    ctx.strokeStyle = prog >= 1 ? '#4fd27a' : this.senior ? '#9be3d0' : '#ffb36b'; ctx.beginPath(); ctx.arc(cx, cy, rr, -Math.PI / 2, -Math.PI / 2 + TAU * prog); ctx.stroke();
    if (this.ringPulse > 0) { ctx.globalAlpha = this.ringPulse * 0.5; ctx.strokeStyle = '#fff'; ctx.lineWidth = H * 0.01; ctx.beginPath(); ctx.arc(cx, cy, rr * (1.15 + (1 - this.ringPulse) * 0.2), 0, TAU); ctx.stroke(); ctx.globalAlpha = 1; }
    const shown = ex.time ? Math.floor(this.reps) : this.reps;
    text(String(shown), cx, cy - rr * 0.05, H * 0.13 * (1 + this.ringPulse * 0.12), '#fff');
    text(ex.time ? `of ${ex.target} seconds` : `of ${ex.target}`, cx, cy + rr * 0.62, H * 0.03 * fs, '#d6defc', 'center', 700);
    drawMascot(cx, H * 0.72, H * 0.075 * fs, this.mode, sceneT, this.joy);
    if (cheer) this.drawCheer();
  },
  drawCheer(){
    const ex = this.cur, ok = this.results.length && this.results[this.results.length - 1].done;
    ctx.fillStyle = 'rgba(6,8,30,0.55)'; ctx.fillRect(0, 0, W, H);
    text(ok ? (this.senior ? 'Well done!' : 'AWESOME!') : 'Good try!', W / 2, H * 0.3, H * 0.12 * (0.85 + 0.15 * Math.min(1, this.stateT * 5)), ok ? '#4fd27a' : '#ffd98a');
    text(ex.name, W / 2, H * 0.42, H * 0.04, '#d6defc', 'center', 600);
    for (let i = 0; i < 3; i++) {
      const on = i < this.stars, k = clamp((this.stateT - 0.5 - i * 0.25) * 4, 0, 1), sc = on ? (k < 1 ? 0.3 + 1.1 * k : 1.1 - 0.1 * Math.min(1, (this.stateT - 0.5 - i * 0.25 - 0.25) * 6)) : 1;
      drawStar(W / 2 + (i - 1) * H * 0.17, H * 0.58, H * 0.07 * sc * (on ? k : 1), '#ffd23f', on ? (k > 0.05 ? 1 : 0) : 0);
    }
  },
};

/* =====================================================================
   RESULTS
   ===================================================================== */
scenes.fitdone = {
  music:'menu', hint:'Great job! Hold a hand over a button',
  enter(d){
    this.d = d; this.parts = []; this.focus = 0;
    const key = 'mp-best-fit' + (d.mode === 'senior' ? 'senior' : 'kids'), prev = +store.get(key, 0);
    this.newBest = d.score > prev; store.set(key, Math.max(prev, d.score)); this.best = Math.max(prev, d.score);
    SFX.fanfare(); confetti(this.parts, 90);
    const r = i => () => { const w = Math.min(W * 0.22, H * 0.42), gap = W * 0.025; return [W / 2 - (w * 3 + gap * 2) / 2 + i * (w + gap), H * 0.84, w, H * 0.1]; };
    this.buttons = [
      HoverButton('Again', '', r(0), () => go('fit', { mode:d.mode, len:d.len }), '#4fd27a'),
      HoverButton('Workouts', '', r(1), () => go('fithub'), '#ffb36b'),
      HoverButton('Menu', '', r(2), () => go('menu'), '#5b8cff'),
    ];
  },
  keys(k){ if (k === 'ArrowLeft') this.focus = Math.max(0, this.focus - 1); if (k === 'ArrowRight') this.focus = Math.min(2, this.focus + 1); if (k === 'Enter') { SFX.select(); this.buttons[this.focus].action(); } },
  update(dt){
    this.parts = stepParts(this.parts, dt); if (Math.random() < dt * 1.5) confetti(this.parts, 3);
    this.buttons.forEach((b, i) => b.focus = I.kb.active && i === this.focus); updateButtons(this.buttons, dt, sceneT);
  },
  draw(){
    const d = this.d, senior = d.mode === 'senior', pct = d.stars / d.maxStars;
    fitBackground(d.mode, sceneT);
    text(pct >= 0.85 ? 'Champion!' : pct >= 0.5 ? 'Great workout!' : 'Nice effort!', W / 2, H * 0.1, H * 0.09, '#ffe14a');
    const n = Math.round(d.maxStars / 3);
    for (let i = 0; i < 3; i++) {   // overall medal stars
      const on = pct >= (i + 1) / 3 - 0.18, k = clamp((sceneT - 0.3 - i * 0.3) * 4, 0, 1);
      drawStar(W / 2 + (i - 1) * H * 0.15, H * 0.25, H * 0.065 * (on ? 0.3 + 0.7 * k : 1), '#ffd23f', on && k > 0.05 ? 1 : 0);
    }
    text(`${d.stars} of ${d.maxStars} stars   ·   ${d.reps} reps`, W / 2, H * 0.37, H * 0.045, '#fff');
    text(this.newBest ? '★ New personal best!' : `Best score: ${this.best}`, W / 2, H * 0.43, H * 0.032, this.newBest ? '#4fd27a' : '#d6defc', 'center', 700);
    // per-exercise rows
    const cols = d.results.length > 4 ? 2 : 1, rowH = H * 0.058, startY = H * 0.51;
    d.results.forEach((r, i) => {
      const col = cols === 2 ? i % 2 : 0, row = cols === 2 ? Math.floor(i / 2) : i, x = W / 2 + (cols === 2 ? (col ? 1 : -1) * W * 0.22 : 0) - W * 0.19, y = startY + row * rowH;
      text(r.ex.name, x, y, H * 0.03, r.done ? '#fff' : '#ffd98a', 'left', 700);
      for (let s = 0; s < 3; s++) drawStar(x + W * 0.3 + s * H * 0.045, y, H * 0.018, '#ffd23f', s < r.stars ? 1 : 0);
    });
    drawParts(this.parts);
    drawButtons(this.buttons);
    drawMascot(W * 0.12, H * 0.3, H * 0.09, d.mode, sceneT, 1); drawMascot(W * 0.88, H * 0.3, H * 0.09, d.mode, sceneT + 1, 1);
  }
};
