/* =====================================================================
   PENGUIN SLIDE — ART & SOUND: a lit, glossy penguin in a beanie and scarf, an icy groomed track with snow banks,
   low-poly mountain ranges, shaded snowy pines, crystal arches, and a full custom soundscape.
   Everything heavy is drawn once into small cached canvases, then stamped each frame.
   ===================================================================== */
const PU = 220;                       // penguin sprite resolution (px per lane-unit)
const PSPR = {};

function pGrad(g, x0, y0, x1, y1, stops){ const gr = g.createLinearGradient(x0, y0, x1, y1); stops.forEach(([k, c]) => gr.addColorStop(k, c)); return gr; }
function pRad(g, x0, y0, r0, x1, y1, r1, stops){ const gr = g.createRadialGradient(x0, y0, r0, x1, y1, r1); stops.forEach(([k, c]) => gr.addColorStop(k, c)); return gr; }
function pCanvas(w, h){ const c = document.createElement('canvas'); c.width = Math.ceil(w); c.height = Math.ceil(h); return c; }

/* ---------------- the penguin ---------------- */
// body sprite, seen from behind; origin (ox, oy) sits at the feet; 1 unit = PU px
function pPenguinSprite(col){
  const key = 'body' + col; if (PSPR[key]) return PSPR[key];
  const u = PU, c = pCanvas(u * 0.95, u * 1.08), g = c.getContext('2d'), ox = c.width / 2, oy = u * 0.97;
  g.translate(ox, oy); g.lineJoin = 'round'; g.lineCap = 'round';
  // feet (webbed, soles towards us)
  for (const sd of [-1, 1]) {
    g.save(); g.translate(sd * u * 0.12, -u * 0.02); g.rotate(sd * 0.25);
    g.fillStyle = pRad(g, -u * 0.02, -u * 0.03, 0, 0, 0, u * 0.12, [[0, '#ffc15a'], [0.6, '#ff8c1a'], [1, '#c45a00']]);
    g.beginPath(); g.moveTo(-u * 0.08, -u * 0.05); g.quadraticCurveTo(-u * 0.11, u * 0.05, -u * 0.06, u * 0.07); g.lineTo(u * 0.06, u * 0.07); g.quadraticCurveTo(u * 0.11, u * 0.05, u * 0.08, -u * 0.05); g.closePath(); g.fill();
    g.strokeStyle = 'rgba(120,50,0,0.6)'; g.lineWidth = u * 0.008; g.beginPath(); for (const x of [-0.03, 0.03]) { g.moveTo(x * u, -u * 0.03); g.lineTo(x * u * 1.4, u * 0.06); } g.stroke();
    g.restore();
  }
  // white belly peeking out at the sides
  g.fillStyle = pRad(g, -u * 0.1, -u * 0.3, u * 0.05, 0, -u * 0.22, u * 0.36, [[0, '#ffffff'], [0.7, '#e3f1ff'], [1, '#a9c6e6']]);
  g.beginPath(); g.ellipse(0, -u * 0.22, u * 0.335, u * 0.27, 0, 0, TAU); g.fill();
  // tail
  g.fillStyle = '#0f1322'; g.beginPath(); g.moveTo(-u * 0.07, -u * 0.04); g.lineTo(0, u * 0.04); g.lineTo(u * 0.07, -u * 0.04); g.closePath(); g.fill();
  // back: glossy black-blue egg
  g.fillStyle = pRad(g, -u * 0.12, -u * 0.42, u * 0.02, 0, -u * 0.28, u * 0.36, [[0, '#56658f'], [0.35, '#2a3250'], [0.8, '#141a2c'], [1, '#090c16']]);
  g.beginPath(); g.moveTo(0, -u * 0.6); g.bezierCurveTo(u * 0.23, -u * 0.6, u * 0.32, -u * 0.36, u * 0.3, -u * 0.18); g.bezierCurveTo(u * 0.28, -u * 0.04, u * 0.14, u * 0.0, 0, u * 0.0); g.bezierCurveTo(-u * 0.14, u * 0.0, -u * 0.28, -u * 0.04, -u * 0.3, -u * 0.18); g.bezierCurveTo(-u * 0.32, -u * 0.36, -u * 0.23, -u * 0.6, 0, -u * 0.6); g.fill();
  // rim light (cold sky light from the right) and a specular streak
  g.strokeStyle = pGrad(g, 0, -u * 0.6, 0, 0, [[0, 'rgba(170,220,255,0.0)'], [0.3, 'rgba(170,220,255,0.55)'], [1, 'rgba(170,220,255,0)']]); g.lineWidth = u * 0.016;
  g.beginPath(); g.moveTo(u * 0.12, -u * 0.57); g.bezierCurveTo(u * 0.28, -u * 0.5, u * 0.31, -u * 0.32, u * 0.29, -u * 0.16); g.stroke();
  g.fillStyle = 'rgba(255,255,255,0.16)'; g.beginPath(); g.ellipse(-u * 0.1, -u * 0.4, u * 0.06, u * 0.14, 0.35, 0, TAU); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.08)'; g.beginPath(); g.ellipse(-u * 0.13, -u * 0.27, u * 0.03, u * 0.08, 0.3, 0, TAU); g.fill();
  // feather texture
  g.strokeStyle = 'rgba(255,255,255,0.05)'; g.lineWidth = u * 0.006; for (let i = 0; i < 14; i++) { const x = (i / 13 - 0.5) * u * 0.42, y = -u * (0.12 + (i % 4) * 0.1); g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + u * 0.01, y + u * 0.03, x, y + u * 0.05); g.stroke(); }
  // scarf wrap (in player colour, with stripes)
  g.fillStyle = pGrad(g, -u * 0.2, 0, u * 0.2, 0, [[0, zShade(col, 0.25)], [0.5, col], [1, zShade(col, -0.45)]]);
  roundRect(-u * 0.2, -u * 0.53, u * 0.4, u * 0.1, u * 0.05, g); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.75)'; for (const x of [-0.12, -0.02, 0.08]) { g.save(); g.beginPath(); roundRect(-u * 0.2, -u * 0.53, u * 0.4, u * 0.1, u * 0.05, g); g.clip(); g.fillRect(x * u, -u * 0.54, u * 0.03, u * 0.12); g.restore(); }
  g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(-u * 0.19, -u * 0.445, u * 0.38, u * 0.012);
  // head
  const hy = -u * 0.66, hr = u * 0.17;
  for (const sd of [-1, 1]) { g.fillStyle = pRad(g, sd * u * 0.13, hy + u * 0.02, 0, sd * u * 0.13, hy + u * 0.02, u * 0.07, [[0, '#ffe680'], [0.6, '#ffb52e'], [1, 'rgba(255,170,40,0)']]); g.beginPath(); g.ellipse(sd * u * 0.135, hy + u * 0.03, u * 0.06, u * 0.075, sd * 0.3, 0, TAU); g.fill(); }
  g.fillStyle = pRad(g, -hr * 0.4, hy - hr * 0.4, hr * 0.1, 0, hy, hr * 1.1, [[0, '#56658f'], [0.45, '#262d48'], [1, '#090c16']]);
  g.beginPath(); g.arc(0, hy, hr, 0, TAU); g.fill();
  g.strokeStyle = 'rgba(170,220,255,0.45)'; g.lineWidth = u * 0.012; g.beginPath(); g.arc(0, hy, hr * 0.96, -0.6, 0.6); g.stroke();
  // beak tip peeking past the head
  g.fillStyle = '#ff9a1f'; g.beginPath(); g.moveTo(-u * 0.035, hy - hr * 0.88); g.lineTo(0, hy - hr * 1.12); g.lineTo(u * 0.035, hy - hr * 0.88); g.closePath(); g.fill();
  // goggle strap
  g.fillStyle = '#121624'; g.fillRect(-hr * 0.99, hy - hr * 0.02, hr * 1.98, hr * 0.26);
  g.fillStyle = col; g.fillRect(-hr * 0.99, hy + hr * 0.07, hr * 1.98, hr * 0.06);
  g.fillStyle = '#c9d4e8'; roundRect(-hr * 0.16, hy - hr * 0.02, hr * 0.32, hr * 0.26, hr * 0.06, g); g.fill();
  // beanie
  g.fillStyle = pRad(g, -hr * 0.4, hy - hr * 0.9, hr * 0.1, 0, hy - hr * 0.5, hr * 1.1, [[0, zShade(col, 0.35)], [0.5, col], [1, zShade(col, -0.5)]]);
  g.beginPath(); g.moveTo(-hr * 1.02, hy - hr * 0.2); g.bezierCurveTo(-hr * 1.05, hy - hr * 1.15, hr * 1.05, hy - hr * 1.15, hr * 1.02, hy - hr * 0.2); g.closePath(); g.fill();
  g.strokeStyle = 'rgba(0,0,0,0.18)'; g.lineWidth = u * 0.006; for (let i = -3; i <= 3; i++) { g.beginPath(); g.moveTo(i * hr * 0.26, hy - hr * 0.22); g.quadraticCurveTo(i * hr * 0.22, hy - hr * 0.7, i * hr * 0.12, hy - hr * 0.95); g.stroke(); }
  g.fillStyle = pGrad(g, 0, hy - hr * 0.42, 0, hy - hr * 0.1, [[0, '#ffffff'], [1, '#c9d9ee']]); roundRect(-hr * 1.06, hy - hr * 0.42, hr * 2.12, hr * 0.3, hr * 0.12, g); g.fill();
  g.strokeStyle = 'rgba(0,0,0,0.12)'; g.lineWidth = u * 0.005; for (let i = -6; i <= 6; i++) { g.beginPath(); g.moveTo(i * hr * 0.16, hy - hr * 0.4); g.lineTo(i * hr * 0.16, hy - hr * 0.14); g.stroke(); }
  return PSPR[key] = { c, ox, oy };
}
function pFlipperSprite(){
  if (PSPR.flip) return PSPR.flip;
  const u = PU, c = pCanvas(u * 0.2, u * 0.48), g = c.getContext('2d'), ox = c.width / 2, oy = u * 0.04;
  g.translate(ox, oy);
  g.fillStyle = pGrad(g, -u * 0.07, 0, u * 0.07, 0, [[0, '#4a5780'], [0.5, '#1c2238'], [1, '#090c16']]);
  g.beginPath(); g.moveTo(-u * 0.05, 0); g.bezierCurveTo(-u * 0.085, u * 0.15, -u * 0.06, u * 0.33, 0, u * 0.42); g.bezierCurveTo(u * 0.06, u * 0.33, u * 0.085, u * 0.15, u * 0.05, 0); g.closePath(); g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.55)'; g.lineWidth = u * 0.012; g.beginPath(); g.moveTo(u * 0.05, u * 0.02); g.bezierCurveTo(u * 0.08, u * 0.15, u * 0.06, u * 0.32, 0, u * 0.41); g.stroke();
  return PSPR.flip = { c, ox, oy };
}
function pSoftSprite(key, rgb){
  if (PSPR[key]) return PSPR[key];
  const c = pCanvas(64, 64), g = c.getContext('2d'); g.fillStyle = pRad(g, 32, 32, 0, 32, 32, 32, [[0, `rgba(${rgb},1)`], [0.45, `rgba(${rgb},0.55)`], [1, `rgba(${rgb},0)`]]); g.fillRect(0, 0, 64, 64);
  return PSPR[key] = c;
}

/* ---------------- scenery sprites ---------------- */
function pTreeSprite(Z, v){
  const key = 'tree' + Z.name + v; if (PSPR[key]) return PSPR[key];
  const u = 200, c = pCanvas(u * 1.1, u * 1.75), g = c.getContext('2d'), ox = c.width / 2, oy = c.height - u * 0.05, rnd = mulberry32(v * 97 + Z.name.length);
  g.translate(ox, oy);
  g.fillStyle = 'rgba(40,70,110,0.25)'; g.beginPath(); g.ellipse(0, 0, u * 0.42, u * 0.07, 0, 0, TAU); g.fill();
  g.fillStyle = pGrad(g, -u * 0.05, 0, u * 0.05, 0, [[0, '#8a5d34'], [1, '#3e2614']]); g.fillRect(-u * 0.05, -u * 0.3, u * 0.1, u * 0.3);
  const tiers = 4 + (v % 2), col = Z.tree;
  for (let i = 0; i < tiers; i++) {
    const k = i / tiers, w = u * (0.5 - k * 0.32) * (0.9 + rnd() * 0.15), y = -u * (0.22 + k * 1.15), th = u * 0.5;
    g.fillStyle = pGrad(g, -w, 0, w, 0, [[0, zShade(col, 0.22)], [0.45, col], [1, zShade(col, -0.5)]]);
    g.beginPath(); g.moveTo(-w, y); for (let j = 0; j <= 6; j++) g.lineTo(-w + j * w / 3, y + (j % 2 ? -u * 0.03 : u * 0.02)); g.lineTo(0, y - th); g.closePath(); g.fill();
    // snow load on each tier
    g.fillStyle = pGrad(g, 0, y - th, 0, y, [[0, '#ffffff'], [1, '#cfe3f7']]);
    g.beginPath(); g.moveTo(-w * 0.82, y - th * 0.3); g.quadraticCurveTo(-w * 0.4, y - th * 0.18, -w * 0.25, y - th * 0.28); g.quadraticCurveTo(0, y - th * 0.16, w * 0.3, y - th * 0.3); g.quadraticCurveTo(w * 0.55, y - th * 0.2, w * 0.82, y - th * 0.3); g.lineTo(0, y - th * 1.0); g.closePath(); g.fill();
    g.fillStyle = 'rgba(120,160,210,0.35)'; g.beginPath(); g.moveTo(w * 0.05, y - th * 0.95); g.lineTo(w * 0.82, y - th * 0.3); g.quadraticCurveTo(w * 0.55, y - th * 0.2, w * 0.3, y - th * 0.3); g.closePath(); g.fill();
  }
  return PSPR[key] = { c, ox, oy, u };
}
function pDecoSprite(kind, Z){
  const key = 'deco' + kind + (kind === 'crystal' ? Z.name : ''); if (PSPR[key]) return PSPR[key];
  const u = 200, c = pCanvas(u * 1.2, u * 1.4), g = c.getContext('2d'), ox = c.width / 2, oy = c.height - u * 0.06; g.translate(ox, oy); g.lineJoin = 'round';
  g.fillStyle = 'rgba(40,70,110,0.25)'; g.beginPath(); g.ellipse(0, 0, u * 0.45, u * 0.07, 0, 0, TAU); g.fill();
  if (kind === 'boulders') {
    for (const [x, r, h] of [[-0.18, 0.22, 0.3], [0.16, 0.18, 0.22], [0.02, 0.13, 0.42]]) {
      g.fillStyle = pRad(g, x * u - r * u * 0.4, -h * u * 0.6, 0, x * u, -h * u * 0.4, r * u * 1.3, [[0, '#a7b3c6'], [0.6, '#6b778d'], [1, '#353d4e']]);
      g.beginPath(); g.ellipse(x * u, -h * u * 0.45, r * u, h * u * 0.5, 0, Math.PI, 0); g.lineTo(x * u + r * u, 0); g.lineTo(x * u - r * u, 0); g.fill();
      g.fillStyle = pGrad(g, 0, -h * u, 0, -h * u * 0.6, [[0, '#ffffff'], [1, '#d2e5f7']]); g.beginPath(); g.ellipse(x * u, -h * u * 0.86, r * u * 0.85, h * u * 0.16, 0, Math.PI, 0); g.quadraticCurveTo(x * u, -h * u * 0.72, x * u - r * u * 0.85, -h * u * 0.86); g.fill();
    }
  } else if (kind === 'flagR' || kind === 'flagB') {
    const fc = kind === 'flagR' ? '#ff3b4e' : '#2f7cf6';
    g.fillStyle = pGrad(g, -u * 0.012, 0, u * 0.012, 0, [[0, '#ffffff'], [1, '#9aa6b8']]); g.fillRect(-u * 0.012, -u * 1.05, u * 0.024, u * 1.05);
    for (let i = 0; i < 5; i++) { g.fillStyle = i % 2 ? '#fff' : fc; g.fillRect(-u * 0.012, -u * (0.2 + i * 0.12), u * 0.024, u * 0.06); }
    g.fillStyle = pGrad(g, 0, -u * 1.0, u * 0.3, -u * 0.8, [[0, zShade(fc, 0.3)], [1, zShade(fc, -0.35)]]); g.beginPath(); g.moveTo(u * 0.012, -u * 1.02); g.quadraticCurveTo(u * 0.18, -u * 0.98, u * 0.32, -u * 0.9); g.quadraticCurveTo(u * 0.18, -u * 0.84, u * 0.012, -u * 0.76); g.closePath(); g.fill();
    g.fillStyle = '#fff'; g.beginPath(); g.ellipse(0, -u * 0.02, u * 0.08, u * 0.025, 0, 0, TAU); g.fill();
  } else if (kind === 'crystal') {
    const glow = Z.stars ? '170,140,255' : '120,220,255';
    g.fillStyle = pRad(g, 0, -u * 0.35, 0, 0, -u * 0.35, u * 0.55, [[0, `rgba(${glow},0.45)`], [1, `rgba(${glow},0)`]]); g.fillRect(-u * 0.6, -u * 0.95, u * 1.2, u * 1.0);
    for (const [x, h, w, a] of [[-0.14, 0.55, 0.09, -0.35], [0.0, 0.85, 0.12, 0.0], [0.14, 0.62, 0.09, 0.3], [-0.26, 0.3, 0.06, -0.6], [0.26, 0.34, 0.06, 0.6]]) {
      g.save(); g.translate(x * u, 0); g.rotate(a); const hh = h * u, ww = w * u;
      g.fillStyle = pGrad(g, -ww, 0, ww, 0, [[0, 'rgba(240,252,255,0.95)'], [0.5, `rgba(${glow},0.85)`], [1, 'rgba(40,90,170,0.9)']]);
      g.beginPath(); g.moveTo(-ww, 0); g.lineTo(-ww, -hh * 0.75); g.lineTo(0, -hh); g.lineTo(ww, -hh * 0.75); g.lineTo(ww, 0); g.closePath(); g.fill();
      g.fillStyle = 'rgba(255,255,255,0.5)'; g.beginPath(); g.moveTo(-ww * 0.6, -hh * 0.1); g.lineTo(-ww * 0.6, -hh * 0.72); g.lineTo(-ww * 0.1, -hh * 0.9); g.lineTo(-ww * 0.1, -hh * 0.1); g.closePath(); g.fill();
      g.restore();
    }
  } else {   // igloo
    g.fillStyle = pRad(g, -u * 0.15, -u * 0.35, u * 0.05, 0, -u * 0.1, u * 0.5, [[0, '#ffffff'], [0.7, '#d6e8f8'], [1, '#93b5d8']]);
    g.beginPath(); g.ellipse(0, 0, u * 0.42, u * 0.4, 0, Math.PI, 0); g.closePath(); g.fill();
    g.strokeStyle = 'rgba(110,150,200,0.55)'; g.lineWidth = u * 0.008;
    for (let i = 1; i < 4; i++) { const yy = -u * 0.1 * i, w = Math.sqrt(1 - Math.pow(yy / (u * 0.4), 2)) * u * 0.42; g.beginPath(); g.moveTo(-w, yy); g.lineTo(w, yy); g.stroke(); for (let j = -3; j <= 3; j++) { const xx = (j + (i % 2) * 0.5) * u * 0.12; if (Math.abs(xx) < w) { g.beginPath(); g.moveTo(xx, yy); g.lineTo(xx, yy + u * 0.1); g.stroke(); } } }
    g.fillStyle = pRad(g, 0, -u * 0.08, 0, 0, -u * 0.05, u * 0.2, [[0, '#ffcf6a'], [0.6, '#b8642a'], [1, '#3a2010']]); g.beginPath(); g.ellipse(0, 0, u * 0.13, u * 0.17, 0, Math.PI, 0); g.closePath(); g.fill();
  }
  return PSPR[key] = { c, ox, oy, u };
}

/* ---------------- obstacles ---------------- */
function pRockSprite(){
  if (PSPR.rock) return PSPR.rock;
  const u = 200, c = pCanvas(u * 1.0, u * 0.62), g = c.getContext('2d'), ox = c.width / 2, oy = c.height - u * 0.06; g.translate(ox, oy); g.lineJoin = 'round';
  g.fillStyle = 'rgba(30,60,100,0.3)'; g.beginPath(); g.ellipse(0, 0, u * 0.46, u * 0.08, 0, 0, TAU); g.fill();
  const pts = [[-0.42, 0], [-0.4, -0.16], [-0.28, -0.3], [-0.08, -0.38], [0.12, -0.36], [0.3, -0.28], [0.41, -0.12], [0.43, 0]];
  g.fillStyle = pRad(g, -u * 0.15, -u * 0.3, u * 0.02, 0, -u * 0.12, u * 0.5, [[0, '#b9c4d6'], [0.5, '#717d93'], [1, '#2e3545']]);
  g.beginPath(); pts.forEach(([x, y], i) => i ? g.lineTo(x * u, y * u) : g.moveTo(x * u, y * u)); g.closePath(); g.fill();
  // facets
  g.fillStyle = 'rgba(0,0,0,0.22)'; g.beginPath(); g.moveTo(0.12 * u, -0.36 * u); g.lineTo(0.3 * u, -0.28 * u); g.lineTo(0.41 * u, -0.12 * u); g.lineTo(0.43 * u, 0); g.lineTo(0.15 * u, 0); g.lineTo(0.05 * u, -0.18 * u); g.closePath(); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.12)'; g.beginPath(); g.moveTo(-0.28 * u, -0.3 * u); g.lineTo(-0.08 * u, -0.38 * u); g.lineTo(-0.02 * u, -0.2 * u); g.lineTo(-0.25 * u, -0.12 * u); g.closePath(); g.fill();
  g.strokeStyle = 'rgba(30,35,50,0.6)'; g.lineWidth = u * 0.01; g.beginPath(); g.moveTo(-0.05 * u, -0.37 * u); g.lineTo(0.0, -0.22 * u); g.lineTo(-0.06 * u, -0.08 * u); g.moveTo(0.22 * u, -0.3 * u); g.lineTo(0.18 * u, -0.15 * u); g.stroke();
  // snow cap + icicles
  g.fillStyle = pGrad(g, 0, -0.42 * u, 0, -0.22 * u, [[0, '#ffffff'], [1, '#cfe2f6']]);
  g.beginPath(); g.moveTo(-0.33 * u, -0.25 * u); g.quadraticCurveTo(-0.2 * u, -0.43 * u, -0.05 * u, -0.41 * u); g.quadraticCurveTo(0.2 * u, -0.42 * u, 0.33 * u, -0.25 * u); g.quadraticCurveTo(0.2 * u, -0.27 * u, 0.12 * u, -0.22 * u); g.quadraticCurveTo(0, -0.28 * u, -0.12 * u, -0.22 * u); g.quadraticCurveTo(-0.22 * u, -0.27 * u, -0.33 * u, -0.25 * u); g.fill();
  g.fillStyle = 'rgba(210,240,255,0.9)'; for (const x of [-0.24, -0.15, 0.06, 0.2]) { g.beginPath(); g.moveTo(x * u - u * 0.015, -0.24 * u); g.lineTo(x * u + u * 0.015, -0.24 * u); g.lineTo(x * u, -0.15 * u); g.closePath(); g.fill(); }
  return PSPR.rock = { c, ox, oy, u };
}
function pArchSprite(){
  if (PSPR.arch) return PSPR.arch;
  const u = 200, top = 1.55, lo = 0.95, c = pCanvas(u * 1.35, u * 1.75), g = c.getContext('2d'), ox = c.width / 2, oy = c.height - u * 0.06; g.translate(ox, oy); g.lineJoin = 'round';
  g.fillStyle = 'rgba(30,60,100,0.25)'; g.beginPath(); g.ellipse(0, 0, u * 0.62, u * 0.08, 0, 0, TAU); g.fill();
  const ice = (x0, x1) => pGrad(g, x0, 0, x1, 0, [[0, 'rgba(235,250,255,0.95)'], [0.35, 'rgba(150,215,250,0.88)'], [1, 'rgba(60,130,200,0.92)']]);
  // pillars
  for (const [x0, w] of [[-0.54, 0.16], [0.38, 0.16]]) { g.fillStyle = ice(x0 * u, (x0 + w) * u); g.beginPath(); g.moveTo(x0 * u, 0); g.lineTo((x0 + 0.02) * u, -top * u); g.lineTo((x0 + w - 0.02) * u, -top * u); g.lineTo((x0 + w) * u, 0); g.closePath(); g.fill(); g.fillStyle = 'rgba(255,255,255,0.45)'; g.fillRect((x0 + 0.025) * u, -top * u, 0.03 * u, top * u); }
  // lintel slab
  g.fillStyle = pGrad(g, 0, -top * u, 0, -lo * u, [[0, 'rgba(240,252,255,0.97)'], [0.5, 'rgba(160,220,252,0.92)'], [1, 'rgba(80,150,215,0.95)']]);
  roundRect(-0.6 * u, -top * u - 0.04 * u, 1.2 * u, (top - lo) * u + 0.04 * u, 0.06 * u, g); g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.8)'; g.lineWidth = u * 0.012; g.beginPath(); g.moveTo(-0.55 * u, -top * u - 0.02 * u); g.lineTo(0.5 * u, -top * u - 0.02 * u); g.stroke();
  g.strokeStyle = 'rgba(40,110,180,0.45)'; g.lineWidth = u * 0.006; g.beginPath(); g.moveTo(-0.3 * u, -top * u + 0.05 * u); g.lineTo(-0.18 * u, -top * u + 0.3 * u); g.lineTo(-0.05 * u, -top * u + 0.22 * u); g.moveTo(0.25 * u, -top * u + 0.08 * u); g.lineTo(0.3 * u, -top * u + 0.4 * u); g.stroke();
  // snow on top
  g.fillStyle = pGrad(g, 0, -top * u - 0.12 * u, 0, -top * u, [[0, '#ffffff'], [1, '#d9eaf9']]); g.beginPath(); g.moveTo(-0.62 * u, -top * u - 0.02 * u); g.quadraticCurveTo(-0.3 * u, -top * u - 0.16 * u, 0, -top * u - 0.1 * u); g.quadraticCurveTo(0.3 * u, -top * u - 0.17 * u, 0.62 * u, -top * u - 0.02 * u); g.closePath(); g.fill();
  // icicles hanging under the lintel (the "duck" cue)
  for (let i = 0; i < 9; i++) { const x = (-0.42 + i * 0.105) * u, l = (0.12 + ((i * 7) % 4) * 0.04) * u; g.fillStyle = pGrad(g, 0, -lo * u, 0, -lo * u + l, [[0, 'rgba(220,245,255,0.95)'], [1, 'rgba(140,210,250,0.6)']]); g.beginPath(); g.moveTo(x - 0.025 * u, -lo * u); g.lineTo(x + 0.025 * u, -lo * u); g.lineTo(x, -lo * u + l); g.closePath(); g.fill(); }
  return PSPR.arch = { c, ox, oy, u };
}
function pSnowmanSprite(){
  if (PSPR.snowman) return PSPR.snowman;
  const u = 200, c = pCanvas(u * 1.1, u * 1.75), g = c.getContext('2d'), ox = c.width / 2, oy = c.height - u * 0.05; g.translate(ox, oy); g.lineJoin = 'round'; g.lineCap = 'round';
  g.fillStyle = 'rgba(30,60,100,0.25)'; g.beginPath(); g.ellipse(0, 0, u * 0.4, u * 0.08, 0, 0, TAU); g.fill();
  const ball = (y, r) => { g.fillStyle = pRad(g, -r * 0.35, y - r * 0.4, r * 0.05, 0, y, r * 1.05, [[0, '#ffffff'], [0.6, '#e6f1fb'], [1, '#9db9d6']]); g.beginPath(); g.arc(0, y, r, 0, TAU); g.fill(); };
  // stick arms (raised, menacing)
  g.strokeStyle = '#5a3a1e'; g.lineWidth = u * 0.025; for (const sd of [-1, 1]) { g.beginPath(); g.moveTo(sd * u * 0.18, -u * 0.8); g.lineTo(sd * u * 0.45, -u * 1.08); g.moveTo(sd * u * 0.37, -u * 0.98); g.lineTo(sd * u * 0.48, -u * 0.95); g.moveTo(sd * u * 0.41, -u * 1.03); g.lineTo(sd * u * 0.4, -u * 1.15); g.stroke(); }
  ball(-u * 0.28, u * 0.3); ball(-u * 0.78, u * 0.22); ball(-u * 1.15, u * 0.16);
  g.fillStyle = '#1b1b22'; for (const y of [-0.7, -0.8, -0.9]) { g.beginPath(); g.arc(0, y * u, u * 0.02, 0, TAU); g.fill(); }
  // scarf
  g.fillStyle = pGrad(g, -u * 0.16, 0, u * 0.16, 0, [[0, '#ff6b7a'], [1, '#a5122b']]); roundRect(-u * 0.16, -u * 1.02, u * 0.32, u * 0.07, u * 0.03, g); g.fill(); g.fillRect(u * 0.06, -u * 1.0, u * 0.06, u * 0.18);
  // angry face
  g.fillStyle = '#16161c'; g.beginPath(); g.arc(-u * 0.055, -u * 1.18, u * 0.02, 0, TAU); g.arc(u * 0.055, -u * 1.18, u * 0.02, 0, TAU); g.fill();
  g.strokeStyle = '#16161c'; g.lineWidth = u * 0.014; g.beginPath(); g.moveTo(-u * 0.1, -u * 1.24); g.lineTo(-u * 0.03, -u * 1.21); g.moveTo(u * 0.1, -u * 1.24); g.lineTo(u * 0.03, -u * 1.21); g.stroke();
  for (let i = 0; i < 5; i++) { g.fillStyle = '#16161c'; g.beginPath(); g.arc(-u * 0.06 + i * u * 0.03, -u * 1.07 + Math.abs(i - 2) * -u * 0.008, u * 0.009, 0, TAU); g.fill(); }
  g.fillStyle = pGrad(g, 0, -u * 1.16, u * 0.2, -u * 1.12, [[0, '#ffb04a'], [1, '#d4600a']]); g.beginPath(); g.moveTo(0, -u * 1.16); g.lineTo(u * 0.22, -u * 1.12); g.lineTo(0, -u * 1.1); g.closePath(); g.fill();
  // top hat
  g.fillStyle = pGrad(g, -u * 0.13, 0, u * 0.13, 0, [[0, '#3a3a48'], [1, '#08080c']]); g.fillRect(-u * 0.13, -u * 1.48, u * 0.26, u * 0.18); g.fillRect(-u * 0.2, -u * 1.31, u * 0.4, u * 0.035);
  g.fillStyle = '#d6264a'; g.fillRect(-u * 0.13, -u * 1.36, u * 0.26, u * 0.035);
  return PSPR.snowman = { c, ox, oy, u };
}
function pFishSprite(){
  if (PSPR.fish) return PSPR.fish;
  const u = 120, c = pCanvas(u * 0.8, u * 0.4), g = c.getContext('2d'), ox = c.width / 2, oy = c.height / 2; g.translate(ox, oy);
  g.fillStyle = pGrad(g, 0, -u * 0.1, 0, u * 0.1, [[0, '#5fd6ff'], [0.5, '#c9f3ff'], [1, '#2a8fc7']]);
  g.beginPath(); g.moveTo(-u * 0.25, 0); g.bezierCurveTo(-u * 0.15, -u * 0.13, u * 0.1, -u * 0.13, u * 0.18, 0); g.bezierCurveTo(u * 0.1, u * 0.13, -u * 0.15, u * 0.13, -u * 0.25, 0); g.fill();
  g.beginPath(); g.moveTo(u * 0.16, 0); g.lineTo(u * 0.33, -u * 0.11); g.quadraticCurveTo(u * 0.28, 0, u * 0.33, u * 0.11); g.closePath(); g.fill();
  g.fillStyle = 'rgba(40,120,180,0.6)'; g.beginPath(); g.moveTo(-u * 0.02, -u * 0.08); g.lineTo(u * 0.08, -u * 0.15); g.lineTo(u * 0.1, -u * 0.07); g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.4)'; g.lineWidth = 1.2; for (let i = 0; i < 5; i++) { g.beginPath(); g.arc(-u * 0.05 + i * u * 0.04, 0, u * 0.03, -0.9, 0.9); g.stroke(); }
  g.fillStyle = '#fff'; g.beginPath(); g.arc(-u * 0.16, -u * 0.02, u * 0.03, 0, TAU); g.fill(); g.fillStyle = '#0a1a2a'; g.beginPath(); g.arc(-u * 0.165, -u * 0.02, u * 0.016, 0, TAU); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.75)'; g.beginPath(); g.ellipse(-u * 0.05, -u * 0.06, u * 0.1, u * 0.018, -0.1, 0, TAU); g.fill();
  return PSPR.fish = { c, ox, oy, u };
}

/* ---------------- zone backdrops ---------------- */
function pSkyLayer(i){
  const Z = PZONES[i], HOR = H * 0.36;
  return cachedLayer('psky' + i, g => {
    const rnd = mulberry32(i * 131 + 7);
    g.fillStyle = pGrad(g, 0, 0, 0, HOR + 2, [[0, Z.sky[0]], [0.7, zMix(Z.sky[0], Z.sky[1], 0.6)], [1, Z.sky[1]]]); g.fillRect(0, 0, W, HOR + 4);
    if (Z.stars) for (let n = 0; n < 140; n++) { g.fillStyle = `rgba(255,255,255,${0.3 + rnd() * 0.7})`; g.beginPath(); g.arc(rnd() * W, rnd() * HOR * 0.85, rnd() * 1.6 + 0.3, 0, TAU); g.fill(); }
    // sun / moon
    const sx = W * 0.78, sy = HOR * 0.34, sr = H * 0.05;
    g.fillStyle = pRad(g, sx, sy, sr * 0.5, sx, sy, sr * 6, [[0, Z.sun + 'cc'], [0.25, Z.sun + '44'], [1, Z.sun + '00']]); g.fillRect(sx - sr * 6, sy - sr * 6, sr * 12, sr * 12);
    g.fillStyle = pRad(g, sx - sr * 0.3, sy - sr * 0.3, 0, sx, sy, sr, [[0, '#ffffff'], [1, Z.sun]]); g.beginPath(); g.arc(sx, sy, sr, 0, TAU); g.fill();
    if (Z.stars) { g.fillStyle = 'rgba(120,120,160,0.25)'; for (let k = 0; k < 5; k++) { g.beginPath(); g.arc(sx + (rnd() - 0.5) * sr * 1.2, sy + (rnd() - 0.5) * sr * 1.2, sr * (0.1 + rnd() * 0.15), 0, TAU); g.fill(); } }
    // three low-poly mountain ranges, lit from the sun side, with snow caps
    const ranges = [[0.3, 0.17, Z.mount[0], 0.55, 7], [0.2, 0.1, Z.mount[1], 0.75, 10], [0.12, 0.05, zShade(Z.mount[1], -0.12), 0.95, 14]];
    for (const [amp, base, col, haze, n] of ranges) {
      const peaks = []; for (let k = 0; k <= n; k++) peaks.push([(k + (rnd() - 0.5) * 0.6) / n * W, HOR - (base + rnd() * amp) * HOR]);
      g.fillStyle = col; g.beginPath(); g.moveTo(0, HOR + 2); peaks.forEach(([x, y], k) => { if (k) { const [px, py] = peaks[k - 1]; g.lineTo((px + x) / 2, Math.max(py, y) + (HOR - Math.max(py, y)) * 0.35); } g.lineTo(x, y); }); g.lineTo(W, HOR + 2); g.closePath(); g.fill();
      for (let k = 0; k < peaks.length; k++) {
        const [x, y] = peaks[k], hgt = HOR - y, w = hgt * 0.9;
        g.fillStyle = 'rgba(0,10,40,0.22)'; g.beginPath(); g.moveTo(x, y); g.lineTo(x + w * 0.9, HOR); g.lineTo(x + w * 0.1, HOR); g.closePath(); g.fill();          // shaded east face
        const cap = 0.36; g.fillStyle = pGrad(g, x - w * cap, y, x + w * cap, y, [[0, '#ffffff'], [0.55, '#f2f8ff'], [1, '#b9cde6']]);
        g.beginPath(); g.moveTo(x, y); g.lineTo(x + w * cap, y + hgt * cap); g.lineTo(x + w * cap * 0.5, y + hgt * cap * 0.8); g.lineTo(x + w * cap * 0.1, y + hgt * cap * 1.1); g.lineTo(x - w * cap * 0.3, y + hgt * cap * 0.85); g.lineTo(x - w * cap * 0.7, y + hgt * cap * 1.05); g.lineTo(x - w * cap, y + hgt * cap); g.closePath(); g.fill();
      }
      g.fillStyle = pGrad(g, 0, HOR - amp * HOR, 0, HOR, [[0, zMix(Z.sky[1], '#ffffff', 0.2).replace('rgb', 'rgba').replace(')', ',0)')], [1, zMix(Z.sky[1], '#ffffff', 0.2).replace('rgb', 'rgba').replace(')', `,${0.55 * haze})`)]]); g.fillRect(0, HOR - (base + amp) * HOR, W, (base + amp) * HOR + 2);
    }
    // distant pine belt on the horizon
    g.fillStyle = zShade(Z.tree, -0.25); for (let x = 0; x < W; x += H * 0.009) { const h = H * (0.012 + rnd() * 0.02); g.beginPath(); g.moveTo(x - h * 0.35, HOR + 2); g.lineTo(x, HOR - h); g.lineTo(x + h * 0.35, HOR + 2); g.fill(); }
    // snowfield below the horizon
    g.fillStyle = pGrad(g, 0, HOR, 0, H, [[0, Z.snow[1]], [0.4, zMix(Z.snow[1], Z.snow[0], 0.5)], [1, Z.snow[0]]]); g.fillRect(0, HOR, W, H - HOR);
    g.fillStyle = 'rgba(120,160,210,0.12)'; for (let k = 0; k < 40; k++) { const y = HOR + (H - HOR) * Math.pow(rnd(), 1.3), w = W * (0.05 + rnd() * 0.15); g.beginPath(); g.ellipse(rnd() * W, y, w, w * 0.04, 0, 0, TAU); g.fill(); }
  });
}
function pCloudTile(i){
  const Z = PZONES[i];
  return cachedLayer('pcl' + i, g => {
    const h = H * 0.3; g.canvas.height = h | 0; const rnd = mulberry32(i * 53 + 1), col = Z.stars ? '120,130,200' : '255,255,255', a0 = Z.stars ? 0.18 : 0.75;
    for (let k = 0; k < 9; k++) { const x = rnd() * W, y = h * (0.2 + rnd() * 0.5), rx = W * (0.07 + rnd() * 0.09);
      for (const off of [0, -W, W]) { if (x + off < -rx * 2 || x + off > W + rx * 2) continue;
        for (let b = 0; b < 5; b++) { const bx = x + off + (b - 2) * rx * 0.45, by = y - Math.sin(b / 4 * Math.PI) * rx * 0.25, br = rx * (0.35 + Math.sin(b / 4 * Math.PI) * 0.25); g.fillStyle = pRad(g, bx - br * 0.2, by - br * 0.3, br * 0.1, bx, by, br, [[0, `rgba(${col},${a0})`], [0.7, `rgba(${col},${a0 * 0.6})`], [1, `rgba(${col},0)`]]); g.beginPath(); g.arc(bx, by, br, 0, TAU); g.fill(); } } }
  });
}
function pCaveOverlay(){
  return cachedLayer('pcave', g => {
    const rnd = mulberry32(999);
    for (let x = -10; x < W + 10; x += H * 0.02 + rnd() * H * 0.03) {
      const l = H * (0.04 + rnd() * 0.14 * (Math.abs(x - W / 2) / (W / 2) + 0.2)), w = H * (0.012 + rnd() * 0.02);
      g.fillStyle = pGrad(g, x - w, 0, x + w, 0, [[0, 'rgba(230,250,255,0.95)'], [0.5, 'rgba(140,210,250,0.85)'], [1, 'rgba(40,100,170,0.9)']]); g.beginPath(); g.moveTo(x - w, 0); g.lineTo(x + w, 0); g.lineTo(x, l); g.closePath(); g.fill();
    }
    g.fillStyle = pGrad(g, 0, 0, 0, H * 0.06, [[0, 'rgba(200,235,255,0.9)'], [1, 'rgba(200,235,255,0)']]); g.fillRect(0, 0, W, H * 0.06);
  });
}
function pFrostOverlay(){
  return cachedLayer('pfrost', g => {
    g.fillStyle = pRad(g, W / 2, H * 0.55, H * 0.4, W / 2, H * 0.55, W * 0.75, [[0, 'rgba(10,30,70,0)'], [0.75, 'rgba(10,30,70,0.18)'], [1, 'rgba(5,15,45,0.5)']]); g.fillRect(0, 0, W, H);
    const rnd = mulberry32(31);
    for (const [cx, cy] of [[0, 0], [W, 0], [0, H], [W, H]]) {
      g.fillStyle = pRad(g, cx, cy, 0, cx, cy, H * 0.35, [[0, 'rgba(235,248,255,0.55)'], [1, 'rgba(235,248,255,0)']]); g.fillRect(cx - H * 0.35, cy - H * 0.35, H * 0.7, H * 0.7);
      g.strokeStyle = 'rgba(255,255,255,0.35)'; g.lineWidth = 1.3;
      const branch = (x, y, a, l, d) => { const nx = x + Math.cos(a) * l, ny = y + Math.sin(a) * l; g.beginPath(); g.moveTo(x, y); g.lineTo(nx, ny); g.stroke(); if (d > 0) { branch(nx, ny, a + 0.6, l * 0.55, d - 1); branch(nx, ny, a - 0.6, l * 0.55, d - 1); branch(nx, ny, a, l * 0.7, d - 1); } };
      const base = Math.atan2(H / 2 - cy, W / 2 - cx); for (let k = 0; k < 5; k++) branch(cx, cy, base + (rnd() - 0.5) * 1.4, H * (0.05 + rnd() * 0.06), 3);
    }
  });
}
function pCrackOverlay(){
  return cachedLayer('pcrack', g => {
    const rnd = mulberry32(5); g.strokeStyle = 'rgba(230,250,255,0.9)'; g.lineCap = 'round';
    const cx = W * 0.5, cy = H * 0.55;
    for (let k = 0; k < 11; k++) { let x = cx, y = cy, a = k / 11 * TAU + rnd() * 0.3; g.lineWidth = 3; g.beginPath(); g.moveTo(x, y); for (let j = 0; j < 7; j++) { a += (rnd() - 0.5) * 0.5; x += Math.cos(a) * H * 0.07; y += Math.sin(a) * H * 0.07; g.lineTo(x, y); } g.stroke(); }
    g.lineWidth = 1.5; g.beginPath(); for (let r = 1; r <= 3; r++) { for (let k = 0; k <= 11; k++) { const a = k / 11 * TAU, rr = H * 0.08 * r * (0.85 + rnd() * 0.3); k ? g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr) : g.moveTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr); } } g.stroke();
  });
}

/* ======================= SOUND ======================= */
const pSnd = {
  // a cute squawk: a high, wobbly voice
  squawk(f = 620, d = 0.22, v = 0.05){ zVoice(f, d, v, { to:f * 0.75, a1:1300, b1:1000, a2:2500, b2:2100, vr:22, vd:0.05, rasp:0.25, rf:3000, att:0.015 }); },
  lane(dir){ zNoiseBurst(0.22, 0.13, 'bandpass', 1400, { to:4200, q:1.6, att:0.01, pan:dir * 0.6 }); zNoiseBurst(0.12, 0.05, 'highpass', 6000, { att:0.005, pan:dir * 0.6, delay:0.03 }); },
  jump(){ zTone(300, 0.32, 'sine', 0.13, { to:900, att:0.005 }); zNoiseBurst(0.3, 0.08, 'bandpass', 900, { to:2600, q:1, att:0.02 }); pSnd.squawk(760, 0.18, 0.045); },
  land(){ zNoiseBurst(0.18, 0.2, 'lowpass', 900, { att:0.003 }); zTone(120, 0.14, 'sine', 0.14, { to:60, att:0.002 }); zNoiseBurst(0.25, 0.08, 'highpass', 3500, { att:0.01, delay:0.02 }); },
  duck(){ zNoiseBurst(0.3, 0.1, 'bandpass', 2400, { to:700, q:1.2, att:0.01 }); zTone(500, 0.2, 'triangle', 0.04, { to:250 }); },
  fish(n){ const base = 880 * Math.pow(2, (n % 8) / 12 * 2); zTone(base, 0.14, 'triangle', 0.07, { att:0.003 }); zTone(base * 1.5, 0.18, 'sine', 0.05, { delay:0.05, att:0.003 }); zTone(base * 2, 0.22, 'sine', 0.025, { delay:0.1, att:0.003 }); zNoiseBurst(0.12, 0.03, 'highpass', 7000, { att:0.002 }); },
  dash(){ for (let i = 0; i < 6; i++) zNoiseBurst(0.07, 0.1, 'bandpass', 600, { delay:i * 0.06, q:1.5, att:0.004 }); zNoiseBurst(0.9, 0.16, 'bandpass', 500, { to:3000, q:0.8, att:0.08 }); zTone(200, 0.7, 'sawtooth', 0.05, { to:700, filt:['lowpass', 1600, 1], att:0.05 }); pSnd.squawk(900, 0.3, 0.06); },
  smash(){ zNoiseBurst(0.5, 0.35, 'lowpass', 1600, { to:300, att:0.002 }); zTone(90, 0.3, 'sine', 0.2, { to:40, att:0.002 }); zNoiseBurst(0.35, 0.12, 'highpass', 4000, { att:0.002, delay:0.03 }); zTone(1200, 0.08, 'square', 0.03, { to:300, delay:0.05 }); },
  hit(){ zNoiseBurst(0.35, 0.3, 'lowpass', 700, { att:0.002 }); zTone(110, 0.3, 'sine', 0.2, { to:45, att:0.002 }); zNoiseBurst(0.25, 0.18, 'highpass', 2500, { att:0.002 }); for (let i = 0; i < 4; i++) zTone(rand(2500, 4500), 0.1, 'sine', 0.02, { delay:0.03 + i * 0.03, to:1500 }); pSnd.squawk(520, 0.35, 0.07); },
  zone(){ [0, 4, 7, 12, 16].forEach((s, i) => zTone(660 * Math.pow(2, s / 12), 0.8, 'sine', 0.035, { delay:i * 0.08, att:0.01 })); zNoiseBurst(1.6, 0.06, 'bandpass', 500, { to:1500, att:0.6 }); },
  // ambience one-shots per zone
  amb(zone){
    if (zone === 0) { if (Math.random() < 0.5) { const p = rand(-0.8, 0.8), f = rand(2600, 3400); for (let i = 0; i < 3; i++) zTone(f, 0.08, 'sine', 0.015, { path:[[0.5, f * 1.2], [1, f * 0.9]], delay:i * 0.12, pan:p }); } else zNoiseBurst(3, 0.05, 'bandpass', 400, { to:1000, att:1.2, q:1.2, pan:rand(-0.7, 0.7) }); }
    else if (zone === 1) { const p = rand(-0.8, 0.8); for (let i = 0; i < 2 + (Math.random() * 3 | 0); i++) { const f = rand(1400, 2600); zTone(f, 0.25, 'sine', 0.035, { to:f * 1.6, delay:i * rand(0.3, 0.9), att:0.002, pan:p }); zTone(f * 0.5, 0.6, 'sine', 0.01, { delay:i * 0.5 + 0.15, att:0.01, pan:-p }); } }
    else { const root = pick([220, 247, 262, 196]); [1, 1.25, 1.5, 2].forEach((m, i) => zTone(root * m, 3.5, 'sine', 0.014, { att:1.4, delay:i * 0.2, vib:[2, 0.5 + i * 0.2] })); }
  },
};

// continuous slide hiss + wind, driven every frame by speed / air time / dash
function pSlideLoop(sc, on){
  if (!audioOk() || !noiseBuf) return;
  let L = sc.loop;
  if (!L && on) {
    const mk = (type, f, q) => { const s = actx.createBufferSource(), fl = actx.createBiquadFilter(), gn = actx.createGain(); s.buffer = noiseBuf; s.loop = true; fl.type = type; fl.frequency.value = f; fl.Q.value = q; gn.gain.value = 0.0001; s.connect(fl).connect(gn).connect(actx.destination); s.start(); return { s, fl, gn }; };
    L = sc.loop = { slide:mk('bandpass', 2600, 0.9), wind:mk('lowpass', 500, 0.6), seen:performance.now() };
    if (!pSlideLoop.watch) pSlideLoop.watch = setInterval(() => { for (const x of pSlideLoop.all) if (performance.now() - x.seen > 250) { x.slide.gn.gain.setTargetAtTime(0.0001, actx.currentTime, 0.05); x.wind.gn.gain.setTargetAtTime(0.0001, actx.currentTime, 0.05); } }, 200);
    pSlideLoop.all.add(L);
  }
  return L;
}
pSlideLoop.all = new Set();
function pSlideStop(sc){ const L = sc.loop; if (!L) return; try { L.slide.s.stop(); L.wind.s.stop(); } catch {} pSlideLoop.all.delete(L); sc.loop = null; }
