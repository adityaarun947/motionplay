/* =====================================================================
   LANE RUNNER — ART (v12): lit, shaded sprites for every world, obstacles, coins, arch and HUD.
   Everything heavy is drawn once into small cached canvases (1 lane-unit = RU px), then stamped each frame.
   ===================================================================== */
const RU = 200, RSPR = {};
function rSpr(key, w, h, ox, oy, fn){
  if (RSPR[key]) return RSPR[key];
  const c = pCanvas(w * RU, h * RU), g = c.getContext('2d'); g.translate(ox * RU, oy * RU); g.lineJoin = 'round'; g.lineCap = 'round';
  fn(g, RU); return (RSPR[key] = { c, ox:ox * RU, oy:oy * RU });
}
// stamp a sprite with its anchor at (X, Y); s = pixels per lane-unit at that depth
// pre-shrunk copies (mipmaps): far-away sprites are drawn from a small copy, which is much cheaper on TV browsers
function rMip(sp, k){
  let lv = 0; while (lv < 4 && k < 0.5 / (1 << lv) && sp.c.width >> (lv + 1) > 8) lv++;
  return rMipLevel(sp, lv);
}
function rMipLevel(sp, lv){
  if (!lv) return sp.c;
  sp.mips = sp.mips || [];
  if (!sp.mips[lv]) { const src = rMipLevel(sp, lv - 1), c = pCanvas(src.width / 2, src.height / 2), g = c.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(src, 0, 0, c.width, c.height); sp.mips[lv] = c; }
  return sp.mips[lv];
}
function rStamp(sp, X, Y, s, a = 1, kx = 1, ky = 1){
  const k = s / RU; if (a <= 0 || k <= 0) return;
  const dx = X - sp.ox * k * kx, dy = Y - sp.oy * k * ky, dw = sp.c.width * k * kx, dh = sp.c.height * k * ky;
  if (dx > W || dy > H || dx + dw < 0 || dy + dh < 0) return;   // off screen
  const pa = ctx.globalAlpha; if (a !== 1) ctx.globalAlpha = pa * Math.min(1, a);
  ctx.drawImage(rMip(sp, k * Math.max(Math.abs(kx), Math.abs(ky))), dx, dy, dw, dh);
  ctx.globalAlpha = pa;
}
function rLayer(key, w, h, fn){ let c = bgCache[key]; if (!c) { c = pCanvas(w, h); fn(c.getContext('2d'), c.width, c.height, c); bgCache[key] = c; } return c; }
const rShade = (g, x0, x1, dark, mid, light) => pGrad(g, x0, 0, x1, 0, [[0, dark], [0.55, mid], [1, light]]);   // light comes from the right
function rBlob(g, x, y, r, light, mid, dark){ g.fillStyle = pRad(g, x + r * 0.35, y - r * 0.4, r * 0.08, x, y, r, [[0, light], [0.55, mid], [1, dark]]); g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); }

/* ---------------- per-world look ---------------- */
const RART = [
  { // Sunny Meadow — red running track through green fields
    sky:[[0, '#1d6fd6'], [0.45, '#4fa6ee'], [0.82, '#a9dcfa'], [1, '#f2f3dc']], sun:[0.77, 0.30], sunC:'#fffbe6', glow:'255,244,200', sunR:0.042, flare:true, rays:true,
    fog:'214,236,248', ground:['#6cbf4f', '#3d8f33'], band:'rgba(25,80,15,0.11)', road:['#c25a40', '#a8432e'], line:'rgba(255,255,255,0.92)', dash:false, edge:'#f7f7f2',
    kerb:['#ffffff', '#2c9a48'], rim:'255,236,190', tint:null, dust:['rgba(196,108,80,0.75)', 'rgba(140,200,95,0.7)', 'rgba(240,230,210,0.7)'], step:0, cloud:'day' },
  { // Skyline City — asphalt boulevard with pavements
    sky:[[0, '#2a64c4'], [0.5, '#6aa4e6'], [0.85, '#c6dcf2'], [1, '#efe6d6']], sun:[0.24, 0.26], sunC:'#fffdf0', glow:'255,250,225', sunR:0.036, flare:true,
    fog:'210,222,236', ground:['#8b949c', '#5d666f'], band:'rgba(0,0,0,0.07)', road:['#4c4f59', '#3a3d46'], line:'rgba(255,255,255,0.9)', dash:true, edge:'#ffd23f',
    kerb:null, walk:['#b9bcc2', '#9a9ea6'], rim:'255,255,255', tint:'rgba(40,60,110,0.08)', dust:['rgba(200,200,205,0.55)', 'rgba(160,165,175,0.5)'], step:1, cloud:'day' },
  { // Desert Sunset — sun-baked highway, mesas, a huge low sun
    sky:[[0, '#2c1650'], [0.3, '#7d2f6c'], [0.58, '#e2564a'], [0.8, '#ff9a4d'], [1, '#ffd88a']], sun:[0.6, 0.83], sunC:'#fff0b0', glow:'255,170,90', sunR:0.085, flare:true,
    fog:'255,190,130', ground:['#e8b46c', '#c4864a'], band:'rgba(140,70,20,0.10)', road:['#6e5848', '#57443a'], line:'#ffd23f', dash:true, edge:'rgba(255,240,220,0.75)',
    kerb:['#ffffff', '#d6402c'], rim:'255,170,100', tint:'rgba(255,110,50,0.13)', dust:['rgba(232,184,120,0.8)', 'rgba(210,150,90,0.75)', 'rgba(250,215,160,0.7)'], step:2, cloud:'dusk', stars:0.25 },
  { // Starry Night — glossy neon road under the milky way
    sky:[[0, '#02031a'], [0.45, '#0b1446'], [0.8, '#2b2474'], [1, '#5b3f8f']], sun:[0.8, 0.26], sunC:'#f0f4ff', glow:'170,190,255', sunR:0.034, moon:true,
    fog:'60,48,120', ground:['#183e3e', '#0c2526'], band:'rgba(0,0,0,0.12)', road:['#1f2236', '#15172a'], line:'#3ff2ff', dash:true, edge:'#ff4fd8', neon:true,
    kerb:null, rim:'140,180,255', tint:'rgba(20,30,110,0.28)', dust:['rgba(80,240,255,0.8)', 'rgba(255,90,220,0.7)', 'rgba(200,220,255,0.6)'], step:3, cloud:'night', stars:1 },
];

/* ---------------- sky + far + mid scenery layers (cached per world, per screen size) ---------------- */
function rSkyLayer(i){
  const A = RART[i];
  return rLayer('rsky' + i, W, H, (g, w, h) => {
    const HOR = h * 0.36, R = mulberry32(101 + i);
    g.fillStyle = pGrad(g, 0, 0, 0, HOR, A.sky); g.fillRect(0, 0, w, HOR + 2);
    if (A.stars) {
      if (i === 3) {   // milky way: a soft diagonal band dusted with tiny stars
        g.save(); g.translate(w * 0.5, HOR * 0.4); g.rotate(-0.35);
        g.fillStyle = pGrad(g, 0, -HOR * 0.22, 0, HOR * 0.22, [[0, 'rgba(150,120,255,0)'], [0.5, 'rgba(190,170,255,0.18)'], [1, 'rgba(150,120,255,0)']]); g.fillRect(-w, -HOR * 0.22, w * 2, HOR * 0.44);
        g.fillStyle = 'rgba(255,220,240,0.08)'; for (let n = 0; n < 14; n++) { g.beginPath(); g.ellipse((R() - 0.5) * w * 1.4, (R() - 0.5) * HOR * 0.2, w * 0.08, HOR * 0.05, 0, 0, TAU); g.fill(); }
        g.fillStyle = '#fff'; for (let n = 0; n < 420; n++) { g.globalAlpha = R() * 0.6; g.fillRect((R() - 0.5) * w * 1.6, (R() + R() + R() - 1.5) * HOR * 0.12, 1, 1); }
        g.restore(); g.globalAlpha = 1;
      }
      for (let n = 0; n < 160 * A.stars; n++) { const y = R() * HOR * 0.9; g.globalAlpha = (0.25 + R() * 0.75) * (1 - y / HOR) * A.stars; g.fillStyle = R() < 0.15 ? '#ffd9b0' : R() < 0.3 ? '#bcd3ff' : '#fff'; g.beginPath(); g.arc(R() * w, y, 0.6 + R() * 1.5, 0, TAU); g.fill(); }
      g.globalAlpha = 1;
    }
    // sun / moon with a wide atmospheric glow
    const sx = A.sun[0] * w, sy = A.sun[1] * HOR, sr = h * A.sunR;
    g.fillStyle = pRad(g, sx, sy, sr * 0.5, sx, sy, sr * 9, [[0, `rgba(${A.glow},0.75)`], [0.25, `rgba(${A.glow},0.25)`], [1, `rgba(${A.glow},0)`]]); g.fillRect(0, 0, w, HOR + 2);
    if (A.moon) {
      g.fillStyle = pRad(g, sx - sr * 0.3, sy - sr * 0.3, sr * 0.1, sx, sy, sr, [[0, '#ffffff'], [0.7, '#e3e9fb'], [1, '#b9c4e6']]); g.beginPath(); g.arc(sx, sy, sr, 0, TAU); g.fill();
      g.fillStyle = 'rgba(140,150,190,0.35)'; for (const [cx, cy, cr] of [[-0.3, -0.2, 0.22], [0.25, 0.1, 0.16], [-0.05, 0.4, 0.12], [0.35, -0.35, 0.09]]) { g.beginPath(); g.arc(sx + cx * sr, sy + cy * sr, cr * sr, 0, TAU); g.fill(); }
    } else {
      g.fillStyle = pRad(g, sx, sy, 0, sx, sy, sr, [[0, '#ffffff'], [0.6, A.sunC], [1, `rgba(${A.glow},0.9)`]]); g.beginPath(); g.arc(sx, sy, sr, 0, TAU); g.fill();
      if (i === 2) { g.fillStyle = 'rgba(255,120,80,0.35)'; for (let k = 0; k < 4; k++) g.fillRect(sx - sr, sy + sr * (0.15 + k * 0.2), sr * 2, sr * 0.05 * (k + 1)); }   // heat bands across the low sun
    }
    if (A.rays) { g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = 0.38; g.translate(sx, sy); for (let k = 0; k < 14; k++) { const an = k / 14 * TAU + (k % 3) * 0.1, sp = 0.05 + (k % 4) * 0.025, L = h * 0.75; g.fillStyle = pRad(g, 0, 0, 0, 0, 0, L, [[0, 'rgba(255,250,220,0.35)'], [1, 'rgba(255,250,220,0)']]); g.beginPath(); g.moveTo(0, 0); g.arc(0, 0, L, an - sp, an + sp); g.closePath(); g.fill(); } g.restore(); }
    g.drawImage(rFarLayer(i), -w * 0.06, 0);   // the far range is baked in (it barely moves)
    // ground below the horizon (the moving stripes are drawn live on top)
    g.fillStyle = pGrad(g, 0, HOR, 0, h, [[0, A.ground[0]], [1, A.ground[1]]]); g.fillRect(0, HOR, w, h - HOR);
    g.fillStyle = pGrad(g, 0, HOR - h * 0.02, 0, HOR + h * 0.09, [[0, `rgba(${A.fog},0)`], [0.3, `rgba(${A.fog},0.75)`], [1, `rgba(${A.fog},0)`]]); g.fillRect(0, HOR - h * 0.02, w, h * 0.11);
  });
}
// the far range: hazy, slow parallax
function rFarLayer(i){
  return rLayer('rfar' + i, W * 1.12, H * 0.38, (g, w, h) => {
    const HOR = H * 0.36, R = mulberry32(211 + i), A = RART[i];
    const ridge = (base, amp, n, rough) => { const pts = []; for (let k = 0; k <= n; k++) pts.push([k / n * w, HOR - base - (R() * 0.6 + 0.4) * amp * (k % 2 ? 1 : 0.45) - rough * R()]); return pts; };
    if (i === 0) {   // snowy blue mountains
      for (const [base, amp, col0, col1, snow] of [[H * 0.03, H * 0.13, '#93b6dc', '#c5dbef', true], [H * 0.01, H * 0.08, '#7fa7cf', '#aecbe6', false]]) {
        const pts = ridge(base, amp, 14, H * 0.01);
        g.beginPath(); g.moveTo(0, HOR); for (const [x, y] of pts) g.lineTo(x, y); g.lineTo(w, HOR); g.closePath();
        g.fillStyle = pGrad(g, 0, HOR - base - amp, 0, HOR, [[0, col0], [1, col1]]); g.fill();
        if (snow) { g.save(); g.clip(); g.fillStyle = 'rgba(255,255,255,0.92)'; for (let k = 1; k < pts.length; k += 2) { const [x, y] = pts[k], d = (HOR - y) * 0.32; g.beginPath(); g.moveTo(x, y); g.lineTo(x - d * 0.9, y + d); g.lineTo(x - d * 0.4, y + d * 0.75); g.lineTo(x, y + d * 1.05); g.lineTo(x + d * 0.5, y + d * 0.7); g.lineTo(x + d * 0.9, y + d); g.closePath(); g.fill(); }
          g.fillStyle = 'rgba(70,100,150,0.18)'; for (let k = 1; k < pts.length; k += 2) { const [x, y] = pts[k]; g.beginPath(); g.moveTo(x, y); g.lineTo(x - (HOR - y) * 0.9, HOR); g.lineTo(x - (HOR - y) * 0.2, HOR); g.closePath(); g.fill(); } g.restore(); }
      }
    } else if (i === 1) {   // pale distant skyline
      for (let k = 0; k < 46; k++) { const bw = (0.015 + R() * 0.035) * w, bh = (0.04 + R() * R() * 0.16) * H, x = R() * w; g.fillStyle = `rgba(${150 + R() * 30 | 0},${178 + R() * 20 | 0},${210 + R() * 15 | 0},0.9)`; g.fillRect(x, HOR - bh, bw, bh); if (R() < 0.18) g.fillRect(x + bw * 0.45, HOR - bh - H * 0.03, bw * 0.1, H * 0.03); }
      g.fillStyle = '#a9c0da'; const tx = w * 0.62; g.fillRect(tx - 3, HOR - H * 0.26, 6, H * 0.26); g.beginPath(); g.ellipse(tx, HOR - H * 0.2, w * 0.012, H * 0.012, 0, 0, TAU); g.fill();
    } else if (i === 2) {   // purple far mesas
      for (let k = 0; k < 6; k++) { const x = R() * w, bw = (0.1 + R() * 0.16) * w, bh = (0.04 + R() * 0.07) * H; g.fillStyle = pGrad(g, 0, HOR - bh, 0, HOR, [[0, '#8a3f6c'], [1, '#c5607a']]); g.beginPath(); g.moveTo(x, HOR); g.lineTo(x + bw * 0.12, HOR - bh); g.lineTo(x + bw * 0.86, HOR - bh); g.lineTo(x + bw, HOR); g.closePath(); g.fill(); }
    } else {   // dark far city with lit windows and neon roofs
      const bs = []; for (let k = 0; k < 40; k++) bs.push({ x:R() * w, bw:(0.02 + R() * 0.04) * w, bh:(0.04 + R() * R() * 0.18) * H }); bs.sort((a, b) => b.bh - a.bh);
      for (const b of bs) {
        g.fillStyle = pGrad(g, 0, HOR - b.bh, 0, HOR, [[0, '#1a1650'], [1, '#2a2068']]); g.fillRect(b.x, HOR - b.bh, b.bw, b.bh);
        for (let wy = HOR - b.bh + 5; wy < HOR - 4; wy += H * 0.016) for (let wx = b.x + 3; wx < b.x + b.bw - 4; wx += W * 0.008) if (R() < 0.32) { g.fillStyle = R() < 0.7 ? 'rgba(255,214,120,0.85)' : 'rgba(140,220,255,0.8)'; g.fillRect(wx, wy, W * 0.004, H * 0.007); }
        if (R() < 0.25) { const nc = pick(['#ff4fd8', '#3ff2ff', '#ffe14a']); g.shadowColor = nc; g.shadowBlur = 8; g.fillStyle = nc; g.fillRect(b.x, HOR - b.bh, b.bw, 2); g.shadowBlur = 0; }
      }
    }
    g.fillStyle = pGrad(g, 0, HOR - H * 0.1, 0, HOR, [[0, `rgba(${A.fog},0)`], [1, `rgba(${A.fog},0.55)`]]); g.fillRect(0, HOR - H * 0.1, w, H * 0.1);
  });
}
// the nearer range: richer detail, faster parallax
function rMidLayer(i){
  return rLayer('rmid' + i, W * 1.2, H * 0.38, (g, w, h, c) => {
    const HOR = H * 0.36, R = mulberry32(307 + i);
    if (i === 0) {   // rolling green hills, tree clumps, a red barn and a windmill
      for (const [amp, base, c0, c1, ph] of [[0.05, 0.035, '#7cc56a', '#5aa64d', 1.3], [0.035, 0.012, '#5fb04f', '#3f8c3a', 4.1]]) {
        g.beginPath(); g.moveTo(0, HOR);
        const yAt = x => HOR - base * H - Math.sin(x / w * 9 + ph) * amp * H * 0.5 - Math.sin(x / w * 23 + ph * 2) * amp * H * 0.18 - amp * H * 0.5;
        for (let x = 0; x <= w; x += w / 80) g.lineTo(x, yAt(x)); g.lineTo(w, HOR); g.closePath();
        g.fillStyle = pGrad(g, 0, HOR - (base + amp) * H, 0, HOR, [[0, c0], [1, c1]]); g.fill();
        for (let k = 0; k < 34; k++) { const x = R() * w, y = yAt(x) + 2, r = H * (0.006 + R() * 0.008); rBlob(g, x, y - r * 0.6, r, '#8fd16a', '#3f8a35', '#24561f'); }
        if (ph > 3) { const bx = w * 0.3, by = yAt(bx) + 3; g.fillStyle = '#b9342b'; g.fillRect(bx, by - H * 0.022, H * 0.03, H * 0.022); g.fillStyle = '#7a1f1a'; g.beginPath(); g.moveTo(bx - 2, by - H * 0.022); g.lineTo(bx + H * 0.015, by - H * 0.035); g.lineTo(bx + H * 0.032, by - H * 0.022); g.closePath(); g.fill(); g.fillStyle = '#fff'; g.fillRect(bx + H * 0.011, by - H * 0.014, H * 0.008, H * 0.014); }
        else { const mx = w * 0.72, my = yAt(mx) + 2; g.fillStyle = pGrad(g, mx - H * 0.01, 0, mx + H * 0.01, 0, [[0, '#d8d2c4'], [1, '#fffaf0']]); g.beginPath(); g.moveTo(mx - H * 0.009, my); g.lineTo(mx - H * 0.005, my - H * 0.07); g.lineTo(mx + H * 0.005, my - H * 0.07); g.lineTo(mx + H * 0.009, my); g.closePath(); g.fill(); c.wm = { x:mx, y:my - H * 0.07, r:H * 0.045 }; }
      }
    } else if (i === 1) {   // detailed downtown towers
      const bs = []; for (let k = 0; k < 26; k++) bs.push({ x:R() * w, bw:(0.035 + R() * 0.05) * w, bh:(0.06 + R() * R() * 0.2) * H, c:pick(['#6f8db0', '#8aa2bf', '#5b7899', '#9db3c9', '#c9b79c', '#7d8fa6', '#b0a08a']), st:R() }); bs.sort((a, b) => b.bh - a.bh);
      for (const b of bs) {
        const y0 = HOR - b.bh;
        g.fillStyle = pGrad(g, b.x, 0, b.x + b.bw, 0, [[0, 'rgba(0,0,0,0.25)'], [0.18, 'rgba(0,0,0,0.25)'], [0.19, 'rgba(0,0,0,0)'], [1, 'rgba(255,255,255,0.12)']]);
        g.save(); g.fillStyle = b.c; g.fillRect(b.x, y0, b.bw, b.bh); g.fillStyle = pGrad(g, b.x, 0, b.x + b.bw, 0, [[0, 'rgba(0,0,0,0.28)'], [0.2, 'rgba(0,0,0,0.28)'], [0.21, 'rgba(0,0,0,0)'], [1, 'rgba(255,255,255,0.14)']]); g.fillRect(b.x, y0, b.bw, b.bh);
        // window grid reflecting the sky
        const gl = pGrad(g, 0, y0, 0, HOR, [[0, 'rgba(220,240,255,0.75)'], [1, 'rgba(120,160,210,0.6)']]);
        if (b.st < 0.5) { g.fillStyle = gl; for (let wy = y0 + H * 0.008; wy < HOR - H * 0.01; wy += H * 0.016) g.fillRect(b.x + b.bw * 0.08, wy, b.bw * 0.84, H * 0.008); }
        else { g.fillStyle = gl; for (let wx = b.x + b.bw * 0.1; wx < b.x + b.bw * 0.9; wx += b.bw * 0.16) g.fillRect(wx, y0 + H * 0.008, b.bw * 0.08, b.bh - H * 0.016); }
        g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(b.x - 1, y0, b.bw + 2, H * 0.004);
        if (b.st > 0.8) { g.fillStyle = '#5a6a80'; g.fillRect(b.x + b.bw * 0.6, y0 - H * 0.018, b.bw * 0.22, H * 0.018); g.fillRect(b.x + b.bw * 0.63, y0 - H * 0.025, b.bw * 0.16, H * 0.007); }
        else if (b.st > 0.62) { g.fillStyle = '#4a5568'; g.fillRect(b.x + b.bw * 0.48, y0 - H * 0.04, 2, H * 0.04); }
        g.restore();
      }
      // tree line along the boulevard
      for (let k = 0; k < 40; k++) { const x = R() * w, r = H * (0.007 + R() * 0.006); rBlob(g, x, HOR - r * 0.7, r, '#7fc96a', '#3d8a3c', '#255a26'); }
    } else if (i === 2) {   // red mesas with strata, cacti on the horizon
      for (let k = 0; k < 5; k++) {
        const x = R() * w * 0.95, bw = (0.12 + R() * 0.18) * w, bh = (0.05 + R() * 0.08) * H, y0 = HOR - bh;
        g.beginPath(); g.moveTo(x, HOR); g.lineTo(x + bw * 0.08, y0 + bh * 0.2); g.lineTo(x + bw * 0.14, y0); g.lineTo(x + bw * 0.84, y0); g.lineTo(x + bw * 0.9, y0 + bh * 0.25); g.lineTo(x + bw, HOR); g.closePath();
        g.save(); g.clip(); g.fillStyle = pGrad(g, 0, y0, 0, HOR, [[0, '#d0603c'], [1, '#8d3524']]); g.fillRect(x, y0, bw, bh);
        for (let s2 = 0; s2 < 7; s2++) { g.fillStyle = s2 % 2 ? 'rgba(255,190,140,0.18)' : 'rgba(90,20,10,0.18)'; g.fillRect(x, y0 + bh * (0.1 + s2 * 0.13), bw, bh * 0.05); }
        g.fillStyle = pGrad(g, x, 0, x + bw, 0, [[0, 'rgba(255,200,120,0.4)'], [0.25, 'rgba(255,200,120,0)'], [0.75, 'rgba(60,10,20,0)'], [1, 'rgba(60,10,20,0.4)']]); g.fillRect(x, y0, bw, bh); g.restore();
        g.fillStyle = 'rgba(255,220,150,0.7)'; g.fillRect(x + bw * 0.14, y0, bw * 0.7, Math.max(1, H * 0.002));
      }
      g.fillStyle = '#3d2b2a'; for (let k = 0; k < 18; k++) { const x = R() * w, ch = H * (0.012 + R() * 0.014); g.fillRect(x, HOR - ch, H * 0.004, ch); if (R() < 0.7) { g.fillRect(x - H * 0.006, HOR - ch * 0.7, H * 0.006, H * 0.003); g.fillRect(x - H * 0.006, HOR - ch * 0.85, H * 0.003, ch * 0.2); } }
    } else {   // dark tree line with cottage windows
      g.beginPath(); g.moveTo(0, HOR); for (let x = 0; x <= w; x += w / 120) g.lineTo(x, HOR - H * (0.025 + Math.abs(Math.sin(x * 0.03)) * 0.015 + R() * 0.01)); g.lineTo(w, HOR); g.closePath(); g.fillStyle = '#0a1a26'; g.fill();
      for (let k = 0; k < 9; k++) { const x = R() * w; g.fillStyle = 'rgba(255,200,110,0.9)'; g.shadowColor = '#ffb050'; g.shadowBlur = 6; g.fillRect(x, HOR - H * 0.012, H * 0.006, H * 0.005); g.shadowBlur = 0; }
    }
  });
}
function rCloud(kind, v){
  return rLayer('rcl' + kind + v, H * 0.36, H * 0.16, (g, w, h) => {
    const R = mulberry32(400 + v * 13 + kind.length);
    const top = kind === 'night' ? 'rgba(120,130,200,0.55)' : kind === 'dusk' ? 'rgba(255,190,170,0.95)' : 'rgba(255,255,255,0.98)';
    const bot = kind === 'night' ? 'rgba(30,30,80,0.45)' : kind === 'dusk' ? 'rgba(190,80,110,0.85)' : 'rgba(200,215,235,0.95)';
    const n = 9 + (R() * 5 | 0);
    for (let k = 0; k < n; k++) { const x = w * (0.15 + R() * 0.7), r = h * (0.18 + R() * 0.22) * (1 - Math.abs(x / w - 0.5)), y = h * 0.62 - r * 0.4 * R();
      g.fillStyle = pRad(g, x + r * 0.2, y - r * 0.5, r * 0.1, x, y, r, [[0, top], [0.7, top], [1, bot]]); g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); }
    g.globalCompositeOperation = 'destination-out'; g.fillStyle = pGrad(g, 0, h * 0.7, 0, h, [[0, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,1)']]); g.fillRect(0, h * 0.7, w, h * 0.3);
  });
}
function rVignette(red){
  return rLayer('rvig' + (red ? 1 : 0), W, H, (g, w, h) => {
    g.fillStyle = pRad(g, w / 2, h * 0.5, Math.min(w, h) * (red ? 0.3 : 0.45), w / 2, h * 0.5, Math.hypot(w, h) * 0.6, red ? [[0, 'rgba(255,0,30,0)'], [1, 'rgba(255,20,40,0.85)']] : [[0, 'rgba(0,0,0,0)'], [0.7, 'rgba(0,0,0,0.15)'], [1, 'rgba(0,0,0,0.55)']]);
    g.fillRect(0, 0, w, h);
  });
}

/* ---------------- small shared sprites ---------------- */
const rShadowSpr = () => rSpr('shadow', 1.2, 0.4, 0.6, 0.2, (g, u) => { g.scale(1, 0.3); g.fillStyle = pRad(g, 0, 0, 0, 0, 0, u * 0.6, [[0, 'rgba(0,0,0,0.5)'], [0.6, 'rgba(0,0,0,0.25)'], [1, 'rgba(0,0,0,0)']]); g.beginPath(); g.arc(0, 0, u * 0.6, 0, TAU); g.fill(); });
const rGlowSpr = (rgb) => rSpr('glow' + rgb, 1, 1, 0.5, 0.5, (g, u) => { g.fillStyle = pRad(g, 0, 0, 0, 0, 0, u * 0.5, [[0, `rgba(${rgb},1)`], [0.25, `rgba(${rgb},0.45)`], [1, `rgba(${rgb},0)`]]); g.fillRect(-u / 2, -u / 2, u, u); });
const rStarSpr = () => rSpr('glint', 1, 1, 0.5, 0.5, (g, u) => { for (const [a, l] of [[0, 0.5], [Math.PI / 2, 0.5], [Math.PI / 4, 0.22], [-Math.PI / 4, 0.22]]) { g.save(); g.rotate(a); g.fillStyle = pGrad(g, -u * l, 0, u * l, 0, [[0, 'rgba(255,255,255,0)'], [0.5, 'rgba(255,255,240,1)'], [1, 'rgba(255,255,255,0)']]); g.beginPath(); g.ellipse(0, 0, u * l, u * 0.035, 0, 0, TAU); g.fill(); g.restore(); } g.fillStyle = pRad(g, 0, 0, 0, 0, 0, u * 0.12, [[0, '#fff'], [1, 'rgba(255,255,255,0)']]); g.beginPath(); g.arc(0, 0, u * 0.12, 0, TAU); g.fill(); });
function rCoinSpr(){
  return rSpr('coin', 0.4, 0.4, 0.2, 0.2, (g, u) => {
    const r = u * 0.18;
    g.fillStyle = pRad(g, -r * 0.3, -r * 0.35, r * 0.1, 0, 0, r, [[0, '#fff6b8'], [0.45, '#ffd23f'], [0.85, '#e8a617'], [1, '#a86d05']]); g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill();
    g.strokeStyle = '#fff1a0'; g.lineWidth = r * 0.08; g.beginPath(); g.arc(0, 0, r * 0.78, 0, TAU); g.stroke();
    g.strokeStyle = 'rgba(150,90,0,0.55)'; g.lineWidth = r * 0.05; g.beginPath(); g.arc(0, 0, r * 0.7, 0, TAU); g.stroke();
    const star = (rr, off) => { g.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, q = k % 2 ? rr * 0.45 : rr; g.lineTo(Math.cos(a) * q + off, Math.sin(a) * q + off); } g.closePath(); };
    g.fillStyle = 'rgba(140,80,0,0.5)'; star(r * 0.48, r * 0.04); g.fill();
    g.fillStyle = pGrad(g, 0, -r * 0.5, 0, r * 0.5, [[0, '#fffbe0'], [1, '#ffc21a']]); star(r * 0.48, 0); g.fill();
    g.fillStyle = 'rgba(255,255,255,0.55)'; g.beginPath(); g.ellipse(-r * 0.35, -r * 0.45, r * 0.25, r * 0.12, -0.6, 0, TAU); g.fill();
  });
}
const rCoinEdge = () => rSpr('coinEdge', 0.4, 0.4, 0.2, 0.2, (g, u) => { const r = u * 0.18; g.fillStyle = pGrad(g, -r, 0, r, 0, [[0, '#7a4a00'], [0.5, '#d99a12'], [1, '#7a4a00']]); g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill(); });
function rHeartSpr(on){
  return rSpr('heart' + on, 0.5, 0.5, 0.25, 0.25, (g, u) => {
    const r = u * 0.2, path = () => { g.beginPath(); g.moveTo(0, r * 0.85); g.bezierCurveTo(-r * 1.25, -r * 0.05, -r * 0.75, -r * 1.05, 0, -r * 0.45); g.bezierCurveTo(r * 0.75, -r * 1.05, r * 1.25, -r * 0.05, 0, r * 0.85); g.closePath(); };
    path(); g.fillStyle = on ? pRad(g, -r * 0.3, -r * 0.4, r * 0.05, 0, 0, r * 1.1, [[0, '#ff9fb4'], [0.45, '#ff3b6b'], [1, '#a3082f']]) : 'rgba(255,255,255,0.18)'; g.fill();
    g.lineWidth = r * 0.1; g.strokeStyle = on ? 'rgba(90,0,20,0.6)' : 'rgba(255,255,255,0.45)'; g.stroke();
    if (on) { g.fillStyle = 'rgba(255,255,255,0.7)'; g.beginPath(); g.ellipse(-r * 0.42, -r * 0.42, r * 0.2, r * 0.11, -0.7, 0, TAU); g.fill(); }
  });
}
const RBALL = ['#ff3b5c', '#ffd23f', '#2f7cf6', '#ffffff', '#3ee08f'];
const rBalloonSpr = (ci) => rSpr('ball' + ci, 0.4, 0.4, 0.2, 0.2, (g, u) => { const r = u * 0.18, c = RBALL[ci]; g.fillStyle = pRad(g, -r * 0.35, -r * 0.4, r * 0.05, 0, 0, r, [[0, '#ffffff'], [0.25, c], [1, ci === 3 ? '#9aa7bd' : 'rgba(0,0,0,0.55)']]); g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill(); g.fillStyle = pRad(g, 0, 0, 0, 0, 0, r, [[0.7, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,0.25)']]); g.fill(); });

/* ---------------- obstacles ---------------- */
// JUMP barrier: red/white striped board on steel legs (board between 0.25 and 0.55 lane-units up)
function rBarrierSpr(){
  return rSpr('barrier', 1.2, 0.85, 0.6, 0.78, (g, u) => {
    for (const sd of [-1, 1]) {   // legs + rubber feet
      g.fillStyle = rShade(g, sd * u * 0.37 - u * 0.025, sd * u * 0.37 + u * 0.025, '#4f5560', '#c9ced8', '#7d8492'); g.fillRect(sd * u * 0.37 - u * 0.025, -u * 0.3, u * 0.05, u * 0.3);
      g.fillStyle = '#1d2027'; roundRect(sd * u * 0.37 - u * 0.1, -u * 0.035, u * 0.2, u * 0.04, u * 0.015, g); g.fill();
      g.fillStyle = '#ff9a1a'; g.fillRect(sd * u * 0.37 - u * 0.07, -u * 0.03, u * 0.035, u * 0.02); g.fillRect(sd * u * 0.37 + u * 0.035, -u * 0.03, u * 0.035, u * 0.02);
    }
    const x0 = -u * 0.46, y0 = -u * 0.56, bw = u * 0.92, bh = u * 0.31;
    g.fillStyle = '#f0e6e6'; g.beginPath(); g.moveTo(x0 + u * 0.02, y0); g.lineTo(x0 + bw - u * 0.02, y0); g.lineTo(x0 + bw - u * 0.05, y0 - u * 0.045); g.lineTo(x0 + u * 0.05, y0 - u * 0.045); g.closePath(); g.fill();   // top face
    roundRect(x0, y0, bw, bh, u * 0.03, g); g.save(); g.clip();
    g.fillStyle = '#fff'; g.fillRect(x0, y0, bw, bh);
    g.fillStyle = '#e1202f'; for (let k = -4; k < 10; k++) { const sx = x0 + k * u * 0.14; g.beginPath(); g.moveTo(sx, y0 + bh); g.lineTo(sx + u * 0.07, y0 + bh); g.lineTo(sx + u * 0.07 + bh, y0); g.lineTo(sx + bh, y0); g.closePath(); g.fill(); }
    g.fillStyle = pGrad(g, 0, y0, 0, y0 + bh, [[0, 'rgba(255,255,255,0.55)'], [0.35, 'rgba(255,255,255,0.08)'], [0.6, 'rgba(0,0,0,0)'], [1, 'rgba(60,0,10,0.35)']]); g.fillRect(x0, y0, bw, bh);
    g.restore();
    g.lineWidth = u * 0.014; g.strokeStyle = 'rgba(70,10,20,0.7)'; roundRect(x0, y0, bw, bh, u * 0.03, g); g.stroke();
    for (const sd of [-1, 1]) { g.fillStyle = pRad(g, sd * u * 0.37, y0 + bh * 0.5, 0, sd * u * 0.37, y0 + bh * 0.5, u * 0.045, [[0, '#fff3c0'], [0.5, '#ffb000'], [1, '#a65a00']]); g.beginPath(); g.arc(sd * u * 0.37, y0 + bh * 0.5, u * 0.04, 0, TAU); g.fill(); }
    // up chevrons painted on the board
    g.fillStyle = 'rgba(255,255,255,0.95)'; g.strokeStyle = 'rgba(80,0,10,0.6)'; g.lineWidth = u * 0.008;
    for (const k of [0, 1]) { const cy = y0 + bh * (0.62 - k * 0.3); g.beginPath(); g.moveTo(-u * 0.09, cy + u * 0.04); g.lineTo(0, cy - u * 0.035); g.lineTo(u * 0.09, cy + u * 0.04); g.lineTo(u * 0.065, cy + u * 0.06); g.lineTo(0, cy + u * 0.002); g.lineTo(-u * 0.065, cy + u * 0.06); g.closePath(); g.fill(); g.stroke(); }
    g.fillStyle = '#2b2f3a'; g.fillRect(-u * 0.035, y0 - u * 0.07, u * 0.07, u * 0.03);   // lamp housing (the light itself blinks live)
  });
}
// DUCK gantry: steel posts, a hazard-striped beam from 1.0 to 1.75 up, and a sign on top
function rGantrySpr(){
  return rSpr('gantry', 1.3, 2.25, 0.65, 2.15, (g, u) => {
    for (const sd of [-1, 1]) {
      const px = sd * u * 0.5;
      g.fillStyle = rShade(g, px - u * 0.04, px + u * 0.04, '#3a404c', '#aeb5c2', '#646c7a'); g.fillRect(px - u * 0.04, -u * 1.8, u * 0.08, u * 1.8);
      g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(px - u * 0.012, -u * 1.8, u * 0.024, u * 1.8);
      g.fillStyle = '#2a2f38'; g.fillRect(px - u * 0.09, -u * 0.04, u * 0.18, u * 0.04); g.fillStyle = '#c9ced8'; for (const bx of [-0.06, 0.06]) { g.beginPath(); g.arc(px + bx * u, -u * 0.02, u * 0.01, 0, TAU); g.fill(); }
      for (let k = 0; k < 6; k++) { g.fillStyle = k % 2 ? '#ffd23f' : '#1b1b22'; g.fillRect(px - u * 0.04, -u * (0.25 + k * 0.1), u * 0.08, u * 0.1); }
    }
    const x0 = -u * 0.55, y0 = -u * 1.75, bw = u * 1.1, bh = u * 0.75;
    g.fillStyle = '#e7d9a0'; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x0 + bw, y0); g.lineTo(x0 + bw - u * 0.04, y0 - u * 0.05); g.lineTo(x0 + u * 0.04, y0 - u * 0.05); g.closePath(); g.fill();
    roundRect(x0, y0, bw, bh, u * 0.03, g); g.save(); g.clip();
    g.fillStyle = '#ffcc1a'; g.fillRect(x0, y0, bw, bh);
    g.fillStyle = '#16161c'; for (let k = -6; k < 12; k++) { const sx = x0 + k * u * 0.16; g.beginPath(); g.moveTo(sx, y0 + bh); g.lineTo(sx + u * 0.08, y0 + bh); g.lineTo(sx + u * 0.08 + bh, y0); g.lineTo(sx + bh, y0); g.closePath(); g.fill(); }
    g.fillStyle = pGrad(g, 0, y0, 0, y0 + bh, [[0, 'rgba(255,255,255,0.45)'], [0.25, 'rgba(255,255,255,0.05)'], [0.7, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,0.45)']]); g.fillRect(x0, y0, bw, bh);
    g.fillStyle = 'rgba(30,30,30,0.85)'; roundRect(-u * 0.2, y0 + bh * 0.3, u * 0.4, bh * 0.4, u * 0.04, g); g.fill();
    g.fillStyle = '#ffffff'; g.beginPath(); g.moveTo(-u * 0.1, y0 + bh * 0.38); g.lineTo(u * 0.1, y0 + bh * 0.38); g.lineTo(0, y0 + bh * 0.62); g.closePath(); g.fill();
    g.restore();
    g.lineWidth = u * 0.016; g.strokeStyle = 'rgba(40,30,0,0.8)'; roundRect(x0, y0, bw, bh, u * 0.03, g); g.stroke();
    g.fillStyle = '#d0d5df'; for (let k = 0; k < 8; k++) { g.beginPath(); g.arc(x0 + bw * (0.06 + k * 0.125), y0 + bh * 0.08, u * 0.012, 0, TAU); g.arc(x0 + bw * (0.06 + k * 0.125), y0 + bh * 0.92, u * 0.012, 0, TAU); g.fill(); }
    // sign above the beam
    const sw = u * 0.5, sh = u * 0.2, sy = y0 - u * 0.05 - sh;
    g.fillStyle = '#5c6270'; g.fillRect(-u * 0.15, sy + sh, u * 0.02, u * 0.05); g.fillRect(u * 0.13, sy + sh, u * 0.02, u * 0.05);
    g.fillStyle = pGrad(g, 0, sy, 0, sy + sh, [[0, '#ff4a55'], [1, '#c4101e']]); roundRect(-sw / 2, sy, sw, sh, u * 0.03, g); g.fill(); g.lineWidth = u * 0.012; g.strokeStyle = '#fff'; g.stroke();
    g.font = `900 ${u * 0.13}px system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff'; g.fillText('DUCK', 0, sy + sh * 0.54);
  });
}
// train nose (front face), stretched onto the train's front rectangle
const RTRAIN = [['#2f6fd8', '#1d4ea8', '#9cc4ff'], ['#d8323c', '#a01822', '#ffb0b4'], ['#20a36b', '#127048', '#a8f0cf'], ['#7a4bd8', '#5229a8', '#d4c0ff']];
function rTrainFront(v){
  return rSpr('trainF' + v, 0.9, 1.5, 0, 0, (g, u) => {
    const [c0, c1, c2] = RTRAIN[v], w = u * 0.9, h = u * 1.5;
    g.fillStyle = pGrad(g, 0, 0, w, 0, [[0, c1], [0.5, c0], [1, c1]]); roundRect(0, 0, w, h, u * 0.12, g); g.fill();
    g.fillStyle = pGrad(g, 0, 0, 0, h * 0.3, [[0, 'rgba(255,255,255,0.35)'], [1, 'rgba(255,255,255,0)']]); roundRect(0, 0, w, h * 0.3, u * 0.12, g); g.fill();
    // windscreen with sky reflection and wipers
    const wx = w * 0.1, wy = h * 0.16, ww = w * 0.8, wh = h * 0.34;
    roundRect(wx, wy, ww, wh, u * 0.06, g); g.fillStyle = pGrad(g, 0, wy, 0, wy + wh, [[0, '#24324a'], [1, '#0b1220']]); g.fill();
    g.save(); roundRect(wx, wy, ww, wh, u * 0.06, g); g.clip(); g.fillStyle = 'rgba(200,230,255,0.35)'; g.beginPath(); g.moveTo(wx + ww * 0.1, wy); g.lineTo(wx + ww * 0.42, wy); g.lineTo(wx + ww * 0.12, wy + wh); g.lineTo(wx - ww * 0.2, wy + wh); g.closePath(); g.fill(); g.fillStyle = 'rgba(200,230,255,0.15)'; g.beginPath(); g.moveTo(wx + ww * 0.5, wy); g.lineTo(wx + ww * 0.6, wy); g.lineTo(wx + ww * 0.3, wy + wh); g.lineTo(wx + ww * 0.2, wy + wh); g.closePath(); g.fill(); g.restore();
    g.strokeStyle = '#111'; g.lineWidth = u * 0.012; g.beginPath(); g.moveTo(wx + ww * 0.3, wy + wh * 0.95); g.lineTo(wx + ww * 0.12, wy + wh * 0.45); g.moveTo(wx + ww * 0.75, wy + wh * 0.95); g.lineTo(wx + ww * 0.57, wy + wh * 0.45); g.stroke();
    g.lineWidth = u * 0.02; g.strokeStyle = 'rgba(0,0,0,0.6)'; roundRect(wx, wy, ww, wh, u * 0.06, g); g.stroke();
    // LED destination board
    g.fillStyle = '#120a04'; roundRect(w * 0.22, h * 0.05, w * 0.56, h * 0.08, u * 0.02, g); g.fill();
    g.font = `800 ${u * 0.075}px ui-monospace, monospace`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#ffae2b'; g.shadowColor = '#ff8a00'; g.shadowBlur = u * 0.03; g.fillText('EXPRESS', w / 2, h * 0.093); g.shadowBlur = 0;
    // livery stripe, number, headlights, bumper
    g.fillStyle = c2; g.fillRect(0, h * 0.56, w, h * 0.05); g.fillStyle = '#ffffff'; g.fillRect(0, h * 0.62, w, h * 0.02);
    g.font = `900 ${u * 0.1}px system-ui, sans-serif`; g.fillStyle = 'rgba(255,255,255,0.9)'; g.fillText(String(7 + v * 12), w / 2, h * 0.7);
    for (const hx of [0.2, 0.8]) { g.fillStyle = '#20242c'; g.beginPath(); g.arc(w * hx, h * 0.74, u * 0.07, 0, TAU); g.fill(); g.fillStyle = pRad(g, w * hx, h * 0.74, 0, w * hx, h * 0.74, u * 0.055, [[0, '#ffffff'], [0.5, '#fff6c8'], [1, '#ffd36b']]); g.beginPath(); g.arc(w * hx, h * 0.74, u * 0.055, 0, TAU); g.fill(); }
    g.fillStyle = '#ff3030'; for (const hx of [0.08, 0.92]) { g.beginPath(); g.arc(w * hx, h * 0.84, u * 0.022, 0, TAU); g.fill(); }
    g.fillStyle = pGrad(g, 0, h * 0.86, 0, h, [[0, '#3a3f4a'], [1, '#14161c']]); g.fillRect(0, h * 0.86, w, h * 0.14);
    g.fillStyle = '#ffd23f'; for (let k = 0; k < 6; k++) { g.beginPath(); g.moveTo(w * k / 6, h); g.lineTo(w * (k + 0.5) / 6, h); g.lineTo(w * (k + 1) / 6, h * 0.9); g.lineTo(w * (k + 0.5) / 6, h * 0.9); g.closePath(); g.fill(); }
    g.fillStyle = '#5a5f6b'; g.fillRect(w * 0.42, h * 0.9, w * 0.16, h * 0.1);
  });
}

/* ---------------- roadside scenery, per world ---------------- */
function rDecoKind(w, k){
  if (w === 0) return k < 0.4 ? 'oak' : k < 0.58 ? 'pine' : k < 0.72 ? 'blossom' : k < 0.86 ? 'bush' : k < 0.94 ? 'sunflowers' : 'hay';
  if (w === 1) return k < 0.34 ? 'lamp' : k < 0.55 ? 'planter' : k < 0.64 ? 'hydrant' : k < 0.78 ? 'billboard' : k < 0.9 ? 'busstop' : 'signal';
  if (w === 2) return k < 0.38 ? 'saguaro' : k < 0.54 ? 'barrel' : k < 0.74 ? 'rock' : k < 0.86 ? 'deadtree' : 'signpost';
  return k < 0.4 ? 'neonlamp' : k < 0.6 ? 'fairytree' : k < 0.76 ? 'neonsign' : k < 0.9 ? 'mushrooms' : 'neonlamp';
}
function rDecoSpr(kind, v, side){
  const key = kind + v + (side > 0 ? 'R' : 'L');
  const tree = (g, u, light, mid, dark, h) => {
    g.fillStyle = rShade(g, -u * 0.09, u * 0.09, '#3a2412', '#7a5130', '#5a3a1e'); g.beginPath(); g.moveTo(-u * 0.1, 0); g.quadraticCurveTo(-u * 0.05, -h * 0.3, -u * 0.06, -h * 0.55); g.lineTo(u * 0.06, -h * 0.55); g.quadraticCurveTo(u * 0.05, -h * 0.3, u * 0.1, 0); g.closePath(); g.fill();
    const R = mulberry32(31 + v * 7 + kind.length), cy = -h * 0.72;
    const blobs = []; for (let k = 0; k < 11; k++) { const a = R() * TAU, d = R() * 0.42; blobs.push([Math.cos(a) * d * u * 0.95, cy + Math.sin(a) * d * u * 0.7, u * (0.2 + R() * 0.16)]); }
    blobs.sort((a, b) => a[1] - b[1]);
    for (const [x, y, r] of blobs) rBlob(g, x, y + r * 0.25, r * 1.08, dark, dark, 'rgba(0,0,0,0.25)');
    for (const [x, y, r] of blobs) rBlob(g, x, y, r, light, mid, dark);
    g.fillStyle = 'rgba(0,0,0,0.12)'; for (let k = 0; k < 40; k++) { const x = (R() - 0.5) * u * 1.2, y = cy + (R() - 0.5) * u * 0.9; g.beginPath(); g.arc(x, y, u * 0.015, 0, Math.PI); g.fill(); }
  };
  switch (kind) {
    case 'oak': return rSpr(key, 1.8, 2.4, 0.9, 2.3, (g, u) => tree(g, u, '#a8e66a', '#4fa33a', '#235e22', u * (1.7 + v * 0.25)));
    case 'blossom': return rSpr(key, 1.8, 2.3, 0.9, 2.2, (g, u) => { tree(g, u, '#ffe4f0', '#ff9ccb', '#b44d84', u * 1.6); const R = mulberry32(9 + v); g.fillStyle = '#fff'; for (let k = 0; k < 30; k++) { g.beginPath(); g.arc((R() - 0.5) * u * 1.1, -u * 1.15 + (R() - 0.5) * u * 0.8, u * 0.018, 0, TAU); g.fill(); } });
    case 'pine': return rSpr(key, 1.2, 2.6, 0.6, 2.5, (g, u) => {
      g.fillStyle = '#4a2e17'; g.fillRect(-u * 0.06, -u * 0.35, u * 0.12, u * 0.35);
      for (let k = 0; k < 5; k++) { const y = -u * (0.25 + k * 0.42), hw = u * (0.55 - k * 0.09), th = u * 0.62;
        g.fillStyle = pGrad(g, -hw, 0, hw, 0, [[0, '#123d1f'], [0.55, '#2f7a3a'], [1, '#59a85a']]); g.beginPath(); g.moveTo(0, y - th); g.quadraticCurveTo(hw * 0.4, y - th * 0.4, hw, y); g.quadraticCurveTo(0, y + u * 0.06, -hw, y); g.quadraticCurveTo(-hw * 0.4, y - th * 0.4, 0, y - th); g.fill();
        g.fillStyle = 'rgba(0,0,0,0.18)'; g.beginPath(); g.ellipse(0, y - u * 0.01, hw * 0.9, u * 0.04, 0, 0, TAU); g.fill(); } });
    case 'bush': return rSpr(key, 1.2, 0.8, 0.6, 0.75, (g, u) => { const R = mulberry32(5 + v); for (let k = 0; k < 7; k++) rBlob(g, (R() - 0.5) * u * 0.8, -u * (0.2 + R() * 0.15), u * (0.16 + R() * 0.1), '#9be36a', '#47a03a', '#22581f'); const fc = ['#ff4f6d', '#ffd23f', '#ffffff', '#b46bff'][v % 4]; for (let k = 0; k < 14; k++) { const x = (R() - 0.5) * u * 0.8, y = -u * (0.2 + R() * 0.3); g.fillStyle = fc; for (let p = 0; p < 5; p++) { g.beginPath(); g.arc(x + Math.cos(p * 1.256) * u * 0.02, y + Math.sin(p * 1.256) * u * 0.02, u * 0.017, 0, TAU); g.fill(); } g.fillStyle = '#ffb000'; g.beginPath(); g.arc(x, y, u * 0.012, 0, TAU); g.fill(); } });
    case 'sunflowers': return rSpr(key, 1.0, 1.4, 0.5, 1.35, (g, u) => { for (const [dx, hh] of [[-0.22, 0.95], [0.05, 1.15], [0.26, 0.85]]) { g.strokeStyle = '#3d8a2f'; g.lineWidth = u * 0.035; g.beginPath(); g.moveTo(dx * u, 0); g.quadraticCurveTo(dx * u + u * 0.04, -hh * u * 0.5, dx * u, -hh * u); g.stroke(); g.fillStyle = '#4fa33a'; g.beginPath(); g.ellipse(dx * u + u * 0.07, -hh * u * 0.45, u * 0.08, u * 0.035, -0.5, 0, TAU); g.fill(); const cx = dx * u, cy = -hh * u; for (let p = 0; p < 14; p++) { const a = p / 14 * TAU; g.fillStyle = p % 2 ? '#ffc21a' : '#ffd84a'; g.beginPath(); g.ellipse(cx + Math.cos(a) * u * 0.1, cy + Math.sin(a) * u * 0.1, u * 0.065, u * 0.025, a, 0, TAU); g.fill(); } rBlob(g, cx, cy, u * 0.07, '#a0622a', '#5a3214', '#2e1806'); } });
    case 'hay': return rSpr(key, 1.0, 0.8, 0.5, 0.75, (g, u) => { const r = u * 0.34; g.fillStyle = pRad(g, -r * 0.3, -r * 1.3, r * 0.1, 0, -r, r, [[0, '#fbe39a'], [0.7, '#d9a94a'], [1, '#9c6a22']]); g.beginPath(); g.arc(0, -r, r, 0, TAU); g.fill(); g.strokeStyle = 'rgba(140,90,30,0.6)'; g.lineWidth = u * 0.012; g.beginPath(); for (let a = 0; a < 18; a += 0.2) { const rr = r * a / 18; g.lineTo(Math.cos(a) * rr, -r + Math.sin(a) * rr); } g.stroke(); });
    case 'lamp': return rSpr(key, 1.2, 2.6, 0.6, 2.5, (g, u) => {
      const dir = -side;   // the arm reaches over the road
      g.fillStyle = rShade(g, -u * 0.035, u * 0.035, '#2a2f3a', '#8a92a3', '#4a5160'); g.fillRect(-u * 0.035, -u * 2.2, u * 0.07, u * 2.2);
      g.fillStyle = '#2f3440'; roundRect(-u * 0.08, -u * 0.25, u * 0.16, u * 0.25, u * 0.03, g); g.fill();
      g.strokeStyle = '#4a5160'; g.lineWidth = u * 0.04; g.beginPath(); g.moveTo(0, -u * 2.15); g.quadraticCurveTo(0, -u * 2.35, dir * u * 0.3, -u * 2.33); g.lineTo(dir * u * 0.42, -u * 2.33); g.stroke();
      g.fillStyle = '#3a404c'; roundRect(dir * u * 0.42 - u * 0.12, -u * 2.38, u * 0.24, u * 0.07, u * 0.03, g); g.fill(); g.fillStyle = '#eef6ff'; g.fillRect(dir * u * 0.42 - u * 0.1, -u * 2.315, u * 0.2, u * 0.018); });
    case 'planter': return rSpr(key, 1.2, 1.9, 0.6, 1.85, (g, u) => { tree(g, u, '#9fe06a', '#3f9c3c', '#1f5a24', u * 1.45); g.fillStyle = rShade(g, -u * 0.3, u * 0.3, '#7d7f86', '#c3c5cc', '#9a9ca4'); g.fillRect(-u * 0.3, -u * 0.3, u * 0.6, u * 0.3); g.fillStyle = 'rgba(255,255,255,0.4)'; g.fillRect(-u * 0.3, -u * 0.3, u * 0.6, u * 0.03); });
    case 'hydrant': return rSpr(key, 0.5, 0.6, 0.25, 0.58, (g, u) => { g.fillStyle = rShade(g, -u * 0.09, u * 0.09, '#8a0e14', '#ff3b3b', '#c41a22'); roundRect(-u * 0.08, -u * 0.4, u * 0.16, u * 0.38, u * 0.05, g); g.fill(); g.fillRect(-u * 0.14, -u * 0.27, u * 0.28, u * 0.07); g.beginPath(); g.arc(0, -u * 0.41, u * 0.085, Math.PI, 0); g.fill(); g.fillStyle = '#d9b33a'; g.fillRect(-u * 0.11, -u * 0.04, u * 0.22, u * 0.04); g.fillStyle = 'rgba(255,255,255,0.5)'; g.fillRect(u * 0.025, -u * 0.38, u * 0.02, u * 0.32); });
    case 'billboard': return rSpr(key, 2.0, 2.4, 1.0, 2.35, (g, u) => {
      for (const sd of [-1, 1]) { g.fillStyle = rShade(g, sd * u * 0.5 - u * 0.03, sd * u * 0.5 + u * 0.03, '#2a2f3a', '#7a8293', '#444b58'); g.fillRect(sd * u * 0.5 - u * 0.03, -u * 1.5, u * 0.06, u * 1.5); }
      const bx = -u * 0.85, by = -u * 2.25, bw = u * 1.7, bh = u * 0.8;
      g.fillStyle = '#20242c'; roundRect(bx - u * 0.04, by - u * 0.04, bw + u * 0.08, bh + u * 0.08, u * 0.04, g); g.fill();
      const ad = [['#ff7a1a', '#ff2e63', 'RUN FAST!'], ['#7b2ff7', '#2f7cf6', 'MOTIONPLAY'], ['#00c2a8', '#2f7cf6', 'JUMP HIGH!'], ['#ffd23f', '#ff7a1a', 'KEEP GOING']][v % 4];
      g.fillStyle = pGrad(g, bx, by, bx + bw, by + bh, [[0, ad[0]], [1, ad[1]]]); g.fillRect(bx, by, bw, bh);
      g.fillStyle = 'rgba(255,255,255,0.18)'; g.beginPath(); g.arc(bx + bw * 0.85, by + bh * 0.3, bh * 0.6, 0, TAU); g.fill();
      g.font = `900 ${u * 0.22}px system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineWidth = u * 0.03; g.strokeStyle = 'rgba(0,0,0,0.35)'; g.strokeText(ad[2], 0, by + bh * 0.5); g.fillStyle = '#fff'; g.fillText(ad[2], 0, by + bh * 0.5);
      g.fillStyle = pGrad(g, 0, by, 0, by + bh, [[0, 'rgba(255,255,255,0.25)'], [0.5, 'rgba(255,255,255,0)'], [1, 'rgba(0,0,0,0.2)']]); g.fillRect(bx, by, bw, bh);
      g.fillStyle = '#3a404c'; for (const lx of [-0.5, 0, 0.5]) g.fillRect(lx * u - u * 0.05, by - u * 0.12, u * 0.1, u * 0.05); });
    case 'busstop': return rSpr(key, 1.6, 1.9, 0.8, 1.85, (g, u) => {
      g.fillStyle = '#5a6272'; for (const px of [-0.6, 0.6]) g.fillRect(px * u - u * 0.025, -u * 1.25, u * 0.05, u * 1.25);
      g.fillStyle = 'rgba(190,225,255,0.35)'; g.fillRect(-u * 0.6, -u * 1.15, u * 1.2, u * 0.95); g.strokeStyle = 'rgba(255,255,255,0.5)'; g.lineWidth = u * 0.012; g.strokeRect(-u * 0.6, -u * 1.15, u * 1.2, u * 0.95);
      g.fillStyle = 'rgba(255,255,255,0.35)'; g.beginPath(); g.moveTo(-u * 0.4, -u * 1.15); g.lineTo(-u * 0.25, -u * 1.15); g.lineTo(-u * 0.5, -u * 0.2); g.lineTo(-u * 0.6, -u * 0.2); g.closePath(); g.fill();
      g.fillStyle = pGrad(g, 0, -u * 1.32, 0, -u * 1.2, [[0, '#d0d6e2'], [1, '#7d8696']]); g.fillRect(-u * 0.72, -u * 1.32, u * 1.44, u * 0.1);
      g.fillStyle = '#8a5a2b'; g.fillRect(-u * 0.45, -u * 0.42, u * 0.9, u * 0.06); g.fillStyle = '#4a5160'; g.fillRect(-u * 0.4, -u * 0.36, u * 0.04, u * 0.36); g.fillRect(u * 0.36, -u * 0.36, u * 0.04, u * 0.36);
      g.fillStyle = '#5a6272'; g.fillRect(u * 0.72, -u * 1.75, u * 0.04, u * 1.75); g.fillStyle = '#2f7cf6'; g.beginPath(); g.arc(u * 0.74, -u * 1.65, u * 0.14, 0, TAU); g.fill(); g.strokeStyle = '#fff'; g.lineWidth = u * 0.02; g.stroke();
      g.font = `900 ${u * 0.09}px system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff'; g.fillText('BUS', u * 0.74, -u * 1.65); });
    case 'signal': return rSpr(key, 0.6, 2.1, 0.3, 2.05, (g, u) => { g.fillStyle = rShade(g, -u * 0.03, u * 0.03, '#2a2f3a', '#7a8293', '#444b58'); g.fillRect(-u * 0.03, -u * 1.5, u * 0.06, u * 1.5); g.fillStyle = '#1b1e25'; roundRect(-u * 0.12, -u * 2.0, u * 0.24, u * 0.55, u * 0.05, g); g.fill(); [['#4a1010', 0], ['#4a3a10', 1], ['#3eff8a', 2]].forEach(([c, k]) => { g.fillStyle = c; if (k === 2) { g.shadowColor = '#3eff8a'; g.shadowBlur = u * 0.08; } g.beginPath(); g.arc(0, -u * (1.89 - k * 0.165), u * 0.06, 0, TAU); g.fill(); g.shadowBlur = 0; }); });
    case 'saguaro': return rSpr(key, 1.2, 2.2, 0.6, 2.1, (g, u) => {
      const cact = (x0, y0, x1, y1, r) => { g.strokeStyle = pGrad(g, x0 - r, 0, x0 + r, 0, [[0, '#1f5a2c'], [0.6, '#4f9a4a'], [1, '#7cc46a']]); g.lineWidth = r * 2; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke(); g.strokeStyle = 'rgba(10,50,20,0.35)'; g.lineWidth = r * 0.12; for (const o of [-0.45, 0, 0.45]) { g.beginPath(); g.moveTo(x0 + o * r, y0); g.lineTo(x1 + o * r, y1); g.stroke(); } };
      const h = u * (1.6 + v * 0.3), r = u * 0.12;
      cact(0, 0, 0, -h, r);
      g.strokeStyle = pGrad(g, -u * 0.4, 0, -u * 0.2, 0, [[0, '#1f5a2c'], [1, '#4f9a4a']]); g.lineWidth = r * 1.5; g.beginPath(); g.moveTo(0, -h * 0.45); g.quadraticCurveTo(-u * 0.32, -h * 0.45, -u * 0.32, -h * 0.75); g.stroke();
      g.strokeStyle = pGrad(g, u * 0.2, 0, u * 0.4, 0, [[0, '#3f8a40'], [1, '#7cc46a']]); g.beginPath(); g.moveTo(0, -h * 0.6); g.quadraticCurveTo(u * 0.3, -h * 0.6, u * 0.3, -h * (0.85 + v * 0.05)); g.stroke();
      if (v) { g.fillStyle = '#ff6fa0'; g.beginPath(); g.arc(0, -h - r * 0.6, u * 0.05, 0, TAU); g.fill(); }
      g.fillStyle = 'rgba(255,255,220,0.55)'; const R = mulberry32(3 + v); for (let k = 0; k < 30; k++) g.fillRect((R() - 0.5) * r * 2, -R() * h, u * 0.008, u * 0.008); });
    case 'barrel': return rSpr(key, 1.0, 0.7, 0.5, 0.65, (g, u) => { for (const [dx, r] of [[-0.18, 0.15], [0.12, 0.2], [0.33, 0.11]]) { const cx = dx * u, cy = -r * u; g.fillStyle = pRad(g, cx + r * u * 0.3, cy - r * u * 0.4, r * u * 0.1, cx, cy, r * u, [[0, '#8fd47a'], [0.6, '#3f8a40'], [1, '#1d4a24']]); g.beginPath(); g.ellipse(cx, cy, r * u, r * u * 1.05, 0, 0, TAU); g.fill(); g.strokeStyle = 'rgba(10,40,15,0.4)'; g.lineWidth = u * 0.01; for (const k of [-0.6, -0.2, 0.2, 0.6]) { g.beginPath(); g.ellipse(cx, cy, Math.abs(k) * r * u, r * u * 1.02, 0, k < 0 ? Math.PI / 2 : -Math.PI / 2, k < 0 ? Math.PI * 1.5 : Math.PI / 2); g.stroke(); } g.fillStyle = '#ff6fa0'; g.beginPath(); g.arc(cx, cy - r * u * 1.0, u * 0.035, 0, TAU); g.fill(); } });
    case 'rock': return rSpr(key, 1.3, 1.0, 0.65, 0.95, (g, u) => { const R = mulberry32(77 + v), pts = []; for (let k = 0; k < 9; k++) { const a = Math.PI + k / 8 * Math.PI; pts.push([Math.cos(a) * u * (0.5 + R() * 0.1), Math.sin(a) * u * (0.55 + v * 0.12 + R() * 0.15)]); }
      g.beginPath(); g.moveTo(pts[0][0], 0); for (const [x, y] of pts) g.lineTo(x, y); g.lineTo(pts[8][0], 0); g.closePath(); g.save(); g.clip();
      g.fillStyle = pGrad(g, -u * 0.5, -u * 0.6, u * 0.5, 0, [[0, '#7a2f1e'], [0.5, '#c4603a'], [1, '#ef9a5a']]); g.fillRect(-u * 0.7, -u, u * 1.4, u);
      for (let k = 0; k < 6; k++) { g.fillStyle = k % 2 ? 'rgba(255,200,150,0.2)' : 'rgba(80,20,10,0.2)'; g.fillRect(-u * 0.7, -u * (0.1 + k * 0.12), u * 1.4, u * 0.04); }
      g.fillStyle = 'rgba(40,10,5,0.3)'; g.fillRect(-u * 0.7, -u * 0.12, u * 1.4, u * 0.12); g.restore(); });
    case 'deadtree': return rSpr(key, 1.4, 1.9, 0.7, 1.85, (g, u) => { g.strokeStyle = '#5a4030'; const br = (x, y, a, l, w2, d) => { const x2 = x + Math.cos(a) * l, y2 = y + Math.sin(a) * l; g.lineWidth = w2; g.beginPath(); g.moveTo(x, y); g.lineTo(x2, y2); g.stroke(); if (d > 0) { br(x2, y2, a - 0.45, l * 0.7, w2 * 0.65, d - 1); br(x2, y2, a + 0.4, l * 0.65, w2 * 0.6, d - 1); } }; br(0, 0, -Math.PI / 2, u * 0.65, u * 0.09, 3); g.strokeStyle = 'rgba(255,200,150,0.35)'; g.lineWidth = u * 0.015; g.beginPath(); g.moveTo(u * 0.02, 0); g.lineTo(u * 0.02, -u * 0.6); g.stroke(); });
    case 'signpost': return rSpr(key, 1.2, 1.6, 0.6, 1.55, (g, u) => { g.fillStyle = rShade(g, -u * 0.04, u * 0.04, '#4a2e17', '#9a6a3a', '#6b4422'); g.fillRect(-u * 0.04, -u * 1.4, u * 0.08, u * 1.4); const dir = -side; g.fillStyle = pGrad(g, 0, -u * 1.35, 0, -u * 1.1, [[0, '#d9a660'], [1, '#a8743a']]); g.beginPath(); g.moveTo(-dir * u * 0.45, -u * 1.36); g.lineTo(dir * u * 0.35, -u * 1.36); g.lineTo(dir * u * 0.48, -u * 1.23); g.lineTo(dir * u * 0.35, -u * 1.1); g.lineTo(-dir * u * 0.45, -u * 1.1); g.closePath(); g.fill(); g.strokeStyle = '#5a3a1e'; g.lineWidth = u * 0.012; g.stroke(); g.font = `800 ${u * 0.09}px system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#3a2210'; g.fillText('OASIS 5 km', 0, -u * 1.23); });
    case 'neonlamp': return rSpr(key, 1.2, 2.6, 0.6, 2.5, (g, u) => { const dir = -side; g.fillStyle = '#1a1d2a'; g.fillRect(-u * 0.035, -u * 2.2, u * 0.07, u * 2.2); g.strokeStyle = '#1a1d2a'; g.lineWidth = u * 0.04; g.beginPath(); g.moveTo(0, -u * 2.15); g.quadraticCurveTo(0, -u * 2.35, dir * u * 0.4, -u * 2.33); g.stroke(); g.shadowColor = '#ffe9a0'; g.shadowBlur = u * 0.12; g.fillStyle = '#fff8d8'; roundRect(dir * u * 0.4 - u * 0.11, -u * 2.33, u * 0.22, u * 0.05, u * 0.025, g); g.fill(); g.shadowBlur = 0; g.shadowColor = '#3ff2ff'; g.shadowBlur = u * 0.06; g.fillStyle = '#3ff2ff'; g.fillRect(-u * 0.035, -u * 0.6, u * 0.07, u * 0.03); g.fillRect(-u * 0.035, -u * 1.2, u * 0.07, u * 0.03); g.shadowBlur = 0; });
    case 'fairytree': return rSpr(key, 1.8, 2.4, 0.9, 2.3, (g, u) => { tree(g, u, '#1f5a5a', '#123a3e', '#071e22', u * 1.7); const R = mulberry32(55 + v); for (let k = 0; k < 26; k++) { const a = k / 26 * TAU * 2.2, x = Math.cos(a) * u * 0.48 * (0.6 + k / 60), y = -u * 1.25 + Math.sin(a) * u * 0.22 + k * u * 0.012 - u * 0.15; const c = ['#ffe14a', '#ff4fd8', '#3ff2ff', '#7dff6a'][k % 4]; g.shadowColor = c; g.shadowBlur = u * 0.05; g.fillStyle = c; g.beginPath(); g.arc(x, y, u * 0.022, 0, TAU); g.fill(); } g.shadowBlur = 0; });
    case 'neonsign': return rSpr(key, 1.6, 2.0, 0.8, 1.95, (g, u) => {
      g.fillStyle = '#1a1d2a'; for (const px of [-0.5, 0.5]) g.fillRect(px * u - u * 0.025, -u * 1.1, u * 0.05, u * 1.1);
      g.fillStyle = 'rgba(10,10,30,0.92)'; roundRect(-u * 0.72, -u * 1.75, u * 1.44, u * 0.7, u * 0.06, g); g.fill();
      const [txt, c] = [['ARCADE', '#ff4fd8'], ['OPEN 24/7', '#3ff2ff'], ['★ RUN ★', '#ffe14a']][v % 3];
      g.strokeStyle = c; g.lineWidth = u * 0.015; g.shadowColor = c; g.shadowBlur = u * 0.06; roundRect(-u * 0.66, -u * 1.69, u * 1.32, u * 0.58, u * 0.05, g); g.stroke();
      g.font = `900 ${u * 0.22}px system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; for (let k = 0; k < 3; k++) { g.fillStyle = k === 2 ? '#ffffff' : c; g.fillText(txt, 0, -u * 1.4); } g.shadowBlur = 0; });
    case 'mushrooms': return rSpr(key, 1.0, 0.8, 0.5, 0.75, (g, u) => { for (const [dx, h, r, c] of [[-0.2, 0.32, 0.14, '#3ff2ff'], [0.1, 0.45, 0.19, '#ff4fd8'], [0.32, 0.24, 0.1, '#b46bff']]) { g.fillStyle = '#d8e0ff'; g.fillRect(dx * u - u * 0.025, -h * u, u * 0.05, h * u); g.shadowColor = c; g.shadowBlur = u * 0.1; g.fillStyle = pRad(g, dx * u, -h * u - r * u * 0.3, 0, dx * u, -h * u, r * u, [[0, '#ffffff'], [0.4, c], [1, c]]); g.beginPath(); g.ellipse(dx * u, -h * u, r * u, r * u * 0.6, 0, Math.PI, 0); g.closePath(); g.fill(); g.shadowBlur = 0; g.fillStyle = 'rgba(255,255,255,0.8)'; for (const s2 of [-0.4, 0.1, 0.5]) { g.beginPath(); g.arc(dx * u + s2 * r * u, -h * u - r * u * 0.3, u * 0.018, 0, TAU); g.fill(); } } });
  }
  return rSpr('none', 0.1, 0.1, 0, 0, () => {});
}
