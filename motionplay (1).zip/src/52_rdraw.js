/* =====================================================================
   LANE RUNNER — DRAWING & VFX (v12). Replaces the runner's old flat drawing; gameplay lives in 50_runner.js.
   ===================================================================== */
const rHash = n => { let h = Math.imul(n ^ 0x9e3779b9, 0x85ebca6b); h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35); h ^= h >>> 16; return (h >>> 0) / 4294967296; };
function rGlass(x, y, w, h, r = h * 0.25, tint = 'rgba(16,22,52,0.46)'){
  roundRect(x, y, w, h, r); ctx.fillStyle = tint; ctx.fill();
  ctx.fillStyle = pGrad(ctx, 0, y, 0, y + h, [[0, 'rgba(255,255,255,0.24)'], [0.45, 'rgba(255,255,255,0.05)'], [1, 'rgba(255,255,255,0)']]); ctx.fill();
  ctx.lineWidth = Math.max(1.5, H * 0.003); ctx.strokeStyle = 'rgba(255,255,255,0.32)'; ctx.stroke();
}

// HUD labels that rarely change are rendered once and stamped (text is slow on TV browsers)
const RTXT = new Map();
function rText(str, x, y, size, color = '#fff', align = 'center', weight = 800){
  size = Math.round(size); const key = str + '|' + size + '|' + color + '|' + weight;
  let c = RTXT.get(key);
  if (!c) {
    if (RTXT.size > 120) RTXT.clear();
    const f = `${weight} ${size}px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`; ctx.font = f;
    const w = Math.ceil(ctx.measureText(str).width + size * 0.4), h = Math.ceil(size * 1.5); c = pCanvas(w, h); const g = c.getContext('2d');
    g.font = f; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineWidth = Math.max(3, size / 9); g.strokeStyle = 'rgba(0,0,0,0.5)'; g.lineJoin = 'round'; g.strokeText(str, w / 2, h / 2); g.fillStyle = color; g.fillText(str, w / 2, h / 2);
    RTXT.set(key, c);
  }
  const dx = align === 'left' ? x - size * 0.2 : align === 'right' ? x - c.width + size * 0.2 : x - c.width / 2;
  ctx.drawImage(c, dx, y - c.height / 2);
}

Object.assign(scenes.runner, {
  artInit(){
    const R = Math.random;
    Object.assign(this, { fx:[], ghosts:[], ghostT:0, lean:0, pvel:0, sq:0, st:0, hitT:0, coinBump:0, stepSign:1, ambT:rand(3, 6), jumpBuf:0, wasDuck:false, camX:0,
      tw:[], twT:2, lastDt:1 / 60, plane:null, shoot:null, heartFx:[], loop:null, bump:0,
      motes:Array.from({ length:26 }, () => ({ x:R(), y:R(), ph:R() * TAU, v:0.5 + R() })) });
  },
  // visual-only state: camera drift, lean, squash, after-images, sky life, tumbleweeds
  stepArt(dt){
    const ex = T => 1 - Math.exp(-dt / T);
    this.camX += (this.px - this.camX) * ex(0.25);
    this.lean += (clamp(this.pvel * 0.035, -0.22, 0.22) - this.lean) * ex(0.06);
    this.sq = Math.max(0, this.sq - dt * 5); this.st = Math.max(0, this.st - dt * 4); this.hitT = Math.max(0, this.hitT - dt * 1.6); this.coinBump = Math.max(0, this.coinBump - dt * 5); this.bump = Math.max(0, this.bump - dt * 6);
    for (const g of this.ghosts) g.a -= dt * 4; this.ghosts = this.ghosts.filter(g => g.a > 0);
    this.ghostT -= dt; if (Math.abs(this.pvel) > 4 && this.ghostT <= 0) { this.ghostT = 0.03; this.ghosts.push({ px:this.px, h:this.jumpH, a:1 }); }
    for (const h of this.heartFx) h.t += dt; this.heartFx = this.heartFx.filter(h => h.t < 0.8);
    if (this.zone === 1) { if (!this.plane && Math.random() < dt * 0.06) this.plane = { x:-0.05, y:rand(0.15, 0.4), d:1, v:rand(0.02, 0.035) }; if (this.plane) { this.plane.x += this.plane.v * dt; if (this.plane.x > 1.1) this.plane = null; } } else this.plane = null;
    if (this.zone === 3) { if (!this.shoot && Math.random() < dt * 0.15) this.shoot = { x:rand(0.1, 0.7), y:rand(0.05, 0.3), vx:rand(0.2, 0.35), vy:rand(0.08, 0.18), t:0, d:rand(0.6, 1) }; if (this.shoot) { this.shoot.t += dt; if (this.shoot.t > this.shoot.d) this.shoot = null; } } else this.shoot = null;
    if (this.zone === 2 && this.state === 'play') { this.twT -= dt; if (this.twT <= 0) { this.twT = rand(2.5, 5); this.tw.push({ x:(Math.random() < 0.5 ? -1 : 1) * rand(1.9, 2.8), z:60, rot:0 }); } }
    const dz = this.state === 'play' ? this.speed * dt : 0;
    for (const w of this.tw) { w.z -= dz + dt * 3; w.rot -= dt * 5; } this.tw = this.tw.filter(w => w.z > -3);
  },
  quadF(P, x0, x1, z0, z1, h = 0, add = false){ const a = P(x0, z0, h), b = P(x1, z0, h), c = P(x1, z1, h), d = P(x0, z1, h); if (!add) ctx.beginPath(); ctx.moveTo(a.X, a.Y); ctx.lineTo(b.X, b.Y); ctx.lineTo(c.X, c.Y); ctx.lineTo(d.X, d.Y); ctx.closePath(); },
  quadW(P, x, z0, z1, h0, h1, add = false){ const a = P(x, z0, h0), b = P(x, z0, h1), c = P(x, z1, h1), d = P(x, z1, h0); if (!add) ctx.beginPath(); ctx.moveTo(a.X, a.Y); ctx.lineTo(b.X, b.Y); ctx.lineTo(c.X, c.Y); ctx.lineTo(d.X, d.Y); ctx.closePath(); },
  fade(z){ return clamp((74 - z) / 12, 0, 1); },

  /* ---------------- the world: sky, ranges, ground, road ---------------- */
  drawWorld(i, a, P){
    const A = RART[i], HOR = H * 0.36, t = this.t, cam = this.camX, RH = ROAD_HALF, Zf = 80, Zn = -2.5;
    const q = (x0, x1, z0, z1, h = 0, add = false) => this.quadF(P, x0, x1, z0, z1, h, add);
    ctx.globalAlpha = a;
    ctx.drawImage(rSkyLayer(i), 0, 0);
    if (i === 3) {   // twinkling bright stars
      ctx.globalCompositeOperation = 'lighter'; const gs = rStarSpr();
      for (let k = 0; k < 9; k++) { const tw = 0.5 + 0.5 * Math.sin(t * (1.3 + k * 0.4) + k * 2); rStamp(gs, rHash(k + 50) * W, rHash(k + 80) * HOR * 0.75, H * 0.03 * (0.6 + rHash(k + 9)), a * tw * 0.8); }
      ctx.globalCompositeOperation = 'source-over';
    }
    for (let k = 0; k < this.clouds.length; k++) { const c = this.clouds[k], cl = rCloud(A.cloud, k % 3), w = cl.width * c.s, h = cl.height * c.s; ctx.globalAlpha = a * (A.cloud === 'night' ? 0.7 : 0.95); ctx.drawImage(cl, c.x * W - w / 2 - cam * W * 0.006, c.y * H - h / 2, w, h); }
    ctx.globalAlpha = a;
    if (a > 0.5) this.drawSkyLife(i, HOR);
    ctx.globalAlpha = a;
    const m = rMidLayer(i), mx = -W * 0.1 - cam * W * 0.03; ctx.drawImage(m, mx, 0);
    if (m.wm) {   // turning windmill sails
      const cx = mx + m.wm.x, cy = m.wm.y; ctx.fillStyle = '#f4efe2'; ctx.strokeStyle = 'rgba(90,80,60,0.6)'; ctx.lineWidth = 1;
      for (let k = 0; k < 4; k++) { const an = t * 1.4 + k * Math.PI / 2, ca = Math.cos(an), sa = Math.sin(an), r = m.wm.r, wd = r * 0.16; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + ca * r - sa * wd, cy + sa * r + ca * wd); ctx.lineTo(cx + ca * r, cy + sa * r); ctx.lineTo(cx + ca * r * 0.2, cy + sa * r * 0.2); ctx.closePath(); ctx.fill(); ctx.stroke(); }
      ctx.fillStyle = '#7a5130'; ctx.beginPath(); ctx.arc(cx, cy, H * 0.004, 0, TAU); ctx.fill();
    }
    // moving field stripes / paving joints / dune ripples
    const thin = i === 1 || i === 2, bl = [3, 1.2, 1.7, 3][i], off = this.dist % (bl * 2);
    ctx.fillStyle = A.band;
    for (let z = Zf - off; z > Zn; z -= bl * 2) { const y1 = P(0, z, 0).Y, y2 = P(0, Math.max(Zn, z - (thin ? 0.2 : bl)), 0).Y; ctx.fillRect(0, y1, W, Math.max(1, y2 - y1)); }
    // city pavements
    if (A.walk) for (const sd of [-1, 1]) {
      const xa = sd < 0 ? -RH - 1.2 : RH, xb = sd < 0 ? -RH : RH + 1.2;
      q(xa, xb, Zf, Zn); ctx.fillStyle = pGrad(ctx, 0, HOR, 0, H, [[0, `rgb(${A.fog})`], [0.15, A.walk[1]], [1, A.walk[0]]]); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,0.13)'; ctx.beginPath(); const o2 = this.dist % 1.2; for (let z = 60 - o2; z > Zn; z -= 1.2) q(xa, xb, z, z + 0.06, 0, true); ctx.fill();
      q(sd < 0 ? -RH - 0.1 : RH, sd < 0 ? -RH : RH + 0.1, Zf, Zn); ctx.fillStyle = '#e1e4ea'; ctx.fill();
    }
    // the road surface
    q(-RH, RH, Zf, Zn); ctx.fillStyle = pGrad(ctx, 0, HOR, 0, H, [[0, `rgb(${A.fog})`], [0.1, `rgba(${A.glow},0.9)`], [0.2, A.road[1]], [1, A.road[0]]]); ctx.fill();   // sun/moon sheen near the horizon
    ctx.fillStyle = 'rgba(0,0,0,0.055)'; ctx.beginPath(); { const o2 = this.dist % 2; for (let z = 64 - o2; z > Zn; z -= 2) q(-RH, RH, z, z + 0.9, 0, true); } ctx.fill();
    // kerbs
    if (A.kerb) for (const sd of [-1, 1]) {
      const xa = sd < 0 ? -RH - 0.15 : RH, xb = sd < 0 ? -RH : RH + 0.15;
      q(xa, xb, Zf, 40); ctx.fillStyle = A.kerb[0]; ctx.fill();
      const o2 = this.dist % 2;
      ctx.beginPath(); for (let z = 41 - o2; z > Zn; z -= 2) q(xa, xb, Math.max(Zn, z - 1), z, 0, true); ctx.fillStyle = A.kerb[0]; ctx.fill();
      ctx.beginPath(); for (let z = 40 - o2; z > Zn; z -= 2) q(xa, xb, Math.max(Zn, z - 1), z, 0, true); ctx.fillStyle = A.kerb[1]; ctx.fill();
    }
    this.drawDecals(i, P, a);
    // inner edge shading (ambient occlusion along the kerbs)
    ctx.fillStyle = 'rgba(0,0,0,0.13)'; ctx.beginPath(); q(-RH, -RH + 0.22, Zf, Zn, 0, true); q(RH - 0.22, RH, Zf, Zn, 0, true); ctx.fill();
    // lane markings
    const dashes = (x, w, dl, gap, z0 = Zf) => { const per = dl + gap, o = this.dist % per; for (let z = z0 - o; z > Zn; z -= per) q(x - w / 2, x + w / 2, Math.max(Zn, z - dl), z, 0, true); };
    if (A.neon) {
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = 'rgba(63,242,255,0.22)'; ctx.beginPath(); for (const x of [-0.5, 0.5]) dashes(x, 0.2, 2.6, 1.4); ctx.fill();
      ctx.fillStyle = 'rgba(255,79,216,0.25)'; ctx.beginPath(); for (const x of [-RH + 0.05, RH - 0.05]) q(x - 0.11, x + 0.11, Zf, Zn, 0, true); ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = '#c8fdff'; ctx.beginPath(); for (const x of [-0.5, 0.5]) dashes(x, 0.045, 2.6, 1.4); ctx.fill();
      ctx.fillStyle = '#ffc8f2'; ctx.beginPath(); for (const x of [-RH + 0.05, RH - 0.05]) q(x - 0.025, x + 0.025, Zf, Zn, 0, true); ctx.fill();
    } else {
      ctx.fillStyle = A.line; ctx.beginPath(); for (const x of [-0.5, 0.5]) { if (A.dash) dashes(x, 0.055, 2, 2); else q(x - 0.03, x + 0.03, Zf, Zn, 0, true); } ctx.fill();
      ctx.fillStyle = A.edge; ctx.beginPath(); for (const x of [-RH + 0.08, RH - 0.08]) q(x - 0.03, x + 0.03, Zf, Zn, 0, true); ctx.fill();
    }
    // horizon haze over the road's far end
    ctx.fillStyle = pGrad(ctx, 0, HOR - H * 0.005, 0, HOR + H * 0.06, [[0, `rgba(${A.fog},0.85)`], [1, `rgba(${A.fog},0)`]]); ctx.fillRect(0, HOR - H * 0.005, W, H * 0.065);
    ctx.globalAlpha = 1;
  },
  // painted details that scroll with the road
  drawDecals(i, P, a){
    const cell = 5, base = Math.floor(this.dist / cell), RH = ROAD_HALF;
    for (let n = base + 15; n >= base; n--) {
      const z = n * cell - this.dist + 2.5; if (z > 72 || z < -2.4) continue;
      const h = rHash(n * 7 + i), h2 = rHash(n * 13 + 5), ln = [-1, 0, 1][Math.floor(h2 * 3)];
      const flat = (x, rz) => { const p = P(x, z, 0), f = P(x, z + rz, 0), b = P(x, z - rz, 0); return [p, Math.max(0.5, (b.Y - f.Y) / 2)]; };
      if (i === 0 && n % 24 === 0) {   // painted lane numbers on the running track
        for (const l of [-1, 0, 1]) { const [p, ry] = flat(l, 0.25); ctx.save(); ctx.translate(p.X, p.Y); ctx.scale(1, Math.min(1, ry / (p.s * 0.25))); ctx.font = `900 ${Math.max(6, p.s * 0.42)}px system-ui, sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.fillText(String(l + 2), 0, 0); ctx.restore(); }
      } else if (i === 1) {
        if (n % 14 === 0) { ctx.fillStyle = 'rgba(255,255,255,0.82)'; ctx.beginPath(); for (let k = 0; k < 8; k++) { const x = -RH + 0.12 + k * 0.37; this.quadF(P, x, x + 0.22, z, z + 1.3, 0, true); } ctx.fill(); }
        else if (h < 0.3) { const [p, ry] = flat(ln * 0.95, 0.22); ctx.fillStyle = '#2a2c33'; ctx.beginPath(); ctx.ellipse(p.X, p.Y, p.s * 0.22, ry, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(160,165,175,0.6)'; ctx.lineWidth = Math.max(1, p.s * 0.012); ctx.beginPath(); ctx.ellipse(p.X, p.Y, p.s * 0.16, ry * 0.72, 0, 0, TAU); ctx.stroke(); }
      } else if (i === 2) {
        if (h < 0.5) { ctx.strokeStyle = 'rgba(25,15,8,0.45)'; ctx.lineWidth = Math.max(1, P(0, z, 0).s * 0.012); ctx.beginPath(); let x = (h2 - 0.5) * 2.2; for (let k = 0; k < 5; k++) { const p = P(x, z + k * 0.45, 0); k ? ctx.lineTo(p.X, p.Y) : ctx.moveTo(p.X, p.Y); x += (rHash(n * 3 + k) - 0.5) * 0.35; } ctx.stroke(); }
        else if (h < 0.72) { const [p, ry] = flat((h2 < 0.5 ? -1 : 1) * (RH - 0.15), 0.5); ctx.fillStyle = 'rgba(236,196,135,0.55)'; ctx.beginPath(); ctx.ellipse(p.X, p.Y, p.s * 0.45, ry, 0, 0, TAU); ctx.fill(); }
      } else if (i === 3 && h < 0.4) {
        const [p, ry] = flat(ln * 0.9, 0.35); ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr(h2 < 0.5 ? '255,79,216' : '63,242,255'), p.X, p.Y, p.s * 0.9, a * 0.35, 1, ry / (p.s * 0.45)); ctx.globalCompositeOperation = 'source-over';
      }
    }
  },
  // birds, aircraft, shooting stars
  drawSkyLife(i, HOR){
    const t = this.t;
    if (i !== 3) {
      ctx.strokeStyle = i === 2 ? 'rgba(40,15,30,0.7)' : 'rgba(40,50,80,0.6)'; ctx.lineWidth = Math.max(1.5, H * 0.003); ctx.lineCap = 'round';
      for (let k = 0; k < (i === 2 ? 2 : 4); k++) {
        let bx, by; if (i === 2) { bx = W * (0.3 + k * 0.3) + Math.cos(t * 0.4 + k * 3) * W * 0.06; by = HOR * (0.35 + k * 0.1) + Math.sin(t * 0.4 + k * 3) * HOR * 0.06; }
        else { bx = ((t * 0.03 + k * 0.29) % 1.2 - 0.1) * W; by = HOR * (0.28 + k * 0.1) + Math.sin(t * 2 + k) * 4; }
        const fl = Math.sin(t * (i === 2 ? 2 : 9) + k * 2) * H * 0.008, sz = H * (i === 2 ? 0.028 : 0.018);
        ctx.beginPath(); ctx.moveTo(bx - sz, by + fl); ctx.quadraticCurveTo(bx - sz * 0.4, by - sz * 0.6, bx, by); ctx.quadraticCurveTo(bx + sz * 0.4, by - sz * 0.6, bx + sz, by + fl); ctx.stroke();
      }
    }
    if (i === 1 && this.plane) {   // an airliner with a contrail
      const p = this.plane, x = p.x * W, y = p.y * HOR;
      ctx.strokeStyle = pGrad(ctx, x - W * 0.3 * p.d, 0, x, 0, [[0, 'rgba(255,255,255,0)'], [1, 'rgba(255,255,255,0.75)']]); ctx.lineWidth = H * 0.004; ctx.beginPath(); ctx.moveTo(x - W * 0.3 * p.d, y + H * 0.004); ctx.lineTo(x, y); ctx.stroke();
      ctx.fillStyle = '#e8ecf4'; ctx.beginPath(); ctx.ellipse(x, y, H * 0.012, H * 0.0028, 0, 0, TAU); ctx.fill(); ctx.fillRect(x - H * 0.003 * p.d, y - H * 0.005, H * 0.004, H * 0.01);
      if (Math.sin(t * 9) > 0.6) { ctx.fillStyle = '#ff3b3b'; ctx.fillRect(x + H * 0.011 * p.d, y - 1, 2, 2); }
    }
    if (i === 3 && this.shoot) {
      const s2 = this.shoot, k = s2.t / s2.d, x = (s2.x + s2.vx * k) * W, y = (s2.y + s2.vy * k) * HOR;
      ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = pGrad(ctx, x - s2.vx * W * 0.12, y - s2.vy * HOR * 0.12, x, y, [[0, 'rgba(180,200,255,0)'], [1, `rgba(255,255,255,${0.9 * Math.sin(k * Math.PI)})`]]); ctx.lineWidth = H * 0.003;
      ctx.beginPath(); ctx.moveTo(x - s2.vx * W * 0.12, y - s2.vy * HOR * 0.12); ctx.lineTo(x, y); ctx.stroke(); ctx.globalCompositeOperation = 'source-over';
    }
  },
  // streaks rushing out of the vanishing point once you're quick
  drawSpeed(){
    if (this.speed < 15) return;
    const k = clamp((this.speed - 15) / 10, 0, 1), cx = W / 2, cy = H * 0.37, t = this.t;
    ctx.lineCap = 'round'; ctx.lineWidth = Math.max(1.5, H * 0.0028);
    for (let n = 0; n < 26; n++) {
      const ang = rHash(n) * TAU, ph = (t * (1.2 + k) + rHash(n + 99)) % 1, r1 = H * (0.3 + ph * ph * 0.9), r2 = r1 + H * (0.06 + 0.12 * k) * ph;
      const x1 = cx + Math.cos(ang) * r1 * 1.4, y1 = cy + Math.sin(ang) * r1 * 0.8, x2 = cx + Math.cos(ang) * r2 * 1.4, y2 = cy + Math.sin(ang) * r2 * 0.8;
      if (Math.abs(x1 - cx) < W * 0.22 && y1 > cy) continue;   // keep the runner's lane clear
      ctx.strokeStyle = `rgba(255,255,255,${0.35 * k * ph})`; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    }
  },

  /* ---------------- scene draw ---------------- */
  draw(){
    const t = this.t, P = (x, z, h) => this.proj(x, z, h);
    ctx.save();
    if (this.shake) ctx.translate(rand(-1, 1) * this.shake * 14, rand(-1, 1) * this.shake * 14);
    if (this.bump) ctx.translate(0, this.bump * H * 0.008);
    if (this.zoneBlend < 1) { this.drawWorld(this.prevZone, 1, P); this.drawWorld(this.zone, this.zoneBlend, P); } else this.drawWorld(this.zone, 1, P);
    this.drawSpeed();
    const things = [...this.obs.map(o => ({ z:o.z, o })), ...this.coins.map(c2 => ({ z:c2.z, c:c2 })), ...this.deco.map(dd => ({ z:dd.z, dd })), ...this.tw.map(w2 => ({ z:w2.z, tw:w2 })), { z:PZ, player:true }];
    if (this.arch) things.push({ z:this.arch.z + 0.01, arch:this.arch });
    things.sort((p, q) => q.z - p.z);
    for (const th of things) {
      if (th.player) this.drawPlayer(P);
      else if (th.c) this.drawCoin(P, th.c, t);
      else if (th.dd) this.drawDeco(P, th.dd, t);
      else if (th.tw) this.drawTumble(P, th.tw);
      else if (th.arch) this.drawArch(P, th.arch, t);
      else this.drawObstacle(P, th.o);
    }
    this.drawAmbient();
    for (const p of this.parts) if (p.heart) { ctx.globalAlpha = clamp(p.life / p.max, 0, 1); text('♥', p.x, p.y, p.r * 4, '#ff6b9a'); }
    ctx.globalAlpha = 1;
    drawParts(this.parts.filter(p => !p.heart), CHAR.trail > 0 && CHAR.trail !== 4 && CHAR.trail !== 8 && !(TRAIL_X[CHAR.trail] && !TRAIL_X[CHAR.trail].add));
    this.drawFx();
    drawPops(this.pops);
    ctx.restore();
    if (this.hitT > 0) { ctx.globalAlpha = clamp(this.hitT, 0, 1) * 0.8; ctx.drawImage(rVignette(true), 0, 0); ctx.globalAlpha = 1; }
    if (this.flash) { ctx.fillStyle = `rgba(255,250,220,${this.flash * 0.45})`; ctx.fillRect(0, 0, W, H); }
    this.drawHud();
  },

  /* ---------------- things along the road ---------------- */
  drawDeco(P, d, t){
    if (d.z < -3) return;
    if (d.w == null) d.w = Math.floor(Math.max(0, this.dist + d.z) / CHECK_EVERY) % RZONES.length;
    const p = P(d.x, d.z, 0), s = p.s; if (p.Y > H + s * 0.3 || s < 1.5) return;
    const kind = rDecoKind(d.w, d.k), v = Math.floor(d.k * 1000) % 3, a = this.fade(d.z);
    rStamp(rShadowSpr(), p.X + s * 0.12, p.Y, s * (kind === 'hydrant' || kind === 'mushrooms' ? 0.5 : 1), a * 0.7);
    rStamp(rDecoSpr(kind, v, d.side), p.X, p.Y, s, a);
    if (kind === 'neonlamp' || (kind === 'lamp' && d.w === 3)) {
      const lx = p.X - d.side * s * 0.4, ly = p.Y - s * 2.31, pool = P(d.x - d.side * 0.4, d.z, 0);
      ctx.globalCompositeOperation = 'lighter';
      rStamp(rGlowSpr('255,226,150'), lx, ly, s * 1.1, a * (0.75 + 0.05 * Math.sin(t * 13 + d.k * 40)));
      rStamp(rGlowSpr('255,214,130'), pool.X, pool.Y, s * 2.2, a * 0.45, 1, 0.28);
      ctx.globalCompositeOperation = 'source-over';
    } else if (d.w === 3 && (kind === 'neonsign' || kind === 'mushrooms' || kind === 'fairytree')) {
      ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr(kind === 'neonsign' ? ['255,79,216', '63,242,255', '255,225,74'][v] : '120,200,255'), p.X, p.Y - s * (kind === 'neonsign' ? 1.4 : kind === 'mushrooms' ? 0.35 : 1.2), s * 1.6, a * (0.3 + 0.08 * Math.sin(t * 3 + d.k * 20))); ctx.globalCompositeOperation = 'source-over';
    }
  },
  drawTumble(P, w){
    const p = P(w.x, w.z, 0.28), s = p.s; if (p.Y > H + s || s < 2) return;
    const a = this.fade(w.z), sp = rSpr('tumble', 0.7, 0.7, 0.35, 0.35, (g, u) => { g.strokeStyle = '#8a6a3a'; g.lineWidth = u * 0.018; const R = mulberry32(8); for (let k = 0; k < 26; k++) { g.beginPath(); const a0 = R() * TAU; g.arc((R() - 0.5) * u * 0.1, (R() - 0.5) * u * 0.1, u * (0.12 + R() * 0.16), a0, a0 + 1.2 + R() * 2); g.stroke(); } g.strokeStyle = '#c9a66a'; g.lineWidth = u * 0.01; for (let k = 0; k < 14; k++) { g.beginPath(); const a0 = R() * TAU; g.arc(0, 0, u * (0.08 + R() * 0.2), a0, a0 + 1.5); g.stroke(); } });
    const sh = P(w.x, w.z, 0); rStamp(rShadowSpr(), sh.X, sh.Y, s * 0.5, a * 0.6);
    ctx.save(); ctx.translate(p.X, p.Y - Math.abs(Math.sin(w.rot * 1.5)) * s * 0.12); ctx.rotate(w.rot); rStamp(sp, 0, 0, s, a); ctx.restore();
  },
  drawObstacle(P, o){
    if (o.z < -3) return;
    // once it's behind the runner it fades away instead of filling the screen
    const behind = clamp((o.z - (PZ - 2.2)) / 1.6, 0, 1), sameLane = Math.abs(o.lane - this.px) < 0.6;
    const a = this.fade(o.z) * (o.type === 'block' && !sameLane ? 1 : behind), g0 = P(o.lane, o.z, 0), s = g0.s, t = this.t, night = this.zone === 3;
    if (a <= 0.01) return;
    if (o.type === 'block') { this.drawTrain(P, o, a, night); return; }
    rStamp(rShadowSpr(), g0.X + s * 0.06, g0.Y, s * 0.95, a * 0.8);
    if (o.type === 'low') {
      if (o.hit) o.fall = Math.min(1.35, (o.fall || 0) + this.lastDt * 6);
      const ky = Math.cos(o.fall || 0);
      rStamp(rBarrierSpr(), g0.X, g0.Y, s, a, 1, ky);
      const on = Math.sin(t * 10 + o.z) > 0, ly = g0.Y - s * 0.62 * ky;
      ctx.fillStyle = on ? '#ffd23f' : '#8a6a10'; ctx.beginPath(); ctx.arc(g0.X, ly, s * 0.035, Math.PI, 0); ctx.fill();
      if (on) { ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr('255,190,60'), g0.X, ly, s * 0.5, a * (night ? 0.9 : 0.6)); ctx.globalCompositeOperation = 'source-over'; }
    } else {
      rStamp(rGantrySpr(), g0.X, g0.Y, s, a);
      for (const sd of [-1, 1]) {
        const on = Math.sin(t * 9 + sd * 1.57) > 0, lx = g0.X + sd * s * 0.5, ly = g0.Y - s * 1.83;
        ctx.fillStyle = on ? '#ff3b3b' : '#6a1010'; ctx.beginPath(); ctx.arc(lx, ly, s * 0.04, 0, TAU); ctx.fill();
        if (on) { ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr('255,60,50'), lx, ly, s * 0.7, a * (night ? 0.9 : 0.65)); ctx.globalCompositeOperation = 'source-over'; }
      }
    }
  },
  drawTrain(P, o, a, night){
    const len = 3.2, hgt = 1.5, x0 = o.lane - 0.45, x1 = o.lane + 0.45, z = o.z;
    if (o.tv == null) o.tv = (Math.random() * RTRAIN.length) | 0;
    const [c0, c1, c2] = RTRAIN[o.tv];
    ctx.globalAlpha = a;
    // headlight beams washing over the road ahead of it
    if (z > PZ - 1) {
      ctx.globalCompositeOperation = 'lighter';
      const fa = P(x0 + 0.12, z, 0), fb = P(x1 - 0.12, z, 0), na = P(x0 - 0.25, Math.max(-2, z - 7), 0), nb = P(x1 + 0.25, Math.max(-2, z - 7), 0);
      ctx.fillStyle = pGrad(ctx, 0, fa.Y, 0, na.Y, [[0, `rgba(255,245,210,${night ? 0.38 : 0.2})`], [1, 'rgba(255,245,210,0)']]);
      ctx.beginPath(); ctx.moveTo(fa.X, fa.Y); ctx.lineTo(fb.X, fb.Y); ctx.lineTo(nb.X, nb.Y); ctx.lineTo(na.X, na.Y); ctx.closePath(); ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
    }
    this.quadF(P, x0 - 0.08, x1 + 0.1, z - 0.05, z + len + 0.2, 0); ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fill();
    if (o.lane !== 0) {   // the side you can see
      const sx = o.lane < 0 ? x1 : x0, top = P(sx, z, hgt), bot = P(sx, z, 0);
      this.quadW(P, sx, z, z + len, 0.15, hgt); ctx.fillStyle = pGrad(ctx, 0, top.Y, 0, bot.Y, [[0, c0], [0.6, c1], [1, '#20242c']]); ctx.fill();
      this.quadW(P, sx, z, z + len, 0, 0.18); ctx.fillStyle = '#16181f'; ctx.fill();
      this.quadW(P, sx, z, z + len, 0.5, 0.58); ctx.fillStyle = c2; ctx.fill();
      this.quadW(P, sx, z, z + len, 0.6, 0.63); ctx.fillStyle = '#ffffff'; ctx.fill();
      ctx.beginPath(); for (let k = 0; k < 3; k++) { const za = z + len * (0.07 + k * 0.32), zb = za + len * 0.22; this.quadW(P, sx, za, zb, 0.82, 1.3, true); } ctx.fillStyle = '#121a2a'; ctx.fill();
      ctx.beginPath(); for (let k = 0; k < 3; k++) { const za = z + len * (0.07 + k * 0.32); this.quadW(P, sx, za, za + len * 0.07, 0.95, 1.3, true); } ctx.fillStyle = 'rgba(190,225,255,0.3)'; ctx.fill();
      ctx.beginPath(); for (const zz of [z + 0.35, z + len - 0.9]) this.quadW(P, sx, zz, zz + 0.55, 0, 0.22, true); ctx.fillStyle = '#0a0b10'; ctx.fill();
      this.quadW(P, sx, z, z + len, 0.15, hgt); ctx.fillStyle = 'rgba(0,0,10,0.18)'; ctx.fill();
    }
    // roof with a couple of cooling units
    { const r0 = P(x0, z, hgt), r1 = P(x0, z + len, hgt); this.quadF(P, x0, x1, z, z + len, hgt); ctx.fillStyle = pGrad(ctx, 0, r1.Y, 0, r0.Y, [[0, '#c9d1de'], [1, '#8d97a8']]); ctx.fill(); }
    ctx.beginPath(); this.quadF(P, x0 + 0.18, x1 - 0.18, z + 0.5, z + 1.2, hgt + 0.01, true); this.quadF(P, x0 + 0.18, x1 - 0.18, z + 1.9, z + 2.6, hgt + 0.01, true); ctx.fillStyle = '#6b7487'; ctx.fill();
    // the nose
    const f0 = P(x0, z, 0), f1 = P(x1, z, hgt), fw = f1.X - f0.X, fh = f0.Y - f1.Y;
    if (fw > 1) {
      ctx.drawImage(rTrainFront(o.tv).c, f0.X, f1.Y, fw, fh);
      ctx.globalCompositeOperation = 'lighter';
      for (const hx of [0.2, 0.8]) rStamp(rGlowSpr('255,240,200'), f0.X + fw * hx, f1.Y + fh * 0.74, fw * (night ? 1.0 : 0.6), a * (night ? 0.95 : 0.7));
      ctx.globalCompositeOperation = 'source-over';
    }
    ctx.globalAlpha = 1;
  },
  drawCoin(P, c, t){
    if (c.z < -1) return;
    const p = P(c.lane, c.z, c.h + Math.sin(t * 4 + c.z) * 0.05), r = p.s * 0.16, a = this.fade(c.z), sS = r / 0.18 * 1.0;
    const ang = t * 4 + c.z * 0.5, cs = Math.cos(ang), sq = Math.abs(cs), dir = cs >= 0 ? 1 : -1;
    ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr('255,200,70'), p.X, p.Y, p.s * 0.75, a * (this.zone === 3 ? 0.6 : 0.4)); ctx.globalCompositeOperation = 'source-over';
    rStamp(rCoinEdge(), p.X - dir * r * 0.1 * (1 - sq), p.Y, sS, a, Math.max(0.16, sq));
    rStamp(rCoinSpr(), p.X + dir * r * 0.03 * (1 - sq), p.Y, sS, a, Math.max(0.05, sq));
    if (sq > 0.92 && (Math.floor(t * 1.5 + c.z * 0.3) % 3 === 0)) { ctx.globalCompositeOperation = 'lighter'; rStamp(rStarSpr(), p.X - r * 0.4, p.Y - r * 0.45, p.s * 0.35, a * (sq - 0.92) * 12); ctx.globalCompositeOperation = 'source-over'; }
  },
  drawArch(P, ar, t){
    if (ar.z < -3) return;
    const z = ar.z, a = this.fade(z), RH = ROAD_HALF;
    ctx.globalAlpha = a;
    // chequered line across the road
    const n = 14, cw = RH * 2 / n;
    for (const [col, odd] of [['#ffffff', 0], ['#15161c', 1]]) { ctx.fillStyle = col; ctx.beginPath(); for (let k = 0; k < n; k++) for (let r = 0; r < 2; r++) if ((k + r) % 2 === odd) this.quadF(P, -RH + k * cw, -RH + (k + 1) * cw, z + r * 0.35, z + (r + 1) * 0.35, 0, true); ctx.fill(); }
    // inflatable balloon arch with chasing colours
    const pts = [], X0 = -RH - 0.3, X1 = RH + 0.3, CH = 2.1, TOP = 3.0;
    for (let k = 0; k <= 8; k++) pts.push([X0, k / 8 * CH]);
    for (let k = 1; k < 16; k++) { const an = Math.PI - k / 16 * Math.PI; pts.push([Math.cos(an) * (X1 - X0) / 2, CH + Math.sin(an) * (TOP - CH)]); }
    for (let k = 8; k >= 0; k--) pts.push([X1, k / 8 * CH]);
    const base = P(0, z, 0), bs = base.s * 0.24 / 0.18, chase = Math.floor(t * 6);
    for (let k = 0; k < pts.length; k++) { const p = P(pts[k][0], z, pts[k][1]); rStamp(rBalloonSpr(ar.got ? 1 : (k + chase) % 4), p.X, p.Y, bs, a); }
    // banner
    const bc = P(0, z, CH + 0.05), bw = base.s * 2.3, bh = base.s * 0.55;
    if (bw > 6) {
      ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr(ar.got ? '120,255,160' : '255,220,90'), bc.X, bc.Y, bw * 1.3, a * (0.45 + 0.15 * Math.sin(t * 8))); ctx.globalCompositeOperation = 'source-over';
      roundRect(bc.X - bw / 2, bc.Y - bh / 2, bw, bh, bh * 0.3); ctx.fillStyle = pGrad(ctx, 0, bc.Y - bh / 2, 0, bc.Y + bh / 2, ar.got ? [[0, '#7dffb0'], [1, '#1f9a55']] : [[0, '#fff2a0'], [0.5, '#ffc21a'], [1, '#d98a00']]); ctx.fill();
      ctx.lineWidth = Math.max(1.5, bh * 0.07); ctx.strokeStyle = '#fff'; ctx.stroke();
      text(ar.got ? '+10 ●' : 'CHECKPOINT', bc.X, bc.Y + bh * 0.03, Math.max(6, bh * 0.52), ar.got ? '#ffffff' : '#5a2c00', 'center', 900);
      for (const sd of [-1, 1]) { const fp = P(sd * (X1 - 0.05), z, CH + 0.15), fs = base.s; ctx.strokeStyle = '#e9e4d8'; ctx.lineWidth = Math.max(1, fs * 0.02); ctx.beginPath(); ctx.moveTo(fp.X, fp.Y); ctx.lineTo(fp.X, fp.Y - fs * 0.5); ctx.stroke(); ctx.fillStyle = sd < 0 ? '#ff3b5c' : '#2f7cf6'; ctx.beginPath(); ctx.moveTo(fp.X, fp.Y - fs * 0.5); ctx.quadraticCurveTo(fp.X + fs * 0.15, fp.Y - fs * (0.46 + Math.sin(t * 8 + sd) * 0.04), fp.X + fs * 0.3, fp.Y - fs * 0.42); ctx.lineTo(fp.X, fp.Y - fs * 0.3); ctx.closePath(); ctx.fill(); }
    }
    ctx.globalAlpha = 1;
  },

  /* ---------------- the runner: drawn offscreen, then lit for the world it's in ---------------- */
  // re-lit at ~30 Hz (or at once when the pose or size changes); it still moves every frame
  charSprite(s, pose){
    const cw = Math.ceil(s * 1.9), ch = Math.ceil(s * 2.15), ox = cw / 2, oy = s * 1.9;
    let C = this._cc; if (!C || C.w !== cw || C.h !== ch) C = this._cc = { w:cw, h:ch, c:pCanvas(cw, ch), rim:pCanvas(cw, ch), key:'' };
    const key = (pose.duck ? 'd' : '') + (pose.air ? 'a' : '') + this.zone + JSON.stringify(CHAR);
    if (C.key === key && C.t === Math.floor(this.t * 30)) return { c:C.c, rim:C.rim, ox, oy };
    C.key = key; C.t = Math.floor(this.t * 30);
    const g = C.c.getContext('2d'), A = RART[this.zone];
    g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1; g.clearRect(0, 0, cw, ch);
    drawChar(ox, oy, s, pose, g);
    const dirX = A.sun[0] > 0.5 ? 1 : -1;
    // one pass of light: dark on the shadow side, lighter towards the sun, plus the world's colour cast
    g.globalCompositeOperation = 'source-atop';
    g.fillStyle = pGrad(g, ox - dirX * s * 0.5, oy, ox + dirX * s * 0.45, oy - s * 1.2, [[0, 'rgba(10,14,40,0.42)'], [0.5, 'rgba(10,14,40,0.07)'], [1, 'rgba(255,255,255,0.12)']]); g.fillRect(0, 0, cw, ch);
    if (A.tint) { g.fillStyle = A.tint; g.fillRect(0, 0, cw, ch); }
    g.globalCompositeOperation = 'source-over';
    // rim light: the silhouette minus a copy nudged away from the sun
    const rg = C.rim.getContext('2d'), d = Math.max(1.5, s * 0.02);
    rg.globalCompositeOperation = 'copy'; rg.drawImage(C.c, 0, 0);
    rg.globalCompositeOperation = 'source-in'; rg.fillStyle = `rgba(${A.rim},0.95)`; rg.fillRect(0, 0, cw, ch);
    rg.globalCompositeOperation = 'destination-out'; rg.drawImage(C.c, -d * dirX, d * 0.7);
    rg.globalCompositeOperation = 'source-over';
    return { c:C.c, rim:C.rim, ox, oy };
  },
  drawPlayer(P){
    const ducking = this.duckT > 0 && this.jumpT < 0, blink = this.inv > 0 && Math.floor(this.inv * 10) % 2;
    const sh = P(this.px, PZ, 0), s = sh.s;
    rStamp(rShadowSpr(), sh.X, sh.Y, s * 0.75 / (1 + this.jumpH * 0.7), 1 / (1 + this.jumpH * 1.2));
    const runOn = this.state === 'play' && this.jumpT < 0 && !ducking;
    const run = runOn ? Math.sin(this.t * 16) : 0, bob = runOn ? Math.abs(Math.cos(this.t * 16)) * s * 0.03 : 0;
    const base = P(this.px, PZ, this.jumpH);
    const spr = this.charSprite(s, { run, duck:ducking, air:this.jumpT >= 0, t:this.t });
    const sy = 1 - 0.16 * this.sq + 0.1 * this.st, sx = 1 + 0.13 * this.sq - 0.06 * this.st;
    for (const gh of this.ghosts) {   // after-images while switching lanes
      const gp = P(gh.px, PZ, gh.h); ctx.globalAlpha = gh.a * 0.35 * (blink ? 0.4 : 1); ctx.drawImage(spr.c, gp.X - spr.ox, gp.Y - spr.oy);
    }
    ctx.globalAlpha = blink ? 0.35 : 1;
    ctx.save(); ctx.translate(base.X, base.Y - bob); ctx.rotate(this.lean); ctx.scale(sx, sy);
    ctx.drawImage(spr.c, -spr.ox, -spr.oy);
    ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = (blink ? 0.3 : 0.85); ctx.drawImage(spr.rim, -spr.ox, -spr.oy);
    ctx.restore(); ctx.globalAlpha = 1;
    if (this.inv > 0) { ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr('255,80,110'), base.X, base.Y - s * 0.6, s * 1.6, 0.25 * Math.min(1, this.inv)); ctx.globalCompositeOperation = 'source-over'; }
  },

  /* ---------------- effects ---------------- */
  feet(){ const p = this.proj(this.px, PZ, this.jumpH); return p; },
  kick(n, spd = 1, up = 1){
    const p = this.feet(), cols = RART[this.zone].dust, night = this.zone === 3;
    for (let k = 0; k < n; k++) this.fx.push({ k:night ? 'spark' : 'puff', x:p.X + rand(-0.18, 0.18) * p.s, y:p.Y - rand(0, 0.04) * p.s, vx:rand(-0.6, 0.6) * p.s * spd, vy:-rand(0.1, 0.7) * p.s * up, r:p.s * rand(0.04, 0.09) * (night ? 0.5 : 1), c:pick(cols), life:rand(0.35, 0.6), max:0.6, g:0.6 * p.s, grow:1.6 });
  },
  ring(c = 'rgba(255,255,255,0.8)', r1 = 0.7, life = 0.4){ const p = this.feet(); this.fx.push({ k:'ring', x:p.X, y:p.Y, r:p.s * 0.1, r1:p.s * r1, c, life, max:life, w:p.s * 0.035 }); },
  laneFx(dir){
    const p = this.feet(), cols = RART[this.zone].dust;
    for (let k = 0; k < 7; k++) this.fx.push({ k:'puff', x:p.X - dir * p.s * 0.1, y:p.Y, vx:-dir * rand(0.6, 1.4) * p.s, vy:-rand(0.1, 0.5) * p.s, r:p.s * rand(0.03, 0.07), c:pick(cols), life:0.4, max:0.4, g:0.5 * p.s, grow:1.4 });
    for (let k = 0; k < 4; k++) this.fx.push({ k:'streak', x:p.X - dir * p.s * 0.3, y:p.Y - p.s * rand(0.3, 1.2), vx:-dir * p.s * 3, vy:0, len:p.s * rand(0.3, 0.6), c:'rgba(255,255,255,0.6)', life:0.22, max:0.22 });
  },
  hitFx(o){
    const p = this.proj(o.lane, PZ + 0.3, 0.8), s = p.s;
    this.hitT = 1; this.heartFx.push({ i:this.lives, t:0 });
    const cols = o.type === 'low' ? ['#e1202f', '#ffffff', '#c9ced8'] : o.type === 'high' ? ['#ffcc1a', '#16161c', '#aeb5c2'] : ['#bfe0ff', '#ffffff', RTRAIN[o.tv || 0][0]];
    for (let k = 0; k < 22; k++) this.fx.push({ k:'chunk', x:p.X + rand(-0.4, 0.4) * s, y:p.Y + rand(-0.4, 0.4) * s, vx:rand(-2.5, 2.5) * s, vy:-rand(0.8, 3) * s, w:s * rand(0.04, 0.12), h:s * rand(0.03, 0.08), rot:rand(0, TAU), vr:rand(-12, 12), c:pick(cols), life:rand(0.6, 1.1), max:1.1, g:5 * s });
    for (let k = 0; k < 16; k++) { const an = rand(0, TAU), v = rand(1.5, 4) * s; this.fx.push({ k:'spark', x:p.X, y:p.Y, vx:Math.cos(an) * v, vy:Math.sin(an) * v - s, r:s * rand(0.015, 0.035), c:pick(['#fff3b0', '#ffb040', '#ffffff']), life:rand(0.3, 0.6), max:0.6, g:3 * s }); }
    this.fx.push({ k:'flashring', x:p.X, y:p.Y, r:s * 0.2, r1:s * 1.6, life:0.35, max:0.35 });
  },
  coinFx(c){
    const p = this.proj(c.lane, c.z, c.h);
    this.fx.push({ k:'coinfly', x:p.X, y:p.Y, x0:p.X, y0:p.Y, s:p.s * 0.16 / 0.18, life:0.55, max:0.55 });
    this.fx.push({ k:'ring', x:p.X, y:p.Y, r:p.s * 0.08, r1:p.s * 0.5, c:'rgba(255,225,110,0.9)', life:0.3, max:0.3, w:p.s * 0.03, round:true });
    for (let k = 0; k < 8; k++) { const an = k / 8 * TAU, v = p.s * rand(1, 1.8); this.fx.push({ k:'spark', x:p.X, y:p.Y, vx:Math.cos(an) * v, vy:Math.sin(an) * v, r:p.s * 0.025, c:pick(['#fff6b0', '#ffd23f', '#ffffff']), life:0.35, max:0.35, g:0 }); }
    this.fx.push({ k:'glint', x:p.X, y:p.Y, s:p.s * 0.7, life:0.3, max:0.3 });
  },
  niceFx(){ const p = this.proj(this.px, PZ, 0.8); this.fx.push({ k:'ring', x:p.X, y:p.Y, r:p.s * 0.3, r1:p.s * 1.1, c:'rgba(120,255,170,0.85)', life:0.35, max:0.35, w:p.s * 0.04, round:true }); },
  checkFx(){
    const cols = ['#ffe14a', '#4fd27a', '#5b8cff', '#ff6b5a', '#ff4fd8', '#ffffff', '#3ff2ff'];
    for (let k = 0; k < 7; k++) this.fx.push({ k:'rocket', x:W * (0.12 + k * 0.127), y:H * 0.8, vx:rand(-0.04, 0.04) * W, vy:-H * rand(0.8, 1.0), c:pick(cols), life:rand(0.55, 0.7), max:0.7, delay:k * 0.14 + rand(0, 0.08) });
    for (let k = 0; k < 110; k++) this.fx.push({ k:'conf', x:rand(0, W), y:-rand(0, H * 0.5), vx:rand(-0.05, 0.05) * W, vy:rand(0.15, 0.35) * H, w:H * rand(0.008, 0.016), h:H * rand(0.004, 0.009), rot:rand(0, TAU), vr:rand(-8, 8), c:pick(cols), life:rand(2, 3.2), max:3.2, ph:rand(0, TAU) });
  },
  stepFx(dt){
    const out = [];
    for (const f of this.fx) {
      if (f.delay > 0) { f.delay -= dt; out.push(f); continue; }
      f.life -= dt; if (f.life <= 0) {
        if (f.k === 'rocket') { const n = 44; for (let k = 0; k < n; k++) { const an = k / n * TAU + rand(-0.05, 0.05), v = H * rand(0.35, 0.6) * (k % 2 ? 1 : 0.7); out.push({ k:'spark', x:f.x, y:f.y, vx:Math.cos(an) * v, vy:Math.sin(an) * v, r:H * rand(0.005, 0.009), c:Math.random() < 0.25 ? '#ffffff' : f.c, life:rand(0.8, 1.3), max:1.3, g:H * 0.3, drag:1.4 }); } out.push({ k:'flashring', x:f.x, y:f.y, r:H * 0.01, r1:H * 0.16, life:0.3, max:0.3 }); }
        if (f.k === 'coinfly') this.coinBump = 1;
        continue;
      }
      if (f.k === 'coinfly') { const u = 1 - f.life / f.max, e = u * u * (3 - 2 * u), tx = W * 0.05, ty = H * 0.175; f.x = lerp(f.x0, tx, e) + Math.sin(u * Math.PI) * W * 0.04; f.y = lerp(f.y0, ty, e) - Math.sin(u * Math.PI) * H * 0.12; out.push(f); continue; }
      if (f.vx !== undefined) { if (f.drag) { f.vx *= 1 - f.drag * dt; f.vy *= 1 - f.drag * dt; } f.x += f.vx * dt; f.y += f.vy * dt; if (f.g) f.vy += f.g * dt; }
      if (f.k === 'puff') { f.vx *= 1 - 3 * dt; f.vy *= 1 - 3 * dt; f.r *= 1 + (f.grow || 1) * dt; }
      if (f.k === 'rocket' && Math.random() < 0.8) out.push({ k:'spark', x:f.x, y:f.y, vx:rand(-0.02, 0.02) * W, vy:H * 0.05, r:H * 0.003, c:'#ffd9a0', life:0.3, max:0.3, g:0 });
      if (f.k === 'conf') { f.x += Math.sin(this.t * 3 + f.ph) * W * 0.08 * dt; }
      if (f.rot !== undefined) f.rot += f.vr * dt;
      out.push(f);
    }
    this.fx = out.length > 700 ? out.slice(out.length - 700) : out;
  },
  drawFx(){
    for (const f of this.fx) {
      if (f.delay > 0) continue;
      const u = clamp(f.life / f.max, 0, 1);
      switch (f.k) {
        case 'puff': ctx.globalAlpha = u * 0.8; ctx.fillStyle = f.c; ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, TAU); ctx.fill(); break;
        case 'spark': ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = Math.min(1, u * 1.5); ctx.fillStyle = f.c; ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, TAU); ctx.fill(); rStamp(rGlowSpr('255,230,170'), f.x, f.y, f.r * 7, u * 0.35); ctx.globalCompositeOperation = 'source-over'; break;
        case 'ring': { const r = lerp(f.r1, f.r, u); ctx.globalAlpha = u; ctx.strokeStyle = f.c; ctx.lineWidth = Math.max(1, f.w * u); ctx.beginPath(); ctx.ellipse(f.x, f.y, r, f.round ? r : r * 0.28, 0, 0, TAU); ctx.stroke(); break; }
        case 'flashring': { const r = lerp(f.r1, f.r, u); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = u; ctx.fillStyle = pRad(ctx, f.x, f.y, 0, f.x, f.y, r, [[0, 'rgba(255,255,230,0.9)'], [0.5, 'rgba(255,200,120,0.35)'], [1, 'rgba(255,150,80,0)']]); ctx.beginPath(); ctx.arc(f.x, f.y, r, 0, TAU); ctx.fill(); ctx.globalCompositeOperation = 'source-over'; break; }
        case 'streak': ctx.globalAlpha = u; ctx.strokeStyle = f.c; ctx.lineWidth = Math.max(1, H * 0.003); ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(f.x - Math.sign(f.vx || 1) * f.len, f.y); ctx.stroke(); break;
        case 'chunk': case 'conf': ctx.globalAlpha = Math.min(1, u * 2); ctx.save(); ctx.translate(f.x, f.y); ctx.rotate(f.rot); ctx.scale(1, f.k === 'conf' ? Math.cos(f.rot * 1.7) : 1); ctx.fillStyle = f.c; ctx.fillRect(-f.w / 2, -f.h / 2, f.w, f.h); ctx.restore(); break;
        case 'rocket': ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 1; rStamp(rGlowSpr('255,220,160'), f.x, f.y, H * 0.05, 0.9); ctx.globalCompositeOperation = 'source-over'; break;
        case 'glint': ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 1; rStamp(rStarSpr(), f.x, f.y, f.s * (1.4 - u * 0.4), u); ctx.globalCompositeOperation = 'source-over'; break;
        case 'coinfly': { const sc = lerp(H * 0.13, f.s, u); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr('255,210,80'), f.x, f.y, sc * 1.4, 0.6); ctx.globalCompositeOperation = 'source-over'; rStamp(rCoinSpr(), f.x, f.y, sc, 1, Math.abs(Math.cos(this.t * 14))); break; }
      }
    }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  },
  // fireflies at night, butterflies and pollen in the meadow, blowing sand in the desert
  drawAmbient(){
    const t = this.t, z = this.zone;
    if (z === 3) { ctx.globalCompositeOperation = 'lighter'; const gl = rGlowSpr('200,255,140'); for (const m of this.motes) { const x = (m.x + Math.sin(t * 0.3 * m.v + m.ph) * 0.03) * W, y = H * (0.42 + m.y * 0.45) + Math.sin(t * 0.8 * m.v + m.ph * 2) * H * 0.02; if (Math.abs(x - W / 2) < W * 0.2) continue; rStamp(gl, x, y, H * 0.04, 0.4 + 0.4 * Math.sin(t * 2 * m.v + m.ph)); } ctx.globalCompositeOperation = 'source-over'; }
    else if (z === 0) {
      ctx.globalCompositeOperation = 'lighter'; const gl = rGlowSpr('255,250,220'); for (let k = 0; k < 14; k++) { const m = this.motes[k], x = ((m.x + t * 0.01 * m.v) % 1) * W, y = H * (0.35 + m.y * 0.4) + Math.sin(t * m.v + m.ph) * H * 0.02; rStamp(gl, x, y, H * 0.012, 0.5); } ctx.globalCompositeOperation = 'source-over';
      for (let k = 0; k < 3; k++) { const m = this.motes[k + 20], side = k % 2 ? 1 : -1, x = W / 2 + side * W * (0.3 + 0.1 * Math.sin(t * 0.5 + m.ph)), y = H * (0.5 + m.y * 0.15) + Math.sin(t * 1.3 + m.ph) * H * 0.04, fl = Math.abs(Math.sin(t * 14 + m.ph)), sz = H * 0.014;
        ctx.fillStyle = ['#ff9ad8', '#ffd23f', '#8fdcff'][k]; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.ellipse(x + sd * sz * 0.6 * fl, y, sz * 0.7 * fl + 1, sz, sd * 0.4, 0, TAU); ctx.fill(); } ctx.fillStyle = '#2a1b12'; ctx.fillRect(x - 1, y - sz * 0.6, 2, sz * 1.2); }
    } else if (z === 2) {
      ctx.strokeStyle = 'rgba(255,220,170,0.25)'; ctx.lineWidth = Math.max(1, H * 0.002); ctx.beginPath();
      for (const m of this.motes) { const x = ((m.x + t * 0.25 * m.v) % 1.1 - 0.05) * W, y = H * (0.55 + m.y * 0.42); ctx.moveTo(x, y); ctx.lineTo(x - W * 0.04 * m.v, y + H * 0.004); }
      ctx.stroke();
    }
  },

  /* ---------------- HUD ---------------- */
  drawHud(){
    const t = this.t, sc = Math.floor(this.dist) + this.coinN * 10;
    const px0 = W * 0.025, py0 = H * 0.03, pw = Math.min(W * 0.4, Math.max(W * 0.25, H * 0.44)), ph = H * 0.29;
    rGlass(px0, py0, pw, ph, H * 0.03);
    const pad = H * 0.025;
    rText('SCORE', px0 + pad, py0 + H * 0.03, H * 0.022, 'rgba(255,255,255,0.75)', 'left', 800);
    text(String(sc), px0 + pad, py0 + H * 0.078, H * 0.065, pGrad(ctx, 0, py0 + H * 0.05, 0, py0 + H * 0.11, [[0, '#ffffff'], [1, '#bfe3ff']]), 'left', 900);
    text(`${Math.floor(this.dist)} m`, px0 + pw - pad, py0 + H * 0.035, H * 0.026, '#c9e6ff', 'right', 800);
    // coins: a spinning coin and a counter that bumps as coins fly in
    const cy = py0 + H * 0.145, cb = 1 + this.coinBump * 0.35;
    ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr('255,200,70'), px0 + pad + H * 0.02, cy, H * 0.09 * cb, 0.35 + this.coinBump * 0.4); ctx.globalCompositeOperation = 'source-over';
    rStamp(rCoinSpr(), px0 + pad + H * 0.02, cy, H * 0.13 * cb, 1, 0.45 + 0.55 * Math.abs(Math.cos(t * 2.5)));
    (cb > 1.01 ? text : rText)(String(this.coinN), px0 + pad + H * 0.05, cy, H * 0.045 * cb, '#ffd23f', 'left', 900);
    if (!this.vs) rText(`wallet ${WALLET.coins + this.coinN}`, px0 + pw - pad, cy, H * 0.022, '#ffe9a8', 'right', 700);
    rText('BEST ' + this.best, px0 + pad, py0 + H * 0.195, H * 0.022, 'rgba(255,255,255,0.8)', 'left', 800);
    // checkpoint progress
    const pr = clamp(1 - (this.nextCheck - this.dist) / CHECK_EVERY, 0, 1), bx = px0 + pad, by = py0 + H * 0.235, bw = pw - pad * 2 - H * 0.04, bh = H * 0.016;
    roundRect(bx, by, bw, bh, bh / 2); ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fill();
    if (pr > 0) { roundRect(bx, by, Math.max(bh, bw * pr), bh, bh / 2); ctx.fillStyle = pGrad(ctx, bx, 0, bx + bw, 0, [[0, '#ffe14a'], [0.6, '#ffb000'], [1, '#ff6b3d']]); ctx.fill();
      ctx.save(); roundRect(bx, by, Math.max(bh, bw * pr), bh, bh / 2); ctx.clip(); const shx = bx + ((t * 0.6) % 1.4 - 0.2) * bw; ctx.fillStyle = pGrad(ctx, shx - bw * 0.1, 0, shx + bw * 0.1, 0, [[0, 'rgba(255,255,255,0)'], [0.5, 'rgba(255,255,255,0.6)'], [1, 'rgba(255,255,255,0)']]); ctx.fillRect(bx, by, bw, bh); ctx.restore(); }
    rText('⚑', bx + bw + H * 0.022, by + bh / 2, H * 0.032, '#ffe14a');
    rText(`next: ${RZONES[(this.zone + 1) % RZONES.length].name} · ${Math.max(0, Math.ceil((this.nextCheck - this.dist) / 10) * 10)} m`, bx, by + H * 0.032, H * 0.018, 'rgba(255,255,255,0.7)', 'left', 700);
    // hearts (the last one beats when it's all you have)
    for (let i = 0; i < 3; i++) {
      const on = i < this.lives, hx = W - H * (0.07 + (2 - i) * 0.085), hy = H * 0.075, beat = on && this.lives === 1 ? 1 + 0.12 * Math.max(0, Math.sin(t * 9)) : 1;
      if (on) { ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr('255,60,100'), hx, hy, H * 0.12 * beat, 0.3); ctx.globalCompositeOperation = 'source-over'; }
      rStamp(rHeartSpr(on), hx, hy, H * 0.14 * beat);
    }
    for (const hf of this.heartFx) {   // a heart breaking into shards
      const hx = W - H * (0.07 + (2 - hf.i) * 0.085), hy = H * 0.075, u = hf.t / 0.8;
      ctx.globalAlpha = 1 - u; for (const sd of [-1, 1]) { ctx.save(); ctx.translate(hx + sd * u * H * 0.05, hy + u * u * H * 0.1); ctx.rotate(sd * u * 1.2); rStamp(rHeartSpr(true), 0, 0, H * 0.14 * (1 + u * 0.3), 1, 0.5); ctx.restore(); }
      ctx.globalAlpha = 1;
    }
    for (const m of this.msgs) { const u = m.t / 1.1, y = H * 0.3 - u * H * 0.04, sz = H * 0.06 * (1 + Math.max(0, 0.25 - m.t) * 1.5); ctx.globalAlpha = clamp(1.1 - m.t, 0, 1) * 1.2; ctx.font = `900 ${Math.round(sz)}px system-ui, sans-serif`; const tw = ctx.measureText(m.text).width; rGlass(W / 2 - tw / 2 - sz * 0.5, y - sz * 0.62, tw + sz, sz * 1.24, sz * 0.4, 'rgba(160,10,30,0.6)'); text(m.text, W / 2, y, sz, '#fff', 'center', 900); ctx.globalAlpha = 1; }
    if (this.banner.t < 3 && this.state === 'play') {   // world title sweeping in
      const bt = this.banner.t, ent = clamp(bt * 3, 0, 1), ex = clamp((3 - bt) * 2, 0, 1), e = 1 - Math.pow(1 - ent, 3), x = W / 2 + (1 - e) * W * 0.5;
      ctx.globalAlpha = Math.min(ent, ex); const bw2 = Math.min(W * 0.42, H * 0.75), bh2 = H * 0.11, by2 = (W < H * 1.2 ? H * 0.36 : H * 0.04) - (1 - ex) * H * 0.05;   // 2-player halves: below the score panel
      rGlass(x - bw2 / 2, by2, bw2, bh2, bh2 * 0.4); text(this.banner.text, x, by2 + bh2 * 0.4, Math.min(H * 0.055, bw2 / 9), pGrad(ctx, 0, by2, 0, by2 + bh2, [[0, '#ffffff'], [1, ['#c8ffb0', '#cfe6ff', '#ffd2a0', '#e2c8ff'][this.zone]]]), 'center', 900);
      rText(`WORLD ${this.zone + 1}`, x, by2 + bh2 * 0.82, H * 0.02, 'rgba(255,255,255,0.75)', 'center', 800); ctx.globalAlpha = 1;
    }
    const gbw = H * 0.22, gbx = W - gbw - 20, gby = H - gbw * 1.25 - 20;
    if (motionLive()) {
      rGlass(gbx, gby, gbw, gbw * 1.25, 14);
      ctx.save(); roundRect(gbx, gby, gbw, gbw * 1.25, 14); ctx.clip(); drawGhost(0.9, [gbx - gbw * 0.1, gby, gbw * 1.2, gbw * 1.25]); ctx.restore();
      const ln = laneInput(); rText(ln < 0 ? '◀ LEFT' : ln > 0 ? 'RIGHT ▶' : 'MIDDLE', gbx + gbw / 2, gby + gbw * 1.25 - 18, H * 0.025, ln ? '#ffe14a' : '#fff', 'center', 800);
    }
    if (this.state === 'ready') {
      const n = Math.ceil(this.readyT), fr = this.readyT - Math.floor(this.readyT), cx = W / 2, cy = H * 0.55, r = H * 0.11;
      rGlass(cx - H * 0.45, H * 0.36, H * 0.9, H * 0.08, H * 0.03); text(motionLive() ? 'Stand in the middle and hold still' : 'Get ready!', cx, H * 0.4, H * 0.04, '#fff', 'center', 800);
      ctx.lineWidth = H * 0.014; ctx.strokeStyle = 'rgba(255,255,255,0.2)'; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.stroke();
      ctx.strokeStyle = '#ffe14a'; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + fr * TAU); ctx.stroke();
      ctx.globalCompositeOperation = 'lighter'; rStamp(rGlowSpr('255,220,90'), cx, cy, r * 3, 0.35); ctx.globalCompositeOperation = 'source-over';
      text(n > 0 ? String(n) : 'GO!', cx, cy, H * 0.13 * (1 + Math.max(0, fr - 0.8) * 1.5), pGrad(ctx, 0, cy - r, 0, cy + r, [[0, '#fff6b0'], [1, '#ffb000']]), 'center', 900);
      rGlass(cx - H * 0.5, H * 0.72, H * 1.0, H * 0.065, H * 0.03); text('Step sideways = change lane · Jump = jump · Squat = duck', cx, H * 0.752, H * 0.028, '#fff', 'center', 700);
    }
    drawMotionBadge();
  },
});
