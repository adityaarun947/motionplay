/* =====================================================================
   PENGUIN SLIDE — belly-slide down an icy mountain.
   Lean to change lane, jump over rocks, squat to slide under ice arches, and raise both hands to FLAP-DASH
   through snowmen. Catch fish for coins. 1 player, or 2 players side by side (same mountain, last one sliding wins 50 coins).
   Art & sound live in 59_part.js.
   ===================================================================== */
const PZONES = [
  { name:'Snowy Slope',  sky:['#5fb4f2', '#e6f6ff'], snow:['#ffffff', '#d4ebff'], mount:['#a9c9e6', '#86abd2'], line:'#bcd9f2', tree:'#2e7d5b', sun:'#fff6c8' },
  { name:'Ice Caves',    sky:['#1d4f96', '#9fd2ff'], snow:['#e2f6ff', '#9fd2f2'], mount:['#5f95cf', '#4377b5'], line:'#8ec5ee', tree:'#1f6b7a', sun:'#d6f1ff' },
  { name:'Aurora Night', sky:['#060a2e', '#2f2a7a'], snow:['#cfd8ff', '#8391d6'], mount:['#36428f', '#262f78'], line:'#7787d8', tree:'#1c4a6b', sun:'#fff0c8', stars:true, aurora:true },
];
const PENG_ZONE = 600;     // metres per zone
const PSTEER_T = 0.05;     // seconds: how quickly the penguin reaches the lane you lean to (smaller = snappier)

scenes.penguin = {
  game:true, music:'penguin', hint:'Lean left/right to steer · jump over rocks · squat under arches · hands up to FLAP-DASH through snowmen',
  enter(){
    Object.assign(this, { obs:[], fish:[], deco:[], parts:[], pops:[], fx:[], flakes:[], big:[], ghosts:[], speed:12, dist:0, fishN:0, smashN:0, lives:3, inv:0, px:0, vx:0, lastLane:0,
      jumpT:-1, jumpH:0, duckT:0, dashT:0, dashCD:0, upWas:false, dashReq:false, untilRow:26, untilDeco:0, state:'ready', readyT:3.4, t:0, shake:0, flash:0, msgs:[],
      best:+store.get('mp-best-penguin', 0), zone:0, zonePrev:null, zoneMix:1, banner:{ text:PZONES[0].name, t:0 }, banked:false, dead:false, paidFish:0, paidDist:0, coinN:0, wasAir:false, skid:0,
      squash:0, crackT:0, ghostT:0, wasDuck:false, ambT:rand(4, 8), loop:null, fishGlow:0 });
    this.R = this.vs ? mulberry32(this.vs.seed + 55) : Math.random;      // two-player: identical mountain for both
    if (this.vs) this.readyT = 0.01;
    for (let i = 0; i < 12; i++) this.preDeco(i * 6);
    for (let i = 0; i < 46; i++) this.flakes.push({ x:rand(0, 1), y:rand(0, 1), s:rand(0.4, 1.2), v:rand(0.06, 0.16) });
    for (let i = 0; i < 12; i++) this.big.push({ x:rand(0, 1), y:rand(0, 1), s:rand(0.6, 1.4), v:rand(0.25, 0.5), ph:rand(0, TAU) });
    if (motionLive() && !this.vs) sendTracker({ t:'calibrate' });
  },
  exit(){ Music.setTempo(1); this.bank(); pSlideStop(this); },
  keys(k){ if (k === 'z' || k === 'Z' || k === 'x' || k === 'X') this.dashReq = true; },
  // Coins are deliberately small in single player: 1 per 3 fish + 1 per 150 m (the 2-player win is the big prize)
  bank(){ if (this.banked) return; this.banked = true; if (this.coinN > 0) { WALLET.coins += this.coinN; saveWallet(); } },
  earn(){
    const want = Math.floor(this.fishN / 3) + Math.floor(this.dist / 150);
    if (want > this.coinN) { const d = want - this.coinN; this.coinN = want; return d; }
    return 0;
  },
  proj(x, z, h){
    const LW = Math.min(W * 0.2, H * 0.36), d = Math.max(0.05, z + ZNEAR), s = ZNEAR / d;
    const HOR = H * 0.36, GY = H * 0.97;
    return { X: W / 2 + x * LW * s, Y: HOR + (GY - HOR) * s - h * LW * s, s: s * LW };
  },
  preDeco(z){ for (const side of [-1, 1]) this.deco.push({ x:side * rand(2.1, 3.1), z:z + rand(0, 4), k:Math.random(), side }); },

  spawnRow(z){
    const R = this.R || Math.random;
    const lanes = [-1, 0, 1].sort(() => R() - 0.5);
    const types = ['rock', 'arch', 'snowman', 'wall'], pk = () => types[Math.floor(R() * 4)];
    const r = R();
    if (r < 0.38) { this.obs.push({ lane:lanes[0], z, type:pk() }); this.fishLine(lanes[1], z); }
    else if (r < 0.68) { this.obs.push({ lane:lanes[0], z, type:pk() }, { lane:lanes[1], z, type:pk() }); this.fishLine(lanes[2], z - 4); }
    else if (r < 0.86 && this.t > 12) { const tp = R() < 0.5 ? 'rock' : 'arch'; for (const l of lanes) this.obs.push({ lane:l, z, type:tp }); }
    else this.fishLine(lanes[0], z);
  },
  fishLine(lane, z){ for (let i = 0; i < 5; i++) this.fish.push({ lane, z:z + i * 2.2, h:0.5 }); },

  update(dt){
    this.parts = stepParts(this.parts, dt); this.pops = stepPops(this.pops, dt); this.stepFx(dt);
    for (const f of this.flakes) { f.y += f.v * dt * (1 + this.speed * 0.05); f.x += Math.sin(sceneT + f.s * 9) * dt * 0.02; if (f.y > 1.02) { f.y = -0.02; f.x = rand(0, 1); } }
    for (const f of this.big) { f.y += f.v * dt * (1 + this.speed * 0.06); f.x += (f.x - 0.5) * dt * this.speed * 0.02 + Math.sin(sceneT + f.ph) * dt * 0.03; if (f.y > 1.1 || f.x < -0.1 || f.x > 1.1) { f.y = -0.08; f.x = rand(0.1, 0.9); } }
    this.zoneMix = Math.min(1, this.zoneMix + dt / 2.0); if (this.zoneMix >= 1) this.zonePrev = null;
    this.squash = Math.max(0, this.squash - dt * 4); this.crackT = Math.max(0, this.crackT - dt); this.fishGlow = Math.max(0, this.fishGlow - dt * 3);
    if (this.state === 'ready') { const p = this.readyT; this.readyT -= dt; countBeep(p, this.readyT); takeJump(); if (this.readyT <= 0) { this.state = 'play'; SFX.go(); } return; }
    this.t += dt;
    const dashing = this.dashT > 0;
    this.speed = Math.min(26, 12 + this.t * 0.16);
    if (!this.vs) Music.setTempo(0.94 + (this.speed - 12) / 14 * 0.28);
    const dz = this.speed * (dashing ? 1.7 : 1) * dt;
    this.dist += dz;

    const zi = Math.floor(this.dist / PENG_ZONE) % PZONES.length;
    if (zi !== this.zone) { this.zonePrev = this.zone; this.zoneMix = 0; this.zone = zi; this.banner = { text:PZONES[zi].name, t:0 }; pSnd.zone(); }
    this.banner.t += dt;

    // steering: snaps quickly to the lane you lean to (keeps a little skid for the look, not for the feel)
    const target = laneInput();
    if (target !== this.lastLane) { pSnd.lane(Math.sign(target - this.lastLane)); this.lastLane = target; this.skid = 0.4; this.ghostT = 0.22; }
    const prevX = this.px, k = 1 - Math.exp(-dt / PSTEER_T);
    this.px = clamp(this.px + (target - this.px) * k, -1.35, 1.35);
    this.vx = (this.px - prevX) / Math.max(dt, 0.001);
    this.skid = Math.max(0, this.skid - dt);
    this.ghostT = Math.max(0, this.ghostT - dt);
    if (this.ghostT > 0) this.ghosts.push({ x:this.px, h:this.jumpH, t:0 });
    for (const g of this.ghosts) g.t += dt; this.ghosts = this.ghosts.filter(g => g.t < 0.18);
    if (Math.abs(this.vx) > 2 && this.jumpT < 0) this.spray(Math.sign(this.vx));

    if (takeJump() && this.jumpT < 0) { this.jumpT = 0; this.duckT = 0; pSnd.jump(); this.wasAir = true; this.puff(10, true); }
    if (this.jumpT >= 0) {
      this.jumpT += dt; const u = this.jumpT / 0.78;
      if (duckInput() && u > 0.2) this.jumpT = -1;
      if (u >= 1 || this.jumpT < 0) { this.jumpT = -1; this.jumpH = 0; } else this.jumpH = 4 * 1.45 * u * (1 - u);
    }
    if (this.jumpT < 0 && this.wasAir) { this.wasAir = false; pSnd.land(); this.puff(14, true); this.squash = 1; this.ring(); }
    if (duckInput() && this.jumpT < 0) this.duckT = Math.max(this.duckT, 0.55);
    this.duckT = Math.max(0, this.duckT - dt);
    const ducking = this.duckT > 0 && this.jumpT < 0;
    if (ducking && !this.wasDuck) { pSnd.duck(); this.puff(8); } this.wasDuck = ducking;

    // flap-dash: raise both hands (or press Z). Smashes snowmen. Recharges in a few seconds.
    const up = !!I.up, edge = up && !this.upWas; this.upWas = up;
    this.dashCD = Math.max(0, this.dashCD - dt); this.dashT = Math.max(0, this.dashT - dt);
    if ((edge || this.dashReq) && this.dashCD <= 0 && this.dashT <= 0) { this.dashT = 0.9; this.dashCD = 4.5; pSnd.dash(); Music.duck(0.35, 1.2); this.flash = 0.25; pop(this.pops, W / 2, H * 0.3, 'FLAP DASH!', '#7fe6ff', 0.06, 0.9); this.ring('150,235,255'); }
    this.dashReq = false;
    this.inv = Math.max(0, this.inv - dt);
    this.shake = Math.max(0, this.shake - dt * 2.5); this.flash = Math.max(0, this.flash - dt * 2);

    // snow spray behind the slider
    this.skidT = (this.skidT || 0) - dt;
    if (this.skidT <= 0 && this.jumpT < 0) { this.skidT = dashing ? 0.02 : 0.05; this.puff(dashing ? 3 : 1, dashing); }

    this.untilRow -= dz;
    if (this.untilRow <= 0) { this.spawnRow(72); this.untilRow = 15 + this.R() * 8; }
    this.untilDeco -= dz; if (this.untilDeco <= 0) { this.untilDeco = rand(4, 7); this.preDeco(72); }

    for (const o of this.obs) {
      o.z -= dz;
      if (o.hit || o.passed || o.smashed) continue;
      const len = o.type === 'wall' ? 3.2 : 0.4;
      if (o.z < PZ + 0.3 && o.z + len > PZ - 0.3 && Math.abs(this.px - o.lane) < 0.55) {
        if (o.type === 'snowman' && dashing) {
          o.smashed = true; this.smashN++; this.fishN += 2; pSnd.smash(); this.shake = 0.5;
          const p = this.proj(o.lane, o.z, 0.8); this.smashFx(p);
          pop(this.pops, p.X, p.Y, 'SMASH! +2 fish', '#7fe6ff', 0.045, 1); continue;
        }
        if (this.inv > 0) continue;
        const safe = (o.type === 'rock' && this.jumpH > 0.55) || (o.type === 'arch' && ducking);
        if (!safe) {
          o.hit = true; this.lives--; this.inv = 1.5; this.shake = 1; pSnd.hit(); this.crackT = 0.7; this.hitFx(o);
          this.msgs.push({ text:o.type === 'rock' ? 'Jump!' : o.type === 'arch' ? 'Squat!' : o.type === 'snowman' ? 'Flap-dash it!' : 'Change lanes!', t:0 });
        } else if (!o.cheered) { o.cheered = true; const p = this.proj(this.px, PZ, 1.6); pop(this.pops, p.X, p.Y, 'Nice!', '#4fd27a', 0.04, 0.8); this.sparkle(p.X, p.Y + p.s * 0.6, 8, '180,255,200'); }
      }
      if (o.z + len < PZ - 0.4) o.passed = true;
    }
    for (const f of this.fish) {
      f.z -= dz;
      if (!f.got && Math.abs(f.z - PZ) < 0.7 && Math.abs(this.px - f.lane) < 0.55 && Math.abs(this.jumpH + 0.4 - f.h) < 0.95) {
        f.got = true; this.fishN++; this.fishGlow = 1;
        pSnd.fish(this.fishN);
        const p = this.proj(f.lane, f.z, f.h); this.sparkle(p.X, p.Y, 12, '140,235,255');
      }
    }
    this.obs = this.obs.filter(o => o.z > -4 && !o.smashed);
    this.fish = this.fish.filter(f => f.z > -2 && !f.got);
    for (const d of this.deco) d.z -= dz;
    this.deco = this.deco.filter(d => d.z > -4);
    for (const m of this.msgs) m.t += dt;
    this.msgs = this.msgs.filter(m => m.t < 1.1);

    // sound: continuous slide hiss & wind, zone ambience
    const L = pSlideLoop(this, true);
    if (L) {
      const now = actx.currentTime, air = this.jumpT >= 0, sp = this.speed / 26, vsK = this.vs ? 0.55 : 1;
      L.seen = performance.now();
      L.slide.gn.gain.setTargetAtTime(air ? 0.0001 : (0.03 + sp * 0.035 + (dashing ? 0.04 : 0) + (ducking ? 0.02 : 0)) * vsK, now, 0.04);
      L.slide.fl.frequency.setTargetAtTime(1500 + sp * 1800 + (ducking ? -500 : 0), now, 0.1);
      L.wind.gn.gain.setTargetAtTime((0.02 + sp * 0.03 + (dashing ? 0.06 : 0) + (air ? 0.02 : 0)) * vsK, now, 0.1);
      L.wind.fl.frequency.setTargetAtTime(300 + sp * 500 + (dashing ? 600 : 0), now, 0.15);
    }
    this.ambT -= dt; if (this.ambT <= 0 && (!this.vs || this.vs.pl === 0)) { this.ambT = rand(6, 12); pSnd.amb(this.zone); }

    const got = this.earn();
    if (got > 0) pop(this.pops, W * 0.5, H * 0.22, `+${got} coin${got > 1 ? 's' : ''}`, '#ffd23f', 0.045, 1);
    if (this.lives <= 0) {
      const res = { game:'penguin', score:Math.floor(this.dist) + this.fishN * 10 + this.smashN * 30, detail:`${Math.floor(this.dist)} m · ${this.fishN} fish · ${this.smashN} snowmen smashed`, coins:this.coinN };
      if (this.vs) { if (!this.dead) { this.dead = true; this.vs.onDead(this, res); } } else go('over', res);
    }
  },
  rescale(sc){ for (const arr of [this.parts, this.pops, this.fx]) for (const o of arr) sc(o, true); },

  /* ---------- effects ---------- */
  stepFx(dt){
    for (const f of this.fx) {
      f.t += dt; f.x += f.vx * dt; f.y += f.vy * dt;
      if (f.k === 'chunk' || f.k === 'carrot' || f.k === 'hat') { f.vy += H * 2.4 * dt; f.rot += f.vr * dt; }
      else if (f.k === 'puff') { f.vx *= Math.exp(-dt * 3); f.vy *= Math.exp(-dt * 3); f.r += f.gr * dt; }
      else if (f.k === 'spark') { f.vy += H * 0.4 * dt; }
    }
    this.fx = this.fx.filter(f => f.t < f.life);
  },
  puff(n, big){
    const p = this.proj(this.px, PZ, this.jumpH > 0.05 ? 0 : 0);
    for (let i = 0; i < n; i++) this.fx.push({ k:'puff', x:p.X + rand(-0.25, 0.25) * p.s, y:p.Y - p.s * 0.02, vx:rand(-0.9, 0.9) * p.s, vy:-rand(0.2, 0.8) * p.s * (big ? 1 : 0.6), r:p.s * rand(0.04, 0.09) * (big ? 1.4 : 1), gr:p.s * rand(0.15, 0.35), a:rand(0.5, 0.85), t:0, life:rand(0.35, 0.6), blue:this.dashT > 0 });
  },
  spray(dir){
    if (Math.random() > 0.6) return;
    const p = this.proj(this.px, PZ, 0);
    for (let i = 0; i < 2; i++) this.fx.push({ k:'puff', x:p.X - dir * p.s * 0.2, y:p.Y - p.s * 0.03, vx:-dir * p.s * rand(1.5, 3), vy:-p.s * rand(0.4, 1.2), r:p.s * rand(0.03, 0.06), gr:p.s * 0.3, a:0.8, t:0, life:0.4 });
  },
  ring(rgb = '255,255,255'){ const p = this.proj(this.px, PZ, 0); this.fx.push({ k:'ring', x:p.X, y:p.Y, vx:0, vy:0, s:p.s, rgb, t:0, life:0.45 }); },
  sparkle(x, y, n, rgb){ for (let i = 0; i < n; i++) { const a = rand(0, TAU), v = H * rand(0.15, 0.55); this.fx.push({ k:'spark', x, y, vx:Math.cos(a) * v, vy:Math.sin(a) * v - H * 0.15, sz:H * rand(0.008, 0.016), rgb, t:0, life:rand(0.4, 0.7) }); } },
  smashFx(p){
    for (let i = 0; i < 22; i++) { const a = rand(-Math.PI, 0), v = p.s * rand(1.5, 4); this.fx.push({ k:'chunk', x:p.X + rand(-0.2, 0.2) * p.s, y:p.Y - rand(0, 0.6) * p.s, vx:Math.cos(a) * v, vy:Math.sin(a) * v, sz:p.s * rand(0.04, 0.1), rot:rand(0, TAU), vr:rand(-12, 12), t:0, life:1.0 }); }
    this.fx.push({ k:'carrot', x:p.X, y:p.Y - p.s * 0.4, vx:p.s * rand(-2, 2), vy:-p.s * 3.5, sz:p.s * 0.2, rot:0, vr:rand(-15, 15), t:0, life:1.0 });
    this.fx.push({ k:'hat', x:p.X, y:p.Y - p.s * 0.7, vx:p.s * rand(-2, 2), vy:-p.s * 4.2, sz:p.s * 0.25, rot:0, vr:rand(-10, 10), t:0, life:1.1 });
    for (let i = 0; i < 10; i++) this.fx.push({ k:'puff', x:p.X, y:p.Y - p.s * 0.3, vx:rand(-2, 2) * p.s, vy:-rand(0.5, 2) * p.s, r:p.s * 0.1, gr:p.s * 0.8, a:0.9, t:0, life:0.6 });
    this.fx.push({ k:'ring', x:p.X, y:p.Y + p.s * 0.6, vx:0, vy:0, s:p.s * 1.4, rgb:'150,235,255', t:0, life:0.5 });
  },
  hitFx(o){
    const p = this.proj(this.px, PZ, 0.4);
    this.sparkle(p.X, p.Y, 14, o.type === 'rock' ? '255,220,120' : '200,240,255');
    for (let i = 0; i < 8; i++) { const a = rand(-Math.PI, 0), v = p.s * rand(1, 3); this.fx.push({ k:'chunk', x:p.X, y:p.Y, vx:Math.cos(a) * v, vy:Math.sin(a) * v, sz:p.s * rand(0.03, 0.07), rot:rand(0, TAU), vr:rand(-12, 12), t:0, life:0.8, ice:o.type !== 'rock' }); }
  },
  drawFx(){
    const soft = pSoftSprite('snow', '255,255,255'), softB = pSoftSprite('snowB', '170,235,255');
    for (const f of this.fx) {
      const k = f.t / f.life;
      if (f.k === 'puff') { ctx.globalAlpha = f.a * (1 - k); const r = f.r * 2.2; ctx.drawImage(f.blue ? softB : soft, f.x - r, f.y - r, r * 2, r * 2); }
      else if (f.k === 'ring') { ctx.globalAlpha = (1 - k) * 0.8; ctx.strokeStyle = `rgb(${f.rgb})`; ctx.lineWidth = Math.max(2, f.s * 0.04 * (1 - k)); ctx.beginPath(); ctx.ellipse(f.x, f.y, f.s * (0.3 + k * 1.1), f.s * (0.08 + k * 0.25), 0, 0, TAU); ctx.stroke(); }
      else if (f.k === 'spark') { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 1 - k; ctx.fillStyle = `rgb(${f.rgb})`; const s = f.sz * (1 - k * 0.5); ctx.beginPath(); ctx.moveTo(f.x, f.y - s * 2); ctx.lineTo(f.x + s * 0.4, f.y - s * 0.4); ctx.lineTo(f.x + s * 2, f.y); ctx.lineTo(f.x + s * 0.4, f.y + s * 0.4); ctx.lineTo(f.x, f.y + s * 2); ctx.lineTo(f.x - s * 0.4, f.y + s * 0.4); ctx.lineTo(f.x - s * 2, f.y); ctx.lineTo(f.x - s * 0.4, f.y - s * 0.4); ctx.closePath(); ctx.fill(); ctx.globalCompositeOperation = 'source-over'; }
      else { ctx.globalAlpha = Math.min(1, (1 - k) * 3); ctx.save(); ctx.translate(f.x, f.y); ctx.rotate(f.rot);
        if (f.k === 'chunk') { ctx.fillStyle = f.ice ? 'rgba(170,225,255,0.95)' : '#f4f9ff'; ctx.beginPath(); ctx.moveTo(-f.sz, -f.sz * 0.6); ctx.lineTo(f.sz * 0.3, -f.sz); ctx.lineTo(f.sz, 0); ctx.lineTo(f.sz * 0.2, f.sz * 0.9); ctx.lineTo(-f.sz * 0.8, f.sz * 0.5); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(120,160,210,0.4)'; ctx.fillRect(0, 0, f.sz * 0.6, f.sz * 0.5); }
        else if (f.k === 'carrot') { ctx.fillStyle = '#ff8a1f'; ctx.beginPath(); ctx.moveTo(-f.sz * 0.5, -f.sz * 0.15); ctx.lineTo(f.sz * 0.6, 0); ctx.lineTo(-f.sz * 0.5, f.sz * 0.15); ctx.closePath(); ctx.fill(); }
        else { ctx.fillStyle = '#16161c'; ctx.fillRect(-f.sz * 0.4, -f.sz * 0.6, f.sz * 0.8, f.sz * 0.6); ctx.fillRect(-f.sz * 0.6, 0, f.sz * 1.2, f.sz * 0.12); ctx.fillStyle = '#d6264a'; ctx.fillRect(-f.sz * 0.4, -f.sz * 0.15, f.sz * 0.8, f.sz * 0.12); }
        ctx.restore(); }
    }
    ctx.globalAlpha = 1;
  },

  /* ---------- drawing ---------- */
  drawSky(i, a){
    const Z = PZONES[i], HOR = H * 0.36;
    ctx.globalAlpha = a; ctx.drawImage(pSkyLayer(i), 0, 0);
    const tile = pCloudTile(i), ox = (sceneT * 6 * (H / 720) + this.dist * 0.4) % W; ctx.drawImage(tile, ox - W, H * 0.02, W, tile.height); ctx.drawImage(tile, ox, H * 0.02, W, tile.height);
    if (Z.aurora) {
      ctx.globalCompositeOperation = 'lighter';
      for (let b = 0; b < 3; b++) {
        const cols = [['80,255,190', 0.32], ['120,170,255', 0.26], ['200,120,255', 0.22]][b], y0 = HOR * (0.1 + b * 0.09), hh = HOR * 0.32;
        const gr = ctx.createLinearGradient(0, y0 - hh * 0.2, 0, y0 + hh); gr.addColorStop(0, `rgba(${cols[0]},0)`); gr.addColorStop(0.35, `rgba(${cols[0]},${cols[1] * a})`); gr.addColorStop(1, `rgba(${cols[0]},0)`);
        ctx.fillStyle = gr; ctx.beginPath();
        for (let x = 0; x <= W; x += W / 24) { const y = y0 + Math.sin(x / W * 5.5 + b * 1.7 + sceneT * (0.3 + b * 0.1)) * HOR * 0.08 + Math.sin(x / W * 13 + sceneT * 0.7) * HOR * 0.02; x ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
        for (let x = W; x >= 0; x -= W / 24) ctx.lineTo(x, y0 + hh + Math.sin(x / W * 5.5 + b * 1.7 + sceneT * (0.3 + b * 0.1)) * HOR * 0.08);
        ctx.closePath(); ctx.fill();
      }
      ctx.globalCompositeOperation = 'source-over';
    } else {
      // lens flare from the sun
      const sx = W * 0.78, sy = HOR * 0.34; ctx.globalCompositeOperation = 'lighter';
      for (const [k, r, c] of [[0.35, 0.025, '255,240,200'], [0.6, 0.05, '160,220,255'], [0.85, 0.018, '255,200,160'], [1.15, 0.07, '140,200,255']]) { const x = sx + (W / 2 - sx) * k * 1.4, y = sy + (H * 0.55 - sy) * k * 1.4, rr = H * r; const g = ctx.createRadialGradient(x, y, 0, x, y, rr); g.addColorStop(0, `rgba(${c},${0.22 * a})`); g.addColorStop(1, `rgba(${c},0)`); ctx.fillStyle = g; ctx.fillRect(x - rr, y - rr, rr * 2, rr * 2); }
      ctx.globalCompositeOperation = 'source-over';
    }
    ctx.globalAlpha = 1;
  },
  drawTrack(Z){
    const HOR = H * 0.36, LX = 1.7, FAR = 70;
    const a = this.proj(-LX, FAR, 0), b = this.proj(LX, FAR, 0), c = this.proj(LX, -1.6, 0), d = this.proj(-LX, -1.6, 0);
    // groomed ice surface
    const ice = ctx.createLinearGradient(0, HOR, 0, H); ice.addColorStop(0, zMix(Z.snow[1], Z.sky[1], 0.4)); ice.addColorStop(0.35, zMix(Z.snow[1], '#bfe4ff', 0.35)); ice.addColorStop(1, zMix(Z.snow[0], '#e9f7ff', 0.5));
    ctx.fillStyle = ice; ctx.beginPath(); ctx.moveTo(a.X, a.Y); ctx.lineTo(b.X, b.Y); ctx.lineTo(c.X, c.Y); ctx.lineTo(d.X, d.Y); ctx.closePath(); ctx.fill();
    // corduroy grooming bands scrolling past
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    for (let z0 = -(this.dist % 3); z0 < FAR; z0 += 3) { const p1 = this.proj(-LX, z0, 0), p2 = this.proj(LX, z0, 0), p3 = this.proj(LX, z0 + 1.2, 0), p4 = this.proj(-LX, z0 + 1.2, 0); ctx.beginPath(); ctx.moveTo(p1.X, p1.Y); ctx.lineTo(p2.X, p2.Y); ctx.lineTo(p3.X, p3.Y); ctx.lineTo(p4.X, p4.Y); ctx.closePath(); ctx.fill(); }
    // glossy sheen streak
    ctx.save(); ctx.beginPath(); ctx.moveTo(a.X, a.Y); ctx.lineTo(b.X, b.Y); ctx.lineTo(c.X, c.Y); ctx.lineTo(d.X, d.Y); ctx.closePath(); ctx.clip();
    const sh = ctx.createLinearGradient(W * 0.3, 0, W * 0.6, 0); sh.addColorStop(0, 'rgba(255,255,255,0)'); sh.addColorStop(0.5, 'rgba(255,255,255,0.22)'); sh.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = sh; ctx.fillRect(0, HOR, W, H);
    // twinkling ice glints
    ctx.globalCompositeOperation = 'lighter';
    const cell = 1.6, n0 = Math.floor(this.dist / cell);
    for (let n = n0; n < n0 + 34; n++) { const z = n * cell - this.dist; if (z < -1) continue; const r = mulberry32(n * 7 + 3); for (let j = 0; j < 2; j++) { const x = (r() * 2 - 1) * LX, tw = Math.sin(sceneT * 7 + n * 1.7 + j * 2.3); if (tw < 0.55) continue; const p = this.proj(x, z, 0), s = p.s * 0.035 * (tw - 0.5) * 2; ctx.fillStyle = `rgba(255,255,255,${(tw - 0.55) * 1.8})`; ctx.fillRect(p.X - s * 2, p.Y - 0.5, s * 4, 1.2); ctx.fillRect(p.X - 0.6, p.Y - s * 2, 1.2, s * 4); } }
    ctx.globalCompositeOperation = 'source-over'; ctx.restore();
    // lane grooves (two carved lines with a highlight)
    for (const lx of [-1.5, -0.5, 0.5, 1.5]) {
      const p1 = this.proj(lx, FAR, 0), p2 = this.proj(lx, -1, 0);
      ctx.strokeStyle = zShade(Z.line, -0.25); ctx.lineWidth = Math.max(2, H * 0.005); ctx.beginPath(); ctx.moveTo(p1.X, p1.Y); ctx.lineTo(p2.X, p2.Y); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = Math.max(1, H * 0.002); ctx.beginPath(); ctx.moveTo(p1.X + 1.5, p1.Y); ctx.lineTo(p2.X + H * 0.004, p2.Y); ctx.stroke();
    }
    // snow banks either side
    for (const sd of [-1, 1]) {
      const pts = []; for (let z = FAR; z >= -1.6; z -= 4) pts.push(z);
      const inner = pts.map(z => this.proj(sd * LX, z, 0)), innerTop = pts.map(z => this.proj(sd * LX, z, 0.24)), outerTop = pts.map(z => this.proj(sd * (LX + 0.55), z, 0.3));
      ctx.fillStyle = sd < 0 ? zMix(Z.snow[1], '#ffffff', 0.4) : zMix(Z.snow[1], '#6f93c2', 0.25); ctx.beginPath(); inner.forEach((p, i) => i ? ctx.lineTo(p.X, p.Y) : ctx.moveTo(p.X, p.Y)); for (let i = innerTop.length - 1; i >= 0; i--) ctx.lineTo(innerTop[i].X, innerTop[i].Y); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#ffffff'; ctx.beginPath(); innerTop.forEach((p, i) => i ? ctx.lineTo(p.X, p.Y) : ctx.moveTo(p.X, p.Y)); for (let i = outerTop.length - 1; i >= 0; i--) ctx.lineTo(outerTop[i].X, outerTop[i].Y); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(120,160,210,0.35)'; ctx.lineWidth = 1.5; ctx.beginPath(); innerTop.forEach((p, i) => i ? ctx.lineTo(p.X, p.Y) : ctx.moveTo(p.X, p.Y)); ctx.stroke();
      // marker poles racing past
      for (let z0 = 6 - (this.dist % 6); z0 < FAR; z0 += 6) {
        const p = this.proj(sd * (LX + 0.2), z0, 0.27), t = this.proj(sd * (LX + 0.2), z0, 0.9); if (p.s < 2) continue;
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = Math.max(1.5, p.s * 0.025); ctx.beginPath(); ctx.moveTo(p.X, p.Y); ctx.lineTo(t.X, t.Y); ctx.stroke();
        ctx.strokeStyle = (Math.floor((z0 + this.dist) / 6) % 2) ? '#ff3b4e' : '#2f7cf6'; ctx.beginPath(); ctx.moveTo(p.X + (t.X - p.X) * 0.55, p.Y + (t.Y - p.Y) * 0.55); ctx.lineTo(t.X, t.Y); ctx.stroke();
      }
    }
    // far haze where the track meets the horizon
    const hz = ctx.createLinearGradient(0, HOR, 0, HOR + H * 0.14); hz.addColorStop(0, zMix(Z.sky[1], '#ffffff', 0.3)); hz.addColorStop(1, zMix(Z.sky[1], '#ffffff', 0.3).replace('rgb', 'rgba').replace(')', ',0)')); ctx.fillStyle = hz; ctx.fillRect(0, HOR - 2, W, H * 0.14);
  },
  draw(now){
    const Z = PZONES[this.zone], HOR = H * 0.36;
    ctx.save();
    if (this.shake > 0) ctx.translate(rand(-1, 1) * this.shake * H * 0.012, rand(-1, 1) * this.shake * H * 0.012);
    if (this.zonePrev !== null && this.zoneMix < 1) { this.drawSky(this.zonePrev, 1); this.drawSky(this.zone, this.zoneMix); } else this.drawSky(this.zone, 1);
    this.drawTrack(Z);

    // everything standing on the slope, far to near
    const things = [];
    for (const dc of this.deco) things.push({ z:dc.z, k:'deco', o:dc });
    for (const o of this.obs) things.push({ z:o.z, k:'obs', o });
    for (const f of this.fish) things.push({ z:f.z, k:'fish', o:f });
    things.push({ z:PZ, k:'me' });
    things.sort((p, q) => q.z - p.z);
    for (const th of things) {
      if (th.z > 72) continue;
      if (th.k === 'deco') this.drawDeco(th.o, Z);
      else if (th.k === 'obs') this.drawObs(th.o);
      else if (th.k === 'fish') this.drawFish(th.o);
      else this.drawPenguin(now);
    }
    this.drawFx();
    drawParts(this.parts);
    // falling snow: small far flakes + big soft flakes rushing past the camera
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    for (const f of this.flakes) { ctx.beginPath(); ctx.arc(f.x * W, f.y * H, Math.max(1.2, f.s * H * 0.004), 0, TAU); ctx.fill(); }
    const soft = pSoftSprite('snow', '255,255,255');
    for (const f of this.big) { const r = H * 0.018 * f.s * (0.6 + f.y); ctx.globalAlpha = 0.55; ctx.drawImage(soft, f.x * W - r, f.y * H - r, r * 2, r * 2); }
    ctx.globalAlpha = 1;
    // speed lines from the vanishing point
    const sk = clamp((this.speed - 15) / 11, 0, 1) * 0.5 + (this.dashT > 0 ? 0.7 : 0);
    if (sk > 0.02) { ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round'; for (let i = 0; i < 22; i++) { const a = i * 2.39996 + 0.3, ph = ((sceneT * (1.6 + (i % 5) * 0.3) + i * 0.37) % 1), r0 = H * (0.25 + ph * 0.9), r1 = r0 + H * (0.08 + ph * 0.25); const cx = W / 2, cy = HOR + H * 0.05; ctx.strokeStyle = `rgba(220,245,255,${sk * 0.45 * ph})`; ctx.lineWidth = 1 + ph * 3; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * r0 * 1.4, cy + Math.sin(a) * r0); ctx.lineTo(cx + Math.cos(a) * r1 * 1.4, cy + Math.sin(a) * r1); ctx.stroke(); } ctx.globalCompositeOperation = 'source-over'; }
    drawPops(this.pops);
    ctx.restore();

    if (this.zone === 1 || this.zonePrev === 1) { ctx.globalAlpha = this.zone === 1 ? this.zoneMix : 1 - this.zoneMix; ctx.drawImage(pCaveOverlay(), 0, 0); ctx.globalAlpha = 1; }
    ctx.drawImage(pFrostOverlay(), 0, 0);
    if (this.crackT > 0) { ctx.globalAlpha = Math.min(1, this.crackT * 2) * 0.8; ctx.drawImage(pCrackOverlay(), 0, 0); ctx.globalAlpha = 1; }
    if (this.flash > 0) { ctx.fillStyle = `rgba(220,245,255,${this.flash * 0.5})`; ctx.fillRect(0, 0, W, H); }
    if (this.inv > 0 && this.lives > 0 && ((this.inv * 10) | 0) % 2 === 0) { ctx.fillStyle = 'rgba(255,60,80,0.10)'; ctx.fillRect(0, 0, W, H); }
    this.drawHud();
    if (this.state === 'ready') {
      const n = Math.ceil(this.readyT), big = n > 0 && this.readyT < 3, k = big ? 1 - (this.readyT % 1) : 0;
      ctx.globalAlpha = big ? Math.min(1, 1.3 - k) : 1; text(big ? String(n) : 'Get ready!', W / 2, H * 0.45, H * (big ? 0.2 * (1 + (1 - Math.min(1, k * 4)) * 0.25) : 0.08), '#fff'); ctx.globalAlpha = 1;
      this.glass(W / 2 - H * 0.42, H * 0.555, H * 0.84, H * 0.055); text('Lean to steer · jump · squat · hands up = FLAP-DASH', W / 2, H * 0.582, H * 0.028, '#fff', 'center', 700);
    }
  },
  glass(x, y, w, h){
    const r = Math.min(h / 2, H * 0.025); roundRect(x, y, w, h, r);
    const g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, 'rgba(255,255,255,0.32)'); g.addColorStop(1, 'rgba(160,210,255,0.16)'); ctx.fillStyle = g; ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.fillStyle = 'rgba(10,30,70,0.25)'; roundRect(x + 2, y + h * 0.5, w - 4, h * 0.5 - 2, r * 0.8); ctx.fill();
  },
  drawHud(){
    const fk = Math.min(1, W / (H * 1.3)), px = W * 0.025, py = H * 0.025;
    this.glass(px, py, H * 0.42 * fk + W * 0.02, H * 0.19);
    text(`${Math.floor(this.dist)} m`, px + H * 0.02, H * 0.075, H * 0.065 * fk, '#fff', 'left');
    const fs = pFishSprite(), fw = H * 0.06 * (1 + this.fishGlow * 0.3); ctx.drawImage(fs.c, px + H * 0.02, H * 0.137 - fw * 0.25, fw, fw * 0.5);
    text(`${this.fishN}  ·  ● ${this.coinN}`, px + H * 0.09, H * 0.138, H * 0.034 * fk, '#fff', 'left', 800);
    text(`Best ${this.best}`, px + H * 0.02, H * 0.183, H * 0.024 * fk, '#e8f4ff', 'left', 700);
    // hearts
    for (let i = 0; i < 3; i++) {
      const x = W * (0.86 + i * 0.045 * (fk < 1 ? 0.8 : 1)), y = H * 0.07, s = H * 0.028 * fk * (i < this.lives ? 1 + (i === this.lives - 1 && this.lives === 1 ? Math.sin(sceneT * 8) * 0.12 : 0) : 0.85);
      ctx.save(); ctx.translate(x, y); ctx.beginPath(); ctx.moveTo(0, s * 0.9); ctx.bezierCurveTo(-s * 1.6, -s * 0.1, -s * 0.9, -s * 1.3, 0, -s * 0.45); ctx.bezierCurveTo(s * 0.9, -s * 1.3, s * 1.6, -s * 0.1, 0, s * 0.9); ctx.closePath();
      if (i < this.lives) { const g = ctx.createRadialGradient(-s * 0.4, -s * 0.5, 0, 0, 0, s * 1.4); g.addColorStop(0, '#ff9ab0'); g.addColorStop(0.5, '#ff3b6b'); g.addColorStop(1, '#a3123a'); ctx.fillStyle = g; ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,0.6)'; ctx.beginPath(); ctx.ellipse(-s * 0.45, -s * 0.5, s * 0.22, s * 0.13, -0.6, 0, TAU); ctx.fill(); }
      else { ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 2; ctx.stroke(); }
      ctx.restore();
    }
    // flap-dash meter: an ice capsule
    const bw = Math.min(W * 0.3, H * 0.55), bh = H * 0.026, bx = W / 2 - bw / 2, by = H * 0.925, k = this.dashT > 0 ? 1 - this.dashT / 0.9 : 1 - this.dashCD / 4.5, ready = this.dashCD <= 0 && this.dashT <= 0;
    this.glass(bx - 4, by - 4, bw + 8, bh + 8);
    const fg = ctx.createLinearGradient(0, by, 0, by + bh); fg.addColorStop(0, ready ? '#e9fbff' : '#a6d4f0'); fg.addColorStop(0.5, ready ? '#7fe6ff' : '#4a86b0'); fg.addColorStop(1, ready ? '#2aa6d6' : '#2c5a80');
    roundRect(bx, by, Math.max(bh, bw * clamp(k, 0, 1)), bh, bh / 2); ctx.fillStyle = fg; if (ready) { ctx.shadowColor = '#7fe6ff'; ctx.shadowBlur = 18 + Math.sin(sceneT * 6) * 8; } ctx.fill(); ctx.shadowBlur = 0;
    text(ready ? '❄ FLAP-DASH ready — hands up!' : 'recharging…', W / 2, by - H * 0.022, H * 0.026 * fk, ready ? '#e9fbff' : '#c9e4f5', 'center', 800);
    // zone banner: a ribbon that sweeps in
    if (this.banner.t < 2.6) {
      const t = this.banner.t, a = Math.min(1, t * 4, (2.6 - t) * 2), w = H * 0.75 * Math.min(1, t * 3), y = H * 0.2;
      ctx.globalAlpha = a; const g = ctx.createLinearGradient(W / 2 - w / 2, 0, W / 2 + w / 2, 0); g.addColorStop(0, 'rgba(20,60,120,0)'); g.addColorStop(0.2, 'rgba(20,60,120,0.75)'); g.addColorStop(0.8, 'rgba(20,60,120,0.75)'); g.addColorStop(1, 'rgba(20,60,120,0)');
      ctx.fillStyle = g; ctx.fillRect(W / 2 - w / 2, y - H * 0.045, w, H * 0.09); ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.fillRect(W / 2 - w * 0.4, y - H * 0.045, w * 0.8, 2); ctx.fillRect(W / 2 - w * 0.4, y + H * 0.043, w * 0.8, 2);
      text(this.banner.text.toUpperCase(), W / 2, y, H * 0.05 * fk, '#fff'); ctx.globalAlpha = 1;
    }
    for (const m of this.msgs) { const s = 1 + Math.max(0, 0.15 - m.t) * 3; ctx.globalAlpha = 1 - m.t / 1.1; text(m.text, W / 2, H * 0.5 - m.t * H * 0.05, H * 0.075 * fk * s, '#ff6b5a'); ctx.globalAlpha = 1; }
  },
  drawDeco(dc, Z){
    const p = this.proj(dc.x, dc.z, 0), s = p.s; if (s < 3) return;
    let sp, scl;
    if (dc.k < 0.62) { sp = pTreeSprite(Z, Math.floor(dc.k * 100) % 3); scl = s / sp.u * 1.05; }
    else if (dc.k < 0.74) { sp = pDecoSprite('boulders', Z); scl = s / sp.u * 0.9; }
    else if (dc.k < 0.84) { sp = pDecoSprite(dc.side < 0 ? 'flagR' : 'flagB', Z); scl = s / sp.u; }
    else if (dc.k < 0.93) { sp = pDecoSprite(this.zone === 0 ? 'boulders' : 'crystal', Z); scl = s / sp.u * 0.9; }
    else { sp = pDecoSprite('igloo', Z); scl = s / sp.u * 1.1; }
    ctx.drawImage(sp.c, p.X - sp.ox * scl, p.Y - sp.oy * scl, sp.c.width * scl, sp.c.height * scl);
  },
  drawObs(o){
    const p = this.proj(o.lane, o.z, 0), s = p.s; if (s < 2) return;
    const near = clamp((14 - o.z) / 10, 0, 1);   // a soft warning glow as it gets close
    if (o.type === 'wall') {   // a long slab of ice (dodge it): front face, top, and inner side, all lit
      const len = 3.2, zf = Math.max(o.z, 0.2), zb = o.z + len; if (zb <= zf) return; const f = this.proj(o.lane, zf, 0), bk = this.proj(o.lane, zb, 0), hgt = 0.95;
      const fT = this.proj(o.lane, zf, hgt), bT = this.proj(o.lane, zb, hgt); if (o.z < 0.2) ctx.globalAlpha = 0.6;
      ctx.fillStyle = 'rgba(30,60,100,0.25)'; ctx.beginPath(); ctx.ellipse(f.X, f.Y, f.s * 0.55, f.s * 0.08, 0, 0, TAU); ctx.fill();
      const side = o.lane <= 0 ? 1 : -1;
      ctx.fillStyle = 'rgba(70,140,205,0.85)'; ctx.beginPath(); ctx.moveTo(f.X + side * f.s * 0.5, f.Y); ctx.lineTo(bk.X + side * bk.s * 0.5, bk.Y); ctx.lineTo(bT.X + side * bT.s * 0.5, bT.Y); ctx.lineTo(fT.X + side * fT.s * 0.5, fT.Y); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(225,248,255,0.96)'; ctx.beginPath(); ctx.moveTo(fT.X - fT.s * 0.5, fT.Y); ctx.lineTo(fT.X + fT.s * 0.5, fT.Y); ctx.lineTo(bT.X + bT.s * 0.5, bT.Y); ctx.lineTo(bT.X - bT.s * 0.5, bT.Y); ctx.closePath(); ctx.fill();
      const g = ctx.createLinearGradient(f.X - f.s * 0.5, 0, f.X + f.s * 0.5, 0); g.addColorStop(0, 'rgba(200,240,255,0.95)'); g.addColorStop(0.5, 'rgba(120,195,240,0.92)'); g.addColorStop(1, 'rgba(60,125,195,0.95)');
      ctx.fillStyle = g; ctx.fillRect(f.X - f.s * 0.5, fT.Y, f.s, f.Y - fT.Y);
      ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = Math.max(1, f.s * 0.012); ctx.beginPath(); ctx.moveTo(f.X - f.s * 0.3, fT.Y + f.s * 0.1); ctx.lineTo(f.X - f.s * 0.1, fT.Y + f.s * 0.45); ctx.lineTo(f.X - f.s * 0.2, fT.Y + f.s * 0.7); ctx.moveTo(f.X + f.s * 0.2, fT.Y + f.s * 0.2); ctx.lineTo(f.X + f.s * 0.28, fT.Y + f.s * 0.6); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.fillRect(f.X - f.s * 0.44, fT.Y + f.s * 0.06, f.s * 0.12, (f.Y - fT.Y) * 0.7);
      ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.moveTo(fT.X - fT.s * 0.52, fT.Y); ctx.quadraticCurveTo(fT.X, fT.Y - fT.s * 0.1, fT.X + fT.s * 0.52, fT.Y); ctx.lineTo(fT.X + fT.s * 0.5, fT.Y + fT.s * 0.04); ctx.lineTo(fT.X - fT.s * 0.5, fT.Y + fT.s * 0.04); ctx.closePath(); ctx.fill();
      ctx.globalAlpha = 1; return;
    }
    const sp = o.type === 'rock' ? pRockSprite() : o.type === 'arch' ? pArchSprite() : pSnowmanSprite(), scl = s / sp.u;
    if (near > 0 && !o.hit && !o.passed) { ctx.globalCompositeOperation = 'lighter'; const col = o.type === 'snowman' ? '255,120,120' : '150,220,255', gl = ctx.createRadialGradient(p.X, p.Y - s * 0.4, 0, p.X, p.Y - s * 0.4, s * 0.9); gl.addColorStop(0, `rgba(${col},${0.12 * near})`); gl.addColorStop(1, `rgba(${col},0)`); ctx.fillStyle = gl; ctx.fillRect(p.X - s, p.Y - s * 1.3, s * 2, s * 1.8); ctx.globalCompositeOperation = 'source-over'; }
    const wob = o.type === 'snowman' ? Math.sin(sceneT * 6 + o.z) * 0.04 : 0;
    ctx.save(); ctx.translate(p.X, p.Y); ctx.rotate(wob); ctx.drawImage(sp.c, -sp.ox * scl, -sp.oy * scl, sp.c.width * scl, sp.c.height * scl); ctx.restore();
    if (o.type === 'arch' && !o.hit) { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.25 + 0.2 * Math.sin(sceneT * 5); ctx.fillStyle = '#9fe2ff'; ctx.fillRect(p.X - s * 0.38, p.Y - s * 0.95, s * 0.76, s * 0.95); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; }
  },
  drawFish(f){
    const p = this.proj(f.lane, f.z, f.h), s = p.s; if (s < 3) return;
    const sp = pFishSprite(), spin = Math.cos(sceneT * 5 + f.z * 0.7), bob = Math.sin(sceneT * 4 + f.z) * s * 0.04, w = s * 0.58, h = w * 0.5;
    ctx.globalCompositeOperation = 'lighter'; const gl = ctx.createRadialGradient(p.X, p.Y + bob, 0, p.X, p.Y + bob, s * 0.35); gl.addColorStop(0, 'rgba(120,230,255,0.35)'); gl.addColorStop(1, 'rgba(120,230,255,0)'); ctx.fillStyle = gl; ctx.fillRect(p.X - s * 0.35, p.Y + bob - s * 0.35, s * 0.7, s * 0.7); ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = 'rgba(40,80,130,0.18)'; ctx.beginPath(); const g = this.proj(f.lane, f.z, 0); ctx.ellipse(g.X, g.Y, s * 0.16, s * 0.04, 0, 0, TAU); ctx.fill();
    ctx.save(); ctx.translate(p.X, p.Y + bob); ctx.scale(Math.abs(spin) < 0.15 ? 0.15 * Math.sign(spin || 1) : spin, 1); ctx.drawImage(sp.c, -w / 2, -h / 2, w, h); ctx.restore();
    if (Math.sin(sceneT * 3 + f.z) > 0.92) { ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = '#fff'; const x = p.X + s * 0.08, y = p.Y + bob - s * 0.06, r = s * 0.06; ctx.fillRect(x - r, y - 0.7, r * 2, 1.4); ctx.fillRect(x - 0.7, y - r, 1.4, r * 2); ctx.globalCompositeOperation = 'source-over'; }
  },
  drawPenguin(now){
    const p = this.proj(this.px, PZ, this.jumpH), g0 = this.proj(this.px, PZ, 0), s = p.s, k = s / PU;
    const dashing = this.dashT > 0, ducking = this.duckT > 0 && this.jumpT < 0, tilt = clamp(this.vx * 0.06, -0.45, 0.45);
    const col = this.vs ? PCOL[this.vs.pl] : '#ff4f6d', body = pPenguinSprite(col), fl = pFlipperSprite();
    const sq = this.squash, air = this.jumpT >= 0, rising = air && this.jumpT / 0.78 < 0.5;
    const sx = (1 + sq * 0.22) * (ducking ? 1.18 : 1) * (rising ? 0.94 : 1), sy = (1 - sq * 0.25) * (ducking ? 0.6 : 1) * (rising ? 1.08 : 1);
    // shadow shrinks as you fly
    const shs = pSoftSprite('shadow', '20,50,90'), sw = s * 0.9 * (1 - this.jumpH * 0.15); ctx.globalAlpha = 0.55 * (1 - this.jumpH * 0.2); ctx.drawImage(shs, g0.X - sw / 2, g0.Y - sw * 0.12, sw, sw * 0.24); ctx.globalAlpha = 1;
    // a faint reflection in the ice
    ctx.save(); ctx.globalAlpha = 0.13 * (1 - Math.min(1, this.jumpH)); ctx.translate(g0.X, g0.Y + (g0.Y - p.Y) + s * 0.02); ctx.scale(sx * k, -sy * k * 0.55); ctx.drawImage(body.c, -body.ox, -body.oy); ctx.restore();
    // after-images while changing lanes
    for (const gh of this.ghosts) { const q = this.proj(gh.x, PZ, gh.h); ctx.save(); ctx.globalAlpha = 0.22 * (1 - gh.t / 0.18); ctx.translate(q.X, q.Y - s * 0.05); ctx.scale(k * sx, k * sy); ctx.drawImage(body.c, -body.ox, -body.oy); ctx.restore(); }
    if (this.inv > 0 && ((this.inv * 14) | 0) % 2 === 0) ctx.globalAlpha = 0.4;
    ctx.save(); ctx.translate(p.X, p.Y - s * 0.05); ctx.rotate(tilt);
    if (dashing) {
      ctx.globalCompositeOperation = 'lighter';
      const gl = ctx.createRadialGradient(0, -s * 0.35, 0, 0, -s * 0.35, s * 1.0); gl.addColorStop(0, 'rgba(150,235,255,0.65)'); gl.addColorStop(1, 'rgba(150,235,255,0)'); ctx.fillStyle = gl; ctx.fillRect(-s * 1.1, -s * 1.4, s * 2.2, s * 2.2);
      ctx.strokeStyle = 'rgba(200,250,255,0.7)'; ctx.lineWidth = s * 0.02; for (let i = 0; i < 3; i++) { const r = s * (0.55 + ((sceneT * 3 + i / 3) % 1) * 0.5); ctx.globalAlpha = 1 - ((sceneT * 3 + i / 3) % 1); ctx.beginPath(); ctx.ellipse(0, -s * 0.3, r, r * 0.35, 0, 0, TAU); ctx.stroke(); }
      ctx.globalAlpha = this.inv > 0 && ((this.inv * 14) | 0) % 2 === 0 ? 0.4 : 1; ctx.globalCompositeOperation = 'source-over';
    }
    ctx.scale(sx, sy);
    // flippers (behind the body edges)
    const flap = dashing ? Math.sin(sceneT * 30) * 0.6 : air ? 0.6 + Math.sin(sceneT * 14) * 0.25 : Math.sin(sceneT * 4 + this.dist * 0.2) * 0.1;
    for (const sd of [-1, 1]) { ctx.save(); ctx.translate(sd * s * 0.26, -s * 0.42); ctx.rotate(sd * (0.55 + flap + (dashing ? 0.5 : 0) + (sd * tilt < 0 ? 0.2 : 0))); ctx.scale(k, k); ctx.drawImage(fl.c, -fl.ox, -fl.oy); ctx.restore(); }
    ctx.save(); ctx.scale(k, k); ctx.drawImage(body.c, -body.ox, -body.oy); ctx.restore();
    // scarf tails streaming in the wind
    const wv = sceneT * (10 + this.speed * 0.4), len = s * (0.32 + this.speed * 0.006 + (dashing ? 0.15 : 0));
    ctx.fillStyle = col; ctx.strokeStyle = zShade(col, -0.35); ctx.lineWidth = Math.max(1, s * 0.008);
    for (const [ox, ph, w] of [[0.1, 0, 0.065], [0.13, 1.4, 0.05]]) {
      const x0 = s * ox, y0 = -s * 0.46; ctx.beginPath(); ctx.moveTo(x0, y0 - s * w / 2);
      const pts = []; for (let i = 1; i <= 6; i++) { const t = i / 6; pts.push([x0 + len * t * 0.9 - tilt * s * 0.3 * t, y0 + len * t * 0.25 + Math.sin(wv - t * 4 + ph) * s * 0.05 * t]); }
      pts.forEach(([x, y], i) => ctx.lineTo(x, y - s * w / 2 * (1 - i / 7))); for (let i = pts.length - 1; i >= 0; i--) ctx.lineTo(pts[i][0], pts[i][1] + s * w / 2 * (1 - i / 7)); ctx.lineTo(x0, y0 + s * w / 2); ctx.closePath(); ctx.fill(); ctx.stroke();
    }
    // bouncing pom-pom
    const pb = Math.sin(sceneT * 9) * s * 0.012 + (air ? -s * 0.02 : 0) + sq * s * 0.03, pr = s * 0.065;
    const pg = ctx.createRadialGradient(-pr * 0.3, -s * 0.86 + pb - pr * 0.3, 0, 0, -s * 0.86 + pb, pr); pg.addColorStop(0, '#ffffff'); pg.addColorStop(1, '#c6d8ee'); ctx.fillStyle = pg; ctx.beginPath(); for (let i = 0; i < 12; i++) { const a = i / 12 * TAU, rr = pr * (i % 2 ? 0.85 : 1.05); ctx.lineTo(Math.cos(a) * rr, -s * 0.86 + pb + Math.sin(a) * rr); } ctx.closePath(); ctx.fill();
    ctx.restore(); ctx.globalAlpha = 1;
  },
};
