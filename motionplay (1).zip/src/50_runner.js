/* =====================================================================
   LANE RUNNER  (with changing worlds, checkpoints and a customizable runner)
   ===================================================================== */
const PZ = 1.6, ZNEAR = 3.2;

/* ---- the runner's look (edit in the Customize screen; saved on the TV) ---- */
const SKINS = ['#f6d3b3', '#e8b98a', '#c98d5f', '#a8693f', '#7a4a2b', '#4d2f1c', '#9be3a8', '#a8c8ff', '#d9b3ff'];
const HAIRC = ['#2a1b12', '#6b4a35', '#c9a24a', '#d2452e', '#f2f2f2', '#ff5fb0', '#3aa0ff', '#7be26f', '#ff8c1a', '#8a2be2', '#00c2a8', '#111111'];
const OUTFITS = ['#ff7a2f', '#e8323c', '#2f7cf6', '#3ec878', '#a65bff', '#ffd23f', '#ff5fb0', '#2b2f3a', '#f2c230', '#19f5c8', '#1a1a2a', '#c2185b', '#0aa3c2', '#ff4500', '#bfe9ff', '#4b5d2a', '#5b2d9c', '#ff00ff', '#101a4d'];
const PANTSC = ['#2b3a67', '#2b2f3a', '#6b4a35', '#3a6b4a', '#7a2b5a', '#d9d9e8', '#c2185b', '#0aa3c2', '#ff8c1a', '#222222'];
const STYLES = ['Short hair', 'Spiky', 'Ponytail', 'Afro', 'Cap', 'Beanie', 'Crown', 'Wizard hat', 'Cat ears', 'Space helmet', 'Ninja band', 'Top hat', 'Pirate hat', 'Viking helmet', 'Bunny ears', 'Party hat', 'Unicorn horn', 'Devil horns', 'Chef hat', 'Flower crown', 'Santa hat'];
const GADGETS = ['Nothing', 'Headphones', 'Scarf', 'Cape', 'Backpack', 'Halo', 'Angel wings', 'Jetpack', 'Gold cape', 'Aura', 'Sunglasses', 'Butterfly wings', 'Dragon wings', 'Gold medal', 'Orbit stars', 'Rainbow cape', 'Mustache', 'Fire aura', 'Ice aura'];
const TRAILS = ['None', 'Sparkles', 'Fire', 'Rainbow', 'Hearts', 'Galaxy', 'Lightning', 'Aurora', 'Confetti', 'Bubbles', 'Snow', 'Gold dust', 'Blue flame', 'Blossoms', 'Toxic', 'Pixel party', 'Comet'];
const TRAIL_X = { 9:{c:['#bfefff', '#e8fbff', '#9fe0ff'], vy:-0.5, g:-0.2, r:0.05, add:false}, 10:{c:['#fff', '#e8f4ff'], vy:0.35, g:0.1, r:0.035, add:false}, 11:{c:['#ffe14a', '#ffd23f', '#fff3a8'], vy:-0.2, g:0, r:0.03, add:true},
  12:{c:['#2f7cf6', '#8fdcff', '#fff'], vy:-0.6, g:-0.3, r:0.05, add:true}, 13:{c:['#ffc2dc', '#ff9ec4', '#fff'], vy:0.3, g:0.05, r:0.04, add:false}, 14:{c:['#7dff3a', '#c6ff3a', '#2fd26a'], vy:-0.3, g:-0.1, r:0.045, add:true},
  15:{c:['#ff4f6d', '#ffd23f', '#3ee08f', '#5b8cff'], vy:0, g:0, r:0.05, add:false, sq:true}, 16:{c:['#fff', '#8fdcff', '#b46bff'], vy:0, g:0, r:0.06, add:true, long:true} };
const loadChar = (key, def) => Object.assign({ skin:1, hair:1, style:0, outfit:0, pants:0, gadget:0, trail:0 }, def, (() => { try { return JSON.parse(store.get(key, '{}')); } catch { return {}; } })());
const CHAR1 = loadChar('mp-char', {}), CHAR2 = loadChar('mp-char2', { skin:2, hair:3, outfit:2, pants:1 });   // player 1's and player 2's runner
let CHAR = CHAR1;                                   // whoever is being drawn / edited right now (see withPlayer, locker, shop)
const saveChar = () => { store.set('mp-char', JSON.stringify(CHAR1)); store.set('mp-char2', JSON.stringify(CHAR2)); };
const charOf = i => i ? CHAR2 : CHAR1;
/* ---- coin wallet + cosmetics shop (coins only; saved on this TV) ---- */
const FREE = { skin:99, hair:99, pants:99, outfit:8, style:6, gadget:6, trail:5 };   // first N of each list are free
const SHOP = [
  { cat:'trail',  key:'trail',  i:8,  name:'Confetti',    price:100 },
  { cat:'trail',  key:'trail',  i:5,  name:'Galaxy',      price:200 },
  { cat:'trail',  key:'trail',  i:6,  name:'Lightning',   price:300 },
  { cat:'trail',  key:'trail',  i:7,  name:'Aurora',      price:400 },
  { cat:'hat',    key:'style',  i:8,  name:'Cat ears',    price:150 },
  { cat:'hat',    key:'style',  i:10, name:'Ninja band',  price:200 },
  { cat:'hat',    key:'style',  i:7,  name:'Wizard hat',  price:300 },
  { cat:'hat',    key:'style',  i:6,  name:'Crown',       price:400 },
  { cat:'hat',    key:'style',  i:9,  name:'Space helmet',price:500 },
  { cat:'gadget', key:'gadget', i:8,  name:'Gold cape',   price:350 },
  { cat:'gadget', key:'gadget', i:7,  name:'Jetpack',     price:500 },
  { cat:'gadget', key:'gadget', i:9,  name:'Aura',        price:600 },
  { cat:'gadget', key:'gadget', i:6,  name:'Angel wings', price:800 },
  { cat:'suit',   key:'outfit', i:10, name:'Shadow suit', price:250 },
  { cat:'suit',   key:'outfit', i:8,  name:'Gold suit',   price:350 },
  { cat:'suit',   key:'outfit', i:9,  name:'Neon suit',   price:450 },
  // ---- v6: lots more ----
  { cat:'trail',  key:'trail',  i:9,  name:'Bubbles',     price:120 },
  { cat:'trail',  key:'trail',  i:10, name:'Snow',        price:150 },
  { cat:'trail',  key:'trail',  i:13, name:'Blossoms',    price:180 },
  { cat:'trail',  key:'trail',  i:15, name:'Pixel party', price:250 },
  { cat:'trail',  key:'trail',  i:11, name:'Gold dust',   price:350 },
  { cat:'trail',  key:'trail',  i:14, name:'Toxic',       price:350 },
  { cat:'trail',  key:'trail',  i:12, name:'Blue flame',  price:500 },
  { cat:'trail',  key:'trail',  i:16, name:'Comet',       price:650 },
  { cat:'hat',    key:'style',  i:15, name:'Party hat',   price:120 },
  { cat:'hat',    key:'style',  i:18, name:'Chef hat',    price:150 },
  { cat:'hat',    key:'style',  i:14, name:'Bunny ears',  price:180 },
  { cat:'hat',    key:'style',  i:20, name:'Santa hat',   price:200 },
  { cat:'hat',    key:'style',  i:19, name:'Flower crown',price:250 },
  { cat:'hat',    key:'style',  i:11, name:'Top hat',     price:300 },
  { cat:'hat',    key:'style',  i:12, name:'Pirate hat',  price:350 },
  { cat:'hat',    key:'style',  i:13, name:'Viking helmet',price:400 },
  { cat:'hat',    key:'style',  i:17, name:'Devil horns', price:450 },
  { cat:'hat',    key:'style',  i:16, name:'Unicorn horn',price:600 },
  { cat:'gadget', key:'gadget', i:10, name:'Sunglasses',  price:150 },
  { cat:'gadget', key:'gadget', i:16, name:'Mustache',    price:150 },
  { cat:'gadget', key:'gadget', i:13, name:'Gold medal',  price:300 },
  { cat:'gadget', key:'gadget', i:15, name:'Rainbow cape',price:450 },
  { cat:'gadget', key:'gadget', i:14, name:'Orbit stars', price:500 },
  { cat:'gadget', key:'gadget', i:18, name:'Ice aura',    price:650 },
  { cat:'gadget', key:'gadget', i:17, name:'Fire aura',   price:650 },
  { cat:'gadget', key:'gadget', i:11, name:'Butterfly wings', price:700 },
  { cat:'gadget', key:'gadget', i:12, name:'Dragon wings',price:900 },
  { cat:'suit',   key:'outfit', i:15, name:'Camo suit',   price:200 },
  { cat:'suit',   key:'outfit', i:16, name:'Royal suit',  price:300 },
  { cat:'suit',   key:'outfit', i:11, name:'Ruby suit',   price:300 },
  { cat:'suit',   key:'outfit', i:12, name:'Ocean suit',  price:350 },
  { cat:'suit',   key:'outfit', i:14, name:'Ice suit',    price:400 },
  { cat:'suit',   key:'outfit', i:13, name:'Lava suit',   price:500 },
  { cat:'suit',   key:'outfit', i:18, name:'Galaxy suit', price:700 },
  { cat:'suit',   key:'outfit', i:17, name:'Rainbow suit',price:900 },
];
const WALLET = { coins: Math.max(0, +store.get('mp-coins', 0) || 0), owned: (() => { try { const a = JSON.parse(store.get('mp-owned', '[]')); return Array.isArray(a) ? a : []; } catch { return []; } })() };
const saveWallet = () => { store.set('mp-coins', String(WALLET.coins)); store.set('mp-owned', JSON.stringify(WALLET.owned)); };
const earnCoins = n => { WALLET.coins += n; saveWallet(); return n; };   // straight into the wallet (zombie waves, shape-fit streaks, 2-player wins)
const owns = (key, i) => i < (FREE[key] ?? 99) || WALLET.owned.includes(key + ':' + i);
const ownedList = (key, n) => { const r = []; for (let i = 0; i < n; i++) if (owns(key, i)) r.push(i); return r; };
const nextOwned = (key, n) => { for (let k = 1; k <= n; k++) { const i = (CHAR[key] + k) % n; if (owns(key, i)) return i; } return CHAR[key]; };
for (const C of [CHAR1, CHAR2]) for (const k of Object.keys(FREE)) if (!owns(k, C[k])) C[k] = 0;   // safety: never wear something you don't own

// pose: { run (-1..1), duck, air (0..1 jumping), t, front }
function drawChar(X, Y, s, pose = {}){
  const run = pose.run || 0, ducking = !!pose.duck, k = ducking ? 0.55 : 1, t = pose.t || 0, front = !!pose.front;
  const skin = SKINS[CHAR.skin], hair = HAIRC[CHAR.hair], coat = CHAR.outfit === 17 ? `hsl(${(t * 90) % 360},85%,58%)` : OUTFITS[CHAR.outfit], pants = PANTSC[CHAR.pants];
  const legH = s * 0.42 * (pose.air ? 0.7 : 1) * k;
  const torsoH = s * 0.45 * k, ty = Y - legH - torsoH, hr = s * 0.15, hy = ty - hr * 0.85;
  const sway = Math.sin(t * 14) * 0.5 * (pose.air ? 0.2 : 1);
  ctx.lineCap = 'round';
  if (CHAR.gadget === 9 || CHAR.gadget === 17 || CHAR.gadget === 18) {   // aura (rainbow / fire / ice)
    ctx.globalCompositeOperation = 'lighter'; const ap = 0.8 + Math.sin(t * 6) * 0.2;
    const ag = ctx.createRadialGradient(X, Y - s * 0.42, s * 0.05, X, Y - s * 0.42, s * 0.75 * ap); ag.addColorStop(0, `hsla(${CHAR.gadget === 9 ? (t * 120) % 360 : CHAR.gadget === 17 ? 18 + Math.sin(t * 9) * 14 : 190},100%,${CHAR.gadget === 18 ? 75 : 62}%,0.55)`); ag.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = ag; ctx.beginPath(); ctx.arc(X, Y - s * 0.42, s * 0.8, 0, TAU); ctx.fill(); ctx.globalCompositeOperation = 'source-over';
  }
  const WINGC = { 6:['#ffffff', '#9fd8ff'], 11:['#ff9ad8', '#7a5bff'], 12:['#ff5a4d', '#4a0f26'] };
  if (WINGC[CHAR.gadget]) {   // angel / butterfly / dragon wings
    const fl = Math.sin(t * 9) * 0.12;
    for (const sd of [-1, 1]) {
      ctx.save(); ctx.translate(X + sd * s * 0.1, ty + torsoH * 0.2); ctx.scale(sd, 1); ctx.rotate(-0.2 - fl);
      const wg = ctx.createLinearGradient(0, 0, s * 0.6, -s * 0.3); wg.addColorStop(0, WINGC[CHAR.gadget][0]); wg.addColorStop(1, WINGC[CHAR.gadget][1]);
      ctx.fillStyle = wg; ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(s * 0.3, -s * 0.5, s * 0.66, -s * 0.3); ctx.quadraticCurveTo(s * 0.52, -s * 0.18, s * 0.6, -s * 0.06); ctx.quadraticCurveTo(s * 0.42, -s * 0.03, s * 0.44, s * 0.09); ctx.quadraticCurveTo(s * 0.26, s * 0.05, s * 0.2, s * 0.2); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(120,170,220,0.6)'; ctx.lineWidth = Math.max(1, s * 0.008); ctx.stroke();
      ctx.restore();
    }
  }
  if (CHAR.gadget === 7) {   // jetpack
    for (const sd of [-1, 1]) {
      ctx.fillStyle = '#8f98b3'; roundRect(X + sd * s * 0.2 - s * 0.06, ty + torsoH * 0.05, s * 0.12, torsoH * 0.75, s * 0.05); ctx.fill();
      ctx.fillStyle = '#e8323c'; ctx.fillRect(X + sd * s * 0.2 - s * 0.06, ty + torsoH * 0.2, s * 0.12, torsoH * 0.07);
      const fh = s * (0.14 + Math.random() * 0.1) * (pose.air ? 1.6 : 1);
      ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = '#ff9a1f'; ctx.beginPath(); ctx.moveTo(X + sd * s * 0.2 - s * 0.045, ty + torsoH * 0.8); ctx.lineTo(X + sd * s * 0.2 + s * 0.045, ty + torsoH * 0.8); ctx.lineTo(X + sd * s * 0.2, ty + torsoH * 0.8 + fh); ctx.fill();
      ctx.fillStyle = '#ffe9a0'; ctx.beginPath(); ctx.moveTo(X + sd * s * 0.2 - s * 0.02, ty + torsoH * 0.8); ctx.lineTo(X + sd * s * 0.2 + s * 0.02, ty + torsoH * 0.8); ctx.lineTo(X + sd * s * 0.2, ty + torsoH * 0.8 + fh * 0.55); ctx.fill(); ctx.globalCompositeOperation = 'source-over';
    }
  }
  // cape / ponytail sit behind the body
  if (CHAR.gadget === 3 || CHAR.gadget === 8 || CHAR.gadget === 15) {
    ctx.fillStyle = CHAR.gadget === 8 ? '#e8b92f' : CHAR.gadget === 15 ? `hsl(${(t * 140) % 360},90%,60%)` : '#d6264a'; ctx.beginPath(); ctx.moveTo(X - s * 0.2, ty + s * 0.02);
    ctx.quadraticCurveTo(X - s * 0.3 + sway * s * 0.05, ty + torsoH * 1.1, X - s * 0.22 + sway * s * 0.08, Y - legH * 0.4);
    ctx.lineTo(X + s * 0.22 - sway * s * 0.08, Y - legH * 0.4); ctx.quadraticCurveTo(X + s * 0.3 - sway * s * 0.05, ty + torsoH * 1.1, X + s * 0.2, ty + s * 0.02); ctx.closePath(); ctx.fill();
    if (front) { ctx.fillStyle = 'rgba(0,0,0,0.18)'; ctx.fill(); }
  }
  // legs + shoes
  const lf = Math.max(0, run) * s * 0.08, rf = Math.max(0, -run) * s * 0.08;
  ctx.fillStyle = pants; roundRect(X - s * 0.17, Y - legH - lf, s * 0.13, legH, s * 0.05); ctx.fill(); roundRect(X + s * 0.04, Y - legH - rf, s * 0.13, legH, s * 0.05); ctx.fill();
  ctx.fillStyle = '#f4f4fa'; roundRect(X - s * 0.19, Y - s * 0.06 - lf, s * 0.17, s * 0.07, s * 0.03); ctx.fill(); roundRect(X + s * 0.02, Y - s * 0.06 - rf, s * 0.17, s * 0.07, s * 0.03); ctx.fill();
  // arms behind torso for backpack look, then torso
  ctx.fillStyle = coat; roundRect(X - s * 0.22, ty, s * 0.44, torsoH, s * 0.1); ctx.fill();
  ctx.fillStyle = 'rgba(0,0,0,0.14)'; roundRect(X - s * 0.15, ty + torsoH * 0.12, s * 0.3, torsoH * 0.6, s * 0.06); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.75)'; ctx.fillRect(X - s * 0.22, ty + torsoH * 0.78, s * 0.44, torsoH * 0.07);
  if (CHAR.outfit >= 8) {   // premium suits shimmer
    ctx.save(); roundRect(X - s * 0.22, ty, s * 0.44, torsoH, s * 0.1); ctx.clip();
    const bx = X - s * 0.4 + ((t * 0.6) % 1) * s * 0.9;
    ctx.fillStyle = 'rgba(255,255,255,0.45)'; ctx.beginPath(); ctx.moveTo(bx, ty); ctx.lineTo(bx + s * 0.1, ty); ctx.lineTo(bx - s * 0.05, ty + torsoH); ctx.lineTo(bx - s * 0.15, ty + torsoH); ctx.fill();
    ctx.restore();
    if (CHAR.outfit === 9) { ctx.strokeStyle = '#eafffb'; ctx.lineWidth = Math.max(2, s * 0.012); roundRect(X - s * 0.22, ty, s * 0.44, torsoH, s * 0.1); ctx.stroke(); }
  }
  if (CHAR.outfit === 18) { ctx.fillStyle = '#fff'; for (let n = 0; n < 9; n++) { const sx = X - s * 0.19 + ((n * 37) % 38) / 38 * s * 0.38, sy = ty + ((n * 53) % 41) / 41 * torsoH * 0.95; ctx.globalAlpha = 0.5 + 0.5 * Math.sin(t * 4 + n); ctx.beginPath(); ctx.arc(sx, sy, Math.max(1, s * 0.01), 0, TAU); ctx.fill(); } ctx.globalAlpha = 1; }
  if (CHAR.gadget === 13 && front) { ctx.strokeStyle = '#d6264a'; ctx.lineWidth = s * 0.03; ctx.beginPath(); ctx.moveTo(X - s * 0.1, ty); ctx.lineTo(X, ty + torsoH * 0.35); ctx.lineTo(X + s * 0.1, ty); ctx.stroke(); ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.arc(X, ty + torsoH * 0.42, s * 0.055, 0, TAU); ctx.fill(); ctx.strokeStyle = '#b8860b'; ctx.lineWidth = s * 0.01; ctx.stroke(); }
  if (CHAR.gadget === 4 && !front) { ctx.fillStyle = '#3b4a7a'; roundRect(X - s * 0.15, ty + torsoH * 0.08, s * 0.3, torsoH * 0.7, s * 0.06); ctx.fill(); ctx.fillStyle = '#ffd23f'; ctx.fillRect(X - s * 0.15, ty + torsoH * 0.34, s * 0.3, torsoH * 0.06); }
  ctx.fillStyle = coat;
  roundRect(X - s * 0.32, ty + s * 0.04 + run * s * 0.05, s * 0.1, torsoH * 0.75, s * 0.05); ctx.fill();
  roundRect(X + s * 0.22, ty + s * 0.04 - run * s * 0.05, s * 0.1, torsoH * 0.75, s * 0.05); ctx.fill();
  ctx.fillStyle = skin; ctx.beginPath(); ctx.arc(X - s * 0.27, ty + s * 0.04 + torsoH * 0.75 + run * s * 0.05, s * 0.05, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(X + s * 0.27, ty + s * 0.04 + torsoH * 0.75 - run * s * 0.05, s * 0.05, 0, TAU); ctx.fill();
  if (CHAR.gadget === 2) {   // scarf
    ctx.fillStyle = '#ff4f6d'; roundRect(X - s * 0.17, ty - s * 0.03, s * 0.34, s * 0.09, s * 0.04); ctx.fill();
    ctx.beginPath(); ctx.moveTo(X + s * 0.1, ty); ctx.quadraticCurveTo(X + s * 0.3 + sway * s * 0.05, ty + s * 0.05, X + s * (0.38 + sway * 0.08), ty + s * 0.18 + sway * s * 0.04); ctx.lineTo(X + s * 0.31, ty + s * 0.2); ctx.quadraticCurveTo(X + s * 0.22, ty + s * 0.1, X + s * 0.06, ty + s * 0.06); ctx.fill();
  }
  // head
  if (CHAR.style === 2) { ctx.fillStyle = hair; ctx.beginPath(); ctx.ellipse(X + sway * s * 0.06, hy + hr * 0.9, hr * 0.38, hr * 1.1, sway * 0.5, 0, TAU); ctx.fill(); }
  ctx.fillStyle = skin; ctx.beginPath(); ctx.arc(X, hy, hr, 0, TAU); ctx.fill();
  const cap = OUTFITS[(CHAR.outfit + 3) % OUTFITS.length];
  const dome = (col, h = 1.02) => { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(X, hy - hr * 0.1, hr * h, Math.PI, 0); ctx.fill(); };
  if (front) {
    ctx.fillStyle = '#2a1b12'; ctx.beginPath(); ctx.arc(X - hr * 0.38, hy + hr * 0.05, hr * 0.1, 0, TAU); ctx.arc(X + hr * 0.38, hy + hr * 0.05, hr * 0.1, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#2a1b12'; ctx.lineWidth = Math.max(2, hr * 0.09); ctx.beginPath(); ctx.arc(X, hy + hr * 0.25, hr * 0.38, 0.2, Math.PI - 0.2); ctx.stroke();
  }
  switch (CHAR.style) {
    case 0: dome(hair); if (!front) ctx.fillRect(X - hr, hy - hr * 0.1, hr * 2, hr * 0.7); break;
    case 1: dome(hair); ctx.beginPath(); for (let i = 0; i < 5; i++) { const a = Math.PI + (i + 0.5) / 5 * Math.PI; ctx.moveTo(X + Math.cos(a - 0.2) * hr, hy - hr * 0.1 + Math.sin(a - 0.2) * hr); ctx.lineTo(X + Math.cos(a) * hr * 1.5, hy - hr * 0.1 + Math.sin(a) * hr * 1.5); ctx.lineTo(X + Math.cos(a + 0.2) * hr, hy - hr * 0.1 + Math.sin(a + 0.2) * hr); } ctx.fill(); if (!front) ctx.fillRect(X - hr, hy - hr * 0.1, hr * 2, hr * 0.55); break;
    case 2: dome(hair); if (!front) ctx.fillRect(X - hr, hy - hr * 0.1, hr * 2, hr * 0.6); break;
    case 3: ctx.fillStyle = hair; ctx.beginPath(); ctx.arc(X, hy - hr * 0.1, hr * 1.4, 0, TAU); ctx.fill(); ctx.fillStyle = skin; if (front) { ctx.beginPath(); ctx.arc(X, hy + hr * 0.2, hr * 0.85, 0, TAU); ctx.fill(); ctx.fillStyle = '#2a1b12'; ctx.beginPath(); ctx.arc(X - hr * 0.38, hy + hr * 0.1, hr * 0.1, 0, TAU); ctx.arc(X + hr * 0.38, hy + hr * 0.1, hr * 0.1, 0, TAU); ctx.fill(); ctx.strokeStyle = '#2a1b12'; ctx.lineWidth = Math.max(2, hr * 0.09); ctx.beginPath(); ctx.arc(X, hy + hr * 0.3, hr * 0.38, 0.2, Math.PI - 0.2); ctx.stroke(); } break;
    case 4: dome(cap, 1.06); ctx.fillStyle = cap; ctx.fillRect(X - hr * 1.06, hy - hr * 0.16, hr * 2.12, hr * 0.16); if (front) { ctx.fillRect(X - hr * 1.1, hy - hr * 0.2, hr * 2.2, hr * 0.22); } else { ctx.fillStyle = hair; ctx.fillRect(X - hr * 0.7, hy, hr * 1.4, hr * 0.5); } break;
    case 6: dome(hair); { const cb = hy - hr * 0.8, cw = hr * 1.0; ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.moveTo(X - cw, cb); ctx.lineTo(X - cw, cb - hr * 0.75); ctx.lineTo(X - cw * 0.5, cb - hr * 0.35); ctx.lineTo(X, cb - hr * 0.9); ctx.lineTo(X + cw * 0.5, cb - hr * 0.35); ctx.lineTo(X + cw, cb - hr * 0.75); ctx.lineTo(X + cw, cb); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#ff3b6b'; ctx.beginPath(); ctx.arc(X, cb - hr * 0.22, hr * 0.14, 0, TAU); ctx.fill(); ctx.fillStyle = '#fff6b8'; ctx.beginPath(); ctx.arc(X - cw * 0.65, cb - hr * 0.5, hr * 0.07, 0, TAU); ctx.arc(X + cw * 0.65, cb - hr * 0.5, hr * 0.07, 0, TAU); ctx.fill(); } break;
    case 7: { const by = hy - hr * 0.7; ctx.fillStyle = '#5a2d9c'; ctx.beginPath(); ctx.ellipse(X, by, hr * 1.7, hr * 0.32, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(X - hr * 0.95, by); ctx.quadraticCurveTo(X - hr * 0.2, by - hr * 1.3, X + hr * 0.7 + sway * hr * 0.15, by - hr * 2.0); ctx.quadraticCurveTo(X + hr * 0.5, by - hr * 0.8, X + hr * 0.95, by); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#ffd23f'; ctx.fillRect(X - hr * 0.95, by - hr * 0.22, hr * 1.9, hr * 0.2); ctx.fillStyle = '#fff6b8'; ctx.beginPath(); ctx.arc(X - hr * 0.1, by - hr * 0.75, hr * 0.1, 0, TAU); ctx.arc(X + hr * 0.25, by - hr * 1.2, hr * 0.07, 0, TAU); ctx.fill(); } break;
    case 8: dome(hair); for (const sd of [-1, 1]) { const bx = X + sd * hr * 0.62, by = hy - hr * 0.7; ctx.fillStyle = hair; ctx.beginPath(); ctx.moveTo(bx - hr * 0.35, by + hr * 0.15); ctx.lineTo(bx + sd * hr * 0.05, by - hr * 0.8); ctx.lineTo(bx + hr * 0.35, by + hr * 0.15); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#ff9ec4'; ctx.beginPath(); ctx.moveTo(bx - hr * 0.18, by + hr * 0.1); ctx.lineTo(bx + sd * hr * 0.04, by - hr * 0.5); ctx.lineTo(bx + hr * 0.18, by + hr * 0.1); ctx.closePath(); ctx.fill(); } break;
    case 9: ctx.fillStyle = 'rgba(170,215,255,0.28)'; ctx.beginPath(); ctx.arc(X, hy, hr * 1.38, 0, TAU); ctx.fill(); ctx.strokeStyle = '#e8eef8'; ctx.lineWidth = hr * 0.16; ctx.stroke(); ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = hr * 0.09; ctx.beginPath(); ctx.arc(X, hy, hr * 1.05, Math.PI * 1.1, Math.PI * 1.45); ctx.stroke(); ctx.fillStyle = '#ff4f6d'; ctx.fillRect(X - hr * 0.08, hy - hr * 1.8, hr * 0.16, hr * 0.45); ctx.beginPath(); ctx.arc(X, hy - hr * 1.82, hr * 0.14, 0, TAU); ctx.fill(); break;
    case 10: dome(hair); ctx.fillStyle = '#e8323c'; ctx.fillRect(X - hr * 1.02, hy - hr * 0.55, hr * 2.04, hr * 0.3); for (const k2 of [0, 1]) { ctx.beginPath(); ctx.moveTo(X + hr * 1.0, hy - hr * 0.4); ctx.lineTo(X + hr * (1.6 + sway * 0.25), hy - hr * (0.2 - k2 * 0.5 - sway * 0.2)); ctx.lineTo(X + hr * 1.0, hy - hr * 0.25); ctx.fill(); } break;
    case 11: dome(hair); ctx.fillStyle = '#16161e'; ctx.fillRect(X - hr * 0.8, hy - hr * 1.9, hr * 1.6, hr * 1.2); ctx.fillStyle = '#c2185b'; ctx.fillRect(X - hr * 0.8, hy - hr * 1.0, hr * 1.6, hr * 0.22); ctx.fillStyle = '#16161e'; ctx.beginPath(); ctx.ellipse(X, hy - hr * 0.7, hr * 1.5, hr * 0.25, 0, 0, TAU); ctx.fill(); break;
    case 12: { dome(hair); const by = hy - hr * 0.7; ctx.fillStyle = '#1b1b26'; ctx.beginPath(); ctx.moveTo(X - hr * 1.7, by + hr * 0.1); ctx.quadraticCurveTo(X, by - hr * 1.9, X + hr * 1.7, by + hr * 0.1); ctx.quadraticCurveTo(X, by + hr * 0.4, X - hr * 1.7, by + hr * 0.1); ctx.fill(); ctx.fillStyle = '#f2f2f2'; ctx.beginPath(); ctx.arc(X, by - hr * 0.5, hr * 0.22, 0, TAU); ctx.fill(); ctx.fillRect(X - hr * 0.06, by - hr * 0.2, hr * 0.12, hr * 0.5); break; }
    case 13: { ctx.fillStyle = '#9aa3b5'; ctx.beginPath(); ctx.arc(X, hy - hr * 0.1, hr * 1.1, Math.PI, 0); ctx.fill(); ctx.fillRect(X - hr * 1.1, hy - hr * 0.2, hr * 2.2, hr * 0.2); ctx.fillStyle = '#f4ecd8'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(X + sd * hr * 1.0, hy - hr * 0.4); ctx.quadraticCurveTo(X + sd * hr * 1.9, hy - hr * 0.6, X + sd * hr * 1.6, hy - hr * 1.5); ctx.quadraticCurveTo(X + sd * hr * 1.3, hy - hr * 0.8, X + sd * hr * 0.9, hy - hr * 0.7); ctx.fill(); } break; }
    case 14: dome(hair); for (const sd of [-1, 1]) { ctx.fillStyle = '#f4f4fa'; ctx.beginPath(); ctx.ellipse(X + sd * hr * 0.5, hy - hr * 1.7 + Math.sin(t * 3 + sd) * hr * 0.06, hr * 0.28, hr * 0.9, sd * 0.2, 0, TAU); ctx.fill(); ctx.fillStyle = '#ff9ec4'; ctx.beginPath(); ctx.ellipse(X + sd * hr * 0.5, hy - hr * 1.7, hr * 0.14, hr * 0.62, sd * 0.2, 0, TAU); ctx.fill(); } break;
    case 15: dome(hair); ctx.fillStyle = '#ff5fb0'; ctx.beginPath(); ctx.moveTo(X - hr * 0.7, hy - hr * 0.8); ctx.lineTo(X, hy - hr * 2.3); ctx.lineTo(X + hr * 0.7, hy - hr * 0.8); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#ffe14a'; ctx.fillRect(X - hr * 0.4, hy - hr * 1.3, hr * 0.8, hr * 0.14); ctx.beginPath(); ctx.arc(X, hy - hr * 2.3, hr * 0.17, 0, TAU); ctx.fill(); break;
    case 16: dome(hair); { const g2 = ctx.createLinearGradient(X, hy - hr * 2.2, X, hy - hr); g2.addColorStop(0, '#ffe14a'); g2.addColorStop(1, '#ff9ad8'); ctx.fillStyle = g2; ctx.beginPath(); ctx.moveTo(X - hr * 0.22, hy - hr * 1.0); ctx.lineTo(X, hy - hr * 2.3); ctx.lineTo(X + hr * 0.22, hy - hr * 1.0); ctx.closePath(); ctx.fill(); } break;
    case 17: dome(hair); for (const sd of [-1, 1]) { ctx.fillStyle = '#d6264a'; ctx.beginPath(); ctx.moveTo(X + sd * hr * 0.35, hy - hr * 0.9); ctx.quadraticCurveTo(X + sd * hr * 1.0, hy - hr * 1.2, X + sd * hr * 0.85, hy - hr * 1.9); ctx.quadraticCurveTo(X + sd * hr * 0.55, hy - hr * 1.3, X + sd * hr * 0.1, hy - hr * 0.9); ctx.fill(); } break;
    case 18: dome(hair); ctx.fillStyle = '#fff'; ctx.fillRect(X - hr * 0.85, hy - hr * 1.0, hr * 1.7, hr * 0.3); for (const dx2 of [-0.7, 0, 0.7]) { ctx.beginPath(); ctx.arc(X + dx2 * hr, hy - hr * 1.5, hr * 0.5, 0, TAU); ctx.fill(); } ctx.fillRect(X - hr * 0.8, hy - hr * 1.5, hr * 1.6, hr * 0.6); break;
    case 19: dome(hair); for (let n = 0; n < 7; n++) { const a = Math.PI + (n + 0.5) / 7 * Math.PI; ctx.fillStyle = ['#ff5fb0', '#ffd23f', '#fff', '#9b5bff'][n % 4]; ctx.beginPath(); ctx.arc(X + Math.cos(a) * hr * 1.0, hy - hr * 0.1 + Math.sin(a) * hr * 1.0, hr * 0.2, 0, TAU); ctx.fill(); } break;
    case 20: dome(hair); ctx.fillStyle = '#d6264a'; ctx.beginPath(); ctx.moveTo(X - hr * 1.0, hy - hr * 0.5); ctx.quadraticCurveTo(X - hr * 0.2, hy - hr * 2.0, X + hr * 1.5 + sway * hr * 0.2, hy - hr * 1.0); ctx.lineTo(X + hr * 1.0, hy - hr * 0.5); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#fff'; ctx.fillRect(X - hr * 1.05, hy - hr * 0.62, hr * 2.1, hr * 0.28); ctx.beginPath(); ctx.arc(X + hr * 1.5 + sway * hr * 0.2, hy - hr * 1.0, hr * 0.24, 0, TAU); ctx.fill(); break;
    case 5: dome(cap, 1.08); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(X - hr * 1.08, hy - hr * 0.35, hr * 2.16, hr * 0.12); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(X, hy - hr * 1.12, hr * 0.22, 0, TAU); ctx.fill(); break;
  }
  if (CHAR.gadget === 10) { ctx.fillStyle = '#111'; if (front) { roundRect(X - hr * 0.95, hy - hr * 0.22, hr * 0.85, hr * 0.5, hr * 0.15); ctx.fill(); roundRect(X + hr * 0.1, hy - hr * 0.22, hr * 0.85, hr * 0.5, hr * 0.15); ctx.fill(); ctx.fillRect(X - hr * 0.15, hy - hr * 0.12, hr * 0.3, hr * 0.08); ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.fillRect(X - hr * 0.8, hy - hr * 0.15, hr * 0.25, hr * 0.07); } else ctx.fillRect(X - hr * 1.02, hy - hr * 0.2, hr * 2.04, hr * 0.12); }
  if (CHAR.gadget === 16 && front) { ctx.fillStyle = '#2a1b12'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.ellipse(X + sd * hr * 0.3, hy + hr * 0.3, hr * 0.38, hr * 0.14, sd * -0.25, 0, TAU); ctx.fill(); } }
  if (CHAR.gadget === 14) { ctx.globalCompositeOperation = 'lighter'; for (let n = 0; n < 3; n++) { const a = t * 3 + n * 2.094; ctx.fillStyle = '#ffe14a'; ctx.beginPath(); ctx.arc(X + Math.cos(a) * s * 0.42, ty + torsoH * 0.3 + Math.sin(a) * s * 0.12, s * 0.035, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,225,74,0.25)'; ctx.beginPath(); ctx.arc(X + Math.cos(a) * s * 0.42, ty + torsoH * 0.3 + Math.sin(a) * s * 0.12, s * 0.08, 0, TAU); ctx.fill(); } ctx.globalCompositeOperation = 'source-over'; }
  if (CHAR.gadget === 1) {   // headphones
    ctx.strokeStyle = '#2b2f3a'; ctx.lineWidth = hr * 0.22; ctx.beginPath(); ctx.arc(X, hy - hr * 0.05, hr * 1.12, Math.PI * 1.05, Math.PI * 1.95); ctx.stroke();
    ctx.fillStyle = '#ff4f6d'; roundRect(X - hr * 1.3, hy - hr * 0.3, hr * 0.38, hr * 0.8, hr * 0.15); ctx.fill(); roundRect(X + hr * 0.92, hy - hr * 0.3, hr * 0.38, hr * 0.8, hr * 0.15); ctx.fill();
  }
  if (CHAR.gadget === 5) {   // halo
    ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(255,225,74,0.3)'; ctx.beginPath(); ctx.ellipse(X, hy - hr * 1.6, hr * 1.1, hr * 0.4, 0, 0, TAU); ctx.fill(); ctx.globalCompositeOperation = 'source-over';
    ctx.strokeStyle = '#ffe14a'; ctx.lineWidth = hr * 0.18; ctx.beginPath(); ctx.ellipse(X, hy - hr * 1.6 + Math.sin(t * 5) * hr * 0.05, hr * 0.85, hr * 0.28, 0, 0, TAU); ctx.stroke();
  }
}

/* ---- the worlds you run through (a new one at every checkpoint (1000 m)) ---- */
const RZONES = [
  { name:'Sunny Meadow', sky:['#5ec8ff', '#d6f3ff'], ground:['#7cc66a', '#3f9b45'], road:'#7d6a5c', far:'hills', deco:'tree', sun:'#fff3a8' },
  { name:'Skyline City', sky:['#6fb6ff', '#cfeeff'], ground:['#8a9aa6', '#5d6b78'], road:'#6c6f7c', far:'city', deco:'lamp', sun:'#fff3a8' },
  { name:'Desert Sunset', sky:['#ff8a5c', '#ffe0a3'], ground:['#e0b26a', '#c58f4a'], road:'#8a6a50', far:'mesa', deco:'cactus', sun:'#ff5a3c' },
  { name:'Starry Night', sky:['#0b1040', '#40338a'], ground:['#1f6a55', '#124a3c'], road:'#4a4a66', far:'nightcity', deco:'glow', sun:'#e8f0ff', stars:true },
];
const ROAD_HALF = 1.55, CHECK_EVERY = 1000;

scenes.runner = {
  game:true, music:'runner', hint:'Step left/right to change lanes · jump · squat to duck',
  enter(){
    Object.assign(this, { obs:[], coins:[], deco:[], parts:[], pops:[], speed:11, dist:0, coinN:0, lives:3, inv:0, px:0, lastLane:0, jumpT:-1, jumpH:0, duckT:0,
                          untilRow:30, untilDeco:0, state:'ready', readyT:3.4, t:0, shake:0, msgs:[], best:+store.get('mp-best-runner', 0), zone:0, prevZone:0, zoneBlend:1, banner:{ text:'', t:9 },
                          nextCheck:CHECK_EVERY, dust:0, trailT:0, coinStreak:0, lastCoinT:-9, wasAir:false, clouds:[], birds:[], flash:0, banked:false, dead:false });
    this.R = this.vs ? mulberry32(this.vs.seed) : Math.random;      // two-player: both runners get the very same course
    if (this.vs) this.readyT = 0.01;
    for (let i = 0; i < 6; i++) this.clouds.push({ x:rand(0, 1), y:rand(0.04, 0.24), s:rand(0.7, 1.4), v:rand(0.004, 0.012) });
    for (let i = 0; i < 12; i++) this.preDeco(i * 6);
    this.banner = { text:RZONES[0].name, t:0 };
    if (motionLive() && !this.vs) sendTracker({ t:'calibrate' });
  },
  exit(){ Music.setTempo(1); if (!this.banked) { this.banked = true; if (this.coinN > 0) { WALLET.coins += this.coinN; saveWallet(); } } },   // coins are kept for the shop
  proj(x, z, h){
    const LW = Math.min(W * 0.2, H * 0.36), d = Math.max(0.05, z + ZNEAR), s = ZNEAR / d;
    const HOR = H * 0.36, GY = H * 0.97;
    return { X: W / 2 + x * LW * s, Y: HOR + (GY - HOR) * s - h * LW * s, s: s * LW };
  },
  preDeco(z){ for (const side of [-1, 1]) this.deco.push({ x:side * rand(2.1, 3.0), z:z + rand(0, 4), k:Math.random(), side }); },
  update(dt){
    this.parts = stepParts(this.parts, dt); this.pops = stepPops(this.pops, dt);
    for (const c of this.clouds) { c.x += c.v * dt; if (c.x > 1.15) { c.x = -0.15; c.y = rand(0.04, 0.24); } }
    if (this.state === 'ready') { const p = this.readyT; this.readyT -= dt; countBeep(p, this.readyT); takeJump(); if (this.readyT <= 0) { this.state = 'play'; SFX.go(); } return; }
    this.t += dt;
    this.speed = Math.min(27, 11 + this.t * 0.17);
    if (!this.vs) Music.setTempo(0.94 + (this.speed - 11) / 16 * 0.3);
    const dz = this.speed * dt;
    this.dist += dz;

    // worlds
    const zi = Math.floor(this.dist / CHECK_EVERY) % RZONES.length;
    if (zi !== this.zone) { this.prevZone = this.zone; this.zone = zi; this.zoneBlend = 0; this.banner = { text:RZONES[zi].name, t:0 }; SFX.swoosh(); }
    this.zoneBlend = Math.min(1, this.zoneBlend + dt / 2.5); this.banner.t += dt;

    const target = laneInput();
    if (target !== this.lastLane) { SFX.whoosh(); this.lastLane = target; }
    this.px += (target - this.px) * Math.min(1, dt * 14);
    if (takeJump() && this.jumpT < 0) { this.jumpT = 0; this.duckT = 0; SFX.boing(); this.wasAir = true; this.puff(6); }
    if (this.jumpT >= 0) {
      this.jumpT += dt; const u = this.jumpT / 0.78;
      if (duckInput() && u > 0.2) this.jumpT = -1;      // squat mid-air = drop down fast
      if (u >= 1 || this.jumpT < 0) { this.jumpT = -1; this.jumpH = 0; } else this.jumpH = 4 * 1.45 * u * (1 - u);
    }
    if (this.jumpT < 0 && this.wasAir) { this.wasAir = false; SFX.land(); this.puff(8); }
    if (duckInput() && this.jumpT < 0) this.duckT = Math.max(this.duckT, 0.55);
    this.duckT = Math.max(0, this.duckT - dt);
    const ducking = this.duckT > 0 && this.jumpT < 0;
    this.inv = Math.max(0, this.inv - dt);
    this.shake = Math.max(0, this.shake - dt * 2.5); this.flash = Math.max(0, this.flash - dt * 2);

    // dust & trail particles
    this.dust -= dt; if (this.dust <= 0 && this.jumpT < 0) { this.dust = 0.09; this.puff(1); }
    this.trailT -= dt; if (this.trailT <= 0 && CHAR.trail) { this.trailT = 0.035; this.emitTrail(); }

    this.untilRow -= dz;
    if (this.untilRow <= 0) { this.spawnRow(72); this.untilRow = 15 + this.R() * 8; }
    this.untilDeco -= dz; if (this.untilDeco <= 0) { this.untilDeco = rand(4, 7); this.preDeco(72); }
    if (this.dist + 72 >= this.nextCheck && !this.arch) { this.arch = { z:this.nextCheck - this.dist, got:false }; }
    if (this.arch) {
      this.arch.z -= dz;
      if (!this.arch.got && this.arch.z < PZ) {
        this.arch.got = true; SFX.fanfare(); this.flash = 0.5;
        this.coinN += 10;
        if (this.lives < 3) { this.lives++; pop(this.pops, W / 2, H * 0.34, 'CHECKPOINT!  +1 ♥  +10 coins', '#ff6b8a', 0.07, 1.8); SFX.heart(); }
        else pop(this.pops, W / 2, H * 0.34, 'CHECKPOINT!  +10 coins', '#ffe14a', 0.07, 1.8);
        for (let i = 0; i < 4; i++) burst(this.parts, W * rand(0.2, 0.8), H * rand(0.18, 0.4), 16, ['#ffe14a', '#4fd27a', '#5b8cff', '#ff6b5a', '#fff'], H * 0.7, H * 0.009, 1.2, 0.7);
        this.nextCheck += CHECK_EVERY;
      }
      if (this.arch.z < -4) this.arch = null;
    }

    for (const o of this.obs) {
      o.z -= dz;
      if (o.hit || o.passed || this.inv > 0) continue;
      const len = o.type === 'block' ? 3.2 : 0.4;
      if (o.z < PZ + 0.3 && o.z + len > PZ - 0.3 && Math.abs(this.px - o.lane) < 0.55) {
        const safe = (o.type === 'low' && this.jumpH > 0.55) || (o.type === 'high' && ducking);
        if (!safe) { o.hit = true; this.lives--; this.inv = 1.5; this.shake = 1; SFX.hit(); this.coinStreak = 0;
          this.msgs.push({ text: o.type === 'low' ? 'Jump!' : o.type === 'high' ? 'Duck!' : 'Change lanes!', t:0 }); }
        else if (!o.cheered) { o.cheered = true; const p = this.proj(this.px, PZ, 1.6); pop(this.pops, p.X, p.Y, 'Nice!', '#4fd27a', 0.04, 0.8); }
      }
      if (o.z + len < PZ - 0.4) o.passed = true;
    }
    for (const c of this.coins) {
      c.z -= dz;
      if (!c.got && Math.abs(c.z - PZ) < 0.6 && Math.abs(this.px - c.lane) < 0.5 && Math.abs(this.jumpH + 0.4 - c.h) < 0.9) {
        c.got = true; this.coinN++;
        this.coinStreak = this.t - this.lastCoinT < 0.45 ? this.coinStreak + 1 : 1; this.lastCoinT = this.t;
        tone(1250 + Math.min(this.coinStreak, 8) * 90, 0.07, 'square', 0.05); setTimeout(() => tone(1700 + Math.min(this.coinStreak, 8) * 90, 0.1, 'square', 0.05), 55);
        const p = this.proj(c.lane, c.z, c.h); burst(this.parts, p.X, p.Y, 8, ['#ffd23f', '#fff6b0'], H * 0.4, H * 0.008, 0.4, 0.5);
      }
    }
    this.obs = this.obs.filter(o => o.z > -4);
    this.coins = this.coins.filter(c => c.z > -2 && !c.got);
    for (const d of this.deco) d.z -= dz;
    this.deco = this.deco.filter(d => d.z > -4);
    for (const m of this.msgs) m.t += dt;
    this.msgs = this.msgs.filter(m => m.t < 1.1);
    if (this.lives <= 0) {
      const res = { game:'runner', score:Math.floor(this.dist) + this.coinN * 10, detail:`${Math.floor(this.dist)} m · ${this.coinN} coins`, coins:this.coinN, game2:'runner' };
      if (this.vs) { if (!this.dead) { this.dead = true; this.vs.onDead(this, res); } } else go('over', res);
    }
  },
  rescale(sc){ for (const arr of [this.parts, this.pops]) for (const o of arr) sc(o, true); },
  puff(n){
    const p = this.proj(this.px, PZ, this.jumpH);
    for (let i = 0; i < n; i++) this.parts.push({ x:p.X + rand(-0.15, 0.15) * p.s, y:p.Y, vx:rand(-0.5, 0.5) * p.s, vy:-rand(0.2, 0.9) * p.s * 0.5, r:p.s * rand(0.03, 0.07), c:'rgba(235,225,205,0.8)', life:0.45, max:0.45, g:0.05 });
  },
  emitTrail(){
    const p = this.proj(this.px, PZ, this.jumpH + 0.55), s = p.s, tr = CHAR.trail, hue = (this.t * 240) % 360;
    const X = TRAIL_X[tr];
    if (X) {
      const n = X.long ? 3 : 1;
      for (let k = 0; k < n; k++) this.parts.push({ x:p.X + rand(-0.2, 0.2) * s, y:p.Y + rand(-0.1, 0.4) * s + (X.long ? k * s * 0.12 : 0), vx:rand(-0.25, 0.25) * s, vy:X.vy * s * rand(0.5, 1.2) + (X.long ? s * 0.1 : 0), r:s * X.r * rand(0.6, 1.2) * (X.long ? 1 - k * 0.25 : 1), c:pick(X.c), life:0.65, max:0.65, g:X.g });
      return;
    }
    const c = tr === 1 ? pick(['#fff', '#ffe14a', '#bfe3ff']) : tr === 2 ? pick(['#ff7a1a', '#ffe14a', '#ff3b3b']) : tr === 3 ? `hsl(${hue},100%,60%)` :
      tr === 5 ? pick(['#b46bff', '#5b8cff', '#ffffff', '#ff8be0']) : tr === 6 ? pick(['#fff7a8', '#ffe14a', '#ffffff', '#8fdcff']) :
      tr === 7 ? `hsl(${150 + Math.sin(this.t * 3) * 70 + rand(-20, 20)},90%,60%)` : tr === 8 ? pick(['#ff4f6d', '#ffd23f', '#3ee08f', '#5b8cff', '#ff8be0']) : '#ff6b9a';
    const spread = tr === 6 ? 0.45 : 0.2;
    this.parts.push({ x:p.X + rand(-spread, spread) * s, y:p.Y + rand(-0.1, 0.4) * s, vx:rand(-spread, spread) * s * (tr === 6 ? 2 : 1), vy:tr === 2 || tr === 7 ? -rand(0.2, 0.6) * s : tr === 8 ? rand(0.1, 0.5) * s : rand(-0.1, 0.2) * s, r:s * (tr === 4 ? 0.06 : tr === 8 ? rand(0.035, 0.07) : tr === 6 ? rand(0.015, 0.035) : rand(0.025, 0.06)), c, life:tr === 3 || tr === 7 ? 0.5 : 0.6, max:0.6, g:tr === 8 ? 0.2 : -0.02, heart:tr === 4 });
    if (tr === 5 && Math.random() < 0.5) this.parts.push({ x:p.X + rand(-0.3, 0.3) * s, y:p.Y + rand(-0.2, 0.5) * s, vx:0, vy:0, r:s * 0.012, c:'#fff', life:0.5, max:0.5, g:0 });
  },
  spawnRow(z){
    const R = this.R || Math.random;
    const lanes = [-1, 0, 1].sort(() => R() - 0.5);
    const types = ['low', 'high', 'block'], pk = () => types[Math.floor(R() * 3)];
    const r = R();
    if (r < 0.38) { this.obs.push({ lane:lanes[0], z, type:pk() }); this.coinLine(lanes[1], z); }
    else if (r < 0.68) { this.obs.push({ lane:lanes[0], z, type:pk() }, { lane:lanes[1], z, type:pk() }); this.coinLine(lanes[2], z - 4); }
    else if (r < 0.86 && this.t > 12) { const tp = R() < 0.5 ? 'low' : 'high'; for (const l of lanes) this.obs.push({ lane:l, z, type:tp }); }
    else this.coinLine(lanes[0], z);
  },
  coinLine(lane, z){ for (let i = 0; i < 5; i++) this.coins.push({ lane, z:z + i * 2.2, h:0.45 }); },

  /* ---------- drawing ---------- */
  zoneLayer(i){
    const Z = RZONES[i], HOR = H * 0.36;
    return cachedLayer('rz' + i, g => {
      const sky = g.createLinearGradient(0, 0, 0, HOR); sky.addColorStop(0, Z.sky[0]); sky.addColorStop(1, Z.sky[1]);
      g.fillStyle = sky; g.fillRect(0, 0, W, HOR + 2);
      if (Z.stars) { g.fillStyle = '#fff'; for (let n = 0; n < 70; n++) { g.globalAlpha = rand(0.3, 1); g.beginPath(); g.arc(rand(0, W), rand(0, HOR * 0.9), rand(1, 2.4), 0, TAU); g.fill(); } g.globalAlpha = 1; }
      // sun / moon with glow
      const sx = W * 0.78, sy = HOR * 0.38, sr = H * 0.05;
      const gl = g.createRadialGradient(sx, sy, sr * 0.4, sx, sy, sr * 4); gl.addColorStop(0, Z.sun + 'aa'); gl.addColorStop(1, Z.sun + '00'); g.fillStyle = gl; g.fillRect(sx - sr * 4, sy - sr * 4, sr * 8, sr * 8);
      g.fillStyle = Z.sun; g.beginPath(); g.arc(sx, sy, sr, 0, TAU); g.fill();
      // far scenery
      const shape = (n, fn) => { for (let b = 0; b < n; b++) fn(b); };
      if (Z.far === 'hills') {
        for (const [col, base, amp] of [['#9ad7a0', 0.82, 0.12], ['#6dbb78', 0.92, 0.09], ['#52a560', 1.0, 0.06]]) {
          g.fillStyle = col; g.beginPath(); g.moveTo(0, HOR);
          for (let x = 0; x <= W; x += W / 40) g.lineTo(x, HOR - (1 - base + amp) * H * 0.12 - Math.sin(x / W * 7 + base * 9) * amp * H * 0.4 * 0.4 - Math.sin(x / W * 15 + base) * amp * H * 0.1);
          g.lineTo(W, HOR); g.closePath(); g.fill();
        }
      } else if (Z.far === 'city' || Z.far === 'nightcity') {
        const night = Z.far === 'nightcity', sl = [];
        shape(30, b => sl.push({ x:rand(-0.1, 1.05), w:rand(0.03, 0.08), h:rand(0.04, 0.2), c:b % 3 })); sl.sort((a, b) => b.h - a.h);
        for (const b of sl) {
          g.fillStyle = night ? ['#161a4a', '#1d2160', '#241d58'][b.c] : ['#8fb3d6', '#7aa0c6', '#a4c2df'][b.c]; g.fillRect(b.x * W, HOR - b.h * H, b.w * W, b.h * H);
          g.fillStyle = night ? 'rgba(255,225,120,0.8)' : 'rgba(255,255,255,0.45)';
          for (let wy = HOR - b.h * H + 8; wy < HOR - 10; wy += H * 0.022) for (let wx = b.x * W + 6; wx < (b.x + b.w) * W - 8; wx += W * 0.011) if (Math.random() < (night ? 0.45 : 0.8)) g.fillRect(wx, wy, W * 0.005, H * 0.009);
        }
      } else if (Z.far === 'mesa') {
        g.fillStyle = '#c9603a'; shape(7, b => { const x = rand(0, W), w = rand(0.08, 0.18) * W, h = rand(0.05, 0.12) * H; g.beginPath(); g.moveTo(x, HOR); g.lineTo(x + w * 0.1, HOR - h); g.lineTo(x + w * 0.9, HOR - h); g.lineTo(x + w, HOR); g.closePath(); g.fill(); });
        g.fillStyle = '#a84a2e'; shape(5, b => { const x = rand(0, W), w = rand(0.06, 0.12) * W, h = rand(0.03, 0.07) * H; g.beginPath(); g.moveTo(x, HOR); g.lineTo(x + w * 0.2, HOR - h); g.lineTo(x + w * 0.8, HOR - h); g.lineTo(x + w, HOR); g.closePath(); g.fill(); });
      }
      const grd = g.createLinearGradient(0, HOR, 0, H); grd.addColorStop(0, Z.ground[0]); grd.addColorStop(1, Z.ground[1]);
      g.fillStyle = grd; g.fillRect(0, HOR, W, H - HOR);
    });
  },
  draw(){
    const t = this.t, P = (x, z, h) => this.proj(x, z, h), Z = RZONES[this.zone], HOR = H * 0.36;
    ctx.save();
    if (this.shake) ctx.translate(rand(-1, 1) * this.shake * 14, rand(-1, 1) * this.shake * 14);
    if (this.zoneBlend < 1) { ctx.drawImage(this.zoneLayer(this.prevZone), 0, 0); ctx.globalAlpha = this.zoneBlend; }
    ctx.drawImage(this.zoneLayer(this.zone), 0, 0); ctx.globalAlpha = 1;
    // clouds & birds
    const night = Z.stars;
    for (const c of this.clouds) {
      const cx = c.x * W, cy = c.y * H, r = H * 0.035 * c.s;
      ctx.fillStyle = night ? 'rgba(120,120,200,0.25)' : 'rgba(255,255,255,0.8)';
      for (const [dx, dy, rr] of [[0, 0, 1], [1.1, 0.2, 0.8], [-1.1, 0.25, 0.75], [0.5, -0.5, 0.8]]) { ctx.beginPath(); ctx.arc(cx + dx * r, cy + dy * r, r * rr, 0, TAU); ctx.fill(); }
    }
    if (!night) { ctx.strokeStyle = 'rgba(40,50,80,0.55)'; ctx.lineWidth = Math.max(1.5, H * 0.003); ctx.lineCap = 'round';
      for (let i = 0; i < 3; i++) { const bx = ((this.t * 0.03 + i * 0.37) % 1.2 - 0.1) * W, by = HOR * (0.3 + i * 0.12) + Math.sin(this.t * 2 + i) * 4, fl = Math.sin(this.t * 9 + i * 2) * H * 0.008;
        ctx.beginPath(); ctx.moveTo(bx - H * 0.02, by + fl); ctx.quadraticCurveTo(bx - H * 0.008, by - H * 0.012, bx, by); ctx.quadraticCurveTo(bx + H * 0.008, by - H * 0.012, bx + H * 0.02, by + fl); ctx.stroke(); } }
    // road
    const roadCol = this.zoneBlend < 1 ? RZONES[this.prevZone].road : Z.road;
    const a = P(-ROAD_HALF, 80, 0), b = P(ROAD_HALF, 80, 0), c = P(ROAD_HALF, -2.5, 0), d = P(-ROAD_HALF, -2.5, 0);
    ctx.fillStyle = Z.road; ctx.beginPath(); ctx.moveTo(a.X, a.Y); ctx.lineTo(b.X, b.Y); ctx.lineTo(c.X, c.Y); ctx.lineTo(d.X, d.Y); ctx.closePath(); ctx.fill();
    // kerbs
    for (const sd of [-1, 1]) { const k1 = P(sd * ROAD_HALF, 80, 0), k2 = P(sd * (ROAD_HALF + 0.12), 80, 0), k3 = P(sd * (ROAD_HALF + 0.12), -2.5, 0), k4 = P(sd * ROAD_HALF, -2.5, 0); ctx.fillStyle = '#e9e4d8'; ctx.beginPath(); ctx.moveTo(k1.X, k1.Y); ctx.lineTo(k2.X, k2.Y); ctx.lineTo(k3.X, k3.Y); ctx.lineTo(k4.X, k4.Y); ctx.closePath(); ctx.fill(); }
    const off = this.dist % 2;
    ctx.fillStyle = 'rgba(0,0,0,0.13)';
    for (let z = 76 - off; z > -2.5; z -= 2) {
      const l = P(-1.5, z, 0), r = P(1.5, z, 0), l2 = P(-1.5, z + 0.35, 0);
      ctx.fillRect(l.X, l2.Y, r.X - l.X, Math.max(1, l.Y - l2.Y));
    }
    ctx.strokeStyle = night ? 'rgba(200,210,255,0.6)' : '#e4e7ee'; ctx.lineWidth = Math.max(2, H * 0.004);
    ctx.beginPath();
    for (const x of [-0.5, 0.5]) { for (let z = 76 - (this.dist % 4); z > -2.5; z -= 4) { const p1 = P(x, z, 0), p2 = P(x, Math.max(-2.5, z - 2), 0); ctx.moveTo(p1.X, p1.Y); ctx.lineTo(p2.X, p2.Y); } }
    ctx.stroke();
    // speed lines once you're going fast
    if (this.speed > 16) {
      const k = (this.speed - 16) / 11;
      ctx.strokeStyle = `rgba(255,255,255,${0.25 * k})`; ctx.lineWidth = 2; ctx.beginPath();
      for (let i = 0; i < 14; i++) { const a2 = (i / 14) * TAU + t, r1 = H * (0.55 + ((t * 3 + i * 0.37) % 1) * 0.5); ctx.moveTo(W / 2 + Math.cos(a2) * r1, H * 0.45 + Math.sin(a2) * r1 * 0.6); ctx.lineTo(W / 2 + Math.cos(a2) * (r1 + H * 0.12), H * 0.45 + Math.sin(a2) * (r1 + H * 0.12) * 0.6); }
      ctx.stroke();
    }

    const things = [...this.obs.map(o => ({ z:o.z, o })), ...this.coins.map(c2 => ({ z:c2.z, c:c2 })), ...this.deco.map(dd => ({ z:dd.z, dd })), { z:PZ, player:true }];
    if (this.arch) things.push({ z:this.arch.z, arch:this.arch });
    things.sort((p, q) => q.z - p.z);
    for (const th of things) {
      if (th.player) this.drawPlayer(P);
      else if (th.c) this.drawCoin(P, th.c, t);
      else if (th.dd) this.drawDeco(P, th.dd, Z, t);
      else if (th.arch) this.drawArch(P, th.arch, t);
      else this.drawObstacle(P, th.o);
    }
    for (const p of this.parts) if (p.heart) { ctx.globalAlpha = clamp(p.life / p.max, 0, 1); text('♥', p.x, p.y, p.r * 4, '#ff6b9a'); }
    ctx.globalAlpha = 1;
    drawParts(this.parts.filter(p => !p.heart), CHAR.trail > 0 && CHAR.trail !== 4 && CHAR.trail !== 8 && !(TRAIL_X[CHAR.trail] && !TRAIL_X[CHAR.trail].add));
    drawPops(this.pops);
    ctx.restore();
    if (this.flash) { ctx.fillStyle = `rgba(255,255,255,${this.flash * 0.35})`; ctx.fillRect(0, 0, W, H); }

    text(`${Math.floor(this.dist) + this.coinN * 10}`, W * 0.04, H * 0.07, H * 0.07, '#fff', 'left');
    text(`● ${this.coinN}`, W * 0.04, H * 0.15, H * 0.045, '#ffd23f', 'left');
    if (!this.vs) text(`wallet ${WALLET.coins + this.coinN}`, W * 0.04 + H * 0.2, H * 0.15, H * 0.026, '#ffe9a8', 'left', 700);
    text('Best ' + this.best, W * 0.04, H * 0.21, H * 0.03, '#ffffff', 'left', 700);
    // progress to the next checkpoint
    const pr = clamp(1 - (this.nextCheck - this.dist) / CHECK_EVERY, 0, 1), pw = W * 0.2, px0 = W * 0.04, py0 = H * 0.275;
    roundRect(px0, py0, pw, H * 0.012, H * 0.006); ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fill();
    roundRect(px0, py0, Math.max(H * 0.012, pw * pr), H * 0.012, H * 0.006); ctx.fillStyle = '#ffe14a'; ctx.fill();
    text('⚑', px0 + pw + H * 0.02, py0 + H * 0.006, H * 0.03, '#ffe14a');
    for (let i = 0; i < 3; i++) text('♥', W * (0.86 + i * 0.045), H * 0.07, H * 0.065, i < this.lives ? '#ff3b6b' : 'rgba(255,255,255,0.4)');
    for (const m of this.msgs) { ctx.globalAlpha = clamp(1.1 - m.t, 0, 1); text(m.text, W / 2, H * 0.3 - m.t * H * 0.05, H * 0.07, '#ff5d6c'); }
    ctx.globalAlpha = 1;
    if (this.banner.t < 3 && this.state === 'play') { ctx.globalAlpha = Math.min(1, (3 - this.banner.t) * 1.5, this.banner.t * 3); text(this.banner.text, W / 2, H * 0.17, H * 0.06, '#fff'); ctx.globalAlpha = 1; }
    const bw = H * 0.22, bx = W - bw - 20, by = H - bw * 1.25 - 20;
    if (motionLive()) {
      roundRect(bx, by, bw, bw * 1.25, 14); ctx.fillStyle = 'rgba(10,14,35,0.55)'; ctx.fill();
      ctx.save(); roundRect(bx, by, bw, bw * 1.25, 14); ctx.clip(); drawGhost(0.9, [bx - bw * 0.1, by, bw * 1.2, bw * 1.25]); ctx.restore();
      const ln = laneInput(); text(ln < 0 ? 'LEFT' : ln > 0 ? 'RIGHT' : 'MIDDLE', bx + bw / 2, by + bw * 1.25 - 18, H * 0.025, '#fff', 'center', 700);
    }
    if (this.state === 'ready') {
      const n = Math.ceil(this.readyT);
      text(motionLive() ? 'Stand in the middle and hold still' : 'Get ready!', W / 2, H * 0.42, H * 0.065);
      text(n > 0 ? String(n) : 'GO!', W / 2, H * 0.56, H * 0.14, '#ffe14a');
      text('Step sideways = change lane · Jump = jump · Squat = duck', W / 2, H * 0.68, H * 0.032, '#fff', 'center', 600);
    }
    drawMotionBadge();
  },
  drawDeco(P, d, Z, t){
    if (d.z < -3) return;
    const p = P(d.x, d.z, 0), s = p.s, k = d.k;
    if (p.Y > H + s || s < 2) return;
    ctx.fillStyle = 'rgba(0,0,0,0.18)'; ctx.beginPath(); ctx.ellipse(p.X, p.Y, s * 0.35, s * 0.07, 0, 0, TAU); ctx.fill();
    if (Z.deco === 'tree') {
      const th = s * (1.1 + k * 0.6); ctx.fillStyle = '#7a4f2a'; ctx.fillRect(p.X - s * 0.06, p.Y - th * 0.5, s * 0.12, th * 0.5);
      ctx.fillStyle = k > 0.5 ? '#2f9e44' : '#3fb55a'; ctx.beginPath(); ctx.arc(p.X, p.Y - th * 0.75, s * 0.42, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(p.X - s * 0.25, p.Y - th * 0.58, s * 0.3, 0, TAU); ctx.arc(p.X + s * 0.25, p.Y - th * 0.58, s * 0.3, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.14)'; ctx.beginPath(); ctx.arc(p.X - s * 0.12, p.Y - th * 0.85, s * 0.18, 0, TAU); ctx.fill();
      if (k > 0.7) { ctx.fillStyle = '#ff5f7e'; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.arc(p.X + Math.cos(i * 1.7) * s * 0.3, p.Y - th * 0.7 + Math.sin(i * 2.3) * s * 0.25, s * 0.05, 0, TAU); ctx.fill(); } }
    } else if (Z.deco === 'lamp' || Z.deco === 'glow') {
      const th = s * 1.7; ctx.fillStyle = '#4a5068'; ctx.fillRect(p.X - s * 0.03, p.Y - th, s * 0.06, th);
      ctx.fillRect(p.X - d.side * s * 0.2, p.Y - th, d.side * s * 0.2 + s * 0.03 * d.side, s * 0.05);
      const lx = p.X - d.side * s * 0.2, ly = p.Y - th + s * 0.05;
      ctx.fillStyle = Z.deco === 'glow' ? '#ffe9a0' : '#fff3b0'; ctx.beginPath(); ctx.arc(lx, ly, s * 0.07, 0, TAU); ctx.fill();
      if (Z.deco === 'glow') { ctx.globalCompositeOperation = 'lighter'; const gr = ctx.createRadialGradient(lx, ly, 0, lx, ly, s * 0.6); gr.addColorStop(0, 'rgba(255,225,120,0.5)'); gr.addColorStop(1, 'rgba(255,225,120,0)'); ctx.fillStyle = gr; ctx.fillRect(lx - s * 0.6, ly - s * 0.6, s * 1.2, s * 1.2); ctx.globalCompositeOperation = 'source-over'; }
      if (k > 0.55 && Z.deco === 'lamp') { ctx.fillStyle = ['#e8323c', '#ffd23f', '#3ec878'][Math.floor(k * 10) % 3]; roundRect(p.X + d.side * s * 0.12, p.Y - s * 0.9, s * 0.4, s * 0.28, s * 0.04); ctx.fill(); ctx.fillStyle = '#fff'; ctx.fillRect(p.X + d.side * s * 0.17, p.Y - s * 0.82, s * 0.3, s * 0.04); }
    } else {
      const th = s * (0.9 + k * 0.7); ctx.fillStyle = '#4d8f4a'; roundRect(p.X - s * 0.07, p.Y - th, s * 0.14, th, s * 0.07); ctx.fill();
      roundRect(p.X - s * 0.28, p.Y - th * 0.62, s * 0.09, th * 0.35, s * 0.045); ctx.fill(); ctx.fillRect(p.X - s * 0.28, p.Y - th * 0.4, s * 0.25, s * 0.08);
      roundRect(p.X + s * 0.19, p.Y - th * 0.75, s * 0.09, th * 0.35, s * 0.045); ctx.fill(); ctx.fillRect(p.X + s * 0.03, p.Y - th * 0.5, s * 0.25, s * 0.08);
      if (k > 0.6) { ctx.fillStyle = '#ff6fa0'; ctx.beginPath(); ctx.arc(p.X, p.Y - th - s * 0.02, s * 0.06, 0, TAU); ctx.fill(); }
    }
  },
  drawArch(P, a, t){
    if (a.z < -3) return;
    const l = P(-ROAD_HALF - 0.2, a.z, 0), r = P(ROAD_HALF + 0.2, a.z, 0), top = P(0, a.z, 2.6), s = l.s;
    ctx.fillStyle = '#e9e4d8'; ctx.fillRect(l.X - s * 0.08, top.Y, s * 0.16, l.Y - top.Y); ctx.fillRect(r.X - s * 0.08, top.Y, s * 0.16, r.Y - top.Y);
    const bh = s * 0.55; roundRect(l.X - s * 0.15, top.Y - bh * 0.3, r.X - l.X + s * 0.3, bh, s * 0.1); ctx.fillStyle = a.got ? '#4a5068' : '#ffe14a'; ctx.fill();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(2, s * 0.05); ctx.stroke();
    for (let i = 0; i < 8; i++) { ctx.fillStyle = (i + Math.floor(t * 3)) % 2 ? '#e8323c' : '#fff'; ctx.fillRect(l.X - s * 0.15 + (r.X - l.X + s * 0.3) * i / 8, top.Y + bh * 0.62, (r.X - l.X + s * 0.3) / 8 + 1, bh * 0.08); }
    text('CHECKPOINT', (l.X + r.X) / 2, top.Y + bh * 0.2, Math.max(8, s * 0.3), a.got ? '#9aa' : '#2b2f3a');
  },
  drawObstacle(P, o){
    if (o.z < -3) return;
    const x0 = o.lane - 0.45, x1 = o.lane + 0.45;
    { const sh = P(o.lane, o.z, 0); ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.beginPath(); ctx.ellipse(sh.X, sh.Y, sh.s * 0.5, sh.s * 0.07, 0, 0, TAU); ctx.fill(); }
    if (o.type === 'block') {
      const len = 3.2, hgt = 1.5;
      const f0 = P(x0, o.z, 0), f1 = P(x1, o.z, hgt), b0 = P(x0, o.z + len, hgt), b1 = P(x1, o.z + len, hgt);
      const sx = o.lane < 0 ? x1 : x0;
      if (o.lane !== 0) { const s0 = P(sx, o.z, 0), s1 = P(sx, o.z, hgt), s2 = P(sx, o.z + len, hgt), s3 = P(sx, o.z + len, 0);
        ctx.fillStyle = '#2a5fae'; ctx.beginPath(); ctx.moveTo(s0.X, s0.Y); ctx.lineTo(s1.X, s1.Y); ctx.lineTo(s2.X, s2.Y); ctx.lineTo(s3.X, s3.Y); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(217,241,255,0.55)'; for (let i = 0; i < 4; i++) { const za = o.z + len * (0.1 + i * 0.22), zb = za + len * 0.14, w0 = P(sx, za, hgt * 0.78), w1 = P(sx, zb, hgt * 0.78), w2 = P(sx, zb, hgt * 0.45), w3 = P(sx, za, hgt * 0.45); ctx.beginPath(); ctx.moveTo(w0.X, w0.Y); ctx.lineTo(w1.X, w1.Y); ctx.lineTo(w2.X, w2.Y); ctx.lineTo(w3.X, w3.Y); ctx.closePath(); ctx.fill(); } }
      ctx.fillStyle = '#5e9cf0'; ctx.beginPath(); ctx.moveTo(f0.X, f1.Y); ctx.lineTo(f1.X, f1.Y); ctx.lineTo(b1.X, b1.Y); ctx.lineTo(b0.X, b0.Y); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#3d7bd8'; ctx.fillRect(f0.X, f1.Y, f1.X - f0.X, f0.Y - f1.Y);
      ctx.fillStyle = '#d9f1ff'; ctx.fillRect(f0.X + (f1.X - f0.X) * 0.12, f1.Y + (f0.Y - f1.Y) * 0.12, (f1.X - f0.X) * 0.76, (f0.Y - f1.Y) * 0.3);
      ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.fillRect(f0.X + (f1.X - f0.X) * 0.45, f1.Y + (f0.Y - f1.Y) * 0.12, (f1.X - f0.X) * 0.04, (f0.Y - f1.Y) * 0.3);
      ctx.fillStyle = '#ffd23f'; ctx.fillRect(f0.X, f0.Y - (f0.Y - f1.Y) * 0.15, f1.X - f0.X, (f0.Y - f1.Y) * 0.06);
      ctx.fillStyle = '#fff6b0'; for (const fx of [0.2, 0.8]) { ctx.beginPath(); ctx.arc(f0.X + (f1.X - f0.X) * fx, f0.Y - (f0.Y - f1.Y) * 0.3, (f1.X - f0.X) * 0.06, 0, TAU); ctx.fill(); }
      ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(255,246,176,0.25)'; for (const fx of [0.2, 0.8]) { ctx.beginPath(); ctx.arc(f0.X + (f1.X - f0.X) * fx, f0.Y - (f0.Y - f1.Y) * 0.3, (f1.X - f0.X) * 0.16, 0, TAU); ctx.fill(); } ctx.globalCompositeOperation = 'source-over';
    } else if (o.type === 'low') {
      const p0 = P(x0, o.z, 0.55), p1 = P(x1, o.z, 0.25), g = P(x0, o.z, 0);
      const w = p1.X - p0.X, hh = p1.Y - p0.Y;
      ctx.fillStyle = '#555'; ctx.fillRect(p0.X + w * 0.08, p0.Y, w * 0.06, g.Y - p0.Y); ctx.fillRect(p0.X + w * 0.86, p0.Y, w * 0.06, g.Y - p0.Y);
      for (let i = 0; i < 6; i++) { ctx.fillStyle = i % 2 ? '#fff' : '#e8323c'; ctx.fillRect(p0.X + w * i / 6, p0.Y, w / 6 + 1, hh); }
      for (const cx of [-0.1, 1.0]) { ctx.fillStyle = '#ff7a1a'; ctx.beginPath(); ctx.moveTo(p0.X + w * cx, g.Y); ctx.lineTo(p0.X + w * (cx + 0.1), g.Y); ctx.lineTo(p0.X + w * (cx + 0.05), g.Y - w * 0.16); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#fff'; ctx.fillRect(p0.X + w * (cx + 0.015), g.Y - w * 0.09, w * 0.07, w * 0.025); }
      const lamp = Math.sin(this.t * 10) > 0; ctx.fillStyle = lamp ? '#ffe14a' : '#a37d00'; ctx.beginPath(); ctx.arc(p0.X + w * 0.5, p0.Y - w * 0.04, w * 0.04, 0, TAU); ctx.fill();
    } else {
      const top = P(x0, o.z, 1.75), bar0 = P(x0, o.z, 1.75), bar1 = P(x1, o.z, 1.0), g = P(x0, o.z, 0);
      const w = bar1.X - bar0.X;
      ctx.fillStyle = '#444'; ctx.fillRect(bar0.X, top.Y, w * 0.06, g.Y - top.Y); ctx.fillRect(bar0.X + w * 0.94, top.Y, w * 0.06, g.Y - top.Y);
      for (let i = 0; i < 6; i++) { ctx.fillStyle = i % 2 ? '#222' : '#ffd23f'; ctx.fillRect(bar0.X + w * i / 6, bar0.Y, w / 6 + 1, bar1.Y - bar0.Y); }
      ctx.fillStyle = 'rgba(255,255,255,0.9)'; roundRect(bar0.X + w * 0.28, bar0.Y - w * 0.18, w * 0.44, w * 0.15, w * 0.03); ctx.fill();
      text('▼', bar0.X + w * 0.5, bar0.Y - w * 0.105, Math.max(6, w * 0.12), '#e8323c');
    }
    if (o.hit) { const p = P(o.lane, o.z, 1); ctx.globalAlpha = 0.5; text('✕', p.X, p.Y, p.s * 0.6, '#ff3b4e'); ctx.globalAlpha = 1; }
  },
  drawCoin(P, c, t){
    if (c.z < -1) return;
    const p = P(c.lane, c.z, c.h + Math.sin(t * 4 + c.z) * 0.05), r = p.s * 0.16, sq = Math.abs(Math.cos(t * 4 + c.z * 0.5));
    ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.ellipse(p.X, p.Y, r * Math.max(0.15, sq), r, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#d9a21a'; ctx.lineWidth = Math.max(1, r * 0.18); ctx.stroke();
    if (sq > 0.6) { ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(p.X - r * 0.2 * sq, p.Y - r * 0.3, r * 0.14, 0, TAU); ctx.fill(); }
  },
  drawPlayer(P){
    if (this.inv > 0 && Math.floor(this.inv * 10) % 2) return;
    const ducking = this.duckT > 0 && this.jumpT < 0;
    const sh = P(this.px, PZ, 0), s = sh.s;
    ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.ellipse(sh.X, sh.Y, s * 0.32 / (1 + this.jumpH), s * 0.08 / (1 + this.jumpH), 0, 0, TAU); ctx.fill();
    const base = P(this.px, PZ, this.jumpH);
    const run = this.state === 'play' && this.jumpT < 0 && !ducking ? Math.sin(this.t * 16) : 0;
    drawChar(base.X, base.Y, s, { run, duck:ducking, air:this.jumpT >= 0, t:this.t });
  }
};

/* =====================================================================
   LOCKER — customize your runner
   ===================================================================== */
scenes.locker = {
  hint:'Hold a hand over a button to change that part of your runner',
  setWho(i){ this.who = i; CHAR = charOf(i); this.pulse(); },
  enter(){
    this.focus = 0; this.parts = []; this.who = CHAR === CHAR2 ? 1 : 0;
    const cols = 2, rows = 4;
    const cell = i => () => {
      const gx = W * 0.5, gw = W * 0.46, gap = W * 0.015, bw = (gw - gap) / 2, bh = H * 0.125;
      const c = i % cols, r = Math.floor(i / cols);
      return [gx + c * (bw + gap), H * 0.18 + r * (bh + H * 0.02), bw, bh];
    };
    const sw = (arr, key) => (x, y, w, h) => { ctx.fillStyle = arr[CHAR[key]]; ctx.beginPath(); ctx.arc(x + w * 0.5, y + h * 0.3, h * 0.2, 0, TAU); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = '#fff'; ctx.stroke(); };
    const nm = (list, key) => (x, y, w, h) => text(list[CHAR[key]], x + w / 2, y + h * 0.32, Math.min(h * 0.24, w / 10), '#ffe14a');
    const cyc = (key, n) => () => { CHAR[key] = nextOwned(key, n); saveChar(); this.pulse(); };
    this.buttons = [
      HoverButton('Skin', '', cell(0), cyc('skin', SKINS.length), '#ffb36b', { draw:sw(SKINS, 'skin') }),
      HoverButton('Hair colour', '', cell(1), cyc('hair', HAIRC.length), '#c9a24a', { draw:sw(HAIRC, 'hair') }),
      HoverButton('Hair / hat', '', cell(2), cyc('style', STYLES.length), '#ff6b9a', { draw:nm(STYLES, 'style') }),
      HoverButton('Jacket', '', cell(3), cyc('outfit', OUTFITS.length), '#5b8cff', { draw:sw(OUTFITS, 'outfit') }),
      HoverButton('Trousers', '', cell(4), cyc('pants', PANTSC.length), '#8f9bd6', { draw:sw(PANTSC, 'pants') }),
      HoverButton('Gadget', '', cell(5), cyc('gadget', GADGETS.length), '#3ee08f', { draw:nm(GADGETS, 'gadget') }),
      HoverButton('Trail', '', cell(6), cyc('trail', TRAILS.length), '#b46bff', { draw:nm(TRAILS, 'trail') }),
      HoverButton('Surprise me', '', cell(7), () => { this.rand(); }, '#ffe14a'),
      HoverButton('Shop  ●', '', () => [W * 0.5, H * 0.18 + 4 * (H * 0.125 + H * 0.02), W * 0.22, H * 0.11], () => go('shop'), '#ffd23f'),
      HoverButton('Run!  ▶', '', () => [W * 0.5 + W * 0.235, H * 0.18 + 4 * (H * 0.125 + H * 0.02), W * 0.225, H * 0.11], () => go('runner'), '#4fd27a'),
      HoverButton('Player 1', '', () => [W * 0.04, H * 0.04, W * 0.2, H * 0.085], () => this.setWho(0), PCOL[0], { tabId:'p0', dwell:0.7 }),
      HoverButton('Player 2', '', () => [W * 0.26, H * 0.04, W * 0.2, H * 0.085], () => this.setWho(1), PCOL[1], { tabId:'p1', dwell:0.7 }),
    ];
  },
  pulse(){ this.pop = 0.25; SFX.rep(); for (let i = 0; i < 8; i++) this.parts.push({ x:W * 0.25 + rand(-1, 1) * W * 0.05, y:H * 0.55 + rand(-1, 1) * H * 0.2, vx:rand(-1, 1) * H * 0.2, vy:rand(-1, 0) * H * 0.3, r:H * rand(0.004, 0.009), c:pick(['#ffe14a', '#fff', '#8fdcff']), life:0.6, max:0.6, g:0.4 }); },
  rand(){ const pk2 = (key, n) => pick(ownedList(key, n)); CHAR.skin = Math.floor(rand(0, SKINS.length)); CHAR.hair = Math.floor(rand(0, HAIRC.length)); CHAR.style = pk2('style', STYLES.length); CHAR.outfit = pk2('outfit', OUTFITS.length); CHAR.pants = Math.floor(rand(0, PANTSC.length)); CHAR.gadget = pk2('gadget', GADGETS.length); CHAR.trail = pk2('trail', TRAILS.length); saveChar(); this.pulse(); },
  keys(k){
    const n = this.buttons.length;
    if (k === 'ArrowDown') this.focus = Math.min(n - 1, this.focus + 2);
    if (k === 'ArrowUp') this.focus = Math.max(0, this.focus - 2);
    if (k === 'ArrowLeft') this.focus = Math.max(0, this.focus - 1);
    if (k === 'ArrowRight') this.focus = Math.min(n - 1, this.focus + 1);
    if (k === 'Enter') { this.buttons[this.focus].action(); }
  },
  update(dt){ this.pop = Math.max(0, (this.pop || 0) - dt); this.parts = stepParts(this.parts, dt); this.buttons.forEach((b, i) => b.focus = I.kb.active && i === this.focus); updateButtons(this.buttons, dt, sceneT); },
  draw(){
    ctx.drawImage(cachedLayer('locker', g => { const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#2a2f6a'); gr.addColorStop(1, '#0d1030'); g.fillStyle = gr; g.fillRect(0, 0, W, H); }), 0, 0);
    text(`Player ${this.who + 1}’s runner`, W * 0.5, H * 0.09, H * 0.048, PCOL[this.who], 'left');
    // spotlight + preview
    const cx = W * 0.25, cy = H * 0.8, s = H * 0.5;
    const sp = ctx.createRadialGradient(cx, cy - s * 0.4, 0, cx, cy - s * 0.4, s * 0.9); sp.addColorStop(0, 'rgba(255,255,255,0.22)'); sp.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = sp; ctx.fillRect(0, 0, W * 0.5, H);
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(cx, cy, s * 0.3, s * 0.06, 0, 0, TAU); ctx.fill();
    const bob = Math.sin(sceneT * 5) * 0.5, k = 1 + (this.pop || 0) * 0.5;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(k, k); ctx.translate(-cx, -cy);
    drawChar(cx, cy - Math.abs(bob) * s * 0.02, s, { run:bob * 0.3, t:sceneT, front:true });
    ctx.restore();
    drawParts(this.parts);
    drawButtons(this.buttons);
    for (const b of this.buttons) if (b.tabId === 'p' + this.who) { const [x, y, w, h] = b.rect(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 5; roundRect(x - 4, y - 4, w + 8, h + 8, Math.min(28, h * 0.4)); ctx.stroke(); }
    text('Each player has their own saved look', W * 0.25, H * 0.93, H * 0.028, '#c9d2ff', 'center', 600);
    text(`● ${WALLET.coins} coins`, W * 0.96, H * 0.148, H * 0.032, '#ffd23f', 'right', 800);
  }
};

/* =====================================================================
   SHOP — spend the coins you collect on cool cosmetics
   ===================================================================== */
scenes.shop = {
  hint:'Hold a hand over an item to buy it (coins only) and wear it',
  enter(){ this.focus = 0; this.parts = []; this.tab = 'trail'; this.page = 0; this.msg = null; this.who = CHAR === CHAR2 ? 1 : 0; this.build(); },
  setWho(i){ this.who = i; CHAR = charOf(i); SFX.rep(); this.build(); },
  tabs:[['trail', 'Trails', '#b46bff'], ['hat', 'Hats', '#ff6b9a'], ['gadget', 'Gear', '#3ee08f'], ['suit', 'Suits', '#ffb36b']],
  build(){
    const gx = W * 0.5, gw = W * 0.46, gap = W * 0.015;
    const tab = i => () => { const bw = (gw - gap * 3) / 4; return [gx + i * (bw + gap), H * 0.16, bw, H * 0.08]; };
    const cell = i => () => { const bw = (gw - gap) / 2, bh = H * 0.15; return [gx + (i % 2) * (bw + gap), H * 0.28 + Math.floor(i / 2) * (bh + H * 0.02), bw, bh]; };
    this.buttons = this.tabs.map((t, i) => HoverButton(t[1], '', tab(i), () => { this.tab = t[0]; this.page = 0; this.build(); SFX.rep(); }, t[2], { tabId:t[0], dwell:0.7 }));
    const all = SHOP.filter(it => it.cat === this.tab).sort((a, b) => a.price - b.price), PER = 6, pages = Math.max(1, Math.ceil(all.length / PER));
    this.page = clamp(this.page || 0, 0, pages - 1); this.pages = pages;
    this.items = all.slice(this.page * PER, this.page * PER + PER);
    this.items.forEach((it, i) => {
      const own = owns(it.key, it.i), worn = CHAR[it.key] === it.i;
      const sub = worn ? '✔ wearing' : own ? 'owned · hover to wear' : WALLET.coins >= it.price ? `● ${it.price} · hover to buy` : `● ${it.price}  (need ${it.price - WALLET.coins} more)`;
      this.buttons.push(HoverButton(it.name, sub, cell(i), () => this.pick(it), own ? '#4fd27a' : WALLET.coins >= it.price ? '#ffd23f' : '#6b7090', { item:it, dwell:1.3 }));
    });
    this.buttons.push(HoverButton('◀  Locker', '', () => [gx, H * 0.84, gw * 0.3, H * 0.1], () => go('locker'), '#5b8cff'));
    this.buttons.push(HoverButton('◀ Page', '', () => [gx + gw * 0.32, H * 0.84, gw * 0.32, H * 0.1], () => { if (this.page > 0) { this.page--; this.build(); SFX.rep(); } }, this.page > 0 ? '#8f9bd6' : '#4a4f6e', { dwell:0.8 }));
    this.buttons.push(HoverButton('Page ▶', '', () => [gx + gw * 0.68, H * 0.84, gw * 0.32, H * 0.1], () => { if (this.page < this.pages - 1) { this.page++; this.build(); SFX.rep(); } }, this.page < this.pages - 1 ? '#8f9bd6' : '#4a4f6e', { dwell:0.8 }));
    this.buttons.push(HoverButton('Player 1', '', () => [W * 0.04, H * 0.04, W * 0.2, H * 0.085], () => this.setWho(0), PCOL[0], { tabId:'p0', dwell:0.7 }));
    this.buttons.push(HoverButton('Player 2', '', () => [W * 0.26, H * 0.04, W * 0.2, H * 0.085], () => this.setWho(1), PCOL[1], { tabId:'p1', dwell:0.7 }));
  },
  pick(it){
    if (owns(it.key, it.i)) { CHAR[it.key] = it.i; saveChar(); SFX.rep(); this.flashMsg('Wearing ' + it.name, '#4fd27a'); }
    else if (WALLET.coins >= it.price) {
      WALLET.coins -= it.price; WALLET.owned.push(it.key + ':' + it.i); saveWallet(); CHAR[it.key] = it.i; saveChar();
      SFX.fanfare(); this.flashMsg('Unlocked ' + it.name + '!', '#ffe14a'); this.pop = 0.35;
      for (let i = 0; i < 4; i++) burst(this.parts, W * 0.25 + rand(-0.1, 0.1) * W, H * rand(0.3, 0.6), 16, ['#ffe14a', '#fff', '#ff6b9a', '#8fdcff'], H * 0.7, H * 0.009, 1.1, 0.6);
    } else { SFX.nope(); this.flashMsg(`Need ${it.price - WALLET.coins} more coins — keep running!`, '#ff8a8a'); }
    this.build();
  },
  flashMsg(t, c){ this.msg = { t, c, age:0 }; },
  keys(k){
    const n = this.buttons.length;
    if (k === 'ArrowDown') this.focus = Math.min(n - 1, this.focus + 2);
    if (k === 'ArrowUp') this.focus = Math.max(0, this.focus - 2);
    if (k === 'ArrowLeft') this.focus = Math.max(0, this.focus - 1);
    if (k === 'ArrowRight') this.focus = Math.min(n - 1, this.focus + 1);
    if (k === 'Enter') { const b = this.buttons[this.focus]; if (b) b.action(); }
  },
  update(dt){
    this.pop = Math.max(0, (this.pop || 0) - dt); this.parts = stepParts(this.parts, dt);
    if (this.msg) { this.msg.age += dt; if (this.msg.age > 2.5) this.msg = null; }
    this.buttons.forEach((b, i) => { b.focus = I.kb.active && i === this.focus; b.sel = b.tabId === this.tab || b.tabId === 'p' + this.who; });
    updateButtons(this.buttons, dt, sceneT);
  },
  draw(){
    ctx.drawImage(cachedLayer('locker', g => { const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#2a2f6a'); gr.addColorStop(1, '#0d1030'); g.fillStyle = gr; g.fillRect(0, 0, W, H); }), 0, 0);
    text('Cosmetics shop', W * 0.5, H * 0.08, H * 0.04, '#fff', 'left');
    text(`Page ${(this.page || 0) + 1}/${this.pages || 1}`, W * 0.73, H * 0.82, H * 0.024, '#c9d2ff', 'center', 700);
    text(`● ${WALLET.coins}`, W * 0.82, H * 0.08, H * 0.05, '#ffd23f', 'right', 800);
    // preview: whatever you're hovering is tried on
    const hov = this.buttons.find(b => b.item && (b.hover || 0) > 0.5);
    const cx = W * 0.25, cy = H * 0.8, sz = H * 0.5;
    const sp = ctx.createRadialGradient(cx, cy - sz * 0.4, 0, cx, cy - sz * 0.4, sz * 0.9); sp.addColorStop(0, 'rgba(255,255,255,0.22)'); sp.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = sp; ctx.fillRect(0, 0, W * 0.5, H);
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(cx, cy, sz * 0.3, sz * 0.06, 0, 0, TAU); ctx.fill();
    const keep = hov ? CHAR[hov.item.key] : 0; if (hov) CHAR[hov.item.key] = hov.item.i;
    const bob = Math.sin(sceneT * 5) * 0.5, k = 1 + (this.pop || 0) * 0.5;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(k, k); ctx.translate(-cx, -cy);
    drawChar(cx, cy - Math.abs(bob) * sz * 0.02, sz, { run:bob * 0.3, t:sceneT, front:true });
    ctx.restore();
    if (hov) CHAR[hov.item.key] = keep;
    if (hov) text('Trying on: ' + hov.item.name, cx, H * 0.2, H * 0.035, '#ffe14a', 'center', 700);
    drawParts(this.parts);
    drawButtons(this.buttons);
    for (const b of this.buttons) if (b.sel) { const [x, y, w, h] = b.rect(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 5; roundRect(x - 4, y - 4, w + 8, h + 8, Math.min(28, h * 0.4)); ctx.stroke(); }
    if (this.msg) { ctx.globalAlpha = Math.min(1, (2.5 - this.msg.age) * 2); text(this.msg.t, W * 0.74, H * 0.79, H * 0.038, this.msg.c, 'center', 800); ctx.globalAlpha = 1; }
    text(`Shopping for Player ${this.who + 1} · coins are shared`, W * 0.25, H * 0.93, H * 0.026, '#c9d2ff', 'center', 600);
  }
};
