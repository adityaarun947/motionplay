/* =====================================================================
   SIMON SAYS MOVES — Simon (the star) and a coach show a sequence of moves; you copy it from memory.
   Each round adds one more move. Each move has its own note, so every sequence is a little melody.
   Tuning: moves are checked with the same body measurements as Fit Zone (I.ex) and must be held briefly.
   A failed attempt gets one free retry; the second failure costs a heart. 3 hearts.
   Modes: Classic · Kids (adds Wave and Spin) · Seniors (standing moves only, more time).
   ===================================================================== */
const SIM_NOTES = [523, 587, 659, 784, 880, 1047, 1175, 1319, 1568, 1760, 1976, 2093, 2349];   // C-major pentatonic, so any order sounds nice
const SIM_N = { aL:8, aR:8, kL:0, kR:0, spread:3, up:0, dx:0, lean:0, squat:0, circ:null, clap:0, hips:0 };
// tier = the round from which the move can appear · legs = needs the tablet to see the legs · senior = allowed in Seniors mode · kids = only in Kids mode
const SIM_MOVES = [
  { id:'lArm',  say:'LEFT ARM UP',     col:'#ff6b6b', tier:1, senior:true,  pose:(p, t) => ({ aL:8 + 160 * p }) },
  { id:'rArm',  say:'RIGHT ARM UP',    col:'#ffb02e', tier:1, senior:true,  pose:(p, t) => ({ aR:8 + 160 * p }) },
  { id:'hips',  say:'HANDS ON HIPS',   col:'#4fd27a', tier:1, senior:true,  pose:(p, t) => ({ hips:p > 0.4 ? 1 : 0 }) },
  { id:'kneeL', say:'LEFT KNEE UP',    col:'#4db8ff', tier:1, senior:false, legs:true, pose:(p, t) => ({ kL:0.9 * p, aL:20, aR:20 }) },
  { id:'kneeR', say:'RIGHT KNEE UP',   col:'#b46bff', tier:1, senior:false, legs:true, pose:(p, t) => ({ kR:0.9 * p, aL:20, aR:20 }) },
  { id:'both',  say:'BOTH ARMS UP',    col:'#ff7ad9', tier:3, senior:true,  pose:(p, t) => ({ aL:8 + 165 * p, aR:8 + 165 * p }) },
  { id:'out',   say:'ARMS OUT WIDE',   col:'#3ee0c0', tier:3, senior:true,  pose:(p, t) => ({ aL:8 + 84 * p, aR:8 + 84 * p }) },
  { id:'clap',  say:'CLAP OVERHEAD',   col:'#ffe14a', tier:3, senior:true,  pose:(p, t) => ({ aL:8 + 158 * p, aR:8 + 158 * p, clap:p > 0.8 ? (1 + Math.cos(t * 12)) / 2 : 0 }) },
  { id:'leanL', say:'LEAN LEFT',       col:'#7fe6ff', tier:5, senior:true,  pose:(p, t) => ({ lean:-17 * p, aL:20, aR:20, dx:-0.5 * p }) },
  { id:'leanR', say:'LEAN RIGHT',      col:'#ff9a3f', tier:5, senior:true,  pose:(p, t) => ({ lean:17 * p, aL:20, aR:20, dx:0.5 * p }) },
  { id:'squat', say:'SQUAT DOWN',      col:'#9be36f', tier:7, senior:false, pose:(p, t) => ({ squat:p, aL:8 + 50 * p, aR:8 + 50 * p, spread:3 + 6 * p }) },
  { id:'jump',  say:'JUMP!',           col:'#ff5a8a', tier:7, senior:false, event:true, pose:(p, t) => ({ up:Math.max(0, Math.sin(t * 7)) * 2 * p, aL:8 + 150 * p, aR:8 + 150 * p }) },
  { id:'wave',  say:'WAVE HELLO',      col:'#ffd23f', tier:3, senior:false, kids:true, event:true, pose:(p, t) => ({ aR:150 * p + 8 + Math.sin(t * 11) * 22 * p }) },
  { id:'spin',  say:'SPIN AROUND',     col:'#c9a0ff', tier:6, senior:false, kids:true, event:true, pose:(p, t) => ({ aL:60, aR:60, spin:p }) },
];
const SIM_MODES = {
  classic: { name:'Classic', sub:'Arms · hips · knees · leans · jumps', col:'#4fd27a', C:'kids',   show:2.0, win:4.0, winMin:2.1, hold:0.30 },
  kids:    { name:'Kids',    sub:'Adds Wave and Spin · more time',        col:'#ff9a3f', C:'kids',   show:2.1, win:4.6, winMin:2.6, hold:0.28 },
  senior:  { name:'Seniors', sub:'Standing moves only · gentle pace',     col:'#4aa3a0', C:'senior', show:2.6, win:6.0, winMin:3.8, hold:0.45 },
};

scenes.simon = {
  game:true, music:'simon', hint:'Watch Simon and the coach, then copy the moves in the same order',
  enter(){
    Object.assign(this, { state:'pick', stateT:0, parts:[], pops:[], mode:null, M:null, C:null, senior:false, round:0, score:0, lives:3, seq:[], si:0, attempt:0, coinN:0, movesDone:0,
      legsOK:true, legsVotes:[], pool:[], shake:0, flash:0, joy:0, clock:0, holdT:0, rel:true, hintOn:false, msg:null, showStart:0, cur:null, best:+store.get('mp-best-simon', 0),
      dst:{ base:0, jumpUntil:-9, jumpLast:-9, waveUntil:-9, spinUntil:-9, dir:0, ext:0, rev:0, revT:0 }, f:null });
    Music.setLevel(0.3);
    const card = i => () => { const w = Math.min(W * 0.27, H * 0.52), gap = W * 0.025, tot = 3 * w + 2 * gap; return [W / 2 - tot / 2 + i * (w + gap), H * 0.22, w, H * 0.52]; };
    const icon = (demo, sty) => (x, y, w, h) => drawCoach(x + w / 2, y + h * 0.62, h * 0.5, coachPose(demo, sceneT, false), sty);
    this.pickButtons = [
      HoverButton('Classic', SIM_MODES.classic.sub, card(0), () => this.begin('classic'), SIM_MODES.classic.col, { draw:icon('reach', COACH_STYLE.kids) }),
      HoverButton('Kids', SIM_MODES.kids.sub, card(1), () => this.begin('kids'), SIM_MODES.kids.col, { draw:icon('jacks', COACH_STYLE.kids) }),
      HoverButton('Seniors', SIM_MODES.senior.sub, card(2), () => this.begin('senior'), SIM_MODES.senior.col, { draw:icon('armsout', COACH_STYLE.senior) }),
      HoverButton('Back', '', () => [W * 0.03, H * 0.88, Math.min(W * 0.14, H * 0.3), H * 0.08], () => go('menu'), '#5b8cff'),
    ];
  },
  exit(){ Music.setLevel(1); },
  keys(k){
    if (this.state === 'pick') { const i = { '1':0, '2':1, '3':2 }[k]; if (i !== undefined) this.pickButtons[i].action(); }
    else if (k === ' ' || k === 'Enter' || k === 'r' || k === 'R') this.kbDone = true;     // no tablet: Space counts the current move
  },
  begin(mode){
    this.mode = mode; this.M = SIM_MODES[mode]; this.C = FITCFG[this.M.C]; this.senior = mode === 'senior';
    this.state = 'ready'; this.stateT = 0; this.legsVotes = [];
    if (motionLive()) sendTracker({ t:'calibrate' });
    SFX.select();
  },
  set(st){ this.state = st; this.stateT = 0; },
  moveOf(id){ return SIM_MOVES.find(m => m.id === id); },
  buildPool(){
    const legs = this.legsOK;
    this.pool = SIM_MOVES.filter(m => (!m.legs || legs) && (!this.senior || m.senior) && (!m.kids || this.mode === 'kids') && (!(m.id === 'squat' || m.id === 'jump') || legs || true));
  },
  newSequence(){
    const n = Math.min(12, this.round + 1), avail = this.pool.filter(m => m.tier <= this.round + 1);
    // newer moves are a bit more likely, so a new move shows up soon after it unlocks
    const wt = m => 1 + (m.tier > this.round - 2 ? 1.4 : 0), seq = [];
    for (let i = 0; i < n; i++) {
      let tries = 0, m;
      do { const tot = avail.reduce((a, x) => a + wt(x), 0); let r = Math.random() * tot; m = avail[0]; for (const x of avail) { r -= wt(x); if (r <= 0) { m = x; break; } } tries++; } while (seq.length && m.id === seq[seq.length - 1].id && tries < 6 && avail.length > 1);
      seq.push(m);
    }
    this.seq = seq;
  },
  startRound(){ this.newSequence(); this.attempt = 0; this.beginShow(`Round ${this.round}`); },
  beginShow(banner){ this.msg = { text:banner, t:0 }; this.si = 0; this.set('intro'); },
  showLen(){ return Math.max(1.1, this.M.show - Math.min(0.8, this.round * 0.07)); },
  winLen(){ return Math.max(this.M.winMin, this.M.win - this.round * 0.14); },

  // ---- move detection: the same I.ex measurements Fit Zone uses ----
  track(f, dt){
    const d = this.dst, C = this.C, now = this.clock;
    const drop = f.drop; if (Math.abs(drop - d.base) < 0.1) d.base += (drop - d.base) * 0.01; this.rel0 = drop - d.base;
    if (this.rel0 < -C.jumpOn && now - d.jumpLast > 0.35) { d.jumpLast = now; d.jumpUntil = now + 0.6; }
    const wy = Math.min(f.wly, f.wry), wx = f.wly <= f.wry ? f.wlx : f.wrx;      // the higher hand
    if (wy < -0.15) {
      if (d.dir === 0) { d.dir = 1; d.ext = wx; } else if ((wx - d.ext) * d.dir < 0 && Math.abs(wx - d.ext) > 0.12 && 0) {}
      const mv = wx - d.ext;
      if (d.dir > 0 && mv < -0.17) { d.dir = -1; d.ext = wx; d.rev++; d.revT = now; } else if (d.dir < 0 && mv > 0.17) { d.dir = 1; d.ext = wx; d.rev++; d.revT = now; }
      else if (d.dir > 0 && wx > d.ext) d.ext = wx; else if (d.dir < 0 && wx < d.ext) d.ext = wx;
      if (now - d.revT > 1.2) d.rev = 0;
      if (d.rev >= 3) { d.waveUntil = now + 0.6; d.rev = 0; }
    } else { d.dir = 0; d.rev = 0; }
    if (f.spin < 0.62) d.spinUntil = now + 0.7;
  },
  test(id, f){
    const C = this.C, d = this.dst, now = this.clock;
    switch (id) {
      case 'lArm': return f.wly < C.reach && f.wry > 0.25;
      case 'rArm': return f.wry < C.reach && f.wly > 0.25;
      case 'both': return f.wly < C.reach && f.wry < C.reach;
      case 'hips': return f.elL < -0.68 && f.elR > 0.68 && f.wly > 0.3 && f.wry > 0.3 && f.wly < 1.7 && f.wry < 1.7;
      case 'kneeL': return f.kuL > C.kneeOn && f.kuR < C.kneeOn;
      case 'kneeR': return f.kuR > C.kneeOn && f.kuL < C.kneeOn;
      case 'out': return Math.min(Math.abs(f.wlx), Math.abs(f.wrx)) > C.out && Math.max(Math.abs(f.wly), Math.abs(f.wry)) < 0.45;
      case 'clap': return Math.abs(f.wlx - f.wrx) < C.clapNear && Math.max(f.wly, f.wry) < -0.3;
      case 'leanL': return f.lean < -C.lean;
      case 'leanR': return f.lean > C.lean;
      case 'squat': return this.rel0 > C.squatOn;
      case 'jump': return now < d.jumpUntil;
      case 'wave': return now < d.waveUntil;
      case 'spin': return now < d.spinUntil;
    }
    return false;
  },
  nextDemo(){ return this.seq[this.si] },

  update(dt){
    this.parts = stepParts(this.parts, dt); this.pops = stepPops(this.pops, dt);
    this.clock += dt; this.stateT += dt; this.joy = Math.max(0, this.joy - dt * 1.5); this.shake = Math.max(0, this.shake - dt * 3); this.flash = Math.max(0, this.flash - dt * 2.5);
    if (this.msg) this.msg.t += dt;
    if (this.state === 'pick') { updateButtons(this.pickButtons, dt, sceneT); return; }
    const f = I.ex && motionLive() ? exF(I.ex) : null;
    if (I.ex && I.ex.length > 17) { f.elL = I.ex[15]; f.elR = I.ex[16]; f.spin = I.ex[17]; } else if (f) { f.elL = f.elR = 0; f.spin = 1; }
    this.f = f; if (f) this.track(f, dt);

    if (this.state === 'ready') {
      if (f && f.legs > 0) this.legsVotes.push(f.legs > 0.5 ? 1 : 0);
      if (this.stateT > 3.6) {
        this.legsOK = !motionLive() ? true : (this.legsVotes.length > 5 && this.legsVotes.reduce((a, b) => a + b, 0) / this.legsVotes.length > 0.6);
        this.buildPool(); this.round = 1; SFX.go(); this.startRound();
      }
      return;
    }
    if (this.state === 'intro') { if (this.stateT > 1.2) { this.set('show'); this.si = 0; this.playNote(); } return; }
    if (this.state === 'show') {
      const L = this.showLen();
      if (this.stateT >= L + 0.28) { this.si++; this.stateT = 0; if (this.si >= this.seq.length) { this.si = 0; this.msg = { text:'Your turn!', t:0 }; this.set('go'); SFX.swoosh(); } else this.playNote(); }
      return;
    }
    if (this.state === 'go') { if (this.stateT > 1.0) { this.set('echo'); this.holdT = 0; this.kbDone = false; this.rel = true; this.si = 0; } return; }
    if (this.state === 'echo') {
      const m = this.seq[this.si], win = this.winLen();
      this.hintOn = this.stateT > win * 0.55;
      let ok = false;
      if (f) {
        const on = this.test(m.id, f);
        if (!this.rel) { if (!on) this.rel = true; this.holdT = 0; }
        else if (m.event) ok = on;
        else { this.holdT = on ? this.holdT + dt : 0; ok = this.holdT >= this.M.hold; }
      } else if (this.kbDone) ok = true;
      this.kbDone = false;
      if (ok) {
        this.score += 10 + 2 * this.round; this.movesDone++; this.joy = 1;
        tone(SIM_NOTES[SIM_MOVES.indexOf(m)], 0.35, 'triangle', 0.12);
        burst(this.parts, W * 0.5, H * 0.5, 16, [m.col, '#fff', '#ffe14a'], H * 0.8, H * 0.01, 0.8, 0.7);
        pop(this.pops, W * 0.5, H * 0.44, '✓', m.col, 0.1, 0.7);
        this.si++; this.stateT = 0; this.holdT = 0;
        this.rel = this.si >= this.seq.length || this.seq[this.si].id !== m.id;      // same move twice in a row: lower it first
        if (this.si >= this.seq.length) this.roundWin();
      } else if (this.stateT > win) this.miss();
      return;
    }
    if (this.state === 'roundwin') { if (this.stateT > 1.6) { this.round++; this.startRound(); } return; }
    if (this.state === 'retry') { if (this.stateT > 1.8) { this.attempt = 1; this.beginShow('Watch once more'); } return; }
    if (this.state === 'lost') {
      if (this.stateT > 2.0) {
        if (this.lives <= 0) go('over', { game:'simon', score:this.score, detail:`Round ${this.round} · ${this.movesDone} moves copied · ${this.M.name} mode`, coins:this.coinN });
        else { this.newSequence(); this.attempt = 0; this.beginShow(`Round ${this.round}`); }
      }
    }
  },
  playNote(){ const m = this.seq[this.si]; tone(SIM_NOTES[SIM_MOVES.indexOf(m)], 0.45, 'triangle', 0.13); },
  roundWin(){
    const bonus = 20 * this.round; this.score += bonus; this.joy = 1.5; this.flash = 0.3;
    let c = 0; if (this.round >= 3) c += 1; if (this.round % 5 === 0) c += 3;
    if (c) this.coinN += earnCoins(c);
    SFX.fanfare(); pop(this.pops, W * 0.5, H * 0.3, `Round ${this.round} clear!  +${bonus}${c ? `  ·  ● +${c}` : ''}`, '#ffe14a', 0.06, 1.5);
    for (let i = 0; i < 3; i++) burst(this.parts, W * rand(0.2, 0.8), H * rand(0.2, 0.5), 16, ['#ffe14a', '#ff7ad9', '#7fe6ff', '#fff'], H * 0.8, H * 0.01, 1, 0.8);
    this.set('roundwin');
  },
  miss(){
    if (this.attempt === 0) { this.msg = { text:'Not quite — free retry!', t:0 }; SFX.land(); this.set('retry'); return; }
    this.lives--; this.shake = 1; this.flash = 0.5; SFX.hit();
    this.msg = { text:this.lives > 0 ? 'Miss!  -1 ♥  New sequence' : 'Out of hearts!', t:0 };
    this.set('lost');
  },
  rescale(sc){ for (const arr of [this.parts, this.pops]) for (const o of arr) sc(o, true); },

  /* ---------------- drawing ---------------- */
  bg(){
    ctx.drawImage(cachedLayer('simon-bg', g => {
      const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#3a1f7a'); gr.addColorStop(0.55, '#7a2a9a'); gr.addColorStop(1, '#c2457a'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
      g.fillStyle = 'rgba(255,255,255,0.06)'; for (let i = 0; i < 14; i++) { g.beginPath(); g.arc(rand(0, W), rand(0, H), rand(H * 0.02, H * 0.09), 0, TAU); g.fill(); }
      const sp = g.createRadialGradient(W * 0.72, H * 0.5, 0, W * 0.72, H * 0.5, H * 0.7); sp.addColorStop(0, 'rgba(255,230,160,0.35)'); sp.addColorStop(1, 'rgba(255,230,160,0)'); g.fillStyle = sp; g.fillRect(0, 0, W, H);
    }), 0, 0);
  },
  coachBox(){ return { cx:W * 0.72, fy:H * 0.9, h:H * 0.66 }; },
  drawCoachMove(m, t, ghost){
    const B = this.coachBox(), p = Math.min(1, t / 0.4), e = p * p * (3 - 2 * p), P = Object.assign({}, SIM_N, m.pose(e, t));
    ctx.save();
    if (P.spin) { const a = Math.max(0.18, Math.abs(Math.cos(t * 6))); ctx.translate(B.cx, 0); ctx.scale(a, 1); ctx.translate(-B.cx, 0); }
    if (ghost) ctx.globalAlpha = 0.45;
    drawCoach(B.cx, B.fy, B.h, P, this.senior ? COACH_STYLE.senior : COACH_STYLE.kids);
    ctx.restore();
  },
  draw(now){
    this.bg();
    ctx.save();
    if (this.shake > 0) ctx.translate(rand(-1, 1) * this.shake * H * 0.012, rand(-1, 1) * this.shake * H * 0.012);
    if (this.state === 'pick') this.drawPick(); else this.drawGame();
    drawParts(this.parts); drawPops(this.pops);
    ctx.restore();
    if (this.flash > 0) { ctx.fillStyle = `rgba(${this.state === 'lost' ? '255,60,60' : '255,240,160'},${this.flash * 0.35})`; ctx.fillRect(0, 0, W, H); }
  },
  drawPick(){
    text('Simon Says Moves', W / 2, H * 0.09, H * 0.08);
    text('Watch the moves, then copy them in the same order. Every round adds one more!', W / 2, H * 0.155, H * 0.03, '#f0e0ff', 'center', 600);
    drawMascot(W * 0.1, H * 0.2, H * 0.07, 'kids', sceneT, 0.4);
    drawButtons(this.pickButtons);
    text('Stand 2–3 metres from the tablet so your whole body fits in view', W / 2, H * 0.935, H * 0.027, '#f0e0ff', 'center', 600);
  },
  simon(joy){ drawMascot(W * 0.2, H * 0.36, H * 0.12, 'kids', sceneT, joy); },
  bubble(lines, col){
    const x = W * 0.04, y = H * 0.52, w = W * 0.36, h = H * 0.3;
    roundRect(x, y, w, h, H * 0.03); ctx.fillStyle = 'rgba(255,255,255,0.94)'; ctx.fill();
    ctx.beginPath(); ctx.moveTo(x + w * 0.42, y); ctx.lineTo(x + w * 0.5, y - H * 0.06); ctx.lineTo(x + w * 0.58, y); ctx.fill();
    lines.forEach((l, i) => text(l.t, x + w / 2, y + h * (0.28 + i * 0.4), H * l.s, l.c || '#2a1b4d', 'center', 800));
  },
  dots(){
    const n = this.seq.length, r = Math.min(H * 0.03, W * 0.4 / Math.max(6, n) / 2), gap = r * 2.7, x0 = W / 2 - (n - 1) * gap / 2;
    for (let i = 0; i < n; i++) {
      const m = this.seq[i], x = x0 + i * gap, y = H * 0.075, done = (this.state === 'echo' || this.state === 'roundwin') && i < this.si || this.state === 'roundwin';
      const cur = (this.state === 'show' && i === this.si) || (this.state === 'echo' && i === this.si);
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU);
      if (done) { ctx.fillStyle = m.col; ctx.fill(); } else if (this.state === 'show' && i < this.si) { ctx.fillStyle = 'rgba(255,255,255,0.45)'; ctx.fill(); } else { ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fill(); }
      ctx.lineWidth = cur ? r * 0.35 : r * 0.15; ctx.strokeStyle = cur ? '#fff' : 'rgba(255,255,255,0.4)'; ctx.stroke();
      if (this.state === 'show' && i === this.si) { ctx.fillStyle = m.col; ctx.beginPath(); ctx.arc(x, y, r * 0.55, 0, TAU); ctx.fill(); }
    }
  },
  drawGame(){
    const fk = Math.min(1, W / (H * 1.3));
    text(`Round ${this.round}`, W * 0.04, H * 0.07, H * 0.05 * fk, '#fff', 'left');
    text(`${this.score} pts  ·  ● ${this.coinN}`, W * 0.04, H * 0.125, H * 0.03 * fk, '#ffe9a8', 'left', 700);
    for (let i = 0; i < 3; i++) text('♥', W * (0.86 + i * 0.045), H * 0.07, H * 0.06 * fk, i < this.lives ? '#ff3b6b' : 'rgba(255,255,255,0.4)');
    if (this.state !== 'ready') this.dots();
    this.simon(this.joy);
    const st = this.state, m = this.seq[this.si];
    if (st === 'ready') {
      this.bubble([{ t:'Get ready!', s:0.06 }, { t:'Stand back so I can see all of you', s:0.028, c:'#6a3fb5' }]);
      const box = [W * 0.5, H * 0.17, Math.min(W * 0.34, H * 0.62), Math.min(W * 0.34, H * 0.62) * 1.05];
      roundRect(box[0], box[1], box[2], box[3], H * 0.025); ctx.fillStyle = 'rgba(8,12,40,0.35)'; ctx.fill();
      ctx.save(); roundRect(box[0], box[1], box[2], box[3], H * 0.025); ctx.clip(); drawGhost(0.95, box, '#ffffff'); ctx.restore();
      text(String(Math.max(1, Math.ceil(3.6 - this.stateT))), box[0] + box[2] / 2, box[1] - H * 0.01, H * 0.06, '#fff');
      if (!(motionLive() && I.present)) text(motionLive() ? 'I can’t see you yet' : 'Keyboard: press Space to do each move', box[0] + box[2] / 2, box[1] + box[3] / 2, H * 0.03, '#ffc24a', 'center', 700);
      return;
    }
    if (st === 'intro' || st === 'go' || st === 'roundwin' || st === 'retry' || st === 'lost') {
      const big = this.msg ? this.msg.text : '';
      this.bubble([{ t:st === 'intro' ? 'Simon says…' : st === 'go' ? 'Your turn!' : big, s:st === 'intro' || st === 'go' ? 0.06 : 0.045, c:st === 'lost' ? '#d6264a' : '#2a1b4d' }, { t:st === 'go' ? `${this.seq.length} moves — same order` : st === 'intro' ? `${this.seq.length} move${this.seq.length > 1 ? 's' : ''} this round` : '', s:0.03, c:'#6a3fb5' }]);
      this.drawCoachIdle();
      return;
    }
    if (st === 'show') {
      const L = this.showLen(), inGap = this.stateT > L;
      this.bubble([{ t:'Simon says:', s:0.035, c:'#6a3fb5' }, { t:m.say, s:Math.min(0.06, 0.62 * W * 0.36 / (m.say.length * H * 0.6)) + 0.01, c:'#2a1b4d' }]);
      if (!inGap) this.drawCoachMove(m, this.stateT, false); else this.drawCoachIdle();
      const k = clamp(this.stateT / L, 0, 1), bw = W * 0.3; ctx.fillStyle = 'rgba(0,0,0,0.25)'; roundRect(W * 0.57, H * 0.93, bw, H * 0.018, H * 0.009); ctx.fill(); ctx.fillStyle = m.col; roundRect(W * 0.57, H * 0.93, Math.max(H * 0.018, bw * k), H * 0.018, H * 0.009); ctx.fill();
      return;
    }
    if (st === 'echo') {
      const win = this.winLen(), k = clamp(1 - this.stateT / win, 0, 1);
      this.bubble([{ t:`Move ${this.si + 1} of ${this.seq.length}`, s:0.04, c:'#2a1b4d' }, { t:this.hintOn ? `Hint: ${m.say}` : 'Do it from memory!', s:this.hintOn ? 0.034 : 0.03, c:this.hintOn ? m.col : '#6a3fb5' }]);
      // you, in a frame, on the right
      const s = Math.min(W * 0.36, H * 0.66), box = [W * 0.56, H * 0.17, s, s * 1.03];
      roundRect(box[0], box[1], box[2], box[3], H * 0.025); ctx.fillStyle = 'rgba(8,12,40,0.35)'; ctx.fill();
      ctx.save(); roundRect(box[0], box[1], box[2], box[3], H * 0.025); ctx.clip(); ctx.globalCompositeOperation = 'lighter'; drawGhost(0.3, box, m.col); ctx.globalCompositeOperation = 'source-over'; drawGhost(0.95, box, '#ffffff'); ctx.restore();
      if (this.hintOn) { ctx.save(); ctx.translate(-W * 0.72 + box[0] + box[2] * 0.02, 0); ctx.globalAlpha = 0.5; ctx.restore(); }
      if (!(motionLive() && I.present)) text(motionLive() ? 'I can’t see you' : 'Keyboard: Space = done', box[0] + box[2] / 2, box[1] + box[3] / 2, H * 0.03, '#ffc24a', 'center', 700);
      // hold ring + time bar
      if (!m.event && this.holdT > 0) { ctx.strokeStyle = m.col; ctx.lineWidth = H * 0.012; ctx.beginPath(); ctx.arc(box[0] + box[2] / 2, box[1] + box[3] + H * 0.05, H * 0.03, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(this.holdT / this.M.hold, 0, 1)); ctx.stroke(); }
      const bw = box[2]; ctx.fillStyle = 'rgba(0,0,0,0.3)'; roundRect(box[0], H * 0.94, bw, H * 0.022, H * 0.011); ctx.fill(); ctx.fillStyle = k > 0.35 ? '#7fe6ff' : '#ff8a5b'; roundRect(box[0], H * 0.94, Math.max(H * 0.022, bw * k), H * 0.022, H * 0.011); ctx.fill();
      if (this.hintOn) { const B = this.coachBox(); ctx.save(); ctx.translate(-(B.cx - (W * 0.3)), 0); this.drawCoachMove(m, this.stateT, true); ctx.restore(); }
      if (this.rel === false) text('Lower your arms/pose first', box[0] + box[2] / 2, box[1] - H * 0.015, H * 0.026, '#ffc24a', 'center', 700);
    }
  },
  drawCoachIdle(){ const B = this.coachBox(); drawCoach(B.cx, B.fy, B.h, Object.assign({}, SIM_N), this.senior ? COACH_STYLE.senior : COACH_STYLE.kids); },
};
