/* =====================================================================
   ZOMBIE SIEGE — WORLD & SOUND: six moods of night (a new one after every wave), weather, birds, lightning, fires,
   plus real-sounding grunts, gunfire and ambience.
   ===================================================================== */
const ZENVS = [
  { id:'blood', name:'BLOOD MOON', sky:['#0c0207', '#35081a', '#8a1a22'], hor:'255,90,50', moon:{ x:0.74, y:0.17, r:0.095, col:'#ff6a42', glow:'255,70,40', craters:true }, stars:0.5,
    far:'#1a060d', mid:'#12040a', ground:['#2e1a1a', '#1b0f10'], cloud:'46,8,16', fog:'170,50,56', fogA:0.3, tint:'rgba(120,0,10,0.10)', weather:'none', birds:'crow', city:true, church:true,
    bed:'wind', amb:['wolf', 'crow', 'wind', 'bell'], flame:'255,140,50' },
  { id:'storm', name:'THUNDERSTORM', sky:['#03060c', '#101c28', '#2f4656'], hor:'120,170,200', moon:null, stars:0,
    far:'#0b1118', mid:'#070b10', ground:['#1b261f', '#0f1713'], cloud:'12,22,32', fog:'110,140,160', fogA:0.32, tint:'rgba(0,30,60,0.12)', weather:'rain', lightning:true, birds:null, city:true,
    bed:'rain', amb:['thunder', 'wind', 'thunder'], flame:'255,150,60' },
  { id:'toxic', name:'TOXIC DUSK', sky:['#04100a', '#173a1a', '#6c9a26'], hor:'190,255,80', moon:{ x:0.3, y:0.2, r:0.075, col:'#d8ff7a', glow:'170,255,60' }, stars:0.2,
    far:'#0c1f0e', mid:'#07140a', ground:['#2a3a1c', '#16200f'], cloud:'18,52,20', fog:'120,190,70', fogA:0.38, tint:'rgba(60,140,10,0.10)', weather:'spores', birds:'bat', city:false, church:false,
    bed:'drone', amb:['bubble', 'owl', 'cricket', 'wind'], flame:'150,255,70' },
  { id:'fire', name:'BURNING NIGHT', sky:['#0a0402', '#3b1306', '#d2561a'], hor:'255,150,50', moon:null, stars:0,
    far:'#1e0a04', mid:'#120603', ground:['#2e1d12', '#170d08'], cloud:'30,10,4', fog:'230,110,50', fogA:0.28, tint:'rgba(180,60,0,0.10)', weather:'ash', birds:'crow', city:true, fires:true,
    bed:'fire', amb:['siren', 'crow', 'wind', 'thunder'], flame:'255,150,40' },
  { id:'mist', name:'DEAD FOG', sky:['#0f121b', '#2a3243', '#7a8498'], hor:'200,210,230', moon:{ x:0.62, y:0.2, r:0.07, col:'#eef3ff', glow:'210,225,255' }, stars:0.15,
    far:'#1b2130', mid:'#10141e', ground:['#2a3030', '#171c1c'], cloud:'60,70,90', fog:'190,200,220', fogA:0.62, tint:'rgba(90,110,150,0.10)', weather:'dust', birds:'crow', city:false, church:true,
    bed:'wind', amb:['owl', 'wolf', 'bell', 'cricket'], flame:'255,170,80' },
  { id:'eclipse', name:'BLACK ECLIPSE', sky:['#05020d', '#1a0a36', '#44226e'], hor:'160,90,255', moon:{ x:0.5, y:0.16, r:0.085, col:'#050208', glow:'150,90,255', eclipse:true }, stars:0.8,
    far:'#120826', mid:'#0a0418', ground:['#241a30', '#120c1a'], cloud:'24,10,48', fog:'130,80,200', fogA:0.3, tint:'rgba(80,0,140,0.12)', weather:'none', birds:'bat', city:true, church:false,
    bed:'drone', amb:['whisper', 'bell', 'wolf', 'drone'], flame:'200,120,255' },
];

function zProj(x, z){ const HOR = H * 0.42, s = Z_NEAR / (z + Z_NEAR); return { X:W / 2 + x * W * 0.32 * s, Y:HOR + (H * 1.06 - HOR) * s, s:H * 0.5 * s }; }

function zTree(g, rnd, x, y, len, ang, wid, depth){
  const nx = x + Math.cos(ang) * len, ny = y + Math.sin(ang) * len, bend = (rnd() - 0.5) * 0.7;
  g.lineWidth = wid; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + Math.cos(ang + bend) * len * 0.55, y + Math.sin(ang + bend) * len * 0.55, nx, ny); g.stroke();
  if (depth > 0) { const n = rnd() < 0.35 ? 3 : 2; for (let i = 0; i < n; i++) zTree(g, rnd, nx, ny, len * (0.6 + rnd() * 0.18), ang + (rnd() - 0.5) * 1.7, wid * 0.62, depth - 1); }
}

function zSkyLayer(env){
  return cachedLayer('zsky_' + env.id, g => {
    const HOR = H * 0.42, rnd = mulberry32(env.id.length * 977 + 11);
    const sky = g.createLinearGradient(0, 0, 0, HOR + 2); sky.addColorStop(0, env.sky[0]); sky.addColorStop(0.62, env.sky[1]); sky.addColorStop(1, env.sky[2]); g.fillStyle = sky; g.fillRect(0, 0, W, HOR + 4);
    if (env.stars) for (let i = 0; i < 130 * env.stars; i++) { const a = rnd() * 0.8 + 0.1; g.fillStyle = `rgba(255,255,255,${a})`; g.beginPath(); g.arc(rnd() * W, rnd() * HOR * 0.8, rnd() * 1.5 + 0.3, 0, TAU); g.fill(); }
    const m = env.moon;
    if (m) {
      const mx = W * m.x, my = H * m.y, mr = H * m.r;
      let gl = g.createRadialGradient(mx, my, mr * 0.6, mx, my, mr * 7); gl.addColorStop(0, `rgba(${m.glow},${m.eclipse ? 0.5 : 0.4})`); gl.addColorStop(0.4, `rgba(${m.glow},0.1)`); gl.addColorStop(1, `rgba(${m.glow},0)`); g.fillStyle = gl; g.fillRect(mx - mr * 7, my - mr * 7, mr * 14, mr * 14);
      if (m.eclipse) {
        g.strokeStyle = 'rgba(200,160,255,0.9)'; g.lineWidth = mr * 0.12; g.beginPath(); g.arc(mx, my, mr * 1.04, 0, TAU); g.stroke();
        for (let i = 0; i < 40; i++) { const a = rnd() * TAU, l = mr * (0.25 + rnd() * 0.9); g.strokeStyle = `rgba(190,140,255,${0.15 + rnd() * 0.25})`; g.lineWidth = 1 + rnd() * 2; g.beginPath(); g.moveTo(mx + Math.cos(a) * mr * 1.1, my + Math.sin(a) * mr * 1.1); g.lineTo(mx + Math.cos(a) * (mr * 1.1 + l), my + Math.sin(a) * (mr * 1.1 + l)); g.stroke(); }
        g.fillStyle = '#030108'; g.beginPath(); g.arc(mx, my, mr, 0, TAU); g.fill();
      } else {
        const dg = g.createRadialGradient(mx - mr * 0.3, my - mr * 0.3, mr * 0.1, mx, my, mr); dg.addColorStop(0, zShade(m.col, 0.45)); dg.addColorStop(0.7, m.col); dg.addColorStop(1, zShade(m.col, -0.4)); g.fillStyle = dg; g.beginPath(); g.arc(mx, my, mr, 0, TAU); g.fill();
        g.fillStyle = 'rgba(40,10,10,0.28)'; for (let i = 0; i < 9; i++) { const a = rnd() * TAU, d = rnd() * mr * 0.75; g.beginPath(); g.arc(mx + Math.cos(a) * d, my + Math.sin(a) * d, mr * (0.05 + rnd() * 0.14), 0, TAU); g.fill(); }
      }
    }
    // horizon glow
    const hg = g.createLinearGradient(0, HOR - H * 0.34, 0, HOR + 2); hg.addColorStop(0, `rgba(${env.hor},0)`); hg.addColorStop(1, `rgba(${env.hor},${env.id === 'fire' ? 0.8 : 0.5})`); g.fillStyle = hg; g.fillRect(0, HOR - H * 0.34, W, H * 0.34 + 2);
  });
}
function zCloudTile(env, layer){
  return cachedLayer('zcl_' + env.id + layer, g => {
    const rnd = mulberry32(env.id.length * 313 + layer * 71 + 5), h = H * 0.4; g.canvas.height = h | 0;
    const n = layer ? 14 : 10;
    for (let i = 0; i < n; i++) {
      const x = rnd() * W, y = h * (layer ? 0.45 + rnd() * 0.45 : 0.1 + rnd() * 0.5), rx = W * (0.12 + rnd() * 0.16) * (layer ? 0.8 : 1.2), ry = H * (0.025 + rnd() * 0.05) * (layer ? 0.8 : 1.3), a = (layer ? 0.5 : 0.7) * (0.5 + rnd() * 0.5);
      for (const ox of [0, -W, W]) { if (x + ox < -rx * 1.2 || x + ox > W + rx * 1.2) continue; const gr = g.createRadialGradient(x + ox, y, 0, x + ox, y, rx); gr.addColorStop(0, `rgba(${env.cloud},${a})`); gr.addColorStop(0.6, `rgba(${env.cloud},${a * 0.5})`); gr.addColorStop(1, `rgba(${env.cloud},0)`); g.save(); g.translate(x + ox, y); g.scale(1, ry / rx); g.translate(-(x + ox), -y); g.fillStyle = gr; g.beginPath(); g.arc(x + ox, y, rx, 0, TAU); g.fill(); g.restore(); }
    }
  });
}
function zFogTile(env, layer){
  return cachedLayer('zfg_' + env.id + layer, g => {
    const rnd = mulberry32(env.id.length * 211 + layer * 31 + 9), h = H * 0.26; g.canvas.height = h | 0;
    for (let i = 0; i < 12; i++) {
      const x = rnd() * W, y = h * (0.3 + rnd() * 0.5), rx = W * (0.1 + rnd() * 0.14), ry = H * (0.02 + rnd() * 0.04);
      for (const ox of [0, -W, W]) { if (x + ox < -rx || x + ox > W + rx) continue; const gr = g.createRadialGradient(x + ox, y, 0, x + ox, y, rx); gr.addColorStop(0, `rgba(${env.fog},0.55)`); gr.addColorStop(1, `rgba(${env.fog},0)`); g.save(); g.translate(x + ox, y); g.scale(1, ry / rx); g.translate(-(x + ox), -y); g.fillStyle = gr; g.beginPath(); g.arc(x + ox, y, rx, 0, TAU); g.fill(); g.restore(); }
    }
  });
}

function zSceneryLayer(env){
  return cachedLayer('zsc_' + env.id, g => {
    const HOR = H * 0.42, rnd = mulberry32(env.id.length * 599 + 3), path = zProj;
    g.clearRect(0, 0, W, H); g.lineCap = 'round'; g.lineJoin = 'round';
    // far hills, hazy
    for (const [col, amp, base, a] of [[env.far, 0.06, 0.005, 1], [env.mid, 0.035, 0.012, 1]]) {
      g.fillStyle = col; g.beginPath(); g.moveTo(0, HOR + H * 0.02);
      let ph = rnd() * 9; for (let x = 0; x <= W; x += W / 40) g.lineTo(x, HOR - H * (amp * (0.5 + 0.5 * Math.sin(x * 0.004 + ph) * Math.sin(x * 0.0017 + ph * 2)) + base));
      g.lineTo(W, HOR + H * 0.02); g.closePath(); g.fill();
    }
    // ruined skyline
    if (env.city) {
      const base = HOR - H * 0.005; let x = W * 0.02;
      while (x < W * 0.98) {
        const bw = W * (0.018 + rnd() * 0.03), bh = H * (0.05 + rnd() * 0.12), skip = rnd() < 0.18; if (!skip) {
          g.fillStyle = zShade(env.far, -0.35); g.beginPath(); g.moveTo(x, base); g.lineTo(x, base - bh); const broken = rnd() < 0.6; if (broken) { g.lineTo(x + bw * 0.35, base - bh * 0.92); g.lineTo(x + bw * 0.55, base - bh * 1.05); g.lineTo(x + bw * 0.8, base - bh * 0.85); g.lineTo(x + bw, base - bh * 0.95); } else g.lineTo(x + bw, base - bh); g.lineTo(x + bw, base); g.closePath(); g.fill();
          const lit = env.fires ? 0.12 : 0.05; for (let wy = base - bh + H * 0.01; wy < base - H * 0.01; wy += H * 0.016) for (let wx = x + bw * 0.15; wx < x + bw * 0.85; wx += bw * 0.28) if (rnd() < lit) { g.fillStyle = env.fires ? 'rgba(255,170,60,0.85)' : 'rgba(255,215,130,0.75)'; g.fillRect(wx, wy, bw * 0.12, H * 0.008); }
        }
        x += bw * (0.9 + rnd() * 0.5);
      }
    }
    if (env.church) {   // little chapel with a glowing window
      const cx = W * (0.14 + rnd() * 0.05), cb = HOR + H * 0.004, cs = H * 0.17; g.fillStyle = '#0a0508';
      g.fillRect(cx - cs * 0.28, cb - cs * 0.42, cs * 0.56, cs * 0.42); g.beginPath(); g.moveTo(cx - cs * 0.34, cb - cs * 0.42); g.lineTo(cx, cb - cs * 0.62); g.lineTo(cx + cs * 0.34, cb - cs * 0.42); g.fill();
      g.fillRect(cx + cs * 0.12, cb - cs * 0.9, cs * 0.14, cs * 0.5); g.beginPath(); g.moveTo(cx + cs * 0.1, cb - cs * 0.9); g.lineTo(cx + cs * 0.19, cb - cs * 1.12); g.lineTo(cx + cs * 0.28, cb - cs * 0.9); g.fill();
      g.strokeStyle = '#0a0508'; g.lineWidth = cs * 0.025; g.beginPath(); g.moveTo(cx + cs * 0.19, cb - cs * 1.12); g.lineTo(cx + cs * 0.19, cb - cs * 1.25); g.moveTo(cx + cs * 0.15, cb - cs * 1.2); g.lineTo(cx + cs * 0.23, cb - cs * 1.2); g.stroke();
      const wg = g.createRadialGradient(cx - cs * 0.08, cb - cs * 0.22, 0, cx - cs * 0.08, cb - cs * 0.22, cs * 0.2); wg.addColorStop(0, 'rgba(255,200,90,0.9)'); wg.addColorStop(1, 'rgba(255,160,50,0)'); g.fillStyle = wg; g.fillRect(cx - cs * 0.3, cb - cs * 0.42, cs * 0.4, cs * 0.4);
      g.fillStyle = '#ffd27a'; roundRect(cx - cs * 0.11, cb - cs * 0.3, cs * 0.06, cs * 0.14, cs * 0.03, g); g.fill(); roundRect(cx + cs * 0.02, cb - cs * 0.3, cs * 0.06, cs * 0.14, cs * 0.03, g); g.fill();
    }
    // dead tree line
    g.strokeStyle = zShade(env.mid, -0.2);
    for (let i = 0; i < 26; i++) { const x = rnd() * W, depth = rnd(), len = H * (0.05 + depth * 0.1); zTree(g, rnd, x, HOR + H * (0.004 + depth * 0.03), len, -Math.PI / 2 + (rnd() - 0.5) * 0.3, H * (0.003 + depth * 0.005), 4); }
    // ground
    const grd = g.createLinearGradient(0, HOR, 0, H); grd.addColorStop(0, zMix(env.ground[0], env.hor.split(',').length === 3 ? `rgb(${env.hor})` : env.ground[0], 0.12)); grd.addColorStop(0.35, env.ground[0]); grd.addColorStop(1, env.ground[1]);
    g.fillStyle = grd; g.fillRect(0, HOR, W, H - HOR);
    const gh = g.createLinearGradient(0, HOR, 0, HOR + H * 0.1); gh.addColorStop(0, `rgba(${env.hor},0.25)`); gh.addColorStop(1, `rgba(${env.hor},0)`); g.fillStyle = gh; g.fillRect(0, HOR, W, H * 0.1);
    // mud, speckle, grass
    for (let i = 0; i < 38; i++) { const z = 1 + rnd() * 30, p = path((rnd() - 0.5) * 9, z); g.fillStyle = `rgba(0,0,0,${0.1 + rnd() * 0.12})`; g.beginPath(); g.ellipse(p.X, p.Y, p.s * (0.3 + rnd() * 0.9), p.s * 0.06 * (0.5 + rnd()), 0, 0, TAU); g.fill(); }
    for (let i = 0; i < 900; i++) { const y = HOR + (H - HOR) * Math.pow(rnd(), 1.6), k = (y - HOR) / (H - HOR); g.fillStyle = rnd() < 0.5 ? 'rgba(0,0,0,0.22)' : 'rgba(255,255,255,0.05)'; g.fillRect(rnd() * W, y, 1 + k * 3, 1 + k * 1.5); }
    // the path toward you, with ruts
    g.fillStyle = zMix(env.ground[0], '#5a4c38', 0.5); g.beginPath(); const p1 = path(-0.5, 40), p2 = path(0.5, 40), p3 = path(1.3, -0.5), p4 = path(-1.3, -0.5); g.moveTo(p1.X, p1.Y); g.lineTo(p2.X, p2.Y); g.lineTo(p3.X, p3.Y); g.lineTo(p4.X, p4.Y); g.closePath(); g.fill();
    g.strokeStyle = 'rgba(0,0,0,0.22)'; g.lineWidth = 2; for (const xs of [-0.55, 0.55]) { g.beginPath(); for (let z = 40; z >= -0.4; z -= 1.5) { const p = path(xs, z); z === 40 ? g.moveTo(p.X, p.Y) : g.lineTo(p.X, p.Y); } g.lineWidth = 3; g.stroke(); }
    // puddles that mirror the sky
    for (let i = 0; i < 6; i++) { const z = 2 + rnd() * 16, p = path((rnd() - 0.5) * 4.6, z), pg = g.createLinearGradient(0, p.Y - p.s * 0.1, 0, p.Y + p.s * 0.1); pg.addColorStop(0, `rgba(${env.hor},0.5)`); pg.addColorStop(1, env.sky[1]); g.fillStyle = pg; g.beginPath(); g.ellipse(p.X, p.Y, p.s * (0.35 + rnd() * 0.5), p.s * 0.07, 0, 0, TAU); g.fill(); g.strokeStyle = 'rgba(255,255,255,0.15)'; g.lineWidth = 1.5; g.stroke(); }
    // side fences running into the distance
    for (const sd of [-1, 1]) {
      g.strokeStyle = '#0b0809'; g.fillStyle = '#0b0809';
      const xs = sd * 3.3;
      for (const hy of [0.5, 1.1]) { g.lineWidth = 3; g.beginPath(); for (let z = 38; z >= 0; z -= 2) { const p = path(xs, z); z === 38 ? g.moveTo(p.X, p.Y - hy * p.s * 0.45) : g.lineTo(p.X, p.Y - hy * p.s * 0.45); } g.stroke(); }
      for (let z = 38; z >= 0.5; z -= 1.4) { const p = path(xs, z), h = p.s * 1.25, w = Math.max(1.5, p.s * 0.05); g.fillRect(p.X - w / 2, p.Y - h, w, h); g.beginPath(); g.moveTo(p.X - w * 1.2, p.Y - h); g.lineTo(p.X, p.Y - h - w * 3.6); g.lineTo(p.X + w * 1.2, p.Y - h); g.fill(); }
    }
    // graves, crosses, bones, deterministic positions
    for (let i = 0; i < 26; i++) {
      const side = i % 2 ? 1 : -1, z = 2.5 + rnd() * 24, p = path(side * (1.9 + rnd() * 3.4), z), w = p.s * 0.5, h = w * (1.1 + rnd() * 0.5), tilt = (rnd() - 0.5) * 0.3, kind = Math.floor(rnd() * 4);
      g.save(); g.translate(p.X, p.Y); g.rotate(tilt);
      g.fillStyle = 'rgba(0,0,0,0.35)'; g.beginPath(); g.ellipse(w * 0.3, 0, w * 0.7, w * 0.12, 0, 0, TAU); g.fill();
      const sg = g.createLinearGradient(-w / 2, 0, w / 2, 0); sg.addColorStop(0, '#9aa0b3'); sg.addColorStop(0.5, '#6c7183'); sg.addColorStop(1, '#2c2f3c'); g.fillStyle = sg;
      if (kind === 0) { g.fillRect(-w * 0.08, -h * 1.1, w * 0.16, h * 1.1); g.fillRect(-w * 0.35, -h * 0.85, w * 0.7, w * 0.15); }
      else if (kind === 1) { roundRect(-w / 2, -h, w, h, w * 0.5, g); g.fill(); g.fillStyle = 'rgba(0,0,0,0.3)'; g.fillRect(-w * 0.2, -h * 0.72, w * 0.4, h * 0.07); g.fillRect(-w * 0.04, -h * 0.85, w * 0.08, h * 0.35); }
      else if (kind === 2) { g.beginPath(); g.moveTo(-w * 0.5, 0); g.lineTo(-w * 0.5, -h * 0.7); g.lineTo(0, -h); g.lineTo(w * 0.5, -h * 0.7); g.lineTo(w * 0.5, 0); g.closePath(); g.fill(); }
      else { roundRect(-w * 0.55, -h * 0.65, w * 1.1, h * 0.65, w * 0.1, g); g.fill(); g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(-w * 0.45, -h * 0.55, w * 0.9, h * 0.05); }
      g.fillStyle = 'rgba(70,110,50,0.35)'; g.beginPath(); g.ellipse(-w * 0.2, -h * 0.1, w * 0.3, h * 0.12, 0, 0, TAU); g.fill();
      g.restore();
    }
    for (let i = 0; i < 5; i++) { const p = path((rnd() - 0.5) * 6, 4 + rnd() * 14), s = p.s * 0.06; g.fillStyle = '#d9d2b8'; g.beginPath(); g.ellipse(p.X, p.Y - s * 0.5, s, s * 0.85, 0, 0, TAU); g.fill(); g.fillStyle = '#18100c'; g.beginPath(); g.arc(p.X - s * 0.35, p.Y - s * 0.55, s * 0.22, 0, TAU); g.arc(p.X + s * 0.35, p.Y - s * 0.55, s * 0.22, 0, TAU); g.fill(); g.fillRect(p.X - s * 0.45, p.Y + s * 0.15, s * 0.9, s * 0.4); }
    // a burnt-out car, left
    { const p = path(-4.6, 9), s = p.s; g.fillStyle = '#0d0c10'; roundRect(p.X - s * 1.1, p.Y - s * 0.55, s * 2.2, s * 0.5, s * 0.15, g); g.fill(); g.beginPath(); g.moveTo(p.X - s * 0.6, p.Y - s * 0.55); g.lineTo(p.X - s * 0.35, p.Y - s * 0.95); g.lineTo(p.X + s * 0.45, p.Y - s * 0.95); g.lineTo(p.X + s * 0.8, p.Y - s * 0.55); g.fill(); g.fillStyle = '#05050a'; for (const wx of [-0.7, 0.7]) { g.beginPath(); g.arc(p.X + wx * s, p.Y - s * 0.05, s * 0.22, 0, TAU); g.fill(); } g.strokeStyle = 'rgba(255,255,255,0.12)'; g.lineWidth = 2; g.beginPath(); g.moveTo(p.X - s * 1.0, p.Y - s * 0.55); g.lineTo(p.X + s * 1.0, p.Y - s * 0.55); g.stroke(); }
    // twisted foreground trees framing the left and right edges
    g.strokeStyle = '#050304';
    for (const sd of [-1, 1]) { const x = sd < 0 ? W * 0.012 : W * 0.988; zTree(g, rnd, x, H * 0.84, H * 0.34, -Math.PI / 2 + sd * 0.12, H * 0.022, 5); }
    // horizon mist is drawn live (so it can drift)
  });
}

let ZVIG = null, ZGRAIN = null, zAmbOwner = null;
function zVignette(){
  return cachedLayer('zvig', g => {
    const gr = g.createRadialGradient(W / 2, H * 0.52, H * 0.35, W / 2, H * 0.52, W * 0.72); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.7, 'rgba(0,0,0,0.28)'); gr.addColorStop(1, 'rgba(0,0,0,0.72)'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
    const bt = g.createLinearGradient(0, H * 0.82, 0, H); bt.addColorStop(0, 'rgba(0,0,0,0)'); bt.addColorStop(1, 'rgba(0,0,0,0.4)'); g.fillStyle = bt; g.fillRect(0, H * 0.82, W, H * 0.18);
  });
}
function zGrainPattern(){
  if (ZGRAIN) return ZGRAIN;
  const c = document.createElement('canvas'); c.width = c.height = 160; const g = c.getContext('2d'), im = g.createImageData(160, 160);
  for (let i = 0; i < im.data.length; i += 4) { const v = Math.random() * 255; im.data[i] = im.data[i + 1] = im.data[i + 2] = v; im.data[i + 3] = 22; }
  g.putImageData(im, 0, 0); return ZGRAIN = ctx.createPattern(c, 'repeat');
}

function zBarricadeLayer(){
  return cachedLayer('zbarr', g => {
    const fy = H * 0.93, rnd = mulberry32(4242); g.lineJoin = 'round'; g.lineCap = 'round';
    // sandbag base
    const by = fy + H * 0.012, bh = H * 0.07;
    const gnd = g.createLinearGradient(0, fy, 0, H); gnd.addColorStop(0, '#1a1410'); gnd.addColorStop(1, '#0a0706'); g.fillStyle = gnd; g.fillRect(0, fy + H * 0.01, W, H);
    // posts and planks
    for (let x = W * 0.012; x < W; x += W * 0.06) {
      const ph = H * (0.095 + rnd() * 0.03), pw = W * 0.034, top = fy - ph + H * 0.03;
      const wg = g.createLinearGradient(x, 0, x + pw, 0); wg.addColorStop(0, '#8d6338'); wg.addColorStop(0.3, '#6d4a28'); wg.addColorStop(1, '#2f1e10');
      g.fillStyle = wg; g.beginPath(); g.moveTo(x, fy + H * 0.04); g.lineTo(x, top + H * 0.012); g.lineTo(x + pw * 0.3, top); g.lineTo(x + pw * 0.75, top + H * 0.008); g.lineTo(x + pw, top - H * 0.004); g.lineTo(x + pw, fy + H * 0.04); g.closePath(); g.fill();
      g.strokeStyle = 'rgba(0,0,0,0.45)'; g.lineWidth = 1.6; for (let k = 0; k < 6; k++) { const gx = x + pw * (0.12 + k * 0.15) + rnd() * 3; g.beginPath(); g.moveTo(gx, top + 4); g.bezierCurveTo(gx + 3, top + ph * 0.3, gx - 3, top + ph * 0.6, gx + 1, fy + H * 0.03); g.stroke(); }
      g.fillStyle = 'rgba(255,230,190,0.18)'; g.fillRect(x + 2, top + 3, pw * 0.12, ph);
      g.fillStyle = '#25282f'; for (const ny of [0.18, 0.62]) { g.beginPath(); g.arc(x + pw * 0.5, top + ph * ny, 3.2, 0, TAU); g.fill(); g.fillStyle = 'rgba(255,255,255,0.3)'; g.beginPath(); g.arc(x + pw * 0.5 - 1, top + ph * ny - 1, 1.1, 0, TAU); g.fill(); g.fillStyle = '#25282f'; }
    }
    // cross beam + metal band
    const bg = g.createLinearGradient(0, fy - H * 0.01, 0, fy + H * 0.03); bg.addColorStop(0, '#a3743f'); bg.addColorStop(0.5, '#6a4624'); bg.addColorStop(1, '#2a1a0c'); g.fillStyle = bg; g.fillRect(0, fy - H * 0.012, W, H * 0.038);
    g.fillStyle = 'rgba(255,255,255,0.16)'; g.fillRect(0, fy - H * 0.012, W, 2);
    const mt = g.createLinearGradient(0, fy + H * 0.018, 0, fy + H * 0.04); mt.addColorStop(0, '#6a7284'); mt.addColorStop(1, '#222632'); g.fillStyle = mt; g.fillRect(0, fy + H * 0.016, W, H * 0.014);
    // barbed wire coils
    g.strokeStyle = '#8c93a3'; g.lineWidth = 2.2; g.beginPath(); for (let x = -10; x < W + 30; x += 22) { const y = fy - H * 0.058 + Math.sin(x * 0.07) * H * 0.012; g.moveTo(x, y); g.bezierCurveTo(x + 8, y - H * 0.025, x + 16, y + H * 0.025, x + 22, y); } g.stroke();
    g.strokeStyle = '#d9dff0'; g.lineWidth = 1; g.stroke();
    g.strokeStyle = '#b8bfd0'; g.lineWidth = 2; for (let x = 8; x < W; x += 55) { const y = fy - H * 0.058 + Math.sin(x * 0.07) * H * 0.012; g.beginPath(); g.moveTo(x - 5, y - 5); g.lineTo(x + 5, y + 5); g.moveTo(x + 5, y - 5); g.lineTo(x - 5, y + 5); g.stroke(); }
    // hazard tape
    g.save(); g.beginPath(); g.rect(0, fy - H * 0.022, W, H * 0.011); g.clip(); g.fillStyle = '#e8b81f'; g.fillRect(0, fy - H * 0.022, W, H * 0.011); g.fillStyle = '#17120a'; for (let x = -20; x < W + 20; x += 30) { g.beginPath(); g.moveTo(x, fy - H * 0.011); g.lineTo(x + 10, fy - H * 0.011); g.lineTo(x + 24, fy - H * 0.022); g.lineTo(x + 14, fy - H * 0.022); g.fill(); } g.restore();
  });
}

/* ---------------- live world: weather, birds, lightning, fire ---------------- */
function zEnvInit(sc, env){
  sc.env = env; sc.wx = []; sc.birds = []; sc.birdT = rand(2, 6); sc.bolt = null; sc.flashSky = 0; sc.lightT = rand(5, 10); sc.ambT = rand(3, 6); sc.bedT = 0; sc.thunderQ = [];
  const n = env.weather === 'rain' ? 160 : env.weather === 'ash' ? 70 : env.weather === 'spores' ? 45 : env.weather === 'dust' ? 40 : 0;
  for (let i = 0; i < n; i++) sc.wx.push({ x:rand(0, W), y:rand(0, H), v:rand(0.6, 1.4), s:rand(0.5, 1.5), ph:rand(0, TAU) });
  sc.embers = []; if (env.fires || env.id === 'blood') for (let i = 0; i < 26; i++) sc.embers.push({ x:rand(0, W), y:rand(H * 0.3, H), v:rand(0.03, 0.09), s:rand(1, 2.6), ph:rand(0, TAU) });
}
function zEnvUpdate(sc, dt){
  const env = sc.env; if (!env) return;
  sc.envMix = Math.min(1, (sc.envMix ?? 1) + dt / 2.2); if (sc.envMix >= 1) sc.envPrev = null;
  sc.flashSky = Math.max(0, sc.flashSky - dt * 3);
  for (const p of sc.wx) {
    if (env.weather === 'rain') { p.y += H * 1.5 * p.v * dt; p.x -= H * 0.18 * p.v * dt; if (p.y > H) { p.y = -20; p.x = rand(0, W * 1.1); } }
    else if (env.weather === 'ash') { p.y += H * 0.07 * p.v * dt; p.x += Math.sin(sceneT * 0.8 + p.ph) * H * 0.03 * dt + H * 0.02 * dt; if (p.y > H) { p.y = -10; p.x = rand(0, W); } if (p.x > W) p.x = 0; }
    else if (env.weather === 'spores') { p.y -= H * 0.03 * p.v * dt; p.x += Math.sin(sceneT * 0.6 + p.ph) * H * 0.02 * dt; if (p.y < H * 0.3) { p.y = H + 10; p.x = rand(0, W); } }
    else if (env.weather === 'dust') { p.x += H * 0.04 * p.v * dt; p.y += Math.sin(sceneT * 0.5 + p.ph) * H * 0.01 * dt; if (p.x > W) p.x = 0; }
  }
  for (const e of sc.embers) { e.y -= H * e.v * dt; e.x += Math.sin(sceneT + e.ph) * H * 0.02 * dt; if (e.y < H * 0.25) { e.y = H * rand(0.9, 1.05); e.x = rand(0, W); } }
  // birds
  sc.birdT -= dt; if (env.birds && sc.birdT <= 0 && sc.birds.length < 4) { const dir = Math.random() < 0.5 ? 1 : -1; sc.birds.push({ x:dir > 0 ? -40 : W + 40, y:H * rand(0.08, 0.32), v:dir * H * rand(0.12, 0.2), ph:rand(0, TAU), s:H * rand(0.014, 0.026), bat:env.birds === 'bat', wob:rand(0, TAU) }); sc.birdT = rand(5, 12); }
  for (const b of sc.birds) { b.x += b.v * dt; b.y += Math.sin(sceneT * 1.3 + b.wob) * H * 0.02 * dt; } sc.birds = sc.birds.filter(b => b.x > -80 && b.x < W + 80);
  // lightning
  if (env.lightning) { sc.lightT -= dt; if (sc.lightT <= 0) { sc.lightT = rand(5, 13); zBolt(sc); } if (sc.bolt) { sc.bolt.t += dt; if (sc.bolt.t > 0.35) sc.bolt = null; } }
  for (const q of sc.thunderQ) q.t -= dt; while (sc.thunderQ.length && sc.thunderQ[0].t <= 0) { sc.thunderQ.shift(); zSnd.thunder(); }
}
function zBolt(sc){
  const HOR = H * 0.42, x0 = rand(W * 0.1, W * 0.9), pts = [[x0, 0]]; let x = x0, y = 0; while (y < HOR) { y += H * rand(0.03, 0.07); x += rand(-H * 0.05, H * 0.05); pts.push([x, y]); }
  const br = []; for (let i = 2; i < pts.length - 1; i += 2) if (Math.random() < 0.6) { const b = [pts[i]]; let bx = pts[i][0], by = pts[i][1]; for (let j = 0; j < 3; j++) { bx += rand(-H * 0.05, H * 0.09) * (Math.random() < 0.5 ? -1 : 1); by += H * rand(0.02, 0.05); b.push([bx, by]); } br.push(b); }
  sc.bolt = { pts, br, t:0 }; sc.flashSky = 1; sc.thunderQ.push({ t:rand(0.4, 2.2) });
  noise(0.08, 0.1, 'highpass', 4000);
}

function zBg(sc, env, alpha){
  ctx.globalAlpha = alpha;
  ctx.drawImage(zSkyLayer(env), 0, 0);
  // drifting clouds, two depths
  const t = sceneT;
  for (const [layer, sp, a] of [[0, 4, 0.9], [1, 9, 0.8]]) { const tile = zCloudTile(env, layer), ox = (t * sp * (H / 720)) % W, h = tile.height; ctx.globalAlpha = alpha * a; ctx.drawImage(tile, ox - W, H * 0.0, W, h); ctx.drawImage(tile, ox, H * 0.0, W, h); }
  ctx.globalAlpha = alpha;
  ctx.drawImage(zSceneryLayer(env), 0, 0);
  const HOR = H * 0.42;
  for (const [layer, sp, a, y] of [[0, 6, 0.9, HOR - H * 0.14], [1, -10, 0.7, HOR - H * 0.04]]) { const tile = zFogTile(env, layer), ox = (((t * sp * (H / 720)) % W) + W) % W; ctx.globalAlpha = alpha * a * env.fogA * 1.6; ctx.drawImage(tile, ox - W, y, W, tile.height); ctx.drawImage(tile, ox, y, W, tile.height); }
  ctx.globalAlpha = 1;
}

function zDrawBirds(sc){
  ctx.fillStyle = '#050206';
  for (const b of sc.birds) {
    const f = Math.sin(sceneT * (b.bat ? 12 : 8) + b.ph), s = b.s, dir = Math.sign(b.v) || 1;
    ctx.save(); ctx.translate(b.x, b.y); ctx.scale(dir, 1); ctx.beginPath();
    ctx.moveTo(-s * 0.2, 0); ctx.quadraticCurveTo(-s * 0.9, -s * (0.9 * f + 0.2), -s * 1.8, -s * (0.5 * f) + s * 0.2); ctx.quadraticCurveTo(-s * 0.9, -s * (0.35 * f) + s * 0.25, 0, s * 0.2);
    ctx.quadraticCurveTo(s * 0.9, -s * (0.35 * f) + s * 0.25, s * 1.8, -s * (0.5 * f) + s * 0.2); ctx.quadraticCurveTo(s * 0.9, -s * (0.9 * f + 0.2), s * 0.2, 0);
    ctx.quadraticCurveTo(s * 0.5, s * 0.15, s * 0.55, s * 0.05); ctx.closePath(); ctx.fill();
    ctx.restore();
  }
}
function zDrawBolt(sc){
  if (!sc.bolt) return; const k = 1 - sc.bolt.t / 0.35, fl = Math.sin(sc.bolt.t * 70) > -0.3 ? 1 : 0.3;
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const draw = (pts, w, a) => { ctx.beginPath(); pts.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.lineWidth = w; ctx.strokeStyle = `rgba(190,215,255,${a * k * fl})`; ctx.stroke(); };
  draw(sc.bolt.pts, H * 0.018, 0.35); draw(sc.bolt.pts, H * 0.006, 0.9); draw(sc.bolt.pts, H * 0.0025, 1); for (const b of sc.bolt.br) { draw(b, H * 0.004, 0.7); }
  ctx.restore();
}

function zDrawFires(sc, env){
  // burning barrels either side of the field
  for (const [x, z] of [[-2.75, 7.5], [2.75, 6.5]]) {
    const p = zProj(x, z), s = p.s * 0.55, fl = 0.8 + 0.2 * Math.sin(sceneT * 11 + x * 3) * Math.sin(sceneT * 7.3 + z), col = env.flame;
    ctx.globalCompositeOperation = 'lighter'; const gr = ctx.createRadialGradient(p.X, p.Y - s * 0.6, 0, p.X, p.Y - s * 0.6, s * 5); gr.addColorStop(0, `rgba(${col},${0.35 * fl})`); gr.addColorStop(1, `rgba(${col},0)`); ctx.fillStyle = gr; ctx.fillRect(p.X - s * 5, p.Y - s * 5.6, s * 10, s * 10);
    const gg = ctx.createRadialGradient(p.X, p.Y, 0, p.X, p.Y, s * 3); gg.addColorStop(0, `rgba(${col},${0.22 * fl})`); gg.addColorStop(1, `rgba(${col},0)`); ctx.save(); ctx.translate(p.X, p.Y); ctx.scale(1, 0.25); ctx.translate(-p.X, -p.Y); ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(p.X, p.Y, s * 3, 0, TAU); ctx.fill(); ctx.restore();
    ctx.globalCompositeOperation = 'source-over';
    const bg = ctx.createLinearGradient(p.X - s * 0.5, 0, p.X + s * 0.5, 0); bg.addColorStop(0, '#5c4a3a'); bg.addColorStop(0.5, '#2e241c'); bg.addColorStop(1, '#0d0907');
    ctx.fillStyle = bg; roundRect(p.X - s * 0.5, p.Y - s * 1.0, s, s * 1.0, s * 0.08); ctx.fill(); ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(p.X - s * 0.5, p.Y - s * 0.7, s, s * 0.06); ctx.fillRect(p.X - s * 0.5, p.Y - s * 0.3, s, s * 0.06);
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 4; i++) { const w = s * (0.55 - i * 0.1), hh = s * (1.0 + 0.5 * Math.sin(sceneT * (9 + i * 3) + i + x) * 0.3 + (3 - i) * 0.2), sway = Math.sin(sceneT * (6 + i) + i) * s * 0.1;
      const fg = ctx.createLinearGradient(0, p.Y - s * 1.0, 0, p.Y - s * 1.0 - hh); fg.addColorStop(0, `rgba(${col},0.9)`); fg.addColorStop(0.5, i < 2 ? 'rgba(255,200,80,0.7)' : 'rgba(255,255,200,0.7)'); fg.addColorStop(1, 'rgba(255,120,20,0)');
      ctx.fillStyle = fg; ctx.beginPath(); ctx.moveTo(p.X - w / 2, p.Y - s * 1.0); ctx.quadraticCurveTo(p.X - w * 0.6 + sway, p.Y - s * 1.0 - hh * 0.5, p.X + sway, p.Y - s * 1.0 - hh); ctx.quadraticCurveTo(p.X + w * 0.6 + sway, p.Y - s * 1.0 - hh * 0.5, p.X + w / 2, p.Y - s * 1.0); ctx.closePath(); ctx.fill(); }
    ctx.globalCompositeOperation = 'source-over';
  }
  if (env.fires) {   // far city fires flicker on the horizon
    ctx.globalCompositeOperation = 'lighter'; const HOR = H * 0.42;
    for (const fx of [0.12, 0.31, 0.55, 0.83]) { const fl = 0.7 + 0.3 * Math.sin(sceneT * 6 + fx * 40), gr = ctx.createRadialGradient(W * fx, HOR - H * 0.02, 0, W * fx, HOR - H * 0.02, H * 0.13); gr.addColorStop(0, `rgba(255,150,50,${0.55 * fl})`); gr.addColorStop(1, 'rgba(255,100,20,0)'); ctx.fillStyle = gr; ctx.fillRect(W * fx - H * 0.13, HOR - H * 0.15, H * 0.26, H * 0.26); }
    ctx.globalCompositeOperation = 'source-over';
  }
}
function zDrawWeather(sc, env){
  if (env.weather === 'rain') { ctx.strokeStyle = 'rgba(190,215,240,0.32)'; ctx.lineWidth = Math.max(1, H * 0.0017); ctx.beginPath(); for (const p of sc.wx) { ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + H * 0.014 * p.s, p.y - H * 0.05 * p.s); } ctx.stroke(); }
  else if (env.weather === 'ash') { for (const p of sc.wx) { ctx.fillStyle = p.s > 1 ? 'rgba(255,150,70,0.8)' : 'rgba(190,180,170,0.55)'; ctx.fillRect(p.x, p.y, H * 0.004 * p.s + 1, H * 0.004 * p.s + 1); } }
  else if (env.weather === 'spores') { ctx.globalCompositeOperation = 'lighter'; for (const p of sc.wx) { const a = 0.35 + 0.35 * Math.sin(sceneT * 2 + p.ph), r = H * 0.006 * p.s; const gr = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r * 3); gr.addColorStop(0, `rgba(190,255,90,${a})`); gr.addColorStop(1, 'rgba(190,255,90,0)'); ctx.fillStyle = gr; ctx.fillRect(p.x - r * 3, p.y - r * 3, r * 6, r * 6); } ctx.globalCompositeOperation = 'source-over'; }
  else if (env.weather === 'dust') { ctx.fillStyle = 'rgba(225,230,245,0.35)'; for (const p of sc.wx) ctx.fillRect(p.x, p.y, H * 0.003 * p.s + 1, H * 0.003 * p.s + 1); }
  if (sc.embers.length) { ctx.globalCompositeOperation = 'lighter'; for (const e of sc.embers) { const a = 0.4 + 0.4 * Math.sin(sceneT * 5 + e.ph); ctx.fillStyle = `rgba(255,${120 + (e.s * 30) | 0},40,${a})`; ctx.fillRect(e.x, e.y, e.s, e.s); } ctx.globalCompositeOperation = 'source-over'; }
}

/* ======================= SOUND ======================= */
function zNoiseBurst(dur, vol, type, f0, o = {}){
  if (!audioOk() || !noiseBuf) return;
  const t = actx.currentTime + (o.delay || 0), s = actx.createBufferSource(), f = actx.createBiquadFilter(), g = actx.createGain();
  s.buffer = noiseBuf; s.loop = true; f.type = type; f.frequency.setValueAtTime(f0, t); if (o.to) f.frequency.exponentialRampToValueAtTime(o.to, t + dur); f.Q.value = o.q || 0.7;
  const att = o.att ?? 0.01; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + att); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
  let node = s.connect(f).connect(g); if (o.pan != null && actx.createStereoPanner) { const p = actx.createStereoPanner(); p.pan.value = o.pan; node = node.connect(p); } node.connect(actx.destination);
  s.start(t, Math.random()); s.stop(t + dur + 0.05);
}
function zTone(freq, dur, type, vol, o = {}){
  if (!audioOk()) return;
  const t = actx.currentTime + (o.delay || 0), osc = actx.createOscillator(), g = actx.createGain(); osc.type = type; osc.frequency.setValueAtTime(freq, t);
  if (o.path) o.path.forEach(([k, f]) => osc.frequency.linearRampToValueAtTime(f, t + dur * k)); else if (o.to) osc.frequency.exponentialRampToValueAtTime(o.to, t + dur);
  const att = o.att ?? 0.01; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + att); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
  let node = osc; if (o.filt) { const f = actx.createBiquadFilter(); f.type = o.filt[0]; f.frequency.value = o.filt[1]; f.Q.value = o.filt[2] || 1; node = node.connect(f); }
  node = node.connect(g); if (o.pan != null && actx.createStereoPanner) { const p = actx.createStereoPanner(); p.pan.value = o.pan; node = node.connect(p); } node.connect(actx.destination);
  if (o.vib) { const l = actx.createOscillator(), lg = actx.createGain(); l.frequency.value = o.vib[1]; lg.gain.value = o.vib[0]; l.connect(lg).connect(osc.frequency); l.start(t); l.stop(t + dur + 0.05); }
  osc.start(t); osc.stop(t + dur + 0.05);
}
// a throat: sawtooth through two vocal formants, with vibrato, a wet rasp and a pitch fall
function zVoice(f0, dur, vol, o = {}){
  if (!audioOk() || !noiseBuf) return;
  const t = actx.currentTime + (o.delay || 0), osc = actx.createOscillator(), g = actx.createGain(), mix = actx.createGain();
  osc.type = 'sawtooth'; osc.frequency.setValueAtTime(f0, t); osc.frequency.linearRampToValueAtTime(o.to || f0 * 0.7, t + dur);
  const f1 = actx.createBiquadFilter(), f2 = actx.createBiquadFilter(); f1.type = f2.type = 'bandpass'; f1.Q.value = 5; f2.Q.value = 7;
  f1.frequency.setValueAtTime(o.a1 || 650, t); f1.frequency.linearRampToValueAtTime(o.b1 || 380, t + dur); f2.frequency.setValueAtTime(o.a2 || 1100, t); f2.frequency.linearRampToValueAtTime(o.b2 || 800, t + dur);
  osc.connect(f1); osc.connect(f2); f1.connect(mix); f2.connect(mix);
  const l = actx.createOscillator(), lg = actx.createGain(); l.frequency.value = o.vr || 6; lg.gain.value = (o.vd ?? 0.035) * f0; l.connect(lg).connect(osc.frequency); l.start(t); l.stop(t + dur + 0.05);
  // amplitude wobble for a wet gurgle
  if (o.am) { const al = actx.createOscillator(), ag = actx.createGain(); al.frequency.value = o.am; ag.gain.value = 0.45; al.connect(ag).connect(mix.gain); mix.gain.value = 0.55; al.start(t); al.stop(t + dur + 0.05); } else mix.gain.value = 1;
  const att = o.att ?? 0.08; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + att); g.gain.linearRampToValueAtTime(vol * 0.7, t + dur * 0.6); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
  let node = mix.connect(g); if (o.lp) { const lp = actx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = o.lp; node = g.connect(lp); }
  if (o.pan != null && actx.createStereoPanner) { const p = actx.createStereoPanner(); p.pan.value = o.pan; node = node.connect(p); } node.connect(actx.destination);
  osc.start(t); osc.stop(t + dur + 0.05);
  if (o.rasp) { const s = actx.createBufferSource(), nf = actx.createBiquadFilter(), ng = actx.createGain(); s.buffer = noiseBuf; s.loop = true; nf.type = 'bandpass'; nf.frequency.value = o.rf || 1400; nf.Q.value = 1.4; ng.gain.setValueAtTime(0.0001, t); ng.gain.linearRampToValueAtTime(vol * o.rasp, t + att); ng.gain.exponentialRampToValueAtTime(0.0008, t + dur); let n2 = s.connect(nf).connect(ng); if (o.pan != null && actx.createStereoPanner) { const p = actx.createStereoPanner(); p.pan.value = o.pan; n2 = n2.connect(p); } n2.connect(actx.destination); s.start(t, Math.random()); s.stop(t + dur + 0.05); }
}

const zSnd = {
  // one zombie clears its throat. kind depends on its type, pan on where it is, loudness on how close
  grunt(z, big){
    const type = z ? z.type : 'walker', pan = z && z.box ? clamp((z.box.x - W / 2) / (W / 2), -1, 1) : 0, near = z ? clamp(1 - (z.z - 1) / (Z_SPAWN + 2), 0.25, 1) : 0.7, v = 0.07 * (0.45 + 0.7 * near);
    const roll = Math.random();
    switch (type) {
      case 'boss': zVoice(48, 1.9, v * 2.1, { to:32, a1:420, b1:220, a2:760, b2:420, vr:4, vd:0.05, rasp:0.9, rf:500, pan, att:0.15, lp:2000 }); zVoice(96, 1.6, v * 1.1, { to:55, vr:7, rasp:0.5, pan, att:0.1, delay:0.05 }); break;
      case 'brute': zVoice(rand(58, 72), 1.2, v * 1.5, { to:40, a1:500, b1:260, vr:5, rasp:0.7, rf:700, pan, att:0.1, lp:2500 }); break;
      case 'runner': if (roll < 0.5) zVoice(rand(150, 190), 0.38, v * 1.1, { to:110, a1:900, b1:600, a2:1500, b2:1100, vr:14, rasp:1.1, rf:1800, pan, att:0.03 }); else { zVoice(rand(160, 210), 0.3, v, { to:120, vr:16, rasp:1.0, rf:2000, pan, att:0.02 }); zVoice(rand(150, 200), 0.3, v * 0.9, { to:100, vr:16, rasp:1.0, rf:2000, pan, att:0.02, delay:0.38 }); } break;
      case 'crawler': zNoiseBurst(0.55, v * 1.6, 'bandpass', 3200, { to:4800, q:3, att:0.05, pan }); zTone(rand(420, 520), 0.4, 'sawtooth', v * 0.5, { path:[[0.3, 640], [1, 300]], vib:[18, 22], filt:['bandpass', 1800, 2], pan, att:0.04 }); break;
      case 'spitter': zVoice(rand(80, 105), 0.9, v * 1.2, { to:62, a1:500, b1:330, vr:16, vd:0.06, am:14, rasp:0.8, rf:900, pan, att:0.08, lp:1800 }); break;
      case 'bloater': zVoice(rand(50, 66), 1.1, v * 1.3, { to:40, a1:380, b1:240, vr:5, am:9, rasp:0.8, rf:600, pan, att:0.12, lp:900 }); zNoiseBurst(0.4, v * 0.7, 'lowpass', 400, { delay:0.5, pan }); break;
      case 'armored': zVoice(rand(80, 100), 0.9, v * 0.9, { to:58, vr:5, rasp:0.4, pan, att:0.1, lp:700 }); break;
      default: {   // classic moan: rise, then fall
        if (roll < 0.55) zVoice(rand(88, 120), rand(0.9, 1.3), v, { to:rand(55, 72), a1:rand(560, 720), b1:360, a2:1050, b2:760, vr:rand(4.5, 6.5), rasp:0.45, rf:1100, pan, att:0.22 });
        else if (roll < 0.8) { zVoice(rand(100, 130), 0.5, v * 1.1, { to:70, vr:11, rasp:0.9, rf:1300, pan, att:0.05 }); zVoice(rand(90, 120), 0.6, v, { to:55, vr:9, rasp:0.8, pan, att:0.05, delay:0.5 }); }
        else zVoice(rand(70, 90), 1.5, v * 1.2, { to:50, a1:430, b1:300, vr:4, rasp:0.6, rf:800, pan, att:0.3, lp:1500 });
      }
    }
  },
  snarl(z){ const pan = z && z.box ? clamp((z.box.x - W / 2) / (W / 2), -1, 1) : 0; zVoice(rand(110, 150), 0.35, 0.06, { to:80, vr:15, rasp:1.1, rf:1600, pan, att:0.02 }); },
  hit(z){ const pan = z && z.box ? clamp((z.box.x - W / 2) / (W / 2), -1, 1) : 0; zNoiseBurst(0.1, 0.18, 'lowpass', 900, { att:0.002, pan }); zTone(rand(150, 190), 0.09, 'sine', 0.12, { to:70, att:0.002, pan }); },
  die(z){ const pan = z && z.box ? clamp((z.box.x - W / 2) / (W / 2), -1, 1) : 0, big = z && (z.type === 'brute' || z.type === 'boss' || z.type === 'bloater'); zVoice(big ? 70 : rand(100, 135), big ? 1.1 : 0.7, 0.075, { to:big ? 36 : 45, a1:650, b1:240, vr:7, rasp:0.8, rf:900, pan, att:0.02, lp:2200 }); zNoiseBurst(0.35, 0.2, 'lowpass', 520, { att:0.004, pan }); zTone(big ? 80 : 130, 0.35, 'sine', 0.14, { to:40, att:0.003, pan, delay:0.12 }); zNoiseBurst(0.3, 0.07, 'bandpass', 1400, { to:500, q:2, delay:0.1, pan }); },
  shot(k){ const p = k === 0 ? -0.18 : k === 1 ? 0.18 : 0; zNoiseBurst(0.07, 0.24, 'highpass', k ? 2800 : 2200, { att:0.001, pan:p }); zNoiseBurst(0.2, 0.15, 'lowpass', k ? 900 : 650, { att:0.002, pan:p }); zTone(k ? 210 : 165, 0.13, 'sine', 0.2, { to:42, att:0.001, pan:p }); zTone(k ? 1700 : 1350, 0.04, 'square', 0.025, { to:300, att:0.001, pan:p }); zNoiseBurst(0.4, 0.05, 'bandpass', 800, { delay:0.07, q:0.8, pan:p }); if (Math.random() < 0.5) zTone(rand(3800, 5200), 0.07, 'triangle', 0.014, { delay:rand(0.18, 0.3), pan:-p }); },
  hurt(){ zNoiseBurst(0.3, 0.38, 'lowpass', 420, { att:0.003 }); zTone(95, 0.3, 'sine', 0.2, { to:40, att:0.003 }); zNoiseBurst(0.18, 0.2, 'bandpass', 1800, { to:700, q:1.5, att:0.002 }); for (let i = 0; i < 3; i++) zTone(rand(500, 900), 0.05, 'square', 0.02, { delay:0.04 + i * 0.05, to:200 }); },
  grenade(){ zNoiseBurst(1.8, 0.55, 'lowpass', 500, { to:80, att:0.005 }); zTone(70, 1.1, 'sine', 0.4, { to:24, att:0.003 }); zNoiseBurst(0.3, 0.3, 'highpass', 3000, { att:0.001 }); zTone(2400, 1.6, 'sine', 0.025, { to:2000, att:0.05, delay:0.15 }); zNoiseBurst(2.4, 0.18, 'lowpass', 220, { delay:0.4, att:0.3 }); },
  medkit(){ [523, 659, 784, 1046, 1318].forEach((f, i) => zTone(f, 0.45, 'sine', 0.07, { delay:i * 0.07, att:0.01 })); zTone(130, 0.5, 'triangle', 0.08, { to:260 }); },
  boost(){ zTone(220, 0.9, 'sawtooth', 0.07, { to:880, att:0.02, filt:['lowpass', 1800, 1] }); zTone(440, 0.9, 'square', 0.04, { to:1760, att:0.02 }); zNoiseBurst(0.7, 0.15, 'highpass', 1500, { to:7000, att:0.3 }); [880, 1320, 1760].forEach((f, i) => zTone(f, 0.3, 'triangle', 0.06, { delay:0.55 + i * 0.07 })); },
  boostAppear(){ zTone(740, 0.12, 'sine', 0.07, { att:0.005 }); zTone(1110, 0.3, 'sine', 0.07, { delay:0.12, att:0.005 }); zNoiseBurst(0.4, 0.05, 'highpass', 5000, { att:0.1 }); },
  thunder(){ zNoiseBurst(0.3, 0.25, 'highpass', 1400, { att:0.002 }); zNoiseBurst(3.4, 0.5, 'lowpass', 260, { to:70, att:0.08, q:0.9 }); zTone(55, 2.6, 'sine', 0.2, { to:30, att:0.1 }); zNoiseBurst(2.4, 0.22, 'lowpass', 150, { delay:0.9, att:0.4 }); },
  wolf(){ const p = rand(-0.8, 0.8), f = rand(300, 380); zTone(f, 3.6, 'triangle', 0.035, { path:[[0.2, f * 1.45], [0.55, f * 1.7], [1, f * 1.1]], vib:[9, 5.2], filt:['lowpass', 1800, 0.8], att:0.7, pan:p }); zTone(f * 2, 3.6, 'sine', 0.012, { path:[[0.2, f * 2.9], [0.55, f * 3.4], [1, f * 2.2]], vib:[14, 5.2], att:0.9, pan:p }); },
  crow(){ const p = rand(-0.9, 0.9), n = 2 + (Math.random() * 3 | 0); for (let i = 0; i < n; i++) { const f = rand(480, 620); zTone(f, 0.24, 'sawtooth', 0.026, { path:[[0.2, f * 1.1], [1, f * 0.62]], filt:['bandpass', 1500, 1.6], delay:i * 0.38, att:0.015, pan:p }); zNoiseBurst(0.2, 0.025, 'bandpass', 1700, { delay:i * 0.38, q:2, att:0.01, pan:p }); } },
  owl(){ const p = rand(-0.8, 0.8); zTone(350, 0.45, 'sine', 0.05, { path:[[0.15, 380], [1, 300]], att:0.06, pan:p, vib:[4, 7] }); zTone(310, 0.7, 'sine', 0.05, { path:[[0.15, 330], [1, 250]], att:0.06, delay:0.6, pan:p, vib:[4, 7] }); },
  bell(){ const p = rand(-0.7, 0.7); for (let n = 0; n < 3; n++) for (const [m, a] of [[1, 1], [2.4, 0.5], [3.1, 0.3], [4.2, 0.2]]) zTone(196 * m, 3.4, 'sine', 0.03 * a, { delay:n * 2.2, att:0.005, pan:p }); },
  siren(){ const p = rand(-0.9, 0.9); zTone(560, 4.2, 'sawtooth', 0.016, { path:[[0.25, 820], [0.5, 560], [0.75, 820], [1, 540]], filt:['lowpass', 1400, 1], att:0.6, pan:p }); },
  bubble(){ const p = rand(-0.8, 0.8); for (let i = 0; i < 5; i++) zTone(rand(180, 420), 0.09, 'sine', 0.04, { to:rand(500, 900), delay:i * rand(0.12, 0.35), att:0.004, pan:p }); },
  cricket(){ const p = rand(-0.9, 0.9), f = rand(4100, 4500); for (let i = 0; i < 12; i++) zTone(f, 0.03, 'sine', 0.011, { delay:(i % 4) * 0.045 + (i / 4 | 0) * 0.32, att:0.004, pan:p }); },
  whisper(){ const p = rand(-0.9, 0.9); zNoiseBurst(1.8, 0.05, 'bandpass', 2400, { to:3400, q:8, att:0.7, pan:p }); zNoiseBurst(1.8, 0.04, 'bandpass', 1500, { to:1000, q:6, att:0.8, pan:-p, delay:0.3 }); },
  drone(){ zTone(55, 5.5, 'sawtooth', 0.03, { att:2, filt:['lowpass', 260, 1] }); zTone(55.8, 5.5, 'sawtooth', 0.03, { att:2, filt:['lowpass', 260, 1] }); },
  wind(){ const p = rand(-0.8, 0.8); zNoiseBurst(4.2, 0.07, 'bandpass', 260, { to:900, q:1.3, att:1.6, pan:p }); },
  fire(){ for (let i = 0; i < 7; i++) zNoiseBurst(0.05, 0.05, 'highpass', 3000, { delay:i * rand(0.07, 0.3), att:0.002, pan:rand(-0.8, 0.8) }); },
};

// replace the old thin sound effects
SFX.shot = k => zSnd.shot(k);
SFX.zhit = () => zSnd.hit();
SFX.zdie = () => zSnd.die();
SFX.groan = () => zSnd.grunt(null);
SFX.hurt = () => zSnd.hurt();
SFX.grenade = () => zSnd.grenade();
SFX.medkit = () => zSnd.medkit();
if (typeof SFX.boost === 'function') SFX.boost = () => zSnd.boost();
if (typeof SFX.boostAppear === 'function') SFX.boostAppear = () => zSnd.boostAppear();

// the living soundscape: a quiet bed plus random one-shots that suit the current mood
function zAmbience(sc, dt){
  const env = sc.env; if (!env || !audioOk()) return;
  sc.bedT -= dt;
  if (sc.bedT <= 0) {
    if (env.bed === 'rain') { zNoiseBurst(2.0, 0.045, 'highpass', 2600, { att:0.6, q:0.4 }); zNoiseBurst(2.0, 0.03, 'bandpass', 900, { att:0.6, q:0.5 }); sc.bedT = 1.5; }
    else if (env.bed === 'wind') { zNoiseBurst(3.2, 0.03, 'bandpass', 320, { to:640, q:1.1, att:1.1 }); sc.bedT = 2.7; }
    else if (env.bed === 'fire') { zNoiseBurst(2.2, 0.03, 'lowpass', 600, { att:0.7 }); for (let i = 0; i < 4; i++) zNoiseBurst(0.04, 0.05, 'highpass', 3200, { delay:rand(0, 2), att:0.001, pan:rand(-0.7, 0.7) }); sc.bedT = 1.9; }
    else if (env.bed === 'drone') { zTone(48, 4, 'sawtooth', 0.016, { att:1.5, filt:['lowpass', 200, 1] }); zTone(48.6, 4, 'sawtooth', 0.016, { att:1.5, filt:['lowpass', 200, 1] }); sc.bedT = 3.4; }
    else sc.bedT = 3;
  }
  sc.ambT -= dt;
  if (sc.ambT <= 0) { sc.ambT = rand(5, 11); const k = pick(env.amb); if (zSnd[k]) zSnd[k](); }
}
