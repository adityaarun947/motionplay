/* =====================================================================
   FRUIT SLASH
   ===================================================================== */
const FRUITS = [
  { name:'watermelon', r:0.075, outer:'#2f9e44', inner:'#ff4d5e', seed:'#1b1b1b', stripe:'#1e6b2d' },
  { name:'orange', r:0.056, outer:'#ff9a1f', inner:'#ffc66b' },
  { name:'apple', r:0.052, outer:'#e3263a', inner:'#fff1c9', seed:'#5a3a1a' },
  { name:'kiwi', r:0.047, outer:'#8a6a3b', inner:'#8bd13c', seed:'#111' },
  { name:'lemon', r:0.05, outer:'#ffe14a', inner:'#fff6b0' },
  { name:'plum', r:0.045, outer:'#7b3fa0', inner:'#ffcf6b' },
  { name:'coconut', r:0.058, outer:'#7a4f2a', inner:'#fffaf0' },
  { name:'banana', r:0.06, outer:'#ffe14a', inner:'#fff3b0' },
  { name:'strawberry', r:0.046, outer:'#ec2f4b', inner:'#ffb3bd' },
  { name:'pineapple', r:0.062, outer:'#f2b227', inner:'#fff0a0' },
  { name:'grapes', r:0.05, outer:'#7a3fb0', inner:'#d9b3ff' },
  { name:'dragonfruit', r:0.058, outer:'#f0368f', inner:'#fff4fa', seed:'#1b1b1b' },
];
const ICE = { name:'ice', r:0.055, outer:'#8fdcff', inner:'#e8f8ff', special:'ice' };
const GOLD = { name:'star', r:0.058, outer:'#ffd23f', inner:'#fff3a8', special:'gold' };
const HEART = { name:'heart', r:0.056, outer:'#ff3b6b', inner:'#ffd1de', special:'heart' };
const FRENZY = { name:'bolt', r:0.056, outer:'#a65bff', inner:'#e6d0ff', special:'frenzy' };
const GIANT = { name:'giant', r:0.14, outer:'#2f9e44', inner:'#ff4d5e', seed:'#1b1b1b', stripe:'#1e6b2d', special:'giant' };
// half: 0 = whole fruit, 1 / -1 = one half seen from the cut side
function drawFruit(f, r, half, t = 0){
  if (half) {
    ctx.save(); ctx.beginPath(); ctx.rect(-r * 1.3, half > 0 ? 0 : -r * 1.3, r * 2.6, r * 1.3); ctx.clip();
    // rind
    ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fillStyle = f.outer; ctx.fill();
    const rind = ctx.createRadialGradient(0, 0, r * 0.7, 0, 0, r); rind.addColorStop(0, 'rgba(0,0,0,0)'); rind.addColorStop(1, 'rgba(0,0,0,0.28)');
    ctx.fillStyle = rind; ctx.fill();
    // juicy flesh with a glossy centre
    ctx.beginPath(); ctx.arc(0, 0, r * 0.84, 0, TAU);
    const fl = ctx.createRadialGradient(-r * 0.15, -r * 0.15, r * 0.05, 0, 0, r * 0.86); fl.addColorStop(0, '#ffffff55'); fl.addColorStop(0.35, f.inner); fl.addColorStop(1, f.inner);
    ctx.fillStyle = f.inner; ctx.fill(); ctx.fillStyle = fl; ctx.fill();
    // citrus segments
    if (f.name === 'orange' || f.name === 'lemon') {
      ctx.save(); ctx.beginPath(); ctx.arc(0, 0, r * 0.8, 0, TAU); ctx.clip();
      ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = r * 0.05;
      for (let i = 0; i < 8; i++) { const a = i / 8 * TAU + 0.2; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); ctx.stroke(); }
      ctx.fillStyle = f.outer; ctx.globalAlpha = 0.35; for (let i = 0; i < 8; i++) { const a = (i + 0.5) / 8 * TAU + 0.2; ctx.beginPath(); ctx.arc(Math.cos(a) * r * 0.35, Math.sin(a) * r * 0.35, r * 0.04, 0, TAU); ctx.fill(); } ctx.globalAlpha = 1;
      ctx.restore();
    }
    // watermelon: pale rind ring between red flesh and green skin
    if (f.name === 'watermelon') { ctx.beginPath(); ctx.arc(0, 0, r * 0.9, 0, TAU); ctx.lineWidth = r * 0.06; ctx.strokeStyle = '#d9f5c4'; ctx.stroke(); }
    if (f.seed) { ctx.fillStyle = f.seed; for (let i = 0; i < 7; i++) { const a = i / 7 * TAU; ctx.beginPath(); ctx.ellipse(Math.cos(a) * r * 0.45, Math.sin(a) * r * 0.45, r * 0.06, r * 0.1, a, 0, TAU); ctx.fill(); } }
    // juice beads on the cut edge
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(Math.cos(i * 2.1) * r * 0.82, Math.sin(i * 2.1) * r * 0.82, r * 0.05, 0, TAU); ctx.fill(); }
    ctx.restore(); return;
  }
  if (f.special === 'gold') {     // star fruit
    ctx.beginPath();
    for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.5 : r * 1.15; ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
    ctx.closePath(); ctx.fillStyle = f.outer; ctx.fill(); ctx.lineWidth = r * 0.08; ctx.strokeStyle = '#e0a400'; ctx.stroke();
    ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.25 + 0.15 * Math.sin(t * 8);
    ctx.beginPath(); ctx.arc(0, 0, r * 1.5, 0, TAU); ctx.fillStyle = '#ffd23f'; ctx.fill();
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; return;
  }
  if (f.special === 'heart' || f.special === 'frenzy') {
    ctx.beginPath(); ctx.arc(0, 0, r * 1.05, 0, TAU); ctx.fillStyle = f.outer; ctx.fill(); ctx.lineWidth = r * 0.08; ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.beginPath();
    if (f.special === 'heart') { ctx.moveTo(0, r * 0.5); ctx.bezierCurveTo(-r * 0.95, -r * 0.1, -r * 0.5, -r * 0.7, 0, -r * 0.25); ctx.bezierCurveTo(r * 0.5, -r * 0.7, r * 0.95, -r * 0.1, 0, r * 0.5); }
    else { ctx.moveTo(r * 0.15, -r * 0.7); ctx.lineTo(-r * 0.45, r * 0.1); ctx.lineTo(-r * 0.05, r * 0.1); ctx.lineTo(-r * 0.2, r * 0.7); ctx.lineTo(r * 0.45, -r * 0.15); ctx.lineTo(r * 0.05, -r * 0.15); }
    ctx.closePath(); ctx.fill();
    ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.25 + 0.15 * Math.sin(t * 8); ctx.beginPath(); ctx.arc(0, 0, r * 1.6, 0, TAU); ctx.fillStyle = f.outer; ctx.fill(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; return;
  }
  if (f.name === 'banana') {
    ctx.lineCap = 'round'; ctx.strokeStyle = '#c99a1a'; ctx.lineWidth = r * 0.62; ctx.beginPath(); ctx.arc(0, -r * 0.55, r * 1.15, Math.PI * 0.18, Math.PI * 0.82); ctx.stroke();
    ctx.strokeStyle = f.outer; ctx.lineWidth = r * 0.5; ctx.beginPath(); ctx.arc(0, -r * 0.55, r * 1.15, Math.PI * 0.18, Math.PI * 0.82); ctx.stroke();
    ctx.strokeStyle = '#6b4a1a'; ctx.lineWidth = r * 0.2; ctx.beginPath(); ctx.moveTo(-r * 1.0, r * 0.52); ctx.lineTo(-r * 1.12, r * 0.4); ctx.moveTo(r * 1.0, r * 0.52); ctx.lineTo(r * 1.1, r * 0.4); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = r * 0.1; ctx.beginPath(); ctx.arc(0, -r * 0.55, r * 1.25, Math.PI * 0.3, Math.PI * 0.6); ctx.stroke(); return;
  }
  if (f.name === 'strawberry') {
    ctx.beginPath(); ctx.moveTo(0, r * 1.05); ctx.bezierCurveTo(-r * 1.25, r * 0.2, -r * 1.05, -r * 0.95, 0, -r * 0.8); ctx.bezierCurveTo(r * 1.05, -r * 0.95, r * 1.25, r * 0.2, 0, r * 1.05); ctx.fillStyle = f.outer; ctx.fill();
    ctx.fillStyle = '#ffe9a0'; for (let i = 0; i < 9; i++) { const a = i * 2.4, rr = (0.2 + (i % 3) * 0.2) * r; ctx.beginPath(); ctx.ellipse(Math.cos(a) * rr, Math.sin(a) * rr * 1.1 + r * 0.1, r * 0.04, r * 0.07, 0, 0, TAU); ctx.fill(); }
    ctx.fillStyle = '#3cbf4a'; ctx.beginPath(); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i - 2) * 0.55; ctx.moveTo(0, -r * 0.8); ctx.lineTo(Math.cos(a) * r * 0.75, -r * 0.8 + Math.sin(a) * r * 0.45 + r * 0.1); ctx.lineTo(Math.cos(a + 0.25) * r * 0.3, -r * 0.8 + Math.sin(a + 0.25) * r * 0.15); } ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.beginPath(); ctx.ellipse(-r * 0.4, -r * 0.2, r * 0.18, r * 0.3, 0.3, 0, TAU); ctx.fill(); return;
  }
  if (f.name === 'pineapple') {
    ctx.fillStyle = '#2f9e44'; ctx.beginPath(); for (let i = 0; i < 7; i++) { const a = -Math.PI / 2 + (i - 3) * 0.28; ctx.moveTo(0, -r * 0.8); ctx.lineTo(Math.cos(a) * r * 0.95, -r * 0.8 + Math.sin(a) * r * 0.95 - r * 0.2); ctx.lineTo(Math.cos(a + 0.12) * r * 0.2, -r * 0.8); } ctx.fill();
    ctx.beginPath(); ctx.ellipse(0, r * 0.15, r * 0.78, r * 0.98, 0, 0, TAU); ctx.fillStyle = f.outer; ctx.fill();
    ctx.save(); ctx.clip(); ctx.strokeStyle = '#b07a12'; ctx.lineWidth = r * 0.07; for (let i = -4; i <= 4; i++) { ctx.beginPath(); ctx.moveTo(i * r * 0.3 - r * 1.2, -r); ctx.lineTo(i * r * 0.3 + r * 1.2, r * 1.4); ctx.moveTo(i * r * 0.3 + r * 1.2, -r); ctx.lineTo(i * r * 0.3 - r * 1.2, r * 1.4); ctx.stroke(); } ctx.restore();
    ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.beginPath(); ctx.ellipse(-r * 0.3, -r * 0.1, r * 0.14, r * 0.35, 0.2, 0, TAU); ctx.fill(); return;
  }
  if (f.name === 'grapes') {
    ctx.fillStyle = '#3cbf4a'; ctx.beginPath(); ctx.ellipse(r * 0.25, -r * 1.1, r * 0.4, r * 0.18, -0.5, 0, TAU); ctx.fill(); ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = r * 0.1; ctx.beginPath(); ctx.moveTo(0, -r * 0.7); ctx.lineTo(0, -r * 1.1); ctx.stroke();
    const G = [[-0.58,-0.5],[0,-0.5],[0.58,-0.5],[-0.3,0],[0.3,0],[0,0.5]]; G.forEach(([gx, gy], k) => { const xx = gx * r, yy = gy * r; ctx.fillStyle = k % 2 ? '#8a4fc2' : f.outer; ctx.beginPath(); ctx.arc(xx, yy, r * 0.33, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.arc(xx - r * 0.1, yy - r * 0.1, r * 0.09, 0, TAU); ctx.fill(); }); return;
  }
  if (f.name === 'dragonfruit') {
    ctx.beginPath(); ctx.ellipse(0, 0, r * 0.82, r * 1.05, 0, 0, TAU); ctx.fillStyle = f.outer; ctx.fill();
    ctx.fillStyle = '#41c46a'; for (const [a, b, rot] of [[-0.7, -0.4, -2.2], [0.7, -0.35, -1.0], [-0.85, 0.2, -2.6], [0.85, 0.25, -0.5], [-0.55, 0.75, 2.6], [0.55, 0.78, 0.5], [0, -1.0, -1.57], [0, 0.95, 1.57]]) { ctx.save(); ctx.translate(a * r, b * r); ctx.rotate(rot); ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(r * 0.2, -r * 0.18, r * 0.55, 0); ctx.quadraticCurveTo(r * 0.2, r * 0.1, 0, 0); ctx.fill(); ctx.restore(); }
    ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.beginPath(); ctx.ellipse(-r * 0.3, -r * 0.3, r * 0.14, r * 0.3, 0.3, 0, TAU); ctx.fill(); return;
  }
  if (f.special === 'giant') {
    ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fillStyle = f.outer; ctx.fill();
    ctx.save(); ctx.clip(); ctx.strokeStyle = f.stripe; ctx.lineWidth = r * 0.16; for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.ellipse(i * r * 0.42, 0, r * 0.12, r * 1.1, 0, 0, TAU); ctx.stroke(); } ctx.restore();
    ctx.lineWidth = Math.max(3, r * 0.05); ctx.strokeStyle = '#ffd23f'; ctx.beginPath(); ctx.arc(0, 0, r * 1.04, 0, TAU); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.ellipse(-r * 0.35, -r * 0.4, r * 0.3, r * 0.17, -0.6, 0, TAU); ctx.fill(); return;
  }
  if (f.name === 'lemon') { ctx.beginPath(); ctx.ellipse(0, 0, r * 1.15, r * 0.88, 0, 0, TAU); }
  else { ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); }
  ctx.fillStyle = f.outer; ctx.fill();
  ctx.lineWidth = Math.max(2, r * 0.06); ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.stroke();
  if (f.stripe) { ctx.save(); ctx.clip(); ctx.strokeStyle = f.stripe; ctx.lineWidth = r * 0.16; for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.ellipse(i * r * 0.42, 0, r * 0.12, r * 1.1, 0, 0, TAU); ctx.stroke(); } ctx.restore(); }
  if (f.name === 'apple') { ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = r * 0.1; ctx.beginPath(); ctx.moveTo(0, -r * 0.85); ctx.lineTo(r * 0.1, -r * 1.25); ctx.stroke(); ctx.fillStyle = '#3cbf4a'; ctx.beginPath(); ctx.ellipse(r * 0.35, -r * 1.1, r * 0.28, r * 0.13, -0.5, 0, TAU); ctx.fill(); }
  if (f.name === 'orange') { ctx.strokeStyle = '#6b4a1a'; ctx.lineWidth = r * 0.08; ctx.beginPath(); ctx.moveTo(0, -r * 0.95); ctx.lineTo(r * 0.05, -r * 1.15); ctx.stroke(); ctx.fillStyle = '#3cbf4a'; ctx.beginPath(); ctx.ellipse(r * 0.3, -r * 1.08, r * 0.26, r * 0.11, -0.4, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(0,0,0,0.12)'; for (let i = 0; i < 9; i++) { ctx.beginPath(); ctx.arc(Math.cos(i * 2.4) * r * 0.55, Math.sin(i * 2.4) * r * 0.55, r * 0.05, 0, TAU); ctx.fill(); } }
  if (f.name === 'lemon') { ctx.fillStyle = '#3cbf4a'; ctx.beginPath(); ctx.ellipse(-r * 1.05, 0, r * 0.2, r * 0.1, 0.3, 0, TAU); ctx.fill(); }
  if (f.name === 'coconut') { ctx.fillStyle = '#4a2f18'; for (const [a, b] of [[-0.3, -0.4], [0.3, -0.4], [0, -0.05]]) { ctx.beginPath(); ctx.arc(a * r, b * r, r * 0.12, 0, TAU); ctx.fill(); } }
  if (f.special === 'ice') {
    ctx.strokeStyle = '#ffffff'; ctx.lineWidth = r * 0.09; ctx.lineCap = 'round';
    for (let i = 0; i < 3; i++) { const a = i * Math.PI / 3; ctx.beginPath(); ctx.moveTo(Math.cos(a) * r * 0.6, Math.sin(a) * r * 0.6); ctx.lineTo(-Math.cos(a) * r * 0.6, -Math.sin(a) * r * 0.6); ctx.stroke(); }
    ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.2 + 0.1 * Math.sin(t * 6);
    ctx.beginPath(); ctx.arc(0, 0, r * 1.45, 0, TAU); ctx.fillStyle = '#8fdcff'; ctx.fill();
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  }
  // soft 3D shading: lit from the top-left, shadowed at the bottom-right
  if (!f.special) {
    const sh = ctx.createRadialGradient(-r * 0.35, -r * 0.4, r * 0.1, 0, 0, r * 1.15);
    sh.addColorStop(0, 'rgba(255,255,255,0.18)'); sh.addColorStop(0.6, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,0,0.3)');
    ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fillStyle = sh; ctx.fill();
  }
  // glossy highlight
  ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.beginPath(); ctx.ellipse(-r * 0.36, -r * 0.4, r * 0.24, r * 0.14, -0.6, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(-r * 0.46, -r * 0.5, r * 0.05, 0, TAU); ctx.fill();
}
function drawBomb(r, t){
  ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.18 + 0.12 * Math.sin(t * 12);
  ctx.beginPath(); ctx.arc(0, 0, r * 1.5, 0, TAU); ctx.fillStyle = '#ff3b3b'; ctx.fill();
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fillStyle = '#23252e'; ctx.fill();
  ctx.lineWidth = r * 0.12; ctx.strokeStyle = `rgba(255,60,60,${0.5 + 0.5 * Math.sin(t * 12)})`; ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.beginPath(); ctx.ellipse(-r * 0.35, -r * 0.35, r * 0.25, r * 0.14, -0.6, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#a07a4a'; ctx.lineWidth = r * 0.1; ctx.beginPath(); ctx.moveTo(0, -r); ctx.quadraticCurveTo(r * 0.3, -r * 1.5, r * 0.6, -r * 1.35); ctx.stroke();
  ctx.fillStyle = Math.sin(t * 30) > 0 ? '#ffe14a' : '#ff7a1a'; ctx.beginPath(); ctx.arc(r * 0.62, -r * 1.36, r * 0.16, 0, TAU); ctx.fill();
  text('!', 0, r * 0.05, r * 1.0, '#ff5d6c');
}
function segDist(px, py, s){
  const vx = s.x2 - s.x1, vy = s.y2 - s.y1, L = vx * vx + vy * vy;
  const t = L ? clamp(((px - s.x1) * vx + (py - s.y1) * vy) / L, 0, 1) : 0;
  return Math.hypot(px - (s.x1 + vx * t), py - (s.y1 + vy * t));
}

const FSTAGES = [
  { name:'The Dojo', base:'#4e321d', wood:['#62402a', '#6a4429'], amb:'dust', rate:0.4, tint:null },
  { name:'Cherry Blossom Garden', base:'#5a3a2a', wood:['#7a5640', '#85604a'], amb:'petals', rate:0.22, tint:'rgba(255,170,200,0.10)', branch:true },
  { name:'Lantern Night Market', base:'#241830', wood:['#3a2a3f', '#43304a'], amb:'fireflies', rate:0.3, tint:'rgba(30,20,80,0.25)', lanterns:true },
];
scenes.fruit = {
  game:true, music:'fruit', hint:'Slice the fruit with quick swipes — avoid the bombs!',
  enter(){
    Object.assign(this, { items:[], halves:[], parts:[], splats:[], pops:[], slashes:[], queue:[], score:0, lives:3, t:0, spawnT:0.5,
                          combo:{ n:0, last:-9, x:0, y:0 }, state:'ready', readyT:2.5, flash:0, flashCol:'255,255,255', shake:0, sliced:0,
                          slow:0, best:+store.get('mp-best-fruit', 0), G:H * 1.9, lifeLost:0,
                          streak:0, mult:1, frenzy:0, stage:0, stageBanner:{ text:'', t:9 }, amb:[], ambT:0, multPulse:0 });
    this.stageBanner = { text:FSTAGES[0].name, t:0 };
    Music.setLevel(0.4);
  },
  exit(){ Music.setLevel(1); },
  update(dt){
    this.G = H * 1.9;
    this.parts = stepParts(this.parts, dt); this.pops = stepPops(this.pops, dt);
    this.stageBanner.t += dt; this.multPulse = Math.max(0, this.multPulse - dt * 2.5);
    this.updateAmbient(dt);
    if (this.state === 'ready') { const p = this.readyT; this.readyT -= dt; countBeep(p, this.readyT); if (this.readyT <= 0) { this.state = 'play'; SFX.go(); } return; }
    this.slow = Math.max(0, this.slow - dt);
    const wdt = dt * (this.slow > 0 ? 0.4 : 1);      // ice fruit slows the world, not your hands
    this.t += wdt;
    const ns = Math.floor(this.t / 45) % FSTAGES.length;       // a new look every 45 seconds
    if (ns !== this.stage) { this.stage = ns; this.stageBanner = { text:FSTAGES[ns].name, t:0 }; SFX.swoosh(); this.amb.length = 0; }
    if (this.frenzy > 0) { this.frenzy -= dt; if (this.frenzy <= 0) { this.frenzy = 0; pop(this.pops, W / 2, H * 0.3, 'Frenzy over', '#e6d0ff', 0.05, 1.2); } }
    this.mult = (1 + Math.min(3, Math.floor(this.streak / 10))) * (this.frenzy > 0 ? 2 : 1);
    Music.setLevel(clamp(0.35 + this.t / 90 + (this.frenzy > 0 ? 0.4 : 0), 0, 1));

    // spawn waves — they get bigger and quicker as you go
    this.spawnT -= wdt;
    if (this.spawnT <= 0) {
      const n = this.frenzy > 0 ? 3 + Math.floor(Math.random() * 3) : 1 + Math.floor(Math.random() * (1 + Math.min(4, this.t / 15)));
      for (let i = 0; i < n; i++) this.queue.push(this.t + i * (this.frenzy > 0 ? 0.1 : 0.18));
      this.spawnT = this.frenzy > 0 ? 0.55 : Math.max(0.55, 1.45 - this.t * 0.015) + n * 0.1;
    }
    while (this.queue.length && this.queue[0] <= this.t) { this.queue.shift(); this.spawn(); }

    // slicing: every blade stroke (tracked + drawn path) is tested against the fruit's swept position
    const pad = H * 0.035;
    for (const s of I.segments) {
      if (s.speed < (s.hand === 2 ? 0.8 : SLICE_SPEED)) continue;
      for (const it of this.items) {
        if (it.dead) continue;
        const d = Math.min(segDist(it.x, it.y, s), segDist(it.px, it.py, s));
        if (d > it.r + pad) continue;
        if (it.f.special === 'giant') {      // the giant melon takes three good cuts
          if (this.t - (it.lastHit || -9) < 0.2) continue;
          it.lastHit = this.t; it.hp--; it.flash = 0.12; SFX.juice(this.combo.n + 2);
          burst(this.parts, it.x, it.y, 14, [it.f.inner, '#ff8a96', '#ffffff'], H * 0.8, H * 0.012, 0.6, 0.6);
          this.slashes.push({ x:it.x, y:it.y, ang:Math.atan2(s.y2 - s.y1, s.x2 - s.x1), len:it.r * 3, t:0 });
          if (it.hp > 0) { pop(this.pops, it.x, it.y - it.r * 0.5, it.hp === 1 ? 'one more!' : 'again!', '#ffe14a', 0.04, 0.7); continue; }
        }
        it.dead = true;
        if (it.bomb) this.explode(it); else this.slice(it, Math.atan2(s.y2 - s.y1, s.x2 - s.x1));
      }
    }
    // sparks fly off fast-moving blades
    for (const c of cursors()) if (c.hd.speed > SLICE_SPEED && Math.random() < 0.5)
      this.parts.push({ x:c.x, y:c.y, vx:rand(-1, 1) * H * 0.2, vy:rand(-1, 0.5) * H * 0.2, r:H * rand(0.003, 0.007), c:HAND_COLORS[c.k], life:0.3, max:0.3, g:0.3 });

    // physics
    for (const it of this.items) {
      it.px = it.x; it.py = it.y;
      it.vy += this.G * wdt; it.x += it.vx * wdt; it.y += it.vy * wdt; it.rot += it.vr * wdt;
      if (!it.dead && it.vy > 0 && it.y > H + it.r * 1.5) {
        it.dead = true;
        if (!it.bomb && !it.f.special) { this.loseLife(); SFX.miss(); pop(this.pops, clamp(it.x, 60, W - 60), H * 0.88, '✕', '#ff5d6c', 0.06); }
        else if (it.f.special === 'giant') { this.loseLife(); SFX.miss(); pop(this.pops, clamp(it.x, 60, W - 60), H * 0.88, 'The melon got away!', '#ff5d6c', 0.04); }
      }
    }
    this.items = this.items.filter(it => !it.dead);
    for (const h of this.halves) { h.vy += this.G * wdt; h.x += h.vx * wdt; h.y += h.vy * wdt; h.rot += h.vr * wdt; }
    this.halves = this.halves.filter(h => h.y < H + 200);
    for (const s of this.splats) s.life -= dt * 0.25;
    this.splats = this.splats.filter(s => s.life > 0);
    for (const s of this.slashes) s.t += dt;
    this.slashes = this.slashes.filter(s => s.t < 0.2);
    this.flash = Math.max(0, this.flash - dt * 2); this.shake = Math.max(0, this.shake - dt * 2); this.lifeLost = Math.max(0, this.lifeLost - dt);

    // combos: 3+ fruit in one flurry
    if (this.combo.n && this.t - this.combo.last > 0.45) {
      if (this.combo.n >= 3) { this.score += this.combo.n; SFX.combo(); pop(this.pops, this.combo.x, this.combo.y - H * 0.08, `Combo ×${this.combo.n}!  +${this.combo.n}`, '#ffe14a', 0.06, 1.3); }
      this.combo.n = 0;
    }
    if (this.lives <= 0) go('over', { game:'fruit', score:this.score, detail:`${this.sliced} fruit sliced` });
  },
  loseLife(){ this.lives--; this.lifeLost = 0.6; this.streak = 0; },
  rescale(sc){ for (const arr of [this.items, this.halves, this.splats, this.parts, this.slashes, this.pops, this.amb]) for (const o of arr) sc(o, true); },
  spawn(){
    const frenzy = this.frenzy > 0;
    const bomb = !frenzy && this.t > 5 && Math.random() < Math.min(0.2, 0.06 + this.t / 250);
    let f = pick(FRUITS);
    if (!bomb && this.t > 8) {
      const r = Math.random();
      if (r < 0.04) f = ICE; else if (r < 0.08) f = GOLD;
      else if (!frenzy && r < 0.115 && this.lives < 3) f = HEART;
      else if (!frenzy && this.t > 20 && r < 0.145 && !this.items.some(i => i.f === FRENZY)) f = FRENZY;
      else if (!frenzy && this.t > 25 && r < 0.17 && !this.items.some(i => i.f === GIANT)) f = GIANT;
    }
    const r = (bomb ? 0.05 : f.r) * H;
    const giant = f === GIANT;
    const x = W * rand(giant ? 0.3 : 0.12, giant ? 0.7 : 0.88), peak = H * (giant ? rand(0.55, 0.7) : rand(0.48, 0.82));
    this.items.push({ f, bomb, r, x, y:H + r, px:x, py:H + r, vx:(W * 0.5 - x) * rand(0.15, 0.55), vy:-Math.sqrt(2 * this.G * peak), rot:rand(0, 6), vr:giant ? rand(-0.8, 0.8) : rand(-3, 3), hp:giant ? 3 : 1 });
  },
  // each stage has its own ambient sparkle drifting over the board
  updateAmbient(dt){
    const S = FSTAGES[this.stage];
    this.ambT -= dt;
    if (this.ambT <= 0 && this.amb.length < 40) {
      this.ambT = S.rate;
      if (S.amb === 'petals') this.amb.push({ x:rand(-0.1, 1) * W, y:-10, vx:rand(0.02, 0.08) * W, vy:rand(0.05, 0.11) * H, r:H * rand(0.008, 0.014), a:rand(0, 6), kind:'petal' });
      else if (S.amb === 'fireflies') this.amb.push({ x:rand(0, 1) * W, y:rand(0.3, 1) * H, vx:rand(-0.02, 0.02) * W, vy:rand(-0.04, 0.01) * H, r:H * rand(0.004, 0.008), a:rand(0, 6), kind:'fly' });
      else this.amb.push({ x:rand(0, 1) * W, y:rand(0.1, 0.9) * H, vx:rand(0.005, 0.02) * W, vy:rand(-0.02, 0.02) * H, r:H * rand(0.003, 0.007), a:rand(0, 6), kind:'dust' });
    }
    for (const p of this.amb) { p.x += p.vx * dt + Math.sin(this.t * 2 + p.a) * dt * 14; p.y += p.vy * dt; p.a += dt; }
    this.amb = this.amb.filter(p => p.y < H + 20 && p.x < W + 20 && p.y > -30 && p.x > -30);
  },
  slice(it, ang){
    this.sliced++; this.streak++;
    if (this.t - this.combo.last < 0.45) this.combo.n++; else this.combo.n = 1;
    this.combo.last = this.t; this.combo.x = it.x; this.combo.y = it.y;
    SFX.juice(this.combo.n);
    if (this.streak % 10 === 0 && this.streak <= 30) { this.multPulse = 1; SFX.combo(); pop(this.pops, W / 2, H * 0.24, `Streak ×${1 + this.streak / 10}!`, '#ffe14a', 0.07, 1.4); }
    let pts = 1;
    if (it.f.special === 'gold') { pts = 5; SFX.gold(); burst(this.parts, it.x, it.y, 26, ['#ffd23f', '#fff3a8', '#ffffff'], H * 0.9, H * 0.01, 0.9, 0.4); }
    if (it.f.special === 'ice') { this.slow = 4; this.flash = 0.6; this.flashCol = '143,220,255'; SFX.freeze(); pop(this.pops, W / 2, H * 0.3, 'FREEZE!', '#8fdcff', 0.08, 1.4); }
    if (it.f.special === 'heart') { pts = 2; if (this.lives < 3) this.lives++; this.lifeLost = 0; SFX.heart(); this.flash = 0.35; this.flashCol = '255,107,138'; pop(this.pops, it.x, it.y - it.r * 1.6, '+1 life ♥', '#ff6b8a', 0.06, 1.3); burst(this.parts, it.x, it.y, 22, ['#ff6b8a', '#ffd1de', '#ffffff'], H * 0.8, H * 0.01, 0.9, 0.3); }
    if (it.f.special === 'frenzy') { pts = 2; this.frenzy = 7; this.flash = 0.45; this.flashCol = '166,91,255'; SFX.fanfare(); this.banner('FRUIT FRENZY!  ×2', '#d6a8ff'); burst(this.parts, it.x, it.y, 30, ['#a65bff', '#e6d0ff', '#ffffff'], H, H * 0.012, 1.0, 0.3); }
    if (it.f.special === 'giant') { pts = 10; SFX.boom(); this.shake = 0.7; this.flash = 0.4; this.flashCol = '255,120,140'; burst(this.parts, it.x, it.y, 50, ['#ff4d5e', '#ff8a96', '#2f9e44', '#ffffff'], H * 1.2, H * 0.016, 1.0, 0.7); }
    pts *= this.mult;
    this.score += pts;
    const nx = -Math.sin(ang), ny = Math.cos(ang), push = H * 0.3;
    for (const side of [1, -1]) this.halves.push({ f:it.f, r:it.r, x:it.x, y:it.y, vx:it.vx + nx * push * side, vy:it.vy * 0.5 + ny * push * side, rot:ang, vr:side * rand(2, 5), side });
    burst(this.parts, it.x, it.y, 18, [it.f.inner, it.f.outer, it.f.inner], H * 0.7, H * 0.011, 0.7, 0.6);
    this.splats.push({ x:it.x, y:it.y, r:it.r * rand(1.3, 1.7), c:it.f.inner, life:1, rot:rand(0, TAU) });
    this.slashes.push({ x:it.x, y:it.y, ang, len:it.r * 3.2, t:0 });
    pop(this.pops, it.x, it.y - it.r, '+' + pts, pts > 1 ? '#ffd23f' : '#fff');
  },
  banner(t, c){ this.stageBanner2 = { text:t, color:c, t:0 }; },
  explode(it){
    SFX.bomb(); this.loseLife(); this.flash = 1; this.flashCol = '255,255,255'; this.shake = 1;
    burst(this.parts, it.x, it.y, 34, ['#ff7a1a', '#ffe14a', '#3a3a3a'], H * 1.1, H * 0.016, 0.9, 0.5);
    pop(this.pops, it.x, it.y, 'BOOM! −1 life', '#ff5d6c', 0.06, 1.2);
  },
  draw(now){
    ctx.save();
    if (this.shake) ctx.translate(rand(-1, 1) * this.shake * 18, rand(-1, 1) * this.shake * 18);
    const ST = FSTAGES[this.stage];
    ctx.drawImage(cachedLayer('board' + this.stage, g => {
      const n = 7;
      g.fillStyle = ST.base; g.fillRect(0, 0, W, H);
      for (let i = 0; i < n; i++) {
        g.fillStyle = ST.wood[i % 2]; g.fillRect(0, i * H / n, W, H / n - Math.max(2, H * 0.004));
        g.strokeStyle = 'rgba(40,22,10,0.18)'; g.lineWidth = Math.max(1, H * 0.002);
        for (let j = 0; j < 9; j++) { const y = i * H / n + rand(0.1, 0.9) * H / n; g.beginPath(); g.moveTo(0, y); g.bezierCurveTo(W * 0.3, y + rand(-6, 6), W * 0.6, y + rand(-6, 6), W, y + rand(-4, 4)); g.stroke(); }
      }
      if (ST.tint) { g.fillStyle = ST.tint; g.fillRect(0, 0, W, H); }
      if (ST.branch) {   // blossom branches in the corners
        g.strokeStyle = '#3a2418'; g.lineCap = 'round';
        for (const [sx, dir] of [[0, 1], [W, -1]]) {
          g.lineWidth = H * 0.016; g.beginPath(); g.moveTo(sx, H * 0.06); g.quadraticCurveTo(sx + dir * W * 0.1, H * 0.1, sx + dir * W * 0.2, H * 0.03); g.stroke();
          g.lineWidth = H * 0.008; g.beginPath(); g.moveTo(sx + dir * W * 0.08, H * 0.09); g.quadraticCurveTo(sx + dir * W * 0.12, H * 0.16, sx + dir * W * 0.17, H * 0.17); g.stroke();
          for (let k = 0; k < 26; k++) { const bx = sx + dir * W * rand(0.02, 0.2), by = H * rand(0.02, 0.18); g.fillStyle = pick(['#ffc2d6', '#ffa6c4', '#fff0f5']); g.beginPath(); g.arc(bx, by, H * rand(0.008, 0.017), 0, TAU); g.fill(); }
        }
      }
      if (ST.lanterns) {
        for (const lx of [0.12, 0.3, 0.5, 0.7, 0.88]) {
          const x = W * lx, y = H * (0.06 + 0.03 * Math.sin(lx * 20)), r = H * 0.035;
          const gl = g.createRadialGradient(x, y + r, 0, x, y + r, r * 5); gl.addColorStop(0, 'rgba(255,170,70,0.55)'); gl.addColorStop(1, 'rgba(255,170,70,0)'); g.fillStyle = gl; g.fillRect(x - r * 5, y - r * 4, r * 10, r * 10);
          g.strokeStyle = '#111'; g.lineWidth = 2; g.beginPath(); g.moveTo(x, 0); g.lineTo(x, y); g.stroke();
          g.fillStyle = '#e8452a'; g.beginPath(); g.ellipse(x, y + r, r * 0.8, r, 0, 0, TAU); g.fill();
          g.fillStyle = '#ffd36a'; g.fillRect(x - r * 0.55, y + r * 0.9, r * 1.1, r * 0.1); g.fillStyle = '#222'; g.fillRect(x - r * 0.3, y - r * 0.05, r * 0.6, r * 0.18);
        }
      }
      const v = g.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, W * 0.75); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.5)');
      g.fillStyle = v; g.fillRect(0, 0, W, H);
    }), 0, 0);
    // ambient drifting bits
    for (const p of this.amb) {
      if (p.kind === 'petal') { ctx.fillStyle = '#ffb7d0'; ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.a); ctx.beginPath(); ctx.ellipse(0, 0, p.r, p.r * 0.55, 0, 0, TAU); ctx.fill(); ctx.restore(); }
      else if (p.kind === 'fly') { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.35 + 0.35 * Math.sin(p.a * 3); ctx.fillStyle = '#ffe98a'; ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 2.2, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; }
      else { ctx.globalAlpha = 0.18 + 0.12 * Math.sin(p.a); ctx.fillStyle = '#ffe9c9'; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; }
    }
    for (const s of this.splats) {
      ctx.globalAlpha = 0.4 * s.life; ctx.fillStyle = s.c;
      ctx.beginPath(); ctx.ellipse(s.x, s.y, s.r, s.r * 0.7, s.rot, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.arc(s.x + Math.cos(s.rot) * s.r * 1.2, s.y + Math.sin(s.rot) * s.r * 0.9, s.r * 0.22, 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1;
    drawGhost(0.12);
    for (const h of this.halves) { ctx.save(); ctx.translate(h.x, h.y); ctx.rotate(h.rot); drawFruit(h.f, h.r, h.side); ctx.restore(); }
    for (const it of this.items) { ctx.save(); ctx.translate(it.x, it.y); if (it.bomb) drawBomb(it.r, this.t); else { ctx.rotate(it.rot); drawFruit(it.f, it.r, 0, this.t); } ctx.restore(); }
    drawParts(this.parts);
    for (const s of this.slashes) {   // bright cut line through each sliced fruit
      const k = 1 - s.t / 0.2, dx = Math.cos(s.ang) * s.len / 2, dy = Math.sin(s.ang) * s.len / 2;
      ctx.globalAlpha = k; ctx.strokeStyle = '#fff'; ctx.lineWidth = H * 0.012 * k; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(s.x - dx, s.y - dy); ctx.lineTo(s.x + dx, s.y + dy); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    I.hands.forEach((hd, k) => drawBlade(hd.trail, HAND_COLORS[k], now));
    drawBlade(I.mouse.trail, '#ffffff', now);
    for (const c of cursors()) {     // glowing blade tip
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = c.hd.speed > SLICE_SPEED ? 0.6 : 0.3;
      ctx.beginPath(); ctx.arc(c.x, c.y, H * 0.03, 0, TAU); ctx.fillStyle = HAND_COLORS[c.k]; ctx.fill();
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
      ctx.beginPath(); ctx.arc(c.x, c.y, H * 0.011, 0, TAU); ctx.fillStyle = '#fff'; ctx.fill();
    }
    drawPops(this.pops);
    ctx.restore();
    if (this.slow > 0) {
      const v = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, W * 0.7);
      v.addColorStop(0, 'rgba(143,220,255,0)'); v.addColorStop(1, `rgba(143,220,255,${0.35 * Math.min(1, this.slow)})`);
      ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
    }
    if (this.flash) { ctx.fillStyle = `rgba(${this.flashCol},${this.flash * 0.6})`; ctx.fillRect(0, 0, W, H); }
    if (this.frenzy > 0) {   // purple frenzy glow around the screen
      const v = ctx.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, W * 0.65); v.addColorStop(0, 'rgba(166,91,255,0)'); v.addColorStop(1, `rgba(166,91,255,${0.28 + 0.12 * Math.sin(this.t * 12)})`);
      ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
      const bw = W * 0.3; roundRect(W / 2 - bw / 2, H * 0.03, bw, H * 0.022, H * 0.011); ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fill();
      roundRect(W / 2 - bw / 2, H * 0.03, Math.max(H * 0.022, bw * this.frenzy / 7), H * 0.022, H * 0.011); ctx.fillStyle = '#c28bff'; ctx.fill();
      text('FRENZY ×2', W / 2, H * 0.08, H * 0.035, '#e6d0ff');
    }
    if (this.stageBanner.t < 3 && this.state === 'play') { ctx.globalAlpha = Math.min(1, (3 - this.stageBanner.t) * 1.5, this.stageBanner.t * 3); text(this.stageBanner.text, W / 2, H * 0.16, H * 0.055, '#fff'); ctx.globalAlpha = 1; }
    if (this.stageBanner2) { const b = this.stageBanner2; b.t += 1 / 60; if (b.t < 2) { ctx.globalAlpha = Math.min(1, (2 - b.t) * 2); text(b.text, W / 2, H * 0.4, H * 0.09 * (0.85 + 0.15 * Math.min(1, b.t * 5)), b.color); ctx.globalAlpha = 1; } }
    // HUD
    text(String(this.score), W * 0.04, H * 0.08, H * 0.08, '#ffe14a', 'left');
    if (this.mult > 1) text('×' + this.mult, W * 0.04 + String(this.score).length * H * 0.05 + H * 0.04, H * 0.085, H * 0.05 * (1 + this.multPulse * 0.5), '#ff9a3f', 'left');
    else if (this.streak >= 3) text(`streak ${this.streak}`, W * 0.04, H * 0.19, H * 0.026, '#ffe9c9', 'left', 700);
    text('Best ' + Math.max(this.best, this.score), W * 0.04, H * 0.15, H * 0.032, '#ffe9c9', 'left', 700);
    for (let i = 0; i < 3; i++) {
      const lost = i < 3 - this.lives, s = lost && i === 2 - this.lives && this.lifeLost ? 1 + this.lifeLost : 1;
      text('✕', W * (0.86 + i * 0.045), H * 0.08, H * 0.06 * s, lost ? '#ff3b4e' : 'rgba(255,255,255,0.35)');
    }
    if (this.state === 'ready') {
      text('Get your hands ready!', W / 2, H * 0.36, H * 0.08);
      text(String(Math.ceil(this.readyT)), W / 2, H * 0.5, H * 0.13, '#ffe14a');
      text('Swipe fast · avoid bombs · ❄ slows time · ★ 5 pts · ♥ extra life · ⚡ frenzy · giant melon = 3 cuts', W / 2, H * 0.63, H * 0.032, '#ffe9c9', 'center', 600);
    }
    drawMotionBadge();
  }
};

