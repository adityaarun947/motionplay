/* =====================================================================
   ZOMBIE SIEGE — ART: shaded zombie sprites, guns, medkit, boost.
   Everything is drawn procedurally once into small cached canvases (so it stays fast on a TV), then stamped each frame.
   ===================================================================== */
const ZU = 34;                              // sprite resolution: pixels per "unit" (a zombie is ~10 units tall)
const ZSPR = new Map();                     // zombie sprite cache
let zIdCounter = 0;

function zRgb(c){
  if (c[0] === '#') { const h = c.length === 4 ? c.replace(/#(.)(.)(.)/, '#$1$1$2$2$3$3') : c, n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
  const m = c.match(/[\d.]+/g); return m ? [+m[0], +m[1], +m[2]] : [128, 128, 128];
}
function zShade(c, f){ const [r, g, b] = zRgb(c), t = f < 0 ? 0 : 255, k = Math.abs(f); return `rgb(${Math.round(r + (t - r) * k)},${Math.round(g + (t - g) * k)},${Math.round(b + (t - b) * k)})`; }
function zMix(a, b, k){ const x = zRgb(a), y = zRgb(b); return `rgb(${Math.round(x[0] + (y[0] - x[0]) * k)},${Math.round(x[1] + (y[1] - x[1]) * k)},${Math.round(x[2] + (y[2] - x[2]) * k)})`; }

// a tapered, cylinder-shaded limb from (x1,y1) to (x2,y2)
function zLimb(g, x1, y1, x2, y2, w1, w2, col, lt = 0.32, dk = 0.5){
  const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1, nx = -dy / L, ny = dx / L, th = Math.atan2(ny, nx), hw = Math.max(w1, w2) / 2, mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
  const gr = g.createLinearGradient(mx - nx * hw, my - ny * hw, mx + nx * hw, my + ny * hw);
  gr.addColorStop(0, zShade(col, lt)); gr.addColorStop(0.4, col); gr.addColorStop(1, zShade(col, -dk));
  g.fillStyle = gr; g.beginPath();
  g.moveTo(x1 + nx * w1 / 2, y1 + ny * w1 / 2); g.lineTo(x2 + nx * w2 / 2, y2 + ny * w2 / 2);
  g.arc(x2, y2, w2 / 2, th, th - Math.PI, true); g.lineTo(x1 - nx * w1 / 2, y1 - ny * w1 / 2); g.arc(x1, y1, w1 / 2, th + Math.PI, th, true);
  g.closePath(); g.fill();
}
function zBlood(g, x, y, rx, ry, a = 0.75, col = '110,10,16'){
  const gr = g.createRadialGradient(x, y, 0, x, y, Math.max(rx, ry));
  gr.addColorStop(0, `rgba(${col},${a})`); gr.addColorStop(0.65, `rgba(${col},${a * 0.6})`); gr.addColorStop(1, `rgba(${col},0)`);
  g.save(); g.translate(x, y); g.scale(1, ry / rx); g.translate(-x, -y); g.fillStyle = gr; g.beginPath(); g.arc(x, y, rx, 0, TAU); g.fill(); g.restore();
}
function zSpikes(g, pts){ g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); }

function zombieVariant(z){ if (z.vi === undefined) { z.vi = (zIdCounter++) % 3; } return z.vi; }

function zombieSprite(z){
  const T = z.T || ZTYPES[z.type], type = z.type, vi = zombieVariant(z), skin = T.skin[vi % T.skin.length], shirt = T.shirt[vi % T.shirt.length];
  const step = Math.round((((z.phase % TAU) + TAU) % TAU) / TAU * 8) % 8, key = type + vi + ':' + step;
  let sp = ZSPR.get(key); if (sp) return sp;
  if (ZSPR.size > 150) ZSPR.delete(ZSPR.keys().next().value);
  const u = ZU, big = type === 'brute' || type === 'boss' || type === 'bloater', wide = type === 'bloater' ? 1.65 : big ? 1.3 : 1, crawl = type === 'crawler';
  const cw = Math.ceil(8.8 * u * wide * (crawl ? 1.25 : 1)), ch = Math.ceil(11.6 * u * (crawl ? 0.9 : 1));
  const c = document.createElement('canvas'); c.width = cw; c.height = ch;
  const g = c.getContext('2d'); g.translate(cw / 2, ch - 0.4 * u); if (crawl) g.scale(1.2, 0.82);
  g.lineJoin = 'round'; g.lineCap = 'round';
  const phase = step / 8 * TAU, walk = Math.sin(phase), bob = Math.abs(Math.cos(phase)) * u * 0.25, hunch = type === 'runner' ? 0.8 : 0;
  const trouser = type === 'brute' ? '#3a3328' : type === 'boss' ? '#2a1840' : type === 'armored' ? '#363c48' : type === 'runner' ? '#33384a' : '#3b3f52';
  const boot = '#2b231e';

  // ---- legs: ragged trousers, one bare shin, scuffed boots ----
  for (const sd of [-1, 1]) {
    const lift = Math.max(0, sd < 0 ? walk : -walk) * u * 0.4, hx = sd * u * 0.72 * wide, kx = sd * u * 0.8 * wide, kyy = -u * 2.25 - lift * 0.4, fx = sd * u * 0.78 * wide, fy = -u * 0.55 - lift;
    zLimb(g, hx, -u * 4.1, kx, kyy, u * 1.25 * wide, u * 1.0 * wide, trouser);
    zLimb(g, kx, kyy, fx, fy, u * 0.95 * wide, u * 0.78 * wide, sd > 0 ? skin : trouser, 0.3, 0.55);
    if (sd > 0) { g.strokeStyle = 'rgba(90,10,14,0.8)'; g.lineWidth = u * 0.08; g.beginPath(); g.moveTo(kx - u * 0.2, kyy + u * 0.4); g.lineTo(kx + u * 0.1, kyy + u * 0.9); g.moveTo(kx + u * 0.15, kyy + u * 0.3); g.lineTo(kx - u * 0.05, kyy + u * 0.7); g.stroke(); zBlood(g, kx, kyy + u * 0.6, u * 0.4, u * 0.3, 0.6); }
    else { g.fillStyle = zShade(trouser, -0.4); zSpikes(g, [[kx - u * 0.5 * wide, fy - u * 0.2], [kx - u * 0.2, fy + u * 0.15], [kx, fy - u * 0.15], [kx + u * 0.2, fy + u * 0.2], [kx + u * 0.5 * wide, fy - u * 0.2], [kx + u * 0.5 * wide, fy - u * 0.55], [kx - u * 0.5 * wide, fy - u * 0.55]]); g.fill(); }
    const bg = g.createLinearGradient(0, fy - u * 0.1, 0, fy + u * 0.5); bg.addColorStop(0, zShade(boot, 0.25)); bg.addColorStop(1, zShade(boot, -0.5));
    g.fillStyle = bg; g.beginPath(); g.ellipse(fx + sd * u * 0.1, fy + u * 0.18, u * 0.78 * wide, u * 0.34, 0, 0, TAU); g.fill();
    g.fillStyle = 'rgba(255,255,255,0.18)'; g.beginPath(); g.ellipse(fx, fy + u * 0.05, u * 0.4 * wide, u * 0.07, 0, 0, TAU); g.fill();
  }

  // ---- torso ----
  const tTop = -u * 7.7 + bob + hunch * u, tBot = -u * 3.9 + bob, tw = u * 1.75 * wide;
  const shirtCol = shirt;
  const tg = g.createLinearGradient(-tw, 0, tw, 0); tg.addColorStop(0, zShade(shirtCol, 0.25)); tg.addColorStop(0.45, shirtCol); tg.addColorStop(1, zShade(shirtCol, -0.5));
  g.fillStyle = tg; g.beginPath(); g.moveTo(-tw * 1.02, tTop + u * 0.7); g.quadraticCurveTo(-tw * 1.02, tTop - u * 0.1, -tw * 0.55, tTop - u * 0.12); g.quadraticCurveTo(0, tTop - u * 0.42, tw * 0.55, tTop - u * 0.12); g.quadraticCurveTo(tw * 1.02, tTop - u * 0.1, tw * 1.02, tTop + u * 0.7);
  g.bezierCurveTo(tw * 0.95, (tTop + tBot) / 2, tw * 0.9, (tTop + tBot) / 2 + u * 0.6, tw * 1.05, tBot);
  for (let i = 0; i <= 8; i++) g.lineTo(tw * 1.05 - (i / 8) * tw * 2.1, tBot + (i % 2 ? u * 0.55 : u * 0.05) + (i === 3 ? u * 0.3 : 0));
  g.bezierCurveTo(-tw * 0.9, (tTop + tBot) / 2 + u * 0.6, -tw * 0.95, (tTop + tBot) / 2, -tw * 1.02, tTop + u * 0.7);
  g.closePath(); g.fill();
  // folds
  g.strokeStyle = 'rgba(0,0,0,0.22)'; g.lineWidth = u * 0.07;
  for (const [a, b] of [[-0.5, 0.12], [0.1, -0.08], [0.55, 0.1]]) { g.beginPath(); g.moveTo(tw * a, tTop + u * 0.9); g.quadraticCurveTo(tw * (a + b), (tTop + tBot) / 2, tw * (a - b * 0.6), tBot - u * 0.3); g.stroke(); }
  // torn open: flesh and ribs
  if (type !== 'armored' && type !== 'bloater') {
    const rx = tw * 0.22, ry = tTop + u * 1.5;
    g.fillStyle = zShade('#5a1218', -0.2); zSpikes(g, [[rx - u * 0.5, ry], [rx, ry - u * 0.25], [rx + u * 0.55, ry + u * 0.1], [rx + u * 0.7, ry + u * 0.9], [rx + u * 0.25, ry + u * 1.55], [rx - u * 0.3, ry + u * 1.25], [rx - u * 0.6, ry + u * 0.6]]); g.fill();
    g.fillStyle = '#2a0509'; zSpikes(g, [[rx - u * 0.2, ry + u * 0.25], [rx + u * 0.4, ry + u * 0.3], [rx + u * 0.5, ry + u * 0.95], [rx, ry + u * 1.15], [rx - u * 0.3, ry + u * 0.7]]); g.fill();
    g.strokeStyle = '#d9cfae'; g.lineWidth = u * 0.1; for (let i = 0; i < 3; i++) { g.beginPath(); g.moveTo(rx - u * 0.2, ry + u * (0.4 + i * 0.25)); g.quadraticCurveTo(rx + u * 0.15, ry + u * (0.3 + i * 0.25), rx + u * 0.5, ry + u * (0.5 + i * 0.25)); g.stroke(); }
    zBlood(g, -tw * 0.45, tBot - u * 0.5, u * 1.0, u * 0.7, 0.55); zBlood(g, tw * 0.1, tTop + u * 2.9, u * 0.7, u * 0.5, 0.5);
  }
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(-tw * 1.05, tBot - u * 0.12, tw * 2.1, u * 0.22);                    // belt
  if (type === 'armored') {
    const pg = g.createLinearGradient(-tw * 0.8, 0, tw * 0.8, 0); pg.addColorStop(0, '#d5dbea'); pg.addColorStop(0.4, '#8f98ae'); pg.addColorStop(1, '#3b4254');
    g.fillStyle = pg; roundRect(-tw * 0.82, tTop + u * 0.3, tw * 1.64, (tBot - tTop) * 0.74, u * 0.4, g); g.fill();
    g.strokeStyle = 'rgba(0,0,0,0.5)'; g.lineWidth = u * 0.1; g.stroke();
    g.fillStyle = '#2f3544'; g.fillRect(-tw * 0.04, tTop + u * 0.35, tw * 0.08, (tBot - tTop) * 0.7);
    g.strokeStyle = 'rgba(255,255,255,0.3)'; g.lineWidth = u * 0.05; g.beginPath(); g.moveTo(-tw * 0.7, tTop + u * 0.6); g.lineTo(-tw * 0.1, tTop + u * 0.6); g.moveTo(tw * 0.2, tTop + u * 1.6); g.lineTo(tw * 0.65, tTop + u * 1.3); g.stroke();
    for (const [a, b] of [[-0.58, 0.14], [0.58, 0.14], [-0.58, 0.58], [0.58, 0.58]]) { const rg = g.createRadialGradient(tw * a - 1, tTop + u * 0.3 + (tBot - tTop) * 0.74 * b - 1, 0, tw * a, tTop + u * 0.3 + (tBot - tTop) * 0.74 * b, u * 0.17); rg.addColorStop(0, '#fff'); rg.addColorStop(1, '#6c7388'); g.fillStyle = rg; g.beginPath(); g.arc(tw * a, tTop + u * 0.3 + (tBot - tTop) * 0.74 * b, u * 0.15, 0, TAU); g.fill(); }
    zBlood(g, tw * 0.3, tBot - u * 0.4, u * 0.8, u * 0.4, 0.35);
  }
  if (type === 'bloater') {
    const cy = (tTop + tBot) / 2 + u * 0.35, bgr = g.createRadialGradient(-tw * 0.3, cy - u * 0.5, u * 0.2, 0, cy, tw * 1.1); bgr.addColorStop(0, '#dff08a'); bgr.addColorStop(0.55, '#a9c455'); bgr.addColorStop(1, '#4e6224');
    g.fillStyle = bgr; g.beginPath(); g.ellipse(0, cy, tw * 0.98, (tBot - tTop) * 0.64, 0, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(70,40,30,0.5)'; g.lineWidth = u * 0.06; for (let i = 0; i < 5; i++) { g.beginPath(); g.moveTo(-tw * 0.7 + i * tw * 0.35, cy - u * 1.3); g.quadraticCurveTo(-tw * 0.6 + i * tw * 0.35, cy, -tw * 0.7 + i * tw * 0.35, cy + u * 1.3); g.stroke(); }
    for (const [a, b, r] of [[-0.45, -0.25, 0.34], [0.38, 0.08, 0.42], [-0.12, 0.38, 0.28], [0.55, -0.4, 0.24], [-0.6, 0.3, 0.2]]) {
      const bx = tw * a, by = cy + (tBot - tTop) * b, rg = g.createRadialGradient(bx - u * r * 0.3, by - u * r * 0.3, 0, bx, by, u * r); rg.addColorStop(0, '#fffbc0'); rg.addColorStop(0.5, '#ddeb70'); rg.addColorStop(1, '#8da331');
      g.fillStyle = rg; g.beginPath(); g.arc(bx, by, u * r, 0, TAU); g.fill(); g.strokeStyle = 'rgba(60,70,10,0.6)'; g.lineWidth = u * 0.06; g.stroke();
    }
    zBlood(g, 0, cy + u * 0.6, u * 0.8, u * 0.5, 0.35, '120,150,20');
  }
  if (type === 'boss') {   // gold-trimmed robe and skull pauldrons
    g.strokeStyle = '#ffd23f'; g.lineWidth = u * 0.16; g.beginPath(); g.moveTo(-tw, tTop + u * 0.1); g.lineTo(-tw * 1.05, tBot); g.moveTo(tw, tTop + u * 0.1); g.lineTo(tw * 1.05, tBot); g.stroke();
    g.fillStyle = '#ffd23f'; g.beginPath(); g.moveTo(-tw * 0.18, tTop); g.lineTo(0, tTop + u * 1.7); g.lineTo(tw * 0.18, tTop); g.closePath(); g.fill();
  }
  // neck
  zLimb(g, 0, tTop + u * 0.3, 0, tTop - u * 0.7, u * 1.1 * (big ? 1.2 : 1), u * 0.95, skin, 0.15, 0.7);

  // ---- arms ----
  for (const sd of [-1, 1]) {
    const sx = sd * tw * 0.95, sy = tTop + u * 0.65, hx = sd * tw * 0.7 + sd * walk * u * 0.25, hy = tTop + u * 2.35 - sd * walk * u * 0.5, ex = sd * (tw + u * 0.55), ey = (sy + hy) / 2 + u * 0.45;
    zLimb(g, sx, sy, ex, ey, u * 1.05 * wide, u * 0.9 * wide, shirtCol, 0.2, 0.5);
    g.fillStyle = zShade(shirtCol, -0.45); zSpikes(g, [[ex - u * 0.5, ey + u * 0.1], [ex - u * 0.15, ey + u * 0.45], [ex, ey + u * 0.15], [ex + u * 0.2, ey + u * 0.5], [ex + u * 0.5, ey + u * 0.1], [ex + u * 0.4, ey - u * 0.3], [ex - u * 0.4, ey - u * 0.3]]); g.fill();
    zLimb(g, ex, ey + u * 0.1, hx, hy, u * 0.78 * wide, u * 0.62 * wide, skin, 0.3, 0.55);
    zBlood(g, (ex + hx) / 2, (ey + hy) / 2, u * 0.4, u * 0.3, 0.5);
    // clawed hand
    const hr = u * 0.58 * wide; const hg = g.createRadialGradient(hx - hr * 0.3, hy - hr * 0.3, 0, hx, hy, hr * 1.2); hg.addColorStop(0, zShade(skin, 0.3)); hg.addColorStop(1, zShade(skin, -0.45));
    g.fillStyle = hg; g.beginPath(); g.arc(hx, hy, hr, 0, TAU); g.fill();
    for (let f = 0; f < 4; f++) { const a = -Math.PI / 2 + (f - 1.5) * 0.42 + sd * 0.12, fl = u * (0.72 - Math.abs(f - 1.5) * 0.1), fx = hx + Math.cos(a) * fl * 1.15, fy = hy + Math.sin(a) * fl * 1.15; zLimb(g, hx + Math.cos(a) * hr * 0.6, hy + Math.sin(a) * hr * 0.6, fx, fy, u * 0.28, u * 0.2, skin, 0.25, 0.55); g.fillStyle = '#2b2320'; g.beginPath(); g.arc(fx, fy, u * 0.1, 0, TAU); g.fill(); }
    zBlood(g, hx, hy - hr * 0.2, hr * 0.8, hr * 0.6, 0.55);
  }

  // ---- head ----
  const hr = u * 1.35 * (big ? 1.15 : 1), hyc = tTop - hr * 0.85, r = hr;
  g.save(); g.translate(0, hyc); g.rotate(Math.sin(phase) * 0.06 + (type === 'runner' ? 0.12 : 0));
  for (const sd of [-1, 1]) { g.fillStyle = zShade(skin, sd < 0 ? -0.1 : -0.35); g.beginPath(); g.ellipse(sd * r * 1.0, r * 0.05, r * (sd > 0 && vi === 1 ? 0.1 : 0.16), r * 0.27, 0, 0, TAU); g.fill(); }
  let gr = g.createRadialGradient(-r * 0.35, -r * 0.45, r * 0.1, 0, 0, r * 1.2); gr.addColorStop(0, zShade(skin, 0.35)); gr.addColorStop(0.5, skin); gr.addColorStop(1, zShade(skin, -0.55));
  g.fillStyle = gr; g.beginPath(); g.ellipse(0, 0, r * 1.02, r, 0, 0, TAU); g.fill();
  const hairy = type === 'walker' || type === 'runner' || (crawl && vi !== 1) || type === 'spitter';
  if (hairy) {
    g.fillStyle = '#211b17'; g.beginPath(); g.moveTo(-r * 1.0, -r * 0.2);
    for (let i = 0; i <= 9; i++) { const a = Math.PI * (1 + i / 9), rr = r * (1.04 + (i % 2 ? 0.2 : 0.03)); g.lineTo(Math.cos(a) * rr, Math.sin(a) * rr * 0.98); }
    g.lineTo(r * 1.0, -r * 0.2); g.quadraticCurveTo(r * 0.3, -r * 0.62, -r * 0.2, -r * 0.5); g.quadraticCurveTo(-r * 0.7, -r * 0.45, -r * 1.0, -r * 0.2); g.fill();
    g.strokeStyle = 'rgba(255,255,255,0.12)'; g.lineWidth = r * 0.04; g.beginPath(); g.moveTo(-r * 0.5, -r * 0.85); g.quadraticCurveTo(-r * 0.1, -r * 1.0, r * 0.3, -r * 0.9); g.stroke();
  }
  if (vi === 2) {   // exposed skull
    g.fillStyle = '#d8cfae'; g.beginPath(); g.ellipse(r * 0.4, -r * 0.68, r * 0.34, r * 0.2, 0.4, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(60,40,20,0.6)'; g.lineWidth = r * 0.03; g.beginPath(); g.moveTo(r * 0.2, -r * 0.7); g.lineTo(r * 0.5, -r * 0.62); g.moveTo(r * 0.35, -r * 0.8); g.lineTo(r * 0.45, -r * 0.55); g.stroke();
    g.strokeStyle = '#6a0f14'; g.lineWidth = r * 0.07; g.beginPath(); g.ellipse(r * 0.4, -r * 0.68, r * 0.35, r * 0.21, 0.4, 0, TAU); g.stroke();
  }
  // brow, sunken eyes
  g.strokeStyle = zShade(skin, -0.65); g.lineWidth = r * 0.14; g.beginPath(); g.moveTo(-r * 0.72, -r * 0.45); g.lineTo(-r * 0.1, -r * 0.27); g.moveTo(r * 0.72, -r * 0.4); g.lineTo(r * 0.1, -r * 0.24); g.stroke();
  const eyeC = type === 'boss' || type === 'runner' || crawl ? '#ff2a2a' : type === 'spitter' ? '#d6ff4a' : '#ffe14a';
  for (const [ex, ey, erx, ery, er] of [[-0.38, -0.1, 0.31, 0.27, 0.19], [0.4, -0.06, 0.27, 0.24, 0.15]]) {
    const sg = g.createRadialGradient(ex * r, ey * r, 0, ex * r, ey * r, erx * r * 1.35); sg.addColorStop(0, '#12080d'); sg.addColorStop(0.55, 'rgba(50,18,40,0.85)'); sg.addColorStop(1, 'rgba(40,20,40,0)');
    g.fillStyle = sg; g.beginPath(); g.ellipse(ex * r, ey * r, erx * r * 1.3, ery * r * 1.3, 0, 0, TAU); g.fill();
    const eg = g.createRadialGradient(ex * r - r * 0.04, ey * r - r * 0.04, 0, ex * r, ey * r, er * r); eg.addColorStop(0, '#f3edc4'); eg.addColorStop(1, '#a89c63');
    g.fillStyle = eg; g.beginPath(); g.ellipse(ex * r, ey * r, er * r * 1.1, er * r * 0.95, 0, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(190,20,20,0.6)'; g.lineWidth = r * 0.02; for (let k = 0; k < 5; k++) { const a = k * 1.25 + ex; g.beginPath(); g.moveTo(ex * r + Math.cos(a) * er * r * 1.05, ey * r + Math.sin(a) * er * r * 0.9); g.lineTo(ex * r + Math.cos(a) * er * r * 0.45, ey * r + Math.sin(a) * er * r * 0.4); g.stroke(); }
    g.fillStyle = eyeC; g.beginPath(); g.arc(ex * r + r * 0.02, ey * r, r * 0.095, 0, TAU); g.fill(); g.fillStyle = '#1a0606'; g.beginPath(); g.ellipse(ex * r + r * 0.02, ey * r, r * 0.032, r * 0.075, 0, 0, TAU); g.fill();
  }
  // nose hollow
  g.fillStyle = '#170a0a'; g.beginPath(); g.ellipse(-r * 0.085, r * 0.22, r * 0.06, r * 0.1, 0.2, 0, TAU); g.ellipse(r * 0.085, r * 0.22, r * 0.06, r * 0.1, -0.2, 0, TAU); g.fill();
  g.strokeStyle = zShade(skin, -0.4); g.lineWidth = r * 0.05; g.beginPath(); g.moveTo(-r * 0.08, -r * 0.05); g.quadraticCurveTo(-r * 0.14, r * 0.12, -r * 0.12, r * 0.26); g.stroke();
  // mouth
  const mg = g.createRadialGradient(0, r * 0.65, 0, 0, r * 0.65, r * 0.6); mg.addColorStop(0, '#5a0d12'); mg.addColorStop(1, '#14040a');
  g.fillStyle = mg; g.beginPath(); g.moveTo(-r * 0.56, r * 0.38); g.quadraticCurveTo(0, r * 0.28, r * 0.56, r * 0.38); g.quadraticCurveTo(r * 0.52, r * 0.9, 0, r * 0.94); g.quadraticCurveTo(-r * 0.52, r * 0.9, -r * 0.56, r * 0.38); g.fill();
  g.fillStyle = '#7d2a32'; g.beginPath(); g.ellipse(0, r * 0.76, r * 0.27, r * 0.12, 0, 0, TAU); g.fill();
  const tooth = (x, y, w, h, dn) => { const tg2 = g.createLinearGradient(x, y, x, y + (dn ? h : -h)); tg2.addColorStop(0, '#f1e8b8'); tg2.addColorStop(1, '#b7a86b'); g.fillStyle = tg2; g.beginPath(); g.moveTo(x - w / 2, y); g.lineTo(x + w / 2, y); g.lineTo(x + (x > 0 ? -1 : 1) * w * 0.1, y + (dn ? h : -h)); g.closePath(); g.fill(); };
  for (let i = 0; i < 6; i++) tooth(-r * 0.46 + i * r * 0.184, r * 0.35 + Math.abs(i - 2.5) * r * 0.015, r * 0.15, r * (0.17 + ((i * 7 + vi) % 3) * 0.05), true);
  for (let i = 0; i < 5; i++) tooth(-r * 0.37 + i * r * 0.185, r * 0.88 - Math.abs(i - 2) * r * 0.03, r * 0.14, r * (0.12 + ((i * 5 + vi) % 3) * 0.04), false);
  g.fillStyle = '#7a0c12'; for (const sd of [-1, 1]) { g.beginPath(); g.moveTo(sd * r * 0.4, r * 0.8); g.quadraticCurveTo(sd * r * 0.5, r * 1.15, sd * r * 0.38, r * 1.3 + (sd > 0 ? r * 0.1 : 0)); g.quadraticCurveTo(sd * r * 0.28, r * 1.15, sd * r * 0.3, r * 0.85); g.fill(); g.beginPath(); g.arc(sd * r * 0.38, r * (1.3 + (sd > 0 ? 0.1 : 0)), r * 0.06, 0, TAU); g.fill(); }
  zBlood(g, 0, r * 0.95, r * 0.55, r * 0.25, 0.5);
  if (vi === 1) {   // torn cheek
    g.fillStyle = '#6a1015'; zSpikes(g, [[r * 0.45, r * 0.15], [r * 0.7, r * 0.2], [r * 0.82, r * 0.5], [r * 0.6, r * 0.72], [r * 0.4, r * 0.55], [r * 0.5, r * 0.4]]); g.fill();
    g.fillStyle = '#e8dfba'; for (let i = 0; i < 3; i++) g.fillRect(r * (0.5 + i * 0.09), r * 0.42, r * 0.06, r * 0.1);
  }
  // veins
  g.strokeStyle = 'rgba(70,35,90,0.45)'; g.lineWidth = r * 0.025;
  for (const [a, b] of [[-0.8, -0.2], [0.75, -0.5]]) { g.beginPath(); g.moveTo(r * a, r * b); g.bezierCurveTo(r * (a * 0.8), r * (b + 0.2), r * (a * 0.6), r * (b + 0.1), r * (a * 0.45), r * (b + 0.35)); g.stroke(); }
  // gear
  if (type === 'boss') {
    const cg = g.createLinearGradient(0, -r * 1.5, 0, -r * 0.8); cg.addColorStop(0, '#fff2a8'); cg.addColorStop(1, '#c98e12');
    g.fillStyle = cg; g.beginPath(); g.moveTo(-r * 0.75, -r * 0.8); for (let i = 0; i <= 4; i++) g.lineTo(-r * 0.75 + i * r * 0.375, -r * (i % 2 ? 1.0 : 1.55)); g.lineTo(r * 0.75, -r * 0.8); g.closePath(); g.fill(); g.strokeStyle = '#8a5d00'; g.lineWidth = r * 0.04; g.stroke();
    for (const x of [-0.75, 0, 0.75]) { g.fillStyle = '#ff2a4a'; g.beginPath(); g.arc(r * x * 0.7, -r * 0.93, r * 0.06, 0, TAU); g.fill(); }
  }
  if (type === 'armored') {
    const hg = g.createLinearGradient(-r, -r, r, 0); hg.addColorStop(0, '#d3d9e8'); hg.addColorStop(0.5, '#8a93a9'); hg.addColorStop(1, '#3a4152');
    g.fillStyle = hg; g.beginPath(); g.arc(0, -r * 0.1, r * 1.14, Math.PI, 0); g.fill(); g.fillRect(-r * 1.14, -r * 0.1, r * 2.28, r * 0.3);
    g.fillStyle = '#14171f'; g.fillRect(-r * 0.78, r * 0.0, r * 1.56, r * 0.14); g.fillStyle = 'rgba(255,255,255,0.4)'; g.fillRect(-r * 0.15, -r * 1.2, r * 0.3, r * 1.1);
    g.strokeStyle = 'rgba(0,0,0,0.4)'; g.lineWidth = r * 0.04; g.beginPath(); g.arc(0, -r * 0.1, r * 1.14, Math.PI, 0); g.stroke();
    g.fillStyle = '#e9edf7'; for (const x of [-0.8, 0.8]) { g.beginPath(); g.arc(r * x, -r * 0.1, r * 0.07, 0, TAU); g.fill(); }
  }
  if (type === 'spitter') { g.fillStyle = 'rgba(190,255,60,0.85)'; g.beginPath(); g.moveTo(-r * 0.15, r * 0.9); g.quadraticCurveTo(0, r * 1.5, r * 0.15, r * 0.9); g.fill(); }
  g.restore();

  // ---- lighting pass: cold moon-rim on the left, deep shadow on the right, grounded at the feet ----
  g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = 'source-atop';
  const lg = g.createLinearGradient(0, 0, cw, 0); lg.addColorStop(0, 'rgba(160,190,255,0.30)'); lg.addColorStop(0.28, 'rgba(160,190,255,0)'); lg.addColorStop(0.62, 'rgba(0,0,12,0)'); lg.addColorStop(1, 'rgba(0,0,14,0.42)');
  g.fillStyle = lg; g.fillRect(0, 0, cw, ch);
  const vg = g.createLinearGradient(0, ch * 0.5, 0, ch); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.4)'); g.fillStyle = vg; g.fillRect(0, 0, cw, ch);
  g.globalCompositeOperation = 'source-over';

  sp = { c, cw, ch, fx: cw / 2, fy: ch - 0.4 * u }; ZSPR.set(key, sp); return sp;
}

let ZSHADOW = null;
function zShadowSprite(){
  if (ZSHADOW) return ZSHADOW;
  const c = document.createElement('canvas'); c.width = 128; c.height = 32; const g = c.getContext('2d');
  const gr = g.createRadialGradient(64, 16, 0, 64, 16, 64); gr.addColorStop(0, 'rgba(0,0,0,0.65)'); gr.addColorStop(0.6, 'rgba(0,0,0,0.3)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
  g.save(); g.scale(1, 0.25); g.fillStyle = gr; g.beginPath(); g.arc(64, 64, 64, 0, TAU); g.fill(); g.restore();
  return ZSHADOW = c;
}
let ZSPLAT = null;
function zSplatSprite(){
  if (ZSPLAT) return ZSPLAT;
  const c = document.createElement('canvas'); c.width = 160; c.height = 50; const g = c.getContext('2d'), rnd = mulberry32(77);
  g.save(); g.scale(1, 0.31);
  for (let i = 0; i < 14; i++) { const a = rnd() * TAU, d = rnd() * 40, x = 80 + Math.cos(a) * d * 1.4, y = 80 + Math.sin(a) * d, rr = 8 + rnd() * 24; const gr = g.createRadialGradient(x, y, 0, x, y, rr); gr.addColorStop(0, 'rgba(90,8,12,0.9)'); gr.addColorStop(0.7, 'rgba(70,6,10,0.6)'); gr.addColorStop(1, 'rgba(60,5,8,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, rr, 0, TAU); g.fill(); }
  g.restore();
  for (let i = 0; i < 10; i++) { g.fillStyle = 'rgba(90,10,14,0.8)'; g.beginPath(); g.arc(rnd() * 160, 8 + rnd() * 34, 1 + rnd() * 2.4, 0, TAU); g.fill(); }
  return ZSPLAT = c;
}

// Used by the menu icon and anything else that wants a zombie
function drawZombieBody(z, X, Y, h, alpha){
  if (!z.T) z.T = ZTYPES[z.type] || ZTYPES.walker;
  const sp = zombieSprite(z), k = (h / 10) / ZU, fl = z.flash > 0;
  ctx.save(); ctx.globalAlpha = alpha; ctx.translate(X, Y);
  const sh = zShadowSprite(), sw = h * 0.62 * (z.type === 'bloater' ? 1.5 : z.type === 'brute' || z.type === 'boss' ? 1.2 : 1); ctx.drawImage(sh, -sw / 2, -sw * 0.125, sw, sw * 0.25);
  if (z.dead) { const d = Math.min(1, z.deathT / 0.45); ctx.rotate(d * 1.35 * (z.fallDir || 1)); ctx.scale(1, 1 - d * 0.15); }
  if (z.lunge) ctx.scale(1 + z.lunge * 0.1, 1 + z.lunge * 0.1);
  if (z.lean) ctx.rotate(z.lean);
  ctx.drawImage(sp.c, -sp.fx * k, -sp.fy * k, sp.cw * k, sp.ch * k);
  if (fl) { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = alpha * 0.75; ctx.drawImage(sp.c, -sp.fx * k, -sp.fy * k, sp.cw * k, sp.ch * k); }
  ctx.restore();
}

// Extra live effects on top of a zombie: glowing eyes, boss aura, bloater pulse, spitter acid charge, wounds
function drawZombieFx(z, alpha){
  const b = z.box; if (!b || z.dead) return;
  const hr = b.hr, ex = [[b.hx - hr * 0.38 + hr * 0.02, b.hy - hr * 0.1], [b.hx + hr * 0.4 + hr * 0.02, b.hy - hr * 0.06]];
  const col = z.type === 'boss' || z.type === 'runner' || z.type === 'crawler' ? '255,40,40' : z.type === 'spitter' ? '200,255,60' : '255,215,60', fl = 0.85 + 0.15 * Math.sin(sceneT * 9 + z.phase * 3);
  ctx.globalCompositeOperation = 'lighter';
  for (const [x, y] of ex) { const gr = ctx.createRadialGradient(x, y, 0, x, y, hr * 0.7); gr.addColorStop(0, `rgba(${col},${0.7 * alpha * fl})`); gr.addColorStop(1, `rgba(${col},0)`); ctx.fillStyle = gr; ctx.fillRect(x - hr * 0.7, y - hr * 0.7, hr * 1.4, hr * 1.4); }
  if (z.type === 'boss') { const gr = ctx.createRadialGradient(b.x, b.y - b.h * 0.5, b.h * 0.1, b.x, b.y - b.h * 0.5, b.h * 0.8); const p = 0.5 + 0.5 * Math.sin(sceneT * 3); gr.addColorStop(0, `rgba(170,60,255,${0.16 * alpha * (0.6 + 0.4 * p)})`); gr.addColorStop(1, 'rgba(170,60,255,0)'); ctx.fillStyle = gr; ctx.fillRect(b.x - b.h * 0.8, b.y - b.h * 1.3, b.h * 1.6, b.h * 1.6); }
  if (z.type === 'bloater') { const p = 0.5 + 0.5 * Math.sin((z.phase || 0) * 1.6), gr = ctx.createRadialGradient(b.x, b.y - b.h * 0.48, 0, b.x, b.y - b.h * 0.48, b.h * 0.32); gr.addColorStop(0, `rgba(214,255,74,${(0.18 + 0.2 * p) * alpha})`); gr.addColorStop(1, 'rgba(214,255,74,0)'); ctx.fillStyle = gr; ctx.fillRect(b.x - b.h * 0.34, b.y - b.h * 0.85, b.h * 0.68, b.h * 0.7); }
  if (z.type === 'spitter' && z.charge > 0) { const gr = ctx.createRadialGradient(b.hx, b.hy + hr * 0.55, 0, b.hx, b.hy + hr * 0.55, hr * (0.5 + 0.9 * z.charge)); gr.addColorStop(0, `rgba(190,255,60,${(0.5 + 0.4 * z.charge) * alpha})`); gr.addColorStop(1, 'rgba(190,255,60,0)'); ctx.fillStyle = gr; ctx.fillRect(b.hx - hr * 1.6, b.hy - hr * 0.8, hr * 3.2, hr * 3); }
  ctx.globalCompositeOperation = 'source-over';
  // fresh wounds as it takes damage
  const dmg = 1 - z.hp / z.maxHp;
  if (dmg > 0.2 && z.type !== 'boss') {
    ctx.globalAlpha = alpha * 0.8; const n = dmg > 0.7 ? 4 : dmg > 0.45 ? 3 : 2; const s = mulberry32((z.vi || 0) * 31 + 5);
    for (let i = 0; i < n; i++) { const x = b.x + (s() - 0.5) * b.h * 0.28, y = b.y - b.h * (0.25 + s() * 0.5), rr = b.h * (0.03 + s() * 0.02); const gr = ctx.createRadialGradient(x, y, 0, x, y, rr); gr.addColorStop(0, 'rgba(60,4,8,0.95)'); gr.addColorStop(1, 'rgba(110,10,16,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, rr, 0, TAU); ctx.fill(); }
    ctx.globalAlpha = 1;
  }
}

/* ---------------- guns ---------------- */
const ZGUN = {};
function zGunSprite(k){
  if (ZGUN[k]) return ZGUN[k];
  const acc = HAND_COLORS[k], c = document.createElement('canvas'); c.width = 980; c.height = 320; const g = c.getContext('2d'), cy = 150;
  g.lineJoin = 'round'; g.lineCap = 'round';
  const metal = (x0, y0, x1, y1, tone = 0) => { const gr = g.createLinearGradient(0, y0, 0, y1); gr.addColorStop(0, zShade('#aab3c8', tone)); gr.addColorStop(0.18, zShade('#6c768e', tone)); gr.addColorStop(0.55, zShade('#2f3548', tone)); gr.addColorStop(1, zShade('#141826', tone)); return gr; };
  // sleeve + glove (the player's arm, coming from the screen corner)
  const sl = g.createLinearGradient(0, cy - 70, 0, cy + 80); sl.addColorStop(0, '#3a4468'); sl.addColorStop(0.5, '#222842'); sl.addColorStop(1, '#0f1222');
  g.fillStyle = sl; g.beginPath(); g.moveTo(0, cy - 66); g.lineTo(300, cy - 52); g.lineTo(310, cy + 76); g.lineTo(0, cy + 90); g.closePath(); g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.1)'; g.lineWidth = 3; for (let x = 60; x < 280; x += 70) { g.beginPath(); g.moveTo(x, cy - 62 + x * 0.047); g.lineTo(x + 6, cy + 84); g.stroke(); }
  g.fillStyle = acc; g.globalAlpha = 0.9; g.fillRect(0, cy - 14, 300, 6); g.globalAlpha = 1;
  const cf = g.createLinearGradient(0, cy - 60, 0, cy + 80); cf.addColorStop(0, '#2a2f42'); cf.addColorStop(1, '#0c0e18'); g.fillStyle = cf; roundRect(262, cy - 62, 70, 142, 14, g); g.fill(); g.strokeStyle = acc; g.lineWidth = 4; g.stroke();
  // magazine
  const mg = g.createLinearGradient(430, 0, 500, 0); mg.addColorStop(0, '#2c3347'); mg.addColorStop(0.5, '#4a5470'); mg.addColorStop(1, '#161a28');
  g.fillStyle = mg; g.beginPath(); g.moveTo(425, cy + 24); g.lineTo(505, cy + 24); g.lineTo(522, cy + 168); g.lineTo(440, cy + 172); g.closePath(); g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.12)'; g.lineWidth = 3; for (let i = 0; i < 5; i++) { g.beginPath(); g.moveTo(432 + i * 3, cy + 54 + i * 22); g.lineTo(508 + i * 3, cy + 54 + i * 22); g.stroke(); }
  g.fillStyle = acc; g.globalAlpha = 0.85; g.fillRect(452, cy + 40, 10, 100); g.globalAlpha = 1;
  // lower frame + trigger guard
  g.fillStyle = metal(0, cy + 6, 0, cy + 40, -0.25); roundRect(340, cy + 2, 400, 40, 12, g); g.fill();
  g.strokeStyle = '#10131f'; g.lineWidth = 10; g.beginPath(); g.moveTo(560, cy + 38); g.quadraticCurveTo(570, cy + 100, 625, cy + 96); g.quadraticCurveTo(675, cy + 92, 668, cy + 38); g.stroke();
  g.strokeStyle = '#3a4260'; g.lineWidth = 4; g.stroke();
  g.fillStyle = '#c6cde0'; g.beginPath(); g.moveTo(618, cy + 38); g.lineTo(640, cy + 38); g.lineTo(632, cy + 84); g.lineTo(614, cy + 80); g.closePath(); g.fill();
  // glove gripping the pistol grip (behind the frame edge, over the magazine well)
  const gg = g.createLinearGradient(0, cy - 40, 0, cy + 120); gg.addColorStop(0, '#2c3149'); gg.addColorStop(0.6, '#171a2a'); gg.addColorStop(1, '#0a0c16');
  g.fillStyle = gg; roundRect(334, cy - 28, 170, 120, 34, g); g.fill(); g.strokeStyle = 'rgba(255,255,255,0.14)'; g.lineWidth = 3; g.stroke();
  g.strokeStyle = '#0a0c16'; g.lineWidth = 6; for (let i = 0; i < 4; i++) { g.beginPath(); g.moveTo(392 + i * 26, cy + 6 + i * 2); g.lineTo(404 + i * 26, cy + 82); g.stroke(); }
  g.fillStyle = acc; g.globalAlpha = 0.85; roundRect(350, cy - 22, 78, 14, 6, g); g.fill(); g.globalAlpha = 1;
  g.fillStyle = '#10131f'; roundRect(468, cy - 50, 120, 36, 16, g); g.fill(); g.strokeStyle = 'rgba(255,255,255,0.16)'; g.lineWidth = 3; g.stroke();      // thumb
  // barrel shroud + muzzle brake
  g.fillStyle = metal(0, cy - 36, 0, cy - 2, -0.1); roundRect(700, cy - 36, 130, 34, 8, g); g.fill();
  g.fillStyle = '#0d101a'; for (let i = 0; i < 5; i++) g.fillRect(716 + i * 22, cy - 30, 8, 22);
  g.fillStyle = metal(0, cy - 40, 0, cy - 0, -0.4); roundRect(826, cy - 42, 78, 42, 6, g); g.fill();
  g.fillStyle = '#05060a'; for (let i = 0; i < 3; i++) g.fillRect(840 + i * 20, cy - 42, 8, 14);
  g.fillStyle = '#04050a'; g.beginPath(); g.ellipse(904, cy - 21, 6, 17, 0, 0, TAU); g.fill();
  // slide: the main body
  const sg = metal(0, cy - 66, 0, cy - 4); g.fillStyle = sg; roundRect(342, cy - 64, 430, 64, 14, g); g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.65)'; g.lineWidth = 3; g.beginPath(); g.moveTo(364, cy - 62); g.lineTo(750, cy - 62); g.stroke();
  g.strokeStyle = 'rgba(0,0,0,0.5)'; g.lineWidth = 3; g.beginPath(); g.moveTo(360, cy - 4); g.lineTo(760, cy - 4); g.stroke();
  g.fillStyle = 'rgba(0,0,0,0.5)'; for (let i = 0; i < 7; i++) g.fillRect(362 + i * 13, cy - 56, 5, 46);                           // rear serrations
  g.fillStyle = '#0a0c14'; roundRect(520, cy - 58, 110, 22, 5, g); g.fill();                                                          // ejection port
  g.fillStyle = '#b8892a'; g.fillRect(540, cy - 52, 66, 8);
  // glowing accent strip
  g.save(); g.shadowColor = acc; g.shadowBlur = 22; g.fillStyle = acc; roundRect(430, cy - 28, 300, 7, 3, g); g.fill(); g.restore();
  g.fillStyle = '#fff'; g.globalAlpha = 0.8; g.fillRect(440, cy - 26, 280, 2); g.globalAlpha = 1;
  // top rail, sights
  g.fillStyle = '#12151f'; g.fillRect(380, cy - 76, 360, 14); g.fillStyle = 'rgba(255,255,255,0.25)'; for (let i = 0; i < 18; i++) g.fillRect(388 + i * 20, cy - 74, 8, 3);
  g.fillStyle = '#10131c'; g.fillRect(372, cy - 94, 12, 26); g.fillRect(420, cy - 94, 12, 26); g.fillStyle = acc; g.fillRect(396, cy - 88, 8, 8);
  g.fillStyle = '#10131c'; g.beginPath(); g.moveTo(812, cy - 42); g.lineTo(820, cy - 90); g.lineTo(830, cy - 42); g.closePath(); g.fill(); g.save(); g.shadowColor = acc; g.shadowBlur = 14; g.fillStyle = acc; g.beginPath(); g.arc(820, cy - 88, 6, 0, TAU); g.fill(); g.restore();
  // laser module
  g.fillStyle = metal(0, cy + 2, 0, cy + 36, -0.3); roundRect(690, cy + 2, 110, 38, 8, g); g.fill(); g.save(); g.shadowColor = '#ff2a2a'; g.shadowBlur = 14; g.fillStyle = '#ff4a4a'; g.beginPath(); g.arc(796, cy + 22, 7, 0, TAU); g.fill(); g.restore();
  g.fillStyle = 'rgba(255,255,255,0.55)'; g.font = '800 17px system-ui, sans-serif'; g.textBaseline = 'middle'; g.fillText(k === 0 ? 'MP-9 · L' : k === 1 ? 'MP-9 · R' : 'MP-9', 560, cy - 18);
  // gloss
  const gl = g.createLinearGradient(342, 0, 772, 0); gl.addColorStop(0, 'rgba(255,255,255,0)'); gl.addColorStop(0.5, 'rgba(255,255,255,0.18)'); gl.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gl; roundRect(342, cy - 64, 430, 22, 12, g); g.fill();
  return ZGUN[k] = { c, muzzle: 912, pivot: 330, cy };
}

function zDrawGun(sc, g, k){
  const [ox, oy] = sc.gunOrigin(k), a = Math.atan2(g.y - oy, g.x - ox), sp = zGunSprite(k), Ltot = H * 0.46, s = Ltot / sp.muzzle;
  const rec = g.recoil;
  ctx.save(); ctx.translate(ox, oy); ctx.rotate(a); ctx.translate(-rec * H * 0.03, 0); ctx.rotate(-rec * 0.02 * (k === 1 ? -1 : 1));
  ctx.globalAlpha = 0.97;
  // soft shadow under the weapon
  ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.ellipse(Ltot * 0.45, H * 0.02, Ltot * 0.5, H * 0.012, 0, 0, TAU); ctx.fill();
  ctx.drawImage(sp.c, -sp.pivot * s * 0.0, -sp.cy * s, sp.c.width * s, sp.c.height * s);
  ctx.globalAlpha = 1;
  const mx = sp.muzzle * s, my = (-21) * s + 0;
  if (g.flash > 0) {
    const f = g.flash / 0.06, col = HAND_COLORS[k]; ctx.globalCompositeOperation = 'lighter';
    const gl = ctx.createRadialGradient(mx, my, 0, mx, my, H * 0.2); gl.addColorStop(0, `rgba(255,240,190,${0.55 * f})`); gl.addColorStop(0.35, `rgba(255,170,60,${0.28 * f})`); gl.addColorStop(1, 'rgba(255,120,20,0)'); ctx.fillStyle = gl; ctx.fillRect(mx - H * 0.2, my - H * 0.2, H * 0.4, H * 0.4);
    ctx.fillStyle = `rgba(255,248,210,${f})`; ctx.beginPath();
    const n = 9, R0 = H * 0.035 * (0.7 + 0.5 * f), R1 = H * 0.11 * (0.6 + 0.6 * f);
    for (let i = 0; i < n * 2; i++) { const ang = i / (n * 2) * TAU + g.spin * 0.0 + (g.shotN || 0) * 1.7, rr = i % 2 ? R0 : R1 * (0.6 + 0.4 * ((i * 37) % 5) / 4); const px = mx + Math.cos(ang) * rr * (Math.cos(ang) > 0 ? 1.5 : 0.5), py = my + Math.sin(ang) * rr * 0.65; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = col; ctx.globalAlpha = 0.6 * f; ctx.beginPath(); ctx.arc(mx + H * 0.012, my, H * 0.03 * f + 3, 0, TAU); ctx.fill(); ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.restore();
  // laser sight to the aim point
  const mxw = ox + Math.cos(a) * Ltot, myw = oy + Math.sin(a) * Ltot;
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = g.lock ? 'rgba(255,70,70,0.35)' : 'rgba(255,60,60,0.16)'; ctx.lineWidth = Math.max(1.5, H * 0.0022); ctx.setLineDash([H * 0.012, H * 0.008]); ctx.beginPath(); ctx.moveTo(mxw, myw); ctx.lineTo(g.x, g.y); ctx.stroke(); ctx.restore();
}

function zDrawCrosshair(sc, g, k){
  const r = H * (0.036 + g.recoil * 0.01), col = g.lock ? '#ff4a4a' : HAND_COLORS[k];
  ctx.save(); ctx.translate(g.x, g.y);
  ctx.lineCap = 'round';
  ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = H * 0.012; for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + g.spin * 0.5 + 0.35; ctx.beginPath(); ctx.arc(0, 0, r, a, a + 1.0); ctx.stroke(); }
  ctx.strokeStyle = col; ctx.lineWidth = H * 0.0065; for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + g.spin * 0.5 + 0.35; ctx.beginPath(); ctx.arc(0, 0, r, a, a + 1.0); ctx.stroke(); }
  ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = H * 0.011; ctx.beginPath(); for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; ctx.moveTo(Math.cos(a) * r * 1.25, Math.sin(a) * r * 1.25); ctx.lineTo(Math.cos(a) * r * 1.7, Math.sin(a) * r * 1.7); } ctx.stroke();
  ctx.strokeStyle = col; ctx.lineWidth = H * 0.0055; ctx.beginPath(); for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; ctx.moveTo(Math.cos(a) * r * 1.25, Math.sin(a) * r * 1.25); ctx.lineTo(Math.cos(a) * r * 1.7, Math.sin(a) * r * 1.7); } ctx.stroke();
  if (g.lock) { ctx.strokeStyle = 'rgba(255,90,90,0.9)'; ctx.lineWidth = H * 0.005; const q = r * 0.78; for (const [sx, sy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) { ctx.beginPath(); ctx.moveTo(sx * q, sy * q * 0.45); ctx.lineTo(sx * q, sy * q); ctx.lineTo(sx * q * 0.45, sy * q); ctx.stroke(); } }
  ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, 0, H * (g.lock ? 0.009 : 0.006), 0, TAU); ctx.fill();
  ctx.globalAlpha = 0.25; ctx.beginPath(); ctx.arc(0, 0, H * 0.02, 0, TAU); ctx.fill();
  ctx.restore();
}

/* ---------------- pickups ---------------- */
let ZMED = null, ZBOOST = null;
function zMedSprite(){
  if (ZMED) return ZMED;
  const S = 260, c = document.createElement('canvas'); c.width = S; c.height = S; const g = c.getContext('2d'); g.lineJoin = 'round'; g.lineCap = 'round';
  const x = 30, y = 70, w = 200, h = 140, d = 26;
  // side + top faces for depth
  const topg = g.createLinearGradient(0, y - d, 0, y); topg.addColorStop(0, '#ffffff'); topg.addColorStop(1, '#cfd6e2');
  g.fillStyle = topg; g.beginPath(); g.moveTo(x + 16, y); g.lineTo(x + 16 + 14, y - d); g.lineTo(x + w - 2, y - d); g.lineTo(x + w + 14 - 18, y - d + 4); g.lineTo(x + w, y); g.closePath(); g.fill();
  const sg = g.createLinearGradient(x + w, 0, x + w + 24, 0); sg.addColorStop(0, '#b4bccb'); sg.addColorStop(1, '#6d7688'); g.fillStyle = sg; g.beginPath(); g.moveTo(x + w, y); g.lineTo(x + w + 22, y - d + 6); g.lineTo(x + w + 22, y + h - d + 6); g.lineTo(x + w, y + h); g.closePath(); g.fill();
  // handle
  g.strokeStyle = '#4b5366'; g.lineWidth = 12; g.beginPath(); g.moveTo(x + 62, y - d + 6); g.quadraticCurveTo(x + 62, y - d - 34, x + 100, y - d - 34); g.quadraticCurveTo(x + 150, y - d - 34, x + 150, y - d + 6); g.stroke();
  g.strokeStyle = '#99a3b8'; g.lineWidth = 5; g.stroke();
  // front face
  const fg = g.createLinearGradient(0, y, 0, y + h); fg.addColorStop(0, '#ffffff'); fg.addColorStop(0.55, '#e4e8f0'); fg.addColorStop(1, '#a9b2c3');
  g.fillStyle = fg; roundRect(x, y, w, h, 20, g); g.fill(); g.strokeStyle = '#7d879b'; g.lineWidth = 4; g.stroke();
  g.fillStyle = 'rgba(0,0,0,0.08)'; g.fillRect(x + 4, y + h * 0.5, w - 8, 3);                                // lid seam
  // latches
  for (const lx of [x + 34, x + w - 56]) { const lg = g.createLinearGradient(lx, 0, lx + 22, 0); lg.addColorStop(0, '#dde2ec'); lg.addColorStop(1, '#7b8498'); g.fillStyle = lg; roundRect(lx, y + h * 0.43, 22, 26, 5, g); g.fill(); g.strokeStyle = '#59627a'; g.lineWidth = 2; g.stroke(); }
  // embossed red cross
  const cg = g.createLinearGradient(0, y + 25, 0, y + h - 18); cg.addColorStop(0, '#ff6676'); cg.addColorStop(0.5, '#e11d34'); cg.addColorStop(1, '#8f0c1c');
  const cx = x + w / 2, cy2 = y + h * 0.54, a = 22, l = 52;
  g.save(); g.shadowColor = 'rgba(0,0,0,0.35)'; g.shadowBlur = 8; g.shadowOffsetY = 4; g.fillStyle = cg; roundRect(cx - a, cy2 - l, a * 2, l * 2, 7, g); g.fill(); roundRect(cx - l, cy2 - a, l * 2, a * 2, 7, g); g.fill(); g.restore();
  g.strokeStyle = 'rgba(255,255,255,0.55)'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx - a + 3, cy2 - l + 6); g.lineTo(cx - a + 3, cy2 - a + 2); g.lineTo(cx - l + 6, cy2 - a + 3); g.stroke();
  // gloss streak
  const gs = g.createLinearGradient(x, y, x + w, y + h * 0.5); gs.addColorStop(0, 'rgba(255,255,255,0.55)'); gs.addColorStop(0.5, 'rgba(255,255,255,0.05)'); gs.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gs; roundRect(x + 6, y + 6, w - 12, h * 0.38, 14, g); g.fill();
  // scuffs
  g.strokeStyle = 'rgba(80,80,90,0.25)'; g.lineWidth = 2; for (const [a1, b1, a2, b2] of [[20, 110, 50, 100], [170, 40, 190, 52], [150, 120, 178, 112]]) { g.beginPath(); g.moveTo(x + a1, y + b1); g.lineTo(x + a2, y + b2); g.stroke(); }
  return ZMED = c;
}
function zBoostSprite(){
  if (ZBOOST) return ZBOOST;
  const S = 260, c = document.createElement('canvas'); c.width = S; c.height = S; const g = c.getContext('2d'); g.lineJoin = 'round'; const cx = S / 2, cy = S / 2;
  // metal hex housing
  const hexp = (r, off = 0) => { g.beginPath(); for (let i = 0; i < 6; i++) { const a = i * TAU / 6 + off; i ? g.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r) : g.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); } g.closePath(); };
  const hg = g.createLinearGradient(cx - 100, cy - 100, cx + 100, cy + 100); hg.addColorStop(0, '#6c5aa8'); hg.addColorStop(0.45, '#2a1d52'); hg.addColorStop(1, '#0c0720');
  hexp(108, Math.PI / 6); g.fillStyle = hg; g.fill(); g.strokeStyle = '#d9b8ff'; g.lineWidth = 5; g.stroke();
  hexp(90, Math.PI / 6); g.fillStyle = '#120a2c'; g.fill(); g.strokeStyle = '#ffd23f'; g.lineWidth = 4; g.stroke();
  for (let i = 0; i < 6; i++) { const a = i * TAU / 6; g.fillStyle = '#ffd23f'; g.beginPath(); g.arc(cx + Math.cos(a) * 99, cy + Math.sin(a) * 99, 5, 0, TAU); g.fill(); }
  // glass dome
  const dg = g.createRadialGradient(cx - 22, cy - 28, 6, cx, cy, 78); dg.addColorStop(0, '#fff6bf'); dg.addColorStop(0.35, '#ffc23a'); dg.addColorStop(1, '#a24a06');
  g.fillStyle = dg; g.beginPath(); g.arc(cx, cy, 74, 0, TAU); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.4)'; g.beginPath(); g.ellipse(cx - 24, cy - 38, 38, 20, -0.5, 0, TAU); g.fill();
  // lightning bolt
  g.save(); g.shadowColor = '#fff'; g.shadowBlur = 14; g.fillStyle = '#fffdf0';
  g.beginPath(); g.moveTo(cx + 12, cy - 60); g.lineTo(cx - 34, cy + 6); g.lineTo(cx - 4, cy + 6); g.lineTo(cx - 16, cy + 60); g.lineTo(cx + 36, cy - 12); g.lineTo(cx + 4, cy - 12); g.closePath(); g.fill(); g.restore();
  g.strokeStyle = '#a25a00'; g.lineWidth = 3; g.stroke();
  return ZBOOST = c;
}

function zPill(txt, x, y, size, col, bg){
  ctx.font = `800 ${Math.round(size)}px system-ui, sans-serif`; const w = ctx.measureText(txt).width + size * 1.4, h = size * 1.7;
  roundRect(x - w / 2, y - h / 2, w, h, h / 2); ctx.fillStyle = bg; ctx.fill(); ctx.strokeStyle = col; ctx.lineWidth = Math.max(1.5, size * 0.07); ctx.stroke();
  text(txt, x, y + size * 0.03, size, col);
}
function zRing(x, y, r, k, col, w){
  ctx.lineCap = 'round'; ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = w + 4; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke();
  ctx.strokeStyle = col; ctx.lineWidth = w; ctx.shadowColor = col; ctx.shadowBlur = 14; ctx.beginPath(); ctx.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 + TAU * k); ctx.stroke(); ctx.shadowBlur = 0;
}

function zDrawMedkit(m){
  const s = H * 0.062, bob = Math.sin(m.t * 2.6) * H * 0.008, a = m.t > 11 ? (Math.sin(m.t * 15) > 0 ? 1 : 0.35) : 1, x = m.x, y = m.y + bob, spr = zMedSprite(), sc = s * 2.6 / 260;
  ctx.save(); ctx.globalAlpha = a;
  ctx.globalCompositeOperation = 'lighter';
  const p = 0.5 + 0.5 * Math.sin(m.t * 4), gr = ctx.createRadialGradient(x, y, 0, x, y, s * (2.6 + p * 0.4)); gr.addColorStop(0, 'rgba(80,255,150,0.5)'); gr.addColorStop(0.5, 'rgba(60,220,120,0.2)'); gr.addColorStop(1, 'rgba(60,220,120,0)'); ctx.fillStyle = gr; ctx.fillRect(x - s * 3.2, y - s * 3.2, s * 6.4, s * 6.4);
  for (let i = 0; i < 2; i++) { const k = ((m.t * 0.7 + i * 0.5) % 1); ctx.globalAlpha = a * (1 - k) * 0.5; ctx.strokeStyle = '#6dffb0'; ctx.lineWidth = H * 0.004; ctx.beginPath(); ctx.ellipse(x, y + s * 1.25, s * (1 + k * 1.4), s * (0.25 + k * 0.35), 0, 0, TAU); ctx.stroke(); }
  ctx.globalAlpha = a; ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(x, y + s * 1.2, s * 1.05, s * 0.22, 0, 0, TAU); ctx.fill();
  ctx.save(); ctx.translate(x, y); ctx.rotate(Math.sin(m.t * 1.6) * 0.06); ctx.drawImage(spr, -130 * sc, -130 * sc, 260 * sc, 260 * sc);
  // travelling shine
  ctx.beginPath(); ctx.rect(-130 * sc + 30 * sc, -60 * sc, 200 * sc, 140 * sc); ctx.clip(); const sh = ((m.t * 0.6) % 1.6 - 0.3) * 260 * sc - 130 * sc; const lg = ctx.createLinearGradient(sh - 40 * sc, 0, sh + 40 * sc, 0); lg.addColorStop(0, 'rgba(255,255,255,0)'); lg.addColorStop(0.5, 'rgba(255,255,255,0.55)'); lg.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = lg; ctx.fillRect(-130 * sc, -80 * sc, 260 * sc, 170 * sc);
  ctx.restore();
  // sparkles
  ctx.globalCompositeOperation = 'lighter'; for (let i = 0; i < 5; i++) { const t = (m.t * 0.9 + i * 0.37) % 1, ang = i * 1.9 + m.t * 0.6, px = x + Math.cos(ang) * s * 1.5, py = y - t * s * 1.9 + Math.sin(ang) * s * 0.3; ctx.globalAlpha = a * (1 - t) * 0.9; ctx.fillStyle = '#c9ffe0'; ctx.beginPath(); ctx.moveTo(px, py - s * 0.1); ctx.lineTo(px + s * 0.03, py); ctx.lineTo(px, py + s * 0.1); ctx.lineTo(px - s * 0.03, py); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.moveTo(px - s * 0.1, py); ctx.lineTo(px, py + s * 0.03); ctx.lineTo(px + s * 0.1, py); ctx.lineTo(px, py - s * 0.03); ctx.closePath(); ctx.fill(); }
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = a;
  if (m.hold > 0) zRing(x, y, s * 1.7, Math.min(1, m.hold / 0.6), '#4fd27a', H * 0.009);
  zPill('HOVER TO HEAL  +30', x, y + s * 2.35, H * 0.024, '#c9ffd9', 'rgba(8,40,24,0.75)');
  ctx.restore();
}
function zDrawBoost(m){
  const s = H * 0.062 * (1 + Math.sin(m.t * 7) * 0.05), bob = Math.sin(m.t * 3) * H * 0.008, a = m.t > 7 ? (Math.sin(m.t * 18) > 0 ? 1 : 0.35) : 1, x = m.x, y = m.y + bob, spr = zBoostSprite(), sc = s * 2.3 / 260;
  ctx.save(); ctx.globalAlpha = a; ctx.globalCompositeOperation = 'lighter';
  const p = 0.5 + 0.5 * Math.sin(m.t * 8), gr = ctx.createRadialGradient(x, y, 0, x, y, s * (3 + p * 0.5)); gr.addColorStop(0, 'rgba(255,200,60,0.55)'); gr.addColorStop(0.45, 'rgba(255,120,20,0.22)'); gr.addColorStop(1, 'rgba(255,120,20,0)'); ctx.fillStyle = gr; ctx.fillRect(x - s * 3.6, y - s * 3.6, s * 7.2, s * 7.2);
  // orbiting rings
  for (let i = 0; i < 2; i++) { ctx.strokeStyle = i ? 'rgba(255,230,120,0.7)' : 'rgba(255,150,40,0.7)'; ctx.lineWidth = H * 0.0035; ctx.beginPath(); ctx.ellipse(x, y, s * 1.7, s * 0.55, m.t * (i ? 2.2 : -1.6) + i * 1.2, 0, TAU); ctx.stroke(); }
  // electric arcs
  ctx.strokeStyle = 'rgba(255,245,170,0.9)'; ctx.lineWidth = H * 0.003; for (let i = 0; i < 4; i++) { if (Math.sin(m.t * 20 + i * 3.1) < -0.2) continue; const a0 = m.t * 3 + i * TAU / 4; ctx.beginPath(); let px = x + Math.cos(a0) * s * 1.1, py = y + Math.sin(a0) * s * 1.1; ctx.moveTo(px, py); for (let j = 1; j <= 4; j++) { const rr = s * (1.1 + j * 0.28), jit = (Math.sin(m.t * 37 + i * 9 + j * 5)) * s * 0.18; ctx.lineTo(x + Math.cos(a0 + jit / s * 0.4) * rr + jit, y + Math.sin(a0 + jit / s * 0.4) * rr - jit * 0.4); } ctx.stroke(); }
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(x, y + s * 1.3, s * 0.95, s * 0.2, 0, 0, TAU); ctx.fill();
  ctx.save(); ctx.translate(x, y); ctx.rotate(Math.sin(m.t * 1.7) * 0.08); ctx.drawImage(spr, -130 * sc, -130 * sc, 260 * sc, 260 * sc); ctx.restore();
  ctx.globalCompositeOperation = 'lighter'; for (let i = 0; i < 6; i++) { const t = (m.t * 1.1 + i * 0.17) % 1, ang = i * 1.05 + m.t * 1.3; ctx.globalAlpha = a * (1 - t); ctx.fillStyle = '#ffe27a'; ctx.beginPath(); ctx.arc(x + Math.cos(ang) * s * (1 + t * 1.3), y + Math.sin(ang) * s * (1 + t * 1.3) - t * s * 0.4, s * 0.06, 0, TAU); ctx.fill(); }
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = a;
  if (m.hold > 0) zRing(x, y, s * 1.75, Math.min(1, m.hold / 0.35), '#ffe14a', H * 0.009);
  zPill('POWER BOOST  ×2 DAMAGE', x, y + s * 2.45, H * 0.024, '#ffe9a8', 'rgba(50,28,6,0.78)');
  ctx.restore();
}
