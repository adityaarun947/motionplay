/* =====================================================================
   ZOMBIE SIEGE — aim with your hands; hovering over a zombie fires.
   5 hits kill a normal zombie. Survive the waves.
   ===================================================================== */
const Z_NEAR = 2.4, Z_FRONT = 1.35, Z_SPAWN = 18;   // zombies become shootable once they're out of the fog (z < Z_SPAWN - 2)
const ZTYPES = {
  walker:{ hp:5,  speed:1.0,  size:1.0,  dmg:6,  score:100,  skin:['#7fb069', '#8fbf6a', '#6fa35a'], shirt:['#5a6b8c', '#7a5c3e', '#4f7a6b', '#8c5a6b'] },
  runner:{ hp:4,  speed:2.0,  size:0.92, dmg:5,  score:150,  skin:['#a3c46a', '#b5cf73'], shirt:['#d9b23a', '#c98a2c'] },
  brute: { hp:14, speed:0.72, size:1.3,  dmg:12, score:350,  skin:['#5f8f55', '#6a9a4f'], shirt:['#a63d3d', '#8c2f2f'] },
  boss:  { hp:45, speed:0.5,  size:1.6,  dmg:22, score:2000, skin:['#4f7f6a'], shirt:['#5b2a86'] },
  crawler:{ hp:3, speed:2.3,  size:0.62, dmg:4,  score:120,  skin:['#8fb86a', '#a1c27a'], shirt:['#6b5a8c', '#8c6b5a'] },   // small, scuttles fast
  spitter:{ hp:4, speed:1.0,  size:0.98, dmg:0,  score:220,  skin:['#c3d83c', '#b4cc3a'], shirt:['#3f6b4f', '#5a7f3c'] },   // stays back and spits acid you can shoot down
  armored:{ hp:9, speed:0.85, size:1.08, dmg:9,  score:300,  skin:['#7fb069'], shirt:['#6a7284', '#58606f'] },              // helmet: headshots are NOT double
  bloater:{ hp:11, speed:0.6, size:1.2,  dmg:10, score:260,  skin:['#9fc45a', '#a8c860'], shirt:['#8a7a4a', '#7a6a3e'] },   // pops in a blast that hurts other zombies
};
const GUN_RATE = 0.17;     // seconds between shots per hand

scenes.zombie = {
  game:true, music:'zombie', hint:'Point your hands at the zombies — hovering fires! Raise both hands for a grenade',
  ownCursors:true,
  enter(){
    Object.assign(this, { zombies:[], parts:[], pops:[], decals:[], tracers:[], banners:[], spits:[], splat:0, lvlT:0,
      wave:0, waveState:'ready', waveT:3.2, toSpawn:[], spawnT:0, hp:100, score:0, kills:0, t:0,
      streak:0, lastKill:-9, grenade:0.6, upHold:0, blast:null, shake:0, hurt:0, flash:0, medkit:null, boostIcon:null, boostT:0, boostCool:25, groanT:2,
      guns:[0, 1, 2].map(() => ({ cool:0, flash:0, recoil:0, lock:false, x:0, y:0, active:false, was:false, spin:0, rx:0, ry:0, dx:0, dy:0, lockRef:null, lockT:0 })),
      best:+store.get('mp-best-zombie', 0), coinsEarned:0, dead:false, casings:[], smoke:[], envPrev:null, envMix:1 });
    zEnvInit(this, this.vs ? ZENVS[(mulberry32((this.vs.seed | 0) + 1)() * ZENVS.length) | 0] : pick(ZENVS)); this._live = true;
    if (this.vs) this.waveT = 0.4;
    Music.setLevel(0.25);
  },
  exit(){ Music.setLevel(1); this._live = false; if (zAmbOwner === this) zAmbOwner = null; },
  rescale(){ this.guns.forEach(g => { g.active = false; g.was = false; }); },
  proj(x, z, h = 0){
    const s = Z_NEAR / (z + Z_NEAR), U = H * 0.5, HOR = H * 0.42, GY = H * 1.06;
    return { X: W / 2 + x * W * 0.32 * s, Y: HOR + (GY - HOR) * s - h * U * s, s: U * s };
  },
  buildWave(n){
    if (this.vs) return this.vs.wave(n);      // two-player: both sides face the same wave
    const list = [], count = Math.min(40, 4 + n * 3);
    for (let i = 0; i < count; i++) {
      const r = Math.random(); let t = 'walker';
      if (n >= 2 && r < 0.14) t = 'crawler';
      else if (n >= 3 && r < 0.14 + 0.1 + n * 0.008) t = 'runner';
      else if (n >= 3 && r < 0.14 + 0.1 + n * 0.008 + 0.09) t = 'spitter';
      else if (n >= 4 && r < 0.62 && r > 0.5) t = 'armored';
      else if (n >= 5 && r > 0.93 - n * 0.004 && r < 0.97) t = 'bloater';
      else if (n >= 4 && r > 0.88 - n * 0.01) t = 'brute';
      list.push(t);
    }
    if (n === 2) list[0] = 'crawler'; if (n === 3) list[0] = 'spitter'; if (n === 4) list[0] = 'armored'; if (n === 5) list.splice(1, 0, 'bloater');   // meet each new kind early
    if (n % 5 === 0) list.push('boss');
    return list;
  },
  startWave(){
    this.wave++; this.waveState = 'intro'; this.waveT = 2.4;
    if (this.wave > 1) {   // a new mood of night after every wave
      const r = this.vs ? mulberry32((this.vs.seed | 0) + this.wave * 131)() : Math.random(), opts = ZENVS.filter(e => e !== this.env), old = this.env;
      zEnvInit(this, opts[Math.floor(r * opts.length)]); this.envPrev = old; this.envMix = 0;
      this.banners.push({ text:this.env.name, t:0, color:'#ffb4a8', small:true });
    }
    this.toSpawn = this.buildWave(this.wave); this.spawnT = 0.3;
    SFX.horn();
  },
  spawnZombie(type){
    const T = ZTYPES[type];
    const hp = type === 'boss' ? T.hp + this.wave * 5 : T.hp;
    // some zombies now come out of the dark from the left or right and cut across to the fence
    const sideChance = this.wave < 2 ? 0 : Math.min(0.5, 0.16 + this.wave * 0.05);
    const side = type !== 'boss' && Math.random() < sideChance ? (Math.random() < 0.5 ? -1 : 1) : 0;
    const spit = type === 'spitter';
    const z = { type, T, x:side ? side * rand(7.2, 8.4) : rand(-1.5, 1.5), z:side ? rand(5, 10) : Z_SPAWN + rand(0, 4), hp, maxHp:hp, side,
      speed:T.speed * (1 + this.wave * 0.06) * rand(0.9, 1.15), size:T.size * rand(0.95, 1.05), phase:rand(0, 6),
      flash:0, dead:false, deathT:0, atkT:rand(0.3, 0.9), lunge:0, kb:0, hunch:type === 'runner' ? 0.8 : 0, lean:0, charge:0, spitT:rand(1.5, 2.6),
      skin:pick(T.skin), shirt:pick(T.shirt), stopZ:spit ? rand(4.6, 6.4) : Z_FRONT + (T.size - 1) * (type === 'boss' ? 4.5 : 2.2) + rand(0, 0.4), tx:spit ? rand(-2.2, 2.2) : rand(-1.3, 1.3), box:null };
    this.zombies.push(z);
    if (side) { this.edgeWarn = 1; zSnd.grunt(z); }
    if (type === 'boss') { this.banners.push({ text:'⚠ BOSS ZOMBIE ⚠', t:0, color:'#ff5d6c' }); zSnd.grunt(z); }
  },
  update(dt){
    zEnvUpdate(this, dt);
    if (!zAmbOwner || !zAmbOwner._live) zAmbOwner = this;
    if (zAmbOwner === this) zAmbience(this, dt);
    for (const c of this.casings) { c.vy += H * 2.2 * dt; c.x += c.vx * dt; c.y += c.vy * dt; c.rot += c.vr * dt; c.t += dt; if (c.y > H * 0.97 && c.vy > 0) { c.y = H * 0.97; c.vy *= -0.35; c.vx *= 0.6; c.vr *= 0.5; if (Math.abs(c.vy) > H * 0.1 && c.t < 3) zTone(rand(3000, 4200), 0.05, 'triangle', 0.012); } } this.casings = this.casings.filter(c => c.t < 1.6);
    for (const f of this.smoke) { f.x += f.vx * dt; f.y += f.vy * dt; f.r += H * 0.06 * dt; f.t += dt; } this.smoke = this.smoke.filter(f => f.t < 0.7);
    this.parts = stepParts(this.parts, dt); this.pops = stepPops(this.pops, dt);
    for (const b of this.banners) b.t += dt; this.banners = this.banners.filter(b => b.t < 2.2);
    for (const tr of this.tracers) tr.t += dt; this.tracers = this.tracers.filter(tr => tr.t < 0.08);
    for (const d of this.decals) d.life -= dt / 8; this.decals = this.decals.filter(d => d.life > 0);
    this.shake = Math.max(0, this.shake - dt * 2.5); this.hurt = Math.max(0, this.hurt - dt * 1.6); this.flash = Math.max(0, this.flash - dt * 2.5);
    if (this.blast) { this.blast.t += dt; if (this.blast.t > 0.7) this.blast = null; }

    if (this.waveState === 'ready') {
      const p = this.waveT; this.waveT -= dt; countBeep(p, this.waveT);
      if (this.waveT <= 0) this.startWave();
      this.aim(dt, false); return;
    }
    this.t += dt;

    // wave flow
    if (this.waveState === 'intro') { this.waveT -= dt; if (this.waveT <= 0) this.waveState = 'fight'; }
    if (this.waveState === 'fight' || this.waveState === 'intro') {
      this.spawnT -= dt;
      if (this.spawnT <= 0 && this.toSpawn.length) {
        this.spawnZombie(this.toSpawn.shift());
        if (this.toSpawn.length && Math.random() < 0.25 + this.wave * 0.03) this.spawnZombie(this.toSpawn.shift());   // pairs
        this.spawnT = Math.max(0.35, 2.0 - this.wave * 0.12) * rand(0.6, 1.3);
      }
      if (this.waveState === 'fight' && !this.toSpawn.length && !this.zombies.length) {
        const bonus = 50 * this.wave + Math.round(this.hp);
        this.score += bonus; this.waveState = 'clear'; this.waveT = 3.5;
        const wc = earnCoins(8 + 2 * this.wave); this.coinsEarned += wc;
        this.banners.push({ text:`Wave ${this.wave} cleared!  +${bonus}   ● +${wc}`, t:0, color:'#4fd27a' }); SFX.waveClear(); SFX.coin();
        for (let i = 0; i < 3; i++) burst(this.parts, W * rand(0.25, 0.75), H * rand(0.2, 0.4), 16, ['#4fd27a', '#ffe14a', '#ffffff'], H * 0.7, H * 0.009, 1.1, 0.6);
        if (this.hp < 100) this.medkit = { x:W * rand(0.3, 0.7), y:H * rand(0.3, 0.55), hold:0, t:0 };
      }
    }
    if (this.waveState === 'clear') { this.waveT -= dt; if (this.waveT <= 0) this.startWave(); }

    // zombies
    this.groanT -= dt; if (this.groanT <= 0 && this.zombies.length) { const cand = this.zombies.filter(q => !q.dead && q.box && q.z < Z_SPAWN); if (cand.length) zSnd.grunt(pick(cand)); this.groanT = rand(1.4, 3.8); }
    for (const z of this.zombies) {
      z.flash = Math.max(0, z.flash - dt); z.lunge = Math.max(0, z.lunge - dt * 3);
      if (z.dead) { z.deathT += dt; continue; }
      z.kb *= Math.exp(-dt * 8);
      z.lean += (0 - z.lean) * Math.min(1, dt * 5);
      if (z.side && Math.abs(z.x - z.tx) > 0.25) {          // cutting across from the side first
        const dir = Math.sign(z.tx - z.x);
        z.x += dir * Math.min(Math.abs(z.tx - z.x), z.speed * 2.6 * dt); z.z = Math.max(z.stopZ, z.z - z.speed * 0.25 * dt);
        z.phase += dt * z.speed * 5; z.lean = dir * 0.1;
      } else if (z.z > z.stopZ) {
        z.z = Math.max(z.stopZ, z.z - z.speed * dt + z.kb * dt * 8);
        z.phase += dt * z.speed * 5;
        z.x += (z.tx - z.x) * dt * 0.25;
        if (Math.random() < dt * 0.2) z.tx = clamp(z.x + rand(-0.8, 0.8), -1.4, 1.4);
      } else if (z.type === 'spitter') {                    // stays back and lobs acid at the fence
        z.phase += dt * 1.5; z.spitT -= dt; z.charge = z.spitT < 0.6 ? 1 - z.spitT / 0.6 : 0;
        if (z.spitT <= 0) {
          z.spitT = rand(2.4, 3.4); z.charge = 0; SFX.spit();
          this.spits.push({ x:z.x, z:z.z, tx:rand(-1.0, 1.0), hp:2, t:0, flash:0 });
        }
      } else {
        z.phase += dt * 2;
        z.atkT -= dt;
        if (z.atkT <= 0) {            // bite the barricade
          z.atkT = z.type === 'boss' ? 1.8 : 1.4; z.lunge = 1;
          this.hp -= z.T.dmg; this.hurt = 1; this.shake = Math.max(this.shake, 0.6); SFX.hurt(); if (Math.random() < 0.55) zSnd.snarl(z);
        }
      }
      const p = this.proj(z.x, z.z), hgt = 1.7 * z.size * p.s, w = hgt * 0.36 * (z.type === 'brute' || z.type === 'boss' ? 1.25 : 1);
      z.box = { x:p.X, y:p.Y, h:hgt, hx:p.X, hy:p.Y - hgt * (0.86 - (z.hunch ? 0.08 : 0)), hr:hgt * 0.14, body:[p.X - w / 2, p.Y - hgt * 0.78, w, hgt * 0.78] };
    }
    this.zombies = this.zombies.filter(z => !z.dead || z.deathT < 1.1);

    // acid balls: shoot them down before they reach the fence
    for (const s of this.spits) {
      s.t += dt; s.flash = Math.max(0, s.flash - dt); s.z -= 4.0 * dt; s.x += (s.tx - s.x) * Math.min(1, dt * 1.6);
      if (s.z <= 0.25 && !s.dead) { s.dead = true; this.hp -= 7; this.hurt = 0.8; this.splat = 1; this.shake = Math.max(this.shake, 0.5); SFX.hurt(); }
    }
    this.spits = this.spits.filter(s => !s.dead);
    this.splat = Math.max(0, this.splat - dt * 0.5);
    this.edgeWarn = Math.max(0, (this.edgeWarn || 0) - dt);
    // the music gets busier as the waves and the crowd grow
    this.lvlT -= dt; if (this.lvlT <= 0) { this.lvlT = 0.5; Music.setLevel(clamp(0.2 + this.wave * 0.14 + this.zombies.filter(z => !z.dead).length * 0.05, 0, 1)); }

    this.aim(dt, true);
    this.updateGrenade(dt);

    // rare boost icon: hover to get 5s of double damage (headshots x4)
    if (this.boostT > 0) this.boostT = Math.max(0, this.boostT - dt);
    this.boostCool -= dt;
    if (!this.boostIcon && this.boostT <= 0 && this.boostCool <= 0 && this.waveState === 'fight' && this.zombies.length && Math.random() < dt / 55) {
      this.boostIcon = { x:W * rand(0.25, 0.75), y:H * rand(0.28, 0.5), hold:0, t:0 }; this.boostCool = 45; SFX.boostAppear();
    }
    if (this.boostIcon) {
      const b = this.boostIcon; b.t += dt;
      const over = cursors().some(c => Math.hypot(c.x - b.x, c.y - b.y) < H * 0.08);
      b.hold = over ? b.hold + dt : Math.max(0, b.hold - dt);
      if (b.hold > 0.35) { this.boostT = 5; SFX.boost(); burst(this.parts, b.x, b.y, 30, ['#ffd23f', '#ff8a00', '#ffffff'], H * 0.7, H * 0.01, 0.8, 0.2); pop(this.pops, b.x, b.y, 'DOUBLE DAMAGE!', '#ffd23f', 0.05); this.boostIcon = null; }
      else if (b.t > 9) this.boostIcon = null;
    }
    // medkit: hover over it to heal
    if (this.medkit) {
      const m = this.medkit; m.t += dt;
      const over = cursors().some(c => Math.hypot(c.x - m.x, c.y - m.y) < H * 0.08);
      m.hold = over ? m.hold + dt : Math.max(0, m.hold - dt);
      if (m.hold > 0.6) { this.hp = Math.min(100, this.hp + 30); SFX.medkit(); burst(this.parts, m.x, m.y, 24, ['#ff5d6c', '#ffffff'], H * 0.6, H * 0.01, 0.7, 0.3); pop(this.pops, m.x, m.y, '+30 health', '#4fd27a', 0.05); this.medkit = null; }
      else if (m.t > 14) this.medkit = null;
    }
    if (this.hp <= 0) {
      this.hp = 0;
      const res = { game:'zombie', score:this.score, detail:`Reached wave ${this.wave} · ${this.kills} zombies`, coins:this.coinsEarned };
      if (this.vs) { if (!this.dead) { this.dead = true; this.vs.onDead(this, res); } } else go('over', res);
    }
  },
  // The zombie (front-most first) under a screen point, with a little aim assist
  // `grow` makes the hit area bigger (used to keep an existing lock from flickering)
  hitTest(z, x, y, pad){
    const b = z.box;
    const head = Math.hypot(x - b.hx, y - b.hy) < b.hr + pad;
    const body = x > b.body[0] - pad && x < b.body[0] + b.body[2] + pad && y > b.body[1] - pad && y < b.body[1] + b.body[3];
    return head ? 2 : body ? 1 : 0;
  },
  target(x, y, g){
    const pad = H * 0.026;
    // acid balls take priority — they're small and urgent
    for (const s of this.spits) {
      const p = this.proj(s.x, s.z, 0.9);
      if (Math.hypot(x - p.X, y - p.Y) < p.s * 0.26 + pad) return { spit:s };
    }
    // a lock you already have is kept for a moment even if your hand wobbles off the edge
    if (g && g.lockRef && g.lockT > 0 && !g.lockRef.dead && g.lockRef.box && this.hitTest(g.lockRef, x, y, pad * 2.4)) {
      const h = this.hitTest(g.lockRef, x, y, pad);
      return { z:g.lockRef, head:h === 2 };
    }
    let best = null;
    for (const z of this.zombies) {
      if (z.dead || !z.box || z.z > Z_SPAWN - 2) continue;
      const h = this.hitTest(z, x, y, pad);
      if (h && (!best || z.z < best.z.z)) best = { z, head:h === 2 };
    }
    return best;
  },
  // Gentle magnet: a slow, careful hand is pulled the last few pixels onto the nearest zombie
  assist(g, x, y, sp){
    if (sp > 0.7) return [x, y];
    const R = H * 0.085 * (1 - sp / 0.7), pull = 0.45 * (1 - sp / 0.7);
    let best = null, bd = R;
    for (const z of this.zombies) {
      if (z.dead || !z.box || z.z > Z_SPAWN - 2) continue;
      const b = z.box;
      for (const [cx, cy, w] of [[b.hx, b.hy, 1.25], [b.x, b.y - b.h * 0.45, 1]]) { const d = Math.hypot(x - cx, y - cy) / w; if (d < bd) { bd = d; best = [cx, cy]; } }
    }
    return best ? [x + (best[0] - x) * pull, y + (best[1] - y) * pull] : [x, y];
  },
  gunOrigin(k){ return k === 0 ? [W * 0.16, H * 1.0] : k === 1 ? [W * 0.84, H * 1.0] : [W * 0.5, H * 1.02]; },
  aim(dt, live){
    const cs = cursors();
    for (const g of this.guns) { g.was = g.active; g.active = false; g.cool -= dt; g.lockT -= dt; g.flash = Math.max(0, g.flash - dt); g.recoil = Math.max(0, g.recoil - dt * 8); }
    for (const c of cs) {
      const g = this.guns[c.k];
      // Aim from the tracker's own reading (no look-ahead, which helps blades but hurts aiming) through a speed-adaptive
      // filter: very steady when you hold still to line up a shot, nearly lag-free when you swing across the screen.
      const rx = c.k === 2 ? c.x : c.hd.nx * W, ry = c.k === 2 ? c.y : c.hd.ny * H;
      if (!g.was) { g.rx = g.fx = rx; g.ry = g.fy = ry; g.dx = g.dy = 0; g.lockRef = null; }
      const d = Math.max(0.004, dt);
      g.dx += ((rx - g.rx) / d - g.dx) * 0.4; g.dy += ((ry - g.ry) / d - g.dy) * 0.4; g.rx = rx; g.ry = ry;
      const sp = Math.hypot(g.dx, g.dy) / H, cutoff = 1.4 + 9 * sp, a = 1 - Math.exp(-TAU * cutoff * d);
      g.fx += (rx - g.fx) * a; g.fy += (ry - g.fy) * a;
      const [ax, ay] = live ? this.assist(g, g.fx, g.fy, sp) : [g.fx, g.fy];
      g.active = true; g.x = ax; g.y = ay;
      const t = live ? this.target(ax, ay, g) : null;
      g.lock = !!t; g.spin += dt * (t ? 6 : 1.5);
      if (t && t.z) { g.lockRef = t.z; g.lockT = 0.22; }
      if (t && g.cool <= 0) this.fire(g, c.k, t, ax, ay);
    }
  },
  fire(g, k, t, x, y){
    g.cool = GUN_RATE; g.flash = 0.06; g.recoil = 1;
    const [ox, oy] = this.gunOrigin(k), a = Math.atan2(y - oy, x - ox), L = H * 0.46;
    this.tracers.push({ x1:ox + Math.cos(a) * L, y1:oy + Math.sin(a) * L, x2:x, y2:y, t:0, c:this.boostT > 0 ? '#ffb020' : HAND_COLORS[k] });
    SFX.shot(k); g.shotN = (g.shotN || 0) + 1;
    { const mx = ox + Math.cos(a) * L, my = oy + Math.sin(a) * L, sd = k === 1 ? 1 : -1;
      this.casings.push({ x:ox + Math.cos(a) * L * 0.35, y:oy + Math.sin(a) * L * 0.35, vx:Math.cos(a + sd * 1.9) * H * rand(0.25, 0.5), vy:Math.sin(a + sd * 1.9) * H * rand(0.25, 0.5) - H * 0.25, rot:rand(0, TAU), vr:rand(-18, 18), t:0 });
      this.smoke.push({ x:mx, y:my, vx:Math.cos(a) * H * 0.05 + rand(-H * 0.02, H * 0.02), vy:Math.sin(a) * H * 0.05 - H * 0.04, r:H * 0.012, t:0 }); }
    if (t.spit) {   // shooting down an acid ball
      const s = t.spit; s.hp--; s.flash = 0.08; burst(this.parts, x, y, 5, ['#d6ff4a', '#9be15d'], H * 0.4, H * 0.008, 0.35, 0.8);
      if (s.hp <= 0) { s.dead = true; this.score += 25; pop(this.pops, x, y - H * 0.03, 'Splat! +25', '#d6ff4a', 0.03, 0.8); burst(this.parts, x, y, 16, ['#d6ff4a', '#9be15d', '#ffffff'], H * 0.6, H * 0.01, 0.5, 0.7); SFX.zhit(); }
      return;
    }
    const z = t.z, helmet = z.type === 'armored' && t.head, dmg = (t.head && !helmet ? 2 : 1) * (this.boostT > 0 ? 2 : 1);
    z.hp -= dmg; z.flash = 0.07; z.kb = 0.25 / z.size;
    if (helmet) { SFX.armor(); burst(this.parts, x, y, 7, ['#ffffff', '#ffe14a'], H * 0.5, H * 0.005, 0.25, 0.3); this.compliment('CLANG!', '#c4cadb', 0.25); }
    t.head = t.head && !helmet;
    if (!helmet) burst(this.parts, x, y, 6, ['#8a0f16', '#b31a22', '#6f8f2a', '#ffffff'], H * 0.45, H * 0.007, 0.4, 0.8);
    if (!helmet && Math.random() < 0.5) zSnd.hit(z);
    if (t.head) this.compliment('HEADSHOT', '#ffe14a', 0.3);
    if (z.hp <= 0) this.kill(z, t.head);
  },
  // Compliments (HEADSHOT, DOUBLE KILL…) are shown one at a time, at the left or right edge, never over the zombies
  compliment(text, color, prob = 1){
    if (Math.random() > prob) return;
    if (this.t - (this.lastComp ?? -9) < 1.8) return;
    this.lastComp = this.t; this.sideFlip = !this.sideFlip;
    this.banners = this.banners.filter(b => !b.side);
    this.banners.push({ text, t:0, color, small:true, side:true, x:this.sideFlip ? W * 0.13 : W * 0.87, y:H * 0.4 });
  },
  kill(z, head){
    z.dead = true; z.deathT = 0; z.fallDir = Math.random() < 0.5 ? -1 : 1; this.kills++;
    if (this.kills % 10 === 0) { this.coinsEarned += earnCoins(2); pop(this.pops, W / 2, H * 0.3, '10 kills!  ● +2', '#ffd23f', 0.04, 1.2); }   // small trickle of coins in every game mode
    this.streak = this.t - this.lastKill < 1.5 ? this.streak + 1 : 1; this.lastKill = this.t;
    const mult = 1 + Math.min(this.streak - 1, 4) * 0.25;
    const pts = Math.round(z.T.score * mult * (head ? 1.5 : 1));
    this.score += pts; this.grenade = Math.min(1, this.grenade + 0.05);
    const b = z.box;
    pop(this.pops, b.hx, b.hy - b.hr * 1.5, '+' + pts, head ? '#ffe14a' : '#ffffff', 0.042);
    burst(this.parts, b.x, b.y - b.h * 0.5, z.type === 'boss' ? 60 : 24, ['#8a0f16', '#b31a22', '#5a0a0f', '#6f8f2a', '#3a0508'], H * 0.8, H * 0.012 * z.size, 0.8, 0.9);
    this.decals.push({ x:z.x, z:z.z, r:0.4 * z.size, life:1 });
    zSnd.die(z);
    if (z.type === 'bloater') {   // pops in a toxic blast that hurts the zombies around it
      SFX.boom(); burst(this.parts, b.x, b.y - b.h * 0.4, 40, ['#d6ff4a', '#9be15d', '#6a8a1a'], H * 1.0, H * 0.016, 0.9, 0.3);
      this.compliment('POP!', '#d6ff4a');
      for (const o of this.zombies) if (o !== z && !o.dead && Math.abs(o.x - z.x) < 2.0 && Math.abs(o.z - z.z) < 3.2) { o.hp -= 5; o.flash = 0.15; if (o.hp <= 0) this.kill(o, false); }
    }
    const names = { 2:'DOUBLE KILL!', 3:'TRIPLE KILL!', 4:'MULTI KILL!', 5:'RAMPAGE!' };
    if (this.streak >= 3) this.compliment(names[Math.min(5, this.streak)], '#ffb23f', this.streak >= 4 ? 0.8 : 0.45);
    if (z.type === 'boss') { this.banners.push({ text:'BOSS DOWN!  ● +10', t:0, color:'#ffe14a' }); this.shake = 1; this.flash = 0.5; this.coinsEarned += earnCoins(10); SFX.coin(); }
  },
  updateGrenade(dt){
    this.grenade = Math.min(1, this.grenade + dt / 25);
    const ready = this.grenade >= 1;
    const handsUp = motionLive() && I.present && I.up;
    this.upHold = ready && handsUp ? this.upHold + dt : 0;
    if (ready && (this.upHold > 0.45 || I.kbGrenade)) this.throwGrenade();
  },
  throwGrenade(){
    this.grenade = 0; this.upHold = 0; this.flash = 1; this.shake = 1.3; SFX.grenade(); Music.duck(0.25, 1.3); this.spits = [];
    const live = this.zombies.filter(z => !z.dead && z.box && z.z < Z_SPAWN - 2);
    const cx = live.length ? live.reduce((s, z) => s + z.box.x, 0) / live.length : W / 2;
    const cy = live.length ? live.reduce((s, z) => s + z.box.y - z.box.h * 0.4, 0) / live.length : H * 0.55;
    this.blast = { x:cx, y:cy, t:0 };
    burst(this.parts, cx, cy, 70, ['#ffe14a', '#ff7a1a', '#ff3b3b', '#555555'], H * 1.6, H * 0.02, 1.0, 0.6);
    for (const z of live) { z.hp -= 6; z.flash = 0.15; z.kb = 1.2 / z.size; if (z.hp <= 0) this.kill(z, false); }
    this.banners.push({ text:'BOOM!', t:0, color:'#ff7a1a' });
  },
  draw(now){
    const HOR = H * 0.42, env = this.env || ZENVS[0];
    ctx.save();
    if (this.shake) ctx.translate(rand(-1, 1) * this.shake * 16, rand(-1, 1) * this.shake * 16);
    if (this.envPrev && this.envMix < 1) { zBg(this, this.envPrev, 1); zBg(this, env, this.envMix); } else zBg(this, env, 1);
    if (this.flashSky > 0) { ctx.fillStyle = `rgba(205,225,255,${this.flashSky * 0.4})`; ctx.fillRect(0, 0, W, H * 0.6); }
    zDrawBolt(this); zDrawBirds(this); zDrawFires(this, env);
    const spl = zSplatSprite();
    for (const d of this.decals) { const p = this.proj(d.x, d.z), w = d.r * p.s * 3.4; ctx.globalAlpha = 0.9 * d.life; ctx.drawImage(spl, p.X - w / 2, p.Y - w * 0.155, w, w * 0.31); }
    ctx.globalAlpha = 1;
    // zombies, far to near, with sheets of haze between the depth layers
    const order = [...this.zombies].sort((a, b) => b.z - a.z), planes = [[13, 0.26], [8, 0.16], [4.5, 0.09]]; let pi = 0;
    const haze = ([zp, a]) => { const y0 = HOR - H * 0.03, y1 = this.proj(0, zp).Y, gr = ctx.createLinearGradient(0, y0, 0, y1); gr.addColorStop(0, `rgba(${env.fog},${a})`); gr.addColorStop(1, `rgba(${env.fog},0)`); ctx.fillStyle = gr; ctx.fillRect(0, y0, W, y1 - y0); };
    for (const z of order) {
      if (!z.box) continue;
      while (pi < planes.length && z.z < planes[pi][0]) haze(planes[pi++]);
      const fogA = clamp((Z_SPAWN + 2 - z.z) / 6, 0, 1), fade = z.dead ? clamp(1 - (z.deathT - 0.6) / 0.5, 0, 1) : 1;
      drawZombieBody(z, z.box.x, z.box.y, z.box.h, fogA * fade);
      if (!z.dead) drawZombieFx(z, fogA);
      if (!z.dead && z.hp < z.maxHp && z.type !== 'boss') {
        const bw = z.box.h * 0.34, bh = Math.max(5, H * 0.009), bx = z.box.x - bw / 2, by = z.box.hy - z.box.hr * 1.9, k = z.hp / z.maxHp;
        roundRect(bx - 2, by - 2, bw + 4, bh + 4, bh * 0.7); ctx.fillStyle = 'rgba(0,0,0,0.65)'; ctx.fill();
        const gr = ctx.createLinearGradient(0, by, 0, by + bh); gr.addColorStop(0, k > 0.4 ? '#7dffa8' : '#ff8a96'); gr.addColorStop(1, k > 0.4 ? '#1f9a4f' : '#b01d30'); roundRect(bx, by, Math.max(bh, bw * k), bh, bh * 0.5); ctx.fillStyle = gr; ctx.fill();
      }
    }
    while (pi < planes.length) haze(planes[pi++]);
    // acid balls flying at the fence
    for (const s of this.spits) {
      const p = this.proj(s.x, s.z, 0.9), r = p.s * 0.2;
      ctx.globalCompositeOperation = 'lighter'; const gl = ctx.createRadialGradient(p.X, p.Y, r * 0.3, p.X, p.Y, r * 2.8); gl.addColorStop(0, 'rgba(190,255,60,0.55)'); gl.addColorStop(1, 'rgba(190,255,60,0)'); ctx.fillStyle = gl; ctx.fillRect(p.X - r * 3, p.Y - r * 3, r * 6, r * 6); ctx.globalCompositeOperation = 'source-over';
      for (let i = 1; i <= 5; i++) { const q = this.proj(s.x, s.z + i * 0.3, 0.9 + i * 0.03); ctx.globalAlpha = 0.5 / i; ctx.fillStyle = '#7fc42a'; ctx.beginPath(); ctx.arc(q.X, q.Y, q.s * 0.15 * (1 - i * 0.1), 0, TAU); ctx.fill(); }
      ctx.globalAlpha = 1; const bg = ctx.createRadialGradient(p.X - r * 0.3, p.Y - r * 0.35, r * 0.1, p.X, p.Y, r); bg.addColorStop(0, s.flash > 0 ? '#fff' : '#f4ffb0'); bg.addColorStop(0.5, '#a8e22a'); bg.addColorStop(1, '#3f6a0c'); ctx.fillStyle = bg; ctx.beginPath(); ctx.arc(p.X, p.Y, r, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.6)'; ctx.beginPath(); ctx.ellipse(p.X - r * 0.3, p.Y - r * 0.38, r * 0.25, r * 0.14, -0.6, 0, TAU); ctx.fill();
      if (s.z < 3) text('!', p.X, p.Y - r * 2, r * 1.6, '#ff5d6c');
    }
    // arrows at the screen edge for zombies still coming in from the sides
    for (const z of this.zombies) {
      if (z.dead || !z.box || (z.box.x > -z.box.h * 0.1 && z.box.x < W + z.box.h * 0.1)) continue;
      const left = z.box.x < 0, ey = clamp(z.box.y - z.box.h * 0.5, H * 0.25, H * 0.8), pulse = 0.65 + 0.35 * Math.sin(this.t * 10), ax = left ? W * 0.025 : W * 0.975, s = H * 0.035;
      ctx.globalAlpha = pulse; ctx.fillStyle = '#ff3b4e'; ctx.beginPath(); ctx.moveTo(ax + (left ? -1 : 1) * s * 0.4, ey); ctx.lineTo(ax + (left ? 1 : -1) * s * 0.8, ey - s * 0.9); ctx.lineTo(ax + (left ? 1 : -1) * s * 0.8, ey + s * 0.9); ctx.closePath(); ctx.fill();
      text('!', ax + (left ? 1 : -1) * s * 2, ey, s * 1.2, '#ff8a96'); ctx.globalAlpha = 1;
    }
    // barricade
    const fy = H * 0.93;
    ctx.drawImage(zBarricadeLayer(), 0, 0);
    if (this.hp < 70) { ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = 2.5; ctx.beginPath(); const n = this.hp < 35 ? 9 : this.hp < 50 ? 6 : 3; for (let i = 0; i < n; i++) { const x = W * (0.07 + i * (0.86 / Math.max(1, n - 1))) + Math.sin(i * 7) * 20; ctx.moveTo(x, fy - H * 0.05); ctx.lineTo(x + W * 0.012, fy - H * 0.01); ctx.lineTo(x - W * 0.004, fy + H * 0.015); ctx.lineTo(x + W * 0.008, fy + H * 0.035); } ctx.stroke(); }
    if (this.hp < 40) { ctx.fillStyle = 'rgba(120,10,16,0.45)'; for (let i = 0; i < 5; i++) { const x = W * (0.12 + i * 0.19); ctx.beginPath(); ctx.ellipse(x, fy + H * 0.005, W * 0.02, H * 0.012, 0, 0, TAU); ctx.fill(); ctx.fillRect(x - 3, fy + H * 0.005, 6, H * 0.03 + (i % 3) * H * 0.01); } }
    drawParts(this.parts);
    for (const f of this.smoke) { const k = f.t / 0.7; ctx.globalAlpha = (1 - k) * 0.22; ctx.fillStyle = '#c8ccd8'; ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, TAU); ctx.fill(); }
    ctx.globalAlpha = 1;
    for (const c of this.casings) { ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(c.rot); ctx.globalAlpha = Math.min(1, (1.6 - c.t) * 2); const cg = ctx.createLinearGradient(0, -3, 0, 3); cg.addColorStop(0, '#ffe29a'); cg.addColorStop(1, '#a8741c'); ctx.fillStyle = cg; ctx.fillRect(-H * 0.007, -H * 0.0025, H * 0.014, H * 0.005); ctx.restore(); }
    ctx.globalAlpha = 1;
    if (this.blast) {
      const b = this.blast, k = b.t / 0.7;
      ctx.globalCompositeOperation = 'lighter';
      const R = H * (0.12 + k * 0.55), fg = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, R); fg.addColorStop(0, `rgba(255,255,230,${1 - k})`); fg.addColorStop(0.3, `rgba(255,190,70,${(1 - k) * 0.9})`); fg.addColorStop(0.7, `rgba(255,90,20,${(1 - k) * 0.5})`); fg.addColorStop(1, 'rgba(255,60,0,0)');
      ctx.fillStyle = fg; ctx.fillRect(b.x - R, b.y - R, R * 2, R * 2);
      ctx.globalAlpha = (1 - k) * 0.9; ctx.strokeStyle = '#fff3c8'; ctx.lineWidth = H * 0.025 * (1 - k); ctx.beginPath(); ctx.arc(b.x, b.y, H * (0.2 + k * 1.0), 0, TAU); ctx.stroke();
      ctx.globalAlpha = (1 - k) * 0.4; ctx.strokeStyle = '#ff9a3a'; ctx.lineWidth = H * 0.012; ctx.beginPath(); ctx.arc(b.x, b.y, H * (0.14 + k * 0.7), 0, TAU); ctx.stroke();
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    }
    // tracers & guns
    ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round';
    for (const tr of this.tracers) { const k = 1 - tr.t / 0.08; ctx.globalAlpha = k; ctx.strokeStyle = tr.c; ctx.lineWidth = H * 0.009; ctx.beginPath(); ctx.moveTo(tr.x1, tr.y1); ctx.lineTo(tr.x2, tr.y2); ctx.stroke(); ctx.strokeStyle = '#fff'; ctx.lineWidth = H * 0.003; ctx.stroke(); const ig = ctx.createRadialGradient(tr.x2, tr.y2, 0, tr.x2, tr.y2, H * 0.03); ig.addColorStop(0, 'rgba(255,240,200,0.9)'); ig.addColorStop(1, 'rgba(255,160,60,0)'); ctx.fillStyle = ig; ctx.fillRect(tr.x2 - H * 0.03, tr.y2 - H * 0.03, H * 0.06, H * 0.06); }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    this.guns.forEach((g, k) => { if (g.active) zDrawGun(this, g, k); });
    this.guns.forEach((g, k) => { if (g.active) zDrawCrosshair(this, g, k); });
    if (this.medkit) zDrawMedkit(this.medkit);
    if (this.boostIcon) zDrawBoost(this.boostIcon);
    drawPops(this.pops);
    ctx.restore();

    zDrawWeather(this, env);
    ctx.fillStyle = env.tint; ctx.fillRect(0, 0, W, H);
    ctx.drawImage(zVignette(), 0, 0);
    if (this.hp < 30 && this.hp > 0) { const p = 0.5 + 0.5 * Math.sin(this.t * 5); ctx.globalAlpha = (0.25 + 0.2 * p) * (1 - this.hp / 30); ctx.drawImage(zVignette(), 0, 0); ctx.fillStyle = 'rgba(160,0,10,0.25)'; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
    { ctx.save(); ctx.fillStyle = zGrainPattern(); ctx.translate(rand(0, 160), rand(0, 160)); ctx.fillRect(-160, -160, W + 160, H + 160); ctx.restore(); }
    if (this.splat > 0) { ctx.globalAlpha = this.splat * 0.55; ctx.fillStyle = '#9be15d'; for (let i = 0; i < 6; i++) { ctx.beginPath(); ctx.arc(W * (0.2 + 0.12 * i) + Math.sin(i * 7) * 40, H * (0.78 + 0.1 * Math.sin(i * 3)), H * (0.05 + 0.02 * (i % 3)), 0, TAU); ctx.fill(); } ctx.globalAlpha = 1; }
    if (this.hurt) { const v = ctx.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, W * 0.7); v.addColorStop(0, 'rgba(255,0,0,0)'); v.addColorStop(1, `rgba(200,0,0,${0.55 * this.hurt})`); ctx.fillStyle = v; ctx.fillRect(0, 0, W, H); }
    if (this.flash) { ctx.fillStyle = `rgba(255,240,200,${this.flash * 0.6})`; ctx.fillRect(0, 0, W, H); }
    this.drawHUD();
    drawMotionBadge();
  },
  drawHUD(){
    text(String(this.score), W * 0.04, H * 0.07, H * 0.07, '#fff', 'left');
    text('Best ' + Math.max(this.best, this.score), W * 0.04, H * 0.135, H * 0.03, '#c9d2ff', 'left', 700);
    const boss = this.zombies.find(z => z.type === 'boss' && !z.dead);
    if (this.wave) {
      const left = this.toSpawn.length + this.zombies.filter(z => !z.dead).length;
      text(`Wave ${this.wave}`, W / 2, H * 0.055, H * 0.05, '#ffe14a');
      if (!boss) text(`${left} zombie${left === 1 ? '' : 's'} left`, W / 2, H * 0.11, H * 0.03, '#c9d2ff', 'center', 700);
    }
    if (this.boostT > 0) {
      const bx = W / 2, by = H * 0.8, k = this.boostT / 5, pw = W * 0.3;
      text(`⚡ BOOST  ×2 damage · headshots ×4  (${this.boostT.toFixed(1)}s)`, bx, by - H * 0.03, H * 0.03, '#ffe14a', 'center', 800);
      roundRect(bx - pw / 2 - 4, by - 4, pw + 8, H * 0.02 + 8, 10); ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fill();
      roundRect(bx - pw / 2, by, Math.max(H * 0.02, pw * k), H * 0.02, 8); ctx.fillStyle = Math.sin(this.t * 14) > 0 ? '#ffd23f' : '#ff9a1f'; ctx.fill();
    }
    // health bar: bevelled metal frame, glossy fill, heart badge
    const bw = W * 0.2, bx = W * 0.96 - bw, by = H * 0.045, bh = H * 0.035, hpk = clamp(this.hp / 100, 0, 1);
    { const fg = ctx.createLinearGradient(0, by - 6, 0, by + bh + 6); fg.addColorStop(0, '#4a5068'); fg.addColorStop(1, '#161a28'); roundRect(bx - 7, by - 7, bw + 14, bh + 14, (bh + 14) / 2); ctx.fillStyle = fg; ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 1.5; ctx.stroke();
      roundRect(bx - 2, by - 2, bw + 4, bh + 4, (bh + 4) / 2); ctx.fillStyle = '#07080f'; ctx.fill();
      const c1 = hpk > 0.5 ? '#8dffb0' : hpk > 0.25 ? '#ffe08a' : '#ff8a96', c2 = hpk > 0.5 ? '#1c9b4c' : hpk > 0.25 ? '#c98a12' : '#b01426', w = Math.max(bh, bw * hpk), hg = ctx.createLinearGradient(0, by, 0, by + bh); hg.addColorStop(0, c1); hg.addColorStop(0.5, c2); hg.addColorStop(1, zShade(c2, -0.4));
      roundRect(bx, by, w, bh, bh / 2); ctx.fillStyle = hg; ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.3)'; roundRect(bx + 3, by + 2, w - 6, bh * 0.35, bh * 0.2); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1.5; ctx.beginPath(); for (let i = 1; i < 10; i++) { const x = bx + bw * i / 10; ctx.moveTo(x, by + 2); ctx.lineTo(x, by + bh - 2); } ctx.stroke();
      if (hpk < 0.3) { ctx.globalAlpha = 0.5 + 0.5 * Math.sin(this.t * 8); ctx.strokeStyle = '#ff3b4e'; ctx.lineWidth = 3; roundRect(bx - 7, by - 7, bw + 14, bh + 14, (bh + 14) / 2); ctx.stroke(); ctx.globalAlpha = 1; } }
    text(`♥ ${Math.ceil(this.hp)}`, bx + bw / 2, by + bh / 2, bh * 0.8, '#fff');
    // boss health
    if (boss) {
      const w = W * 0.4, x = W * 0.3, y = H * 0.088;
      ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(x - 3, y - 3, w + 6, H * 0.022 + 6);
      ctx.fillStyle = '#b46bff'; ctx.fillRect(x, y, w * boss.hp / boss.maxHp, H * 0.022);
      text('BOSS', x - 10, y + H * 0.011, H * 0.025, '#e6c8ff', 'right');
    }
    // grenade meter
    const gx = W / 2, gy = H * 0.87, gr = H * 0.042, ready = this.grenade >= 1;
    { const bg = ctx.createRadialGradient(gx, gy - gr * 0.3, gr * 0.2, gx, gy, gr * 1.35); bg.addColorStop(0, '#3a4058'); bg.addColorStop(1, '#0c0e18'); ctx.fillStyle = bg; ctx.beginPath(); ctx.arc(gx, gy, gr * 1.25, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,0.2)'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.lineCap = 'round'; ctx.strokeStyle = ready ? '#ffb23f' : '#8890b8'; ctx.lineWidth = H * 0.008; if (ready) { ctx.shadowColor = '#ffb23f'; ctx.shadowBlur = 14; } ctx.beginPath(); ctx.arc(gx, gy, gr * 1.1, -Math.PI / 2, -Math.PI / 2 + TAU * this.grenade); ctx.stroke(); ctx.shadowBlur = 0;
      const gg = ctx.createRadialGradient(gx - gr * 0.2, gy - gr * 0.1, 0, gx, gy + gr * 0.1, gr * 0.62); gg.addColorStop(0, ready ? '#9cc65a' : '#6c8148'); gg.addColorStop(1, ready ? '#2f4318' : '#252e17'); ctx.fillStyle = gg; ctx.beginPath(); ctx.ellipse(gx, gy + gr * 0.12, gr * 0.5, gr * 0.58, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1.5; for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(gx - gr * 0.46, gy + gr * (0.12 + i * 0.28)); ctx.lineTo(gx + gr * 0.46, gy + gr * (0.12 + i * 0.28)); ctx.stroke(); } ctx.beginPath(); ctx.moveTo(gx, gy - gr * 0.4); ctx.lineTo(gx, gy + gr * 0.7); ctx.stroke();
      ctx.fillStyle = '#9aa0ae'; roundRect(gx - gr * 0.2, gy - gr * 0.68, gr * 0.4, gr * 0.22, gr * 0.06); ctx.fill(); ctx.strokeStyle = '#c8ccd8'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(gx + gr * 0.3, gy - gr * 0.62, gr * 0.17, 0, TAU); ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.ellipse(gx - gr * 0.22, gy - gr * 0.12, gr * 0.1, gr * 0.2, 0.3, 0, TAU); ctx.fill(); }
    if (ready) {
      const pulse = 0.6 + 0.4 * Math.sin(this.t * 6);
      ctx.globalAlpha = pulse; text(motionLive() ? 'Raise both hands above your head!' : 'Press G for a grenade!', gx, gy - gr * 1.8, H * 0.03, '#ffb23f', 'center', 800); ctx.globalAlpha = 1;
      if (this.upHold > 0) { ctx.strokeStyle = '#fff'; ctx.lineWidth = H * 0.012; ctx.beginPath(); ctx.arc(gx, gy, gr * 1.45, -Math.PI / 2, -Math.PI / 2 + TAU * Math.min(1, this.upHold / 0.45)); ctx.stroke(); }
    }
    // banners
    if (this.waveState === 'ready') {
      text('Zombie Siege', W / 2, H * 0.3, H * 0.09, '#b9ff7a');
      text('Point your hands at the zombies — hovering over one fires', W / 2, H * 0.41, H * 0.034, '#fff', 'center', 600);
      text('5 hits each · headshots do double · watch the sides · shoot down acid · hands up = grenade', W / 2, H * 0.47, H * 0.028, '#c9d2ff', 'center', 600);
      text(String(Math.max(1, Math.ceil(this.waveT))), W / 2, H * 0.6, H * 0.13, '#ffe14a');
    } else if (this.waveState === 'intro') {
      const k = 1 - this.waveT / 2.4, a = k < 0.15 ? k / 0.15 : this.waveT < 0.4 ? this.waveT / 0.4 : 1;
      ctx.globalAlpha = a; text(`WAVE ${this.wave}`, W / 2, H * 0.36, H * 0.13 * (0.9 + 0.1 * Math.min(1, k * 4)), '#ff5d6c');
      text(`${this.toSpawn.length + this.zombies.length} zombies incoming`, W / 2, H * 0.47, H * 0.035, '#fff', 'center', 700); ctx.globalAlpha = 1;
    }
    let by2 = H * 0.27;
    for (const b of this.banners) {
      const a = b.t < 0.15 ? b.t / 0.15 : clamp((2.2 - b.t) / 0.4, 0, 1), sc = b.t < 0.15 ? 0.7 + b.t / 0.15 * 0.3 : 1;
      ctx.globalAlpha = a;
      if (b.side) { text(b.text, b.x, b.y, H * 0.045 * sc, b.color, 'center', 800); }
      else { text(b.text, W / 2, by2, H * (b.small ? 0.045 : 0.07) * sc, b.color); by2 += H * 0.08; }
    }
    ctx.globalAlpha = 1;
  }
};

