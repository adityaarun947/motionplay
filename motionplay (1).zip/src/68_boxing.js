/* =====================================================================
   BOXING DOJO — punch the glowing pads (left, centre, right), block his attacks, duck his overhead swings.
   Punches are detected by how fast your ARM STRAIGHTENS (and moves towards the camera), not by where your hand ends up,
   so slow reaches and ordinary arm swings don't count.  Tuning numbers are all in BOXCFG.
   ===================================================================== */
const BOXCFG = {
  win:0.30,          // look at the last 0.30 s of each fist
  extGain:0.38,      // arm must straighten by this much (in torso lengths) inside that window…
  extMin:0.82,       // …and end up at least this extended
  fwdGain:0.45,      // OR move this far towards the camera (needs the depth from the tablet) while at least 0.7 extended
  refractory:0.28,   // seconds before the same fist can punch again
  yBand:0.85,        // fist must be roughly chest/head height when it lands (|height vs shoulder| below this)
  blockHold:0.12,    // both hands up in front of the face for this long = blocking
};
const BOX_LANES = [0.27, 0.5, 0.73];

scenes.boxing = {
  game:true, music:'boxing', ownCursors:true, hint:'Punch the glowing pads · both hands up in front of your face to BLOCK · duck for overhead swings',
  enter(){
    Object.assign(this, { state:'ready', stateT:0, round:1, score:0, hp:100, ehp:100, emax:100, parts:[], pops:[], pads:[], atk:null, atkT:2.2, t:0, roundT:0, roundLen:45, combo:0, comboT:0, bestCombo:0,
      lastHand:-1, hist:[], alt:0, handsH:[[], []], lastPunch:[-9, -9], armed:[true, true], blockT:0, blocking:false, blockUntil:-9, ducking:false, shake:0, flash:0, flashCol:'255,255,255', hitStop:0,
      coinN:0, ko:0, kos:0, msg:null, crowd:0, legsOK:true, hits:0, whiffs:0, combo10:false, padT:0.6, hurtT:0, best:+store.get('mp-best-boxing', 0), kbBlock:-9, dodgeMsg:0, feintFooled:false, outroKind:null, f:null });
    this.crowdFig = Array.from({ length:26 }, (_, i) => ({ x:(i + 0.5) / 26, ph:rand(0, TAU), c:pick(['#2a2f55', '#3b2a55', '#552a3b', '#2a4a55', '#4a3a2a']), h:rand(0.85, 1.15), row:i % 2 }));
    Music.setLevel(0.5);
    if (motionLive()) sendTracker({ t:'calibrate' });
  },
  exit(){ Music.setLevel(1); },
  keys(k){ const l = { a:0, s:1, d:2 }[k]; if (l !== undefined && this.state === 'fight') this.punch(l === 2 ? 1 : l === 0 ? 0 : (this.lastHand === 0 ? 1 : 0), l); if (k === 'b' || k === 'B') this.kbBlock = this.t + 0.7; },
  set(st){ this.state = st; this.stateT = 0; },
  startRound(){
    this.roundLen = Math.min(60, 42 + this.round * 3); this.roundT = 0; this.emax = 70 + this.round * 15; this.ehp = this.emax; this.pads = []; this.atk = null; this.atkT = 2.0;
    this.combo = 0; this.combo10 = false; this.msg = { text:`Round ${this.round}`, t:0, sub:'FIGHT!' }; this.set('intro'); SFX.go();
  },
  fistKind(){ return Math.random() < 0.38 ? 'high' : 'mid'; },

  // ---- sensing: the same body measurements Fit Zone uses ----
  sense(dt){
    const f = I.ex && motionLive() ? I.ex : null; this.f = f;
    // block: both hands up in front of the face (between chin and top of head, not stretched overhead, hands close in)
    let blk = false;
    if (f) { const wly = f[1], wry = f[3], wlx = f[0], wrx = f[2]; blk = wly < 0.1 && wly > -1.15 && wry < 0.1 && wry > -1.15 && Math.abs(wlx) < 0.85 && Math.abs(wrx) < 0.85 && Math.abs(wlx - wrx) < 1.3 && !(wly < -0.95 && wry < -0.95 && Math.abs(wlx - wrx) > 1.6); }
    if (this.t < this.kbBlock) blk = true;
    this.blockT = blk ? this.blockT + dt : 0; this.blocking = this.blockT >= BOXCFG.blockHold; if (this.blocking) this.blockUntil = this.t;
    this.ducking = duckInput();
    if (!f || f.length < 22) return;
    for (const k of [0, 1]) {
      const ext = f[18 + k], fwd = f[20 + k], wy = f[k ? 3 : 1], H_ = this.handsH[k];
      H_.push({ t:this.t, ext, fwd }); while (H_.length && this.t - H_[0].t > BOXCFG.win) H_.shift();
      if (this.t - this.lastPunch[k] < BOXCFG.refractory || H_.length < 3) continue;
      if (!this.armed[k]) { if (ext < 0.72) this.armed[k] = true; else continue; }
      const eMin = Math.min(...H_.map(h => h.ext)), fMin = Math.min(...H_.map(h => h.fwd));
      const isPunch = (ext - eMin > BOXCFG.extGain && ext > BOXCFG.extMin) || (fwd - fMin > BOXCFG.fwdGain && ext > 0.7 && fwd > 0.15);
      if (isPunch && Math.abs(wy) < BOXCFG.yBand && !this.blocking) { this.lastPunch[k] = this.t; this.armed[k] = false; this.punch(k); }
    }
  },
  // a punch with fist k (0 = left, 1 = right): which pad is it aimed at?
  punch(k, laneHint){
    if (this.state !== 'fight') return;
    const hd = I.hands[k], live = hd && handLive(hd, performance.now()), padR = H * 0.075;
    let best = null, bd = 1e9;
    for (const p of this.pads) {
      if (p.hit) continue;
      const d = laneHint !== undefined ? Math.abs(p.lane - laneHint) * 1000 : live ? Math.hypot(hd.x - p.x, hd.y - p.y) : Math.abs(p.x - (k ? W * 0.62 : W * 0.38)) + Math.abs(p.y - H * 0.45);
      if (d < bd) { bd = d; best = p; }
    }
    const reach = laneHint !== undefined ? 500 : live ? padR * 2.6 : W * 0.4;
    this.swing = { k, t:0.18 };
    if (best && bd <= reach) { this.hitPad(best, k); } else { this.whiffs++; noise(0.07, 0.07, 'bandpass', 900); }
  },
  hitPad(p, k){
    p.hit = true; this.hits++;
    const alt = this.lastHand >= 0 && this.lastHand !== k;
    this.combo = (this.comboT > 0 ? this.combo : 0) + 1; this.comboT = 1.5; this.bestCombo = Math.max(this.bestCombo, this.combo);
    this.alt = alt ? this.alt + 1 : 0; this.lastHand = k;
    this.hist.push(k ? 'R' : 'L'); if (this.hist.length > 4) this.hist.shift();
    const mult = 1 + Math.floor(this.combo / 4), pts = 100 * mult + (this.alt >= 2 ? 40 * this.alt : 0);
    this.score += pts;
    const dmg = 9 + Math.min(10, this.combo * 1.2);
    this.ehp = Math.max(0, this.ehp - dmg); this.hitStop = 0.05; this.shake = 0.35;
    SFX.hit(); noise(0.1, 0.35, 'lowpass', 600); tone(130, 0.14, 'sine', 0.3, 55);
    burst(this.parts, p.x, p.y, 18, ['#ffe14a', '#fff', '#ff7a3f'], H * 0.9, H * 0.011, 0.6, 0.6);
    pop(this.pops, p.x, p.y - H * 0.06, `+${pts}`, '#ffe14a', 0.045, 0.9);
    if (this.combo >= 3 && this.combo % 3 === 0 || (this.alt === 2)) {
      const lab = this.alt >= 2 ? this.hist.slice(-3).join('-') + '!' : `COMBO ×${this.combo}`;
      pop(this.pops, W / 2, H * 0.2, lab, '#fff', 0.07, 1.2); this.cheer(this.combo >= 6 ? 1 : 0.6);
    }
    if (this.combo >= 10 && !this.combo10) { this.combo10 = true; this.coinN += earnCoins(1); pop(this.pops, W / 2, H * 0.3, '10-HIT COMBO!  ● +1', '#ffd23f', 0.06, 1.5); }
    if (this.ehp <= 0) this.knockout();
  },
  cheer(v){ this.crowd = Math.max(this.crowd, v); noise(0.9, 0.12 * v, 'bandpass', 1400); setTimeout(() => noise(0.7, 0.08 * v, 'bandpass', 2000), 160); },
  knockout(){
    this.kos++; this.hitStop = 0.25; this.shake = 1.2; this.flash = 0.7; this.flashCol = '255,255,255';
    noise(0.5, 0.5, 'lowpass', 400); tone(70, 0.5, 'sine', 0.4, 30); SFX.fanfare(); this.cheer(1.4);
    const bonus = 500 + this.round * 100 + Math.floor((this.roundLen - this.roundT) * 10); this.score += bonus;
    const c = 3 + (this.round >= 3 ? 1 : 0); this.coinN += earnCoins(c);
    this.msg = { text:'KNOCKOUT!', t:0, sub:`+${bonus}  ·  ● +${c}` }; this.outroKind = 'ko'; this.pads = []; this.atk = null; this.set('outro');
  },
  endRoundTime(){
    const c = 1; this.coinN += earnCoins(c); const bonus = 150 * this.round; this.score += bonus;
    this.msg = { text:'TIME!', t:0, sub:`Round ${this.round} done  ·  +${bonus}  ·  ● +${c}` }; this.outroKind = 'time'; this.pads = []; this.atk = null; this.cheer(0.8); this.set('outro');
  },
  playerHit(dmg, label){
    this.hp = Math.max(0, this.hp - dmg); this.combo = 0; this.comboT = 0; this.shake = 1; this.flash = 0.5; this.flashCol = '255,50,50'; this.hurtT = 0.4; SFX.hit(); noise(0.12, 0.4, 'lowpass', 500);
    pop(this.pops, W / 2, H * 0.5, `${label}  -${dmg}`, '#ff5a5a', 0.07, 1.1);
    if (this.hp <= 0) { this.msg = { text:'You were knocked out!', t:0, sub:'' }; this.set('lost'); }
  },

  update(dt){
    this.parts = stepParts(this.parts, dt); this.pops = stepPops(this.pops, dt);
    this.stateT += dt; this.crowd = Math.max(0, this.crowd - dt * 0.6); this.flash = Math.max(0, this.flash - dt * 2.5); this.shake = Math.max(0, this.shake - dt * 3); this.hurtT = Math.max(0, this.hurtT - dt);
    if (this.msg) this.msg.t += dt; if (this.swing) { this.swing.t -= dt; if (this.swing.t <= 0) this.swing = null; }
    if (this.hitStop > 0) { this.hitStop -= dt; return; }
    this.t += dt;
    this.sense(dt);
    if (this.state === 'ready') { if (this.stateT > 3.2) this.startRound(); return; }
    if (this.state === 'intro') { if (this.stateT > 1.6) this.set('fight'); return; }
    if (this.state === 'outro') { if (this.stateT > 2.6) { this.round++; this.hp = Math.min(100, this.hp + 30); this.startRound(); } return; }
    if (this.state === 'lost') { if (this.stateT > 2.2) go('over', { game:'boxing', score:this.score, detail:`Round ${this.round} · best combo ${this.bestCombo} · ${this.kos} knockout${this.kos === 1 ? '' : 's'}`, coins:this.coinN }); return; }
    // ----- fight -----
    this.roundT += dt; this.comboT = Math.max(0, this.comboT - dt); if (this.comboT <= 0 && this.combo > 0) { if (this.combo >= 4) pop(this.pops, W / 2, H * 0.36, `${this.combo}-hit combo`, '#e8f4ff', 0.04, 1); this.combo = 0; }
    if (this.roundT >= this.roundLen) return this.endRoundTime();
    const r = this.round;
    // pads (targets)
    this.padT -= dt; const maxPads = Math.min(3, 1 + Math.floor(r / 2));
    if (this.padT <= 0 && this.pads.filter(p => !p.hit).length < maxPads) {
      const free = [0, 1, 2].filter(l => !this.pads.some(p => p.lane === l && !p.hit));
      if (free.length) { const l = pick(free); this.pads.push({ lane:l, x:W * BOX_LANES[l], y:H * (l === 1 ? 0.4 : 0.5) + rand(-0.03, 0.03) * H, life:Math.max(0.9, 2.0 - r * 0.12), age:0, hit:false, ph:rand(0, TAU) }); }
      this.padT = Math.max(0.5, 1.25 - r * 0.09) * rand(0.8, 1.2);
    }
    for (const p of this.pads) { p.age += dt; if (p.hit) p.fade = (p.fade || 0) + dt; else if (p.age > p.life) { p.gone = true; this.combo = 0; this.comboT = 0; } }
    this.pads = this.pads.filter(p => !p.gone && !(p.hit && p.fade > 0.25));
    // opponent attacks
    if (!this.atk) { this.atkT -= dt; if (this.atkT <= 0 && !this.pads.length < 0) {} if (this.atkT <= 0) {
      const feint = r >= 2 && Math.random() < Math.min(0.45, 0.12 + 0.07 * r);
      this.atk = { kind:this.fistKind(), feint, t:0, wind:Math.max(0.55, 1.0 - r * 0.06), side:Math.random() < 0.5 ? -1 : 1, done:false, flinched:false };
      noise(0.25, 0.12, 'bandpass', 500);
    } }
    else this.updateAttack(dt);
  },
  updateAttack(dt){
    const a = this.atk; a.t += dt; const p = a.t / a.wind;
    if (this.blocking || this.ducking) a.flinched = a.flinched || p > 0.3;       // you reacted early
    if (a.feint && !a.done && p >= 0.7) {
      a.done = true;
      if (this.blocking || this.ducking) { this.combo = 0; this.comboT = 0; pop(this.pops, W / 2, H * 0.4, 'Fooled by the feint!', '#ffc24a', 0.05, 1.1); }
      else { this.score += 25; pop(this.pops, W / 2, H * 0.4, 'Good read!  +25', '#7fe6ff', 0.05, 1.1); }
    }
    if (!a.feint && !a.done && p >= 1) {
      a.done = true;
      const protectedNow = this.t - this.blockUntil < 0.18;
      if (a.kind === 'mid') {
        if (protectedNow) { SFX.land(); tone(900, 0.1, 'square', 0.1); noise(0.1, 0.2, 'highpass', 2500); this.score += 40; pop(this.pops, W / 2, H * 0.45, 'BLOCKED!  +40', '#7fe6ff', 0.06, 1); this.shake = 0.3; }
        else this.playerHit(14, 'HIT!');
      } else {
        if (this.ducking) { SFX.whoosh(); this.score += 60; pop(this.pops, W / 2, H * 0.45, 'DODGED!  +60', '#4fd27a', 0.06, 1); }
        else if (protectedNow) { tone(700, 0.1, 'square', 0.1); this.playerHit(7, 'Half-blocked'); }
        else this.playerHit(18, 'OVERHEAD!');
      }
    }
    if (a.t > a.wind + 0.45) { this.atk = null; this.atkT = Math.max(1.1, 3.0 - this.round * 0.22) * rand(0.8, 1.2); }
  },
  rescale(sc){ for (const arr of [this.parts, this.pops, this.pads]) for (const o of arr) sc(o, true); },

  /* ---------------- drawing ---------------- */
  background(){
    ctx.drawImage(cachedLayer('dojo', g => {
      const wall = g.createLinearGradient(0, 0, 0, H * 0.6); wall.addColorStop(0, '#3a1f1a'); wall.addColorStop(1, '#6b3a24'); g.fillStyle = wall; g.fillRect(0, 0, W, H * 0.62);
      g.fillStyle = 'rgba(0,0,0,0.18)'; for (let x = 0; x < W; x += W / 9) g.fillRect(x, 0, 4, H * 0.62);
      for (const bx of [0.1, 0.9]) { g.fillStyle = '#b8222d'; g.fillRect(W * bx - W * 0.04, H * 0.06, W * 0.08, H * 0.34); g.fillStyle = '#f4e3b0'; g.font = `800 ${H * 0.08}px sans-serif`; g.textAlign = 'center'; g.fillText(bx < 0.5 ? '力' : '道', W * bx, H * 0.18); g.fillText(bx < 0.5 ? '武' : '場', W * bx, H * 0.3); }
      for (const lx of [0.27, 0.5, 0.73]) { g.fillStyle = '#e8402a'; g.beginPath(); g.ellipse(W * lx, H * 0.1, W * 0.025, H * 0.05, 0, 0, TAU); g.fill(); g.fillStyle = '#ffd890'; g.beginPath(); g.ellipse(W * lx, H * 0.1, W * 0.012, H * 0.03, 0, 0, TAU); g.fill(); g.strokeStyle = '#2a1b12'; g.lineWidth = 3; g.beginPath(); g.moveTo(W * lx, 0); g.lineTo(W * lx, H * 0.05); g.stroke(); }
      const fl = g.createLinearGradient(0, H * 0.58, 0, H); fl.addColorStop(0, '#c89a5a'); fl.addColorStop(1, '#8a5f33'); g.fillStyle = fl; g.fillRect(0, H * 0.58, W, H * 0.42);
      g.strokeStyle = 'rgba(80,50,20,0.35)'; g.lineWidth = 2; for (let i = 0; i < 9; i++) { const y = H * 0.58 + i * H * 0.047; g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
      g.fillStyle = '#e8dcc0'; g.beginPath(); g.moveTo(W * 0.14, H * 0.96); g.lineTo(W * 0.86, H * 0.96); g.lineTo(W * 0.76, H * 0.68); g.lineTo(W * 0.24, H * 0.68); g.closePath(); g.fill();
      g.strokeStyle = '#b8222d'; g.lineWidth = 6; g.stroke();
    }), 0, 0);
    // the crowd along the back wall, jumping when they cheer
    for (const c of this.crowdFig) {
      const jump = Math.max(0, Math.sin(sceneT * 9 + c.ph)) * this.crowd * H * 0.03, x = c.x * W, y = H * (0.6 + c.row * 0.035) - jump, s = H * 0.05 * c.h;
      ctx.fillStyle = c.c; ctx.beginPath(); ctx.arc(x, y - s * 0.9, s * 0.32, 0, TAU); ctx.fill(); roundRect(x - s * 0.4, y - s * 0.6, s * 0.8, s * 0.8, s * 0.2); ctx.fill();
      if (this.crowd > 0.3) { ctx.strokeStyle = c.c; ctx.lineWidth = s * 0.12; ctx.beginPath(); ctx.moveTo(x - s * 0.35, y - s * 0.4); ctx.lineTo(x - s * 0.6, y - s * 1.1 - jump * 0.3); ctx.moveTo(x + s * 0.35, y - s * 0.4); ctx.lineTo(x + s * 0.6, y - s * 1.1 - jump * 0.3); ctx.stroke(); }
    }
  },
  drawMaster(){
    const cx = W * 0.5, base = H * 0.88, s = H * 0.5, a = this.atk, p = a ? clamp(a.t / a.wind, 0, 1) : 0;
    const bob = Math.sin(sceneT * 3) * s * 0.012, lunge = a && !a.feint && p > 0.55 ? (p - 0.55) * s * 0.3 : 0, hurt = this.hitStop > 0 || this.state === 'outro' && this.outroKind === 'ko';
    ctx.save(); ctx.translate(cx + (a && a.feint && p > 0.3 ? Math.sin(sceneT * 30) * s * 0.01 : 0), base + bob - lunge * 0.4);
    if (hurt) { ctx.rotate(this.outroKind === 'ko' ? Math.min(0.6, this.stateT * 1.2) : 0.04); ctx.translate(0, this.outroKind === 'ko' ? Math.min(s * 0.2, this.stateT * s * 0.4) : 0); }
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(0, s * 0.02, s * 0.34, s * 0.05, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#1f2a55'; roundRect(-s * 0.2, -s * 0.5, s * 0.17, s * 0.5, s * 0.05); ctx.fill(); roundRect(s * 0.03, -s * 0.5, s * 0.17, s * 0.5, s * 0.05); ctx.fill();      // legs (hakama)
    ctx.fillStyle = '#f4f4fa'; roundRect(-s * 0.3, -s * 1.0, s * 0.6, s * 0.58, s * 0.1); ctx.fill();                                                                           // gi top
    ctx.fillStyle = '#d6d6e4'; ctx.beginPath(); ctx.moveTo(-s * 0.08, -s * 1.0); ctx.lineTo(0, -s * 0.78); ctx.lineTo(s * 0.08, -s * 1.0); ctx.fill();
    ctx.fillStyle = '#16161e'; ctx.fillRect(-s * 0.31, -s * 0.5, s * 0.62, s * 0.07);                                                                                            // black belt
    const headY = -s * 1.17; ctx.fillStyle = '#f0c9a0'; ctx.beginPath(); ctx.arc(0, headY, s * 0.15, 0, TAU); ctx.fill();
    ctx.fillStyle = '#16161e'; ctx.beginPath(); ctx.arc(0, headY - s * 0.03, s * 0.158, Math.PI * 1.04, Math.PI * 1.96); ctx.fill();
    ctx.fillStyle = '#d6263a'; ctx.fillRect(-s * 0.16, headY - s * 0.075, s * 0.32, s * 0.05); ctx.fillRect(s * 0.1, headY - s * 0.07, s * 0.2, s * 0.03);
    const tell = a && !a.feint && p > 0.5, fe = a && a.feint && p > 0.5;
    ctx.strokeStyle = '#2a1b12'; ctx.lineWidth = s * 0.012; ctx.beginPath(); ctx.moveTo(-s * 0.09, headY - s * 0.005 - (tell ? s * 0.025 : 0)); ctx.lineTo(-s * 0.03, headY + s * 0.012); ctx.moveTo(s * 0.09, headY - s * 0.005 - (tell ? s * 0.025 : 0)); ctx.lineTo(s * 0.03, headY + s * 0.012); ctx.stroke();
    ctx.beginPath(); if (tell) { ctx.arc(0, headY + s * 0.085, s * 0.03, 0, TAU); ctx.fillStyle = '#5a1f1f'; ctx.fill(); } else { ctx.moveTo(-s * 0.04, headY + s * 0.075); ctx.lineTo(s * 0.04, headY + s * 0.075); ctx.stroke(); }
    // guard fists (the one that attacks is drawn separately, big, towards you)
    for (const sd of [-1, 1]) { if (a && sd === a.side && p > 0.05) continue; ctx.fillStyle = '#f4f4fa'; ctx.beginPath(); ctx.ellipse(sd * s * 0.34, -s * 0.85, s * 0.07, s * 0.16, sd * 0.2, 0, TAU); ctx.fill(); ctx.fillStyle = '#e63946'; ctx.beginPath(); ctx.arc(sd * s * 0.37, -s * 0.97, s * 0.1, 0, TAU); ctx.fill(); }
    ctx.restore();
    if (a) this.drawAttack(a, p, cx, base, s);
    if (fe) text('feint?', cx, H * 0.2, H * 0.04, '#ffe14a', 'center', 800);
  },
  drawAttack(a, p, cx, base, s){
    // the fist cocks back, then flies towards you: real = it keeps coming (and glows red), feint = it stops and pulls back
    const sx = cx + a.side * s * 0.37, sy = base - s * 0.97, tx = W * 0.5 - a.side * W * 0.04, ty = a.kind === 'high' ? H * 0.12 : H * 0.62;
    const reach = a.feint ? Math.sin(Math.min(1, p / 0.7) * Math.PI * 0.5) * (p > 0.7 ? Math.max(0, 1 - (p - 0.7) / 0.3) : 1) * 0.6 : Math.min(1, Math.max(0, (p - 0.25) / 0.75));
    const k = a.feint ? reach : reach * reach, x = sx + (tx - sx) * k - (p < 0.25 ? a.side * s * 0.05 * (p / 0.25) : 0), y = sy + (ty - sy) * k - (p < 0.25 ? s * 0.06 * (p / 0.25) : 0), r = s * (0.1 + 0.34 * k);
    const real = !a.feint && p > 0.5;
    if (real) { const gl = ctx.createRadialGradient(x, y, r * 0.3, x, y, r * 2); gl.addColorStop(0, 'rgba(255,60,60,0.7)'); gl.addColorStop(1, 'rgba(255,60,60,0)'); ctx.fillStyle = gl; ctx.fillRect(x - r * 2, y - r * 2, r * 4, r * 4); }
    ctx.fillStyle = '#e63946'; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.fillStyle = '#f4f4fa'; ctx.beginPath(); ctx.arc(x, y + r * 0.45, r * 0.55, 0, Math.PI); ctx.fill();
    if (p > 0.2 && p < 1.1) { const high = a.kind === 'high'; text(high ? '⬇ DUCK' : '✋ BLOCK', W / 2, H * 0.26, H * 0.05, real ? '#ff6b6b' : '#ffe14a', 'center', 800); }
  },
  drawPad(p){
    const r = H * 0.075, k = p.hit ? 1 + (p.fade || 0) * 3 : 1, life = clamp(1 - p.age / p.life, 0, 1);
    ctx.save(); ctx.translate(p.x, p.y + Math.sin(sceneT * 5 + p.ph) * H * 0.006); ctx.globalAlpha = p.hit ? Math.max(0, 1 - (p.fade || 0) * 4) : 1;
    const gl = ctx.createRadialGradient(0, 0, r * 0.4, 0, 0, r * 1.9 * k); gl.addColorStop(0, 'rgba(255,225,90,0.8)'); gl.addColorStop(1, 'rgba(255,225,90,0)'); ctx.fillStyle = gl; ctx.fillRect(-r * 2 * k, -r * 2 * k, r * 4 * k, r * 4 * k);
    ctx.fillStyle = '#ffb02e'; ctx.beginPath(); ctx.arc(0, 0, r * k, 0, TAU); ctx.fill(); ctx.fillStyle = '#fff3c4'; ctx.beginPath(); ctx.arc(0, 0, r * 0.62 * k, 0, TAU); ctx.fill(); ctx.fillStyle = '#e63946'; ctx.beginPath(); ctx.arc(0, 0, r * 0.28 * k, 0, TAU); ctx.fill();
    ctx.strokeStyle = life > 0.35 ? '#fff' : '#ff5a5a'; ctx.lineWidth = r * 0.14; ctx.beginPath(); ctx.arc(0, 0, r * 1.25, -Math.PI / 2, -Math.PI / 2 + TAU * life); ctx.stroke();
    ctx.restore();
  },
  drawGloves(){
    const now = performance.now();
    I.hands.forEach((hd, k) => {
      if (!handLive(hd, now)) return;
      const ext = this.f && this.f.length > 21 ? this.f[18 + k] : 0.8, sc = 1 + clamp(ext - 0.8, 0, 0.6) * 0.5, r = H * 0.05 * sc, sw = this.swing && this.swing.k === k ? 1.35 : 1;
      ctx.fillStyle = k ? '#2f7cf6' : '#e63946'; ctx.beginPath(); ctx.arc(hd.x, hd.y, r * sw, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.arc(hd.x - r * 0.3, hd.y - r * 0.3, r * 0.3, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(2, r * 0.12); ctx.beginPath(); ctx.arc(hd.x, hd.y, r * sw, 0, TAU); ctx.stroke();
    });
    if (this.blocking) { ctx.strokeStyle = 'rgba(127,230,255,0.8)'; ctx.lineWidth = H * 0.012; ctx.beginPath(); ctx.arc(W / 2, H * 0.8, H * 0.2, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); text('BLOCK', W / 2, H * 0.62, H * 0.04, '#7fe6ff', 'center', 800); }
    if (this.ducking) text('DUCK', W / 2, H * 0.62, H * 0.04, '#4fd27a', 'center', 800);
  },
  draw(now){
    ctx.save();
    if (this.shake > 0) ctx.translate(rand(-1, 1) * this.shake * H * 0.012, rand(-1, 1) * this.shake * H * 0.012);
    this.background(); this.drawMaster();
    for (const p of this.pads) this.drawPad(p);
    drawParts(this.parts); drawPops(this.pops); this.drawGloves();
    ctx.restore();
    if (this.flash > 0) { ctx.fillStyle = `rgba(${this.flashCol},${this.flash * 0.45})`; ctx.fillRect(0, 0, W, H); }
    if (this.hurtT > 0) { ctx.strokeStyle = `rgba(255,40,40,${this.hurtT * 2})`; ctx.lineWidth = H * 0.05; ctx.strokeRect(0, 0, W, H); }
    this.drawHud();
    if (this.state === 'ready') {
      text('Boxing Dojo', W / 2, H * 0.12, H * 0.07, '#fff'); text(String(Math.max(1, Math.ceil(3.2 - this.stateT))), W / 2, H * 0.28, H * 0.1, '#ffe14a');
      text('PUNCH the glowing pads · hands up at your face to BLOCK · DUCK for overhead swings', W / 2, H * 0.37, H * 0.028, '#fff', 'center', 700);
    }
    if (this.msg && (this.state === 'intro' || this.state === 'outro' || this.state === 'lost')) { const a = this.state === 'intro' ? 1 : 1; ctx.globalAlpha = a; text(this.state === 'intro' && this.msg.t > 0.8 ? this.msg.sub : this.msg.text, W / 2, H * 0.33, H * 0.11, this.state === 'lost' ? '#ff5a5a' : '#fff'); if (this.state !== 'intro' && this.msg.sub) text(this.msg.sub, W / 2, H * 0.42, H * 0.04, '#ffe9a8', 'center', 700); ctx.globalAlpha = 1; }
  },
  drawHud(){
    const fk = Math.min(1, W / (H * 1.3)), bw = W * 0.3, by = H * 0.04, bh = H * 0.032;
    const bar = (x, k, col, label, right) => { ctx.fillStyle = 'rgba(0,0,0,0.4)'; roundRect(x, by, bw, bh, bh / 2); ctx.fill(); ctx.fillStyle = col; const w = Math.max(bh, bw * clamp(k, 0, 1)); roundRect(right ? x + bw - w : x, by, w, bh, bh / 2); if (k > 0) ctx.fill(); text(label, right ? x + bw : x, by + bh + H * 0.03, H * 0.024 * fk, '#fff', right ? 'right' : 'left', 700); };
    bar(W * 0.03, this.hp / 100, this.hp > 35 ? '#4fd27a' : '#ff5a5a', 'YOU', false);
    bar(W * 0.67, this.ehp / this.emax, '#ffb02e', 'SENSEI', true);
    text(this.state === 'fight' || this.state === 'intro' ? String(Math.max(0, Math.ceil(this.roundLen - this.roundT))) : '', W / 2, H * 0.085, H * 0.06 * fk, '#fff');
    text(`Round ${this.round}  ·  ${this.score} pts  ·  ● ${this.coinN}`, W / 2, H * 0.165, H * 0.026 * fk, '#ffe9a8', 'center', 700);
    if (this.combo >= 2) {
      text(`${this.combo} HIT COMBO  ×${1 + Math.floor(this.combo / 4)}`, W * 0.5, H * 0.935, H * 0.05 * fk, '#ffe14a');
      const k = clamp(this.comboT / 1.5, 0, 1), cw = W * 0.2; ctx.fillStyle = 'rgba(0,0,0,0.3)'; roundRect(W / 2 - cw / 2, H * 0.955, cw, H * 0.012, H * 0.006); ctx.fill(); ctx.fillStyle = '#ffe14a'; roundRect(W / 2 - cw / 2, H * 0.955, Math.max(H * 0.012, cw * k), H * 0.012, H * 0.006); ctx.fill();
    }
    if (this.hist.length && this.combo >= 2) text(this.hist.join(' – '), W * 0.5, H * 0.89, H * 0.03 * fk, '#fff', 'center', 800);
    if (!(motionLive() && I.present) && this.state !== 'lost') text(motionLive() ? 'Step back into view' : 'Keyboard: A / S / D punch · B block · ↓ duck', W / 2, H * 0.985, H * 0.024, '#ffc24a', 'center', 700);
  },
};
