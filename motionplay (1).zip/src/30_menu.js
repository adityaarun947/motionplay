/* =====================================================================
   MENU
   ===================================================================== */
scenes.menu = {
  hint:'Hold a hand over a game on the TV to start it',
  enter(){
    this.focus = 0;
    const card = i => () => { const w = Math.min(W * 0.17, H * 0.205), h = w * 1.3, gap = Math.min(W * 0.013, H * 0.02), row = i < 5 ? 0 : 1, n = row ? 4 : 5, c = row ? i - 5 : i, tot = n * w + (n - 1) * gap; return [W / 2 - tot / 2 + c * (w + gap), H * 0.235 + row * (h + gap), w, h]; };
    this.buttons = [
      HoverButton('Fruit Slash', 'Swipe to slice', card(0), () => go('fruit'), '#ff6b5a', { draw:drawFruitIcon, best:'fruit' }),
      HoverButton('Lane Runner', 'Step · jump · 1–2 players', card(1), () => launch('runner'), '#4fd27a', { draw:drawRunnerIcon, best:'runner' }),
      HoverButton('Zombie Siege', 'Aim & blast · 1–2 players', card(2), () => launch('zombie'), '#b46bff', { draw:drawZombieIcon, best:'zombie' }),
      HoverButton('Fit Zone', 'Guided workouts', card(3), () => go('fithub'), '#3ee0c0', { draw:drawFitIcon }),
      HoverButton('Shape Fit', 'Fit the hole · 1–2 players', card(4), () => launch('shape'), '#ff8a3d', { draw:drawShapeIcon, best:'shape' }),
      HoverButton('Penguin Slide', 'Slip · jump · dash · 1–2 players', card(5), () => launch('penguin'), '#4db8ff', { draw:drawPenguinIcon, best:'penguin' }),
      HoverButton('Balloon Burst', 'Reach & pop', card(6), () => go('balloon'), '#ff5a8a', { draw:drawBalloonIcon, best:'balloon' }),
      HoverButton('Simon Says', 'Copy the moves', card(7), () => go('simon'), '#ffd23f', { draw:drawSimonIcon, best:'simon' }),
      HoverButton('Boxing Dojo', 'Punch · block · duck', card(8), () => go('boxing'), '#e63946', { draw:drawBoxingIcon, best:'boxing' }),
      HoverButton('Customize & shop', '', () => [W / 2 - Math.min(W * 0.2, H * 0.36) / 2, H * 0.87, Math.min(W * 0.2, H * 0.36), H * 0.07], () => go('locker'), '#ffb36b'),
    ];
  },
  keys(k){
    if (k === 'ArrowLeft') this.focus = Math.max(0, this.focus - 1);
    if (k === 'ArrowDown') this.focus = Math.min(9, this.focus + 5 > 8 ? 9 : this.focus + 5);
    if (k === 'ArrowUp') this.focus = this.focus >= 9 ? 7 : Math.max(0, this.focus - 5);
    if (k === 'ArrowRight') this.focus = Math.min(8, this.focus + 1);
    if (k === 'Enter') { SFX.select(); this.buttons[this.focus].action(); }
  },
  update(dt){ this.buttons.forEach((b, i) => b.focus = I.kb.active && i === this.focus); updateButtons(this.buttons, dt, sceneT); },
  draw(){
    ctx.drawImage(cachedLayer('menu', g => {
      const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#1b1f4a'); gr.addColorStop(1, '#0b0e1f');
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
    }), 0, 0);
    for (let i = 0; i < 40; i++) { const x = (i * 197.3 + sceneT * 12 * (1 + i % 3)) % W, y = (i * 113.7) % (H * 0.95); ctx.fillStyle = 'rgba(255,255,255,0.08)'; ctx.beginPath(); ctx.arc(x, y, 2 + i % 3, 0, TAU); ctx.fill(); }
    drawGhost(0.16);
    text('MotionPlay', W / 2, H * 0.11, H * 0.09, '#fff');
    text(motionLive() ? 'Hold a hand over a game to start' : 'Use ← → and Enter, or click a game', W / 2, H * 0.2, H * 0.035, '#c9d2ff', 'center', 600);
    text('MotionPlay v9 · 9 games · 2-player', 20, H * 0.975, H * 0.022, '#9aa6d8', 'left', 600);
    if (Music.muted) text('♪ music off', W - 20, H * 0.03, H * 0.022, '#9aa6d8', 'right', 600);
    text(`● ${WALLET.coins} coins`, W - 20, H * 0.975, H * 0.026, '#ffd23f', 'right', 800);
    drawButtons(this.buttons);
  }
};
function drawFruitIcon(x, y, w, h){ const r = h * 0.17; ctx.save(); ctx.translate(x + w / 2 - r * 0.5, y + h * 0.33); drawFruit(FRUITS[0], r, 0); ctx.restore(); ctx.save(); ctx.translate(x + w / 2 + r * 0.9, y + h * 0.37); drawFruit(FRUITS[1], r * 0.7, 0); ctx.restore(); }
function drawRunnerIcon(x, y, w, h){
  const cx = x + w / 2, top = y + h * 0.12, bot = y + h * 0.58;
  ctx.fillStyle = '#3a3f55'; ctx.beginPath(); ctx.moveTo(cx - w * 0.08, top); ctx.lineTo(cx + w * 0.08, top); ctx.lineTo(cx + w * 0.38, bot); ctx.lineTo(cx - w * 0.38, bot); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#c9d2ff'; ctx.lineWidth = 3;
  for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(cx + s * w * 0.027, top); ctx.lineTo(cx + s * w * 0.127, bot); ctx.stroke(); }
  ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.arc(cx, bot - h * 0.1, h * 0.05, 0, TAU); ctx.fill();
}
function drawPenguinIcon(x, y, w, h){
  const cx = x + w / 2, cy = y + h * 0.55, s = h * 0.62, bob = Math.sin(sceneT * 3) * s * 0.02;
  ctx.fillStyle = '#e8f6ff'; ctx.beginPath(); ctx.ellipse(cx, cy + s * 0.08, s * 0.5, s * 0.1, 0, 0, TAU); ctx.fill();
  ctx.save(); ctx.translate(cx, cy + bob); ctx.rotate(Math.sin(sceneT * 2) * 0.12);
  ctx.fillStyle = '#ff9a1f'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * s * 0.1, -s * 0.06); ctx.lineTo(sd * s * 0.2, s * 0.06); ctx.lineTo(sd * s * 0.04, s * 0.05); ctx.fill(); }
  ctx.fillStyle = '#1d2233'; for (const sd of [-1, 1]) { ctx.save(); ctx.translate(sd * s * 0.26, -s * 0.28); ctx.rotate(sd * 0.9); ctx.beginPath(); ctx.ellipse(0, 0, s * 0.07, s * 0.2, 0, 0, TAU); ctx.fill(); ctx.restore(); }
  ctx.fillStyle = '#262c42'; ctx.beginPath(); ctx.ellipse(0, -s * 0.28, s * 0.3, s * 0.3, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(0, -s * 0.62, s * 0.17, 0, TAU); ctx.fill();
  ctx.fillStyle = '#ff4f6d'; roundRect(-s * 0.19, -s * 0.5, s * 0.38, s * 0.09, s * 0.04); ctx.fill();
  ctx.restore();
}
function drawSimonIcon(x, y, w, h){
  const cx = x + w / 2, cy = y + h * 0.42, r = h * 0.2, cols = ['#ff5a5a', '#4fd27a', '#5b8cff', '#ffd23f'], lit = Math.floor(sceneT * 2) % 4;
  cols.forEach((c, i) => { const a = i * Math.PI / 2 - Math.PI / 4; ctx.fillStyle = c; ctx.globalAlpha = i === lit ? 1 : 0.45; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r * 1.5, a - Math.PI / 4 + 0.05, a + Math.PI / 4 - 0.05); ctx.closePath(); ctx.fill(); });
  ctx.globalAlpha = 1; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(cx, cy, r * 0.55, 0, TAU); ctx.fill(); ctx.fillStyle = '#1b1f4a'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.arc(cx + sd * r * 0.2, cy - r * 0.08, r * 0.07, 0, TAU); ctx.fill(); } ctx.beginPath(); ctx.arc(cx, cy + r * 0.08, r * 0.2, 0.15, Math.PI - 0.15); ctx.stroke();
}
function drawBoxingIcon(x, y, w, h){
  const cx = x + w / 2, cy = y + h * 0.44, r = h * 0.17, p = Math.abs(Math.sin(sceneT * 3));
  for (const [sd, col] of [[-1, '#e63946'], [1, '#2f7cf6']]) { const k = sd < 0 ? p : 1 - p, gx = cx + sd * r * (1.5 - k * 0.7), gr = r * (0.85 + k * 0.3); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(gx, cy, gr, 0, TAU); ctx.fill(); ctx.fillStyle = '#f4f4fa'; ctx.fillRect(gx - gr * 0.5, cy + gr * 0.7, gr, gr * 0.5); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.arc(gx - gr * 0.3, cy - gr * 0.3, gr * 0.28, 0, TAU); ctx.fill(); }
  ctx.fillStyle = '#ffe14a'; for (let i = 0; i < 6; i++) { const a = i * TAU / 6 + sceneT; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * r * 0.5, cy - r * 1.4 + Math.sin(a) * r * 0.25, 3, 0, TAU); ctx.fill(); }
}
function drawBalloonIcon(x, y, w, h){
  const cx = x + w / 2, cy = y + h * 0.4;
  for (const [dx, dy, r, c] of [[-0.2, 0.06, 0.17, '#ff5a6e'], [0.2, 0.02, 0.15, '#4db8ff'], [0, -0.06 + Math.sin(sceneT * 2) * 0.02, 0.19, '#ffc800']]) {
    const bx = cx + dx * w, by = cy + dy * h, rr = r * w;
    ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(bx, by + rr * 1.1); ctx.quadraticCurveTo(bx + 8, by + rr * 1.8, cx, y + h * 0.78); ctx.stroke();
    ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(bx, by, rr, rr * 1.12, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.beginPath(); ctx.ellipse(bx - rr * 0.35, by - rr * 0.4, rr * 0.15, rr * 0.28, -0.5, 0, TAU); ctx.fill();
  }
}
function drawFitIcon(x, y, w, h){ drawCoach(x + w / 2, y + h * 0.66, h * 0.5, coachPose('jacks', sceneT, false), COACH_STYLE.kids); }
function drawZombieIcon(x, y, w, h){
  const fake = { type:'walker', size:1, phase:sceneT * 3, flash:0, lunge:0, dead:false, skin:'#7fb069', shirt:'#5a6b8c', hunch:0 };
  drawZombieBody(fake, x + w / 2, y + h * 0.62, h * 0.55, 1);
}

function drawShapeIcon(x, y, w, h){
  const cx = x + w / 2, top = y + h * 0.1, ww = w * 0.74, hh = h * 0.56;
  ctx.fillStyle = '#c9561a'; roundRect(cx - ww / 2, top, ww, hh, 10); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'destination-out'; ctx.restore();
  ctx.fillStyle = '#12163a'; drawSil(ctx, cx, top + hh * 0.95, hh * 0.78, coachPose('jacks', sceneT, false) && { aL:90 + Math.sin(sceneT * 2) * 55, aR:90 + Math.sin(sceneT * 2) * 55 }, '#12163a', 0);
}
