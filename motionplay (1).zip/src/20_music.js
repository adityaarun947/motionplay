
/* ---------------------------------------------------------------------
   MUSIC — a tiny synth band: every game has its own looping tune.
   Drums, bass, chords, an arpeggio and a lead line, all synthesized live (no audio files).
   --------------------------------------------------------------------- */
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
// "step:note step:note:len" → a 64-step melody (4 bars of 16 steps). len is in steps.
function melody(s){ const a = new Array(64).fill(null); s.trim().split(/\s+/).forEach(p => { const [st, n, l] = p.split(':').map(Number); a[st] = [n, l || 3]; }); return a; }
const R = null;

const TRACKS = {
  // gentle, welcoming
  menu:{ bpm:92, prog:[[60,64,67],[57,60,64],[53,57,60],[55,59,62]], roots:[36,33,29,31],
    bass:[0,R,R,R,R,R,R,R,0,R,R,R,R,R,7,R], bassV:{ type:'sine', vol:0.12, dur:0.5, cut:600 },
    arp:[0,R,1,R,2,R,1,R,0,R,1,R,2,R,3,R], arpV:{ type:'triangle', vol:0.07, dur:0.3, cut:2200 },
    pad:{ type:'triangle', vol:0.035, att:0.4, cut:900 },
    lead:melody('0:79:4 6:76:2 8:79:4 14:84:2 16:83:4 22:79:2 24:76:6 32:79:4 38:81:2 40:84:4 46:83:2 48:79:4 54:76:2 56:74:6'),
    leadV:{ type:'sine', vol:0.05, cut:2600 },
    drums:{ k:'x.......x.......', h:'..x...x...x...x.', soft:0.6 }, lv:{ drums:0, lead:0 } },
  // bouncy marimba-style
  fruit:{ bpm:118, prog:[[55,59,62],[52,55,59],[60,64,67],[62,66,69]], roots:[43,40,36,38],
    bass:[0,R,R,12,R,R,7,R,0,R,R,12,R,7,R,R], bassV:{ type:'triangle', vol:0.15, dur:0.22, cut:900 },
    arp:[2,R,1,2,R,1,2,R,1,R,2,1,R,2,R,3], arpV:{ type:'sine', vol:0.085, dur:0.14, cut:3000 },
    pad:{ type:'triangle', vol:0.025, att:0.2, cut:800 },
    lead:melody('0:79:2 2:83:2 4:86:2 6:83:2 8:81:3 12:79:2 16:83:2 18:86:2 20:88:3 24:86:2 26:83:2 28:81:3 32:79:2 34:83:2 36:86:2 38:88:2 40:90:3 44:88:2 48:86:3 52:83:2 54:81:2 56:79:6'),
    leadV:{ type:'triangle', vol:0.075, cut:3200, dur:0.2 },
    drums:{ k:'x.....x.x.......', s:'....x.......x...', h:'x.x.x.x.x.x.x.xx', soft:0.55 }, lv:{ drums:0, lead:0.2 } },
  // driving, sporty — speeds up with the runner
  runner:{ bpm:132, prog:[[57,60,64],[53,57,60],[60,64,67],[55,59,62]], roots:[33,29,36,31],
    bass:[0,R,0,R,12,R,0,R,0,R,12,R,0,R,7,R], bassV:{ type:'sawtooth', vol:0.085, dur:0.16, cut:650 },
    arp:[0,1,2,1,0,1,2,3,0,1,2,1,2,3,2,1], arpV:{ type:'square', vol:0.03, dur:0.09, cut:2200 },
    pad:{ type:'sawtooth', vol:0.02, att:0.1, cut:700 },
    lead:melody('0:81:2 3:84:2 6:88:2 8:86:2 10:84:2 12:81:3 16:79:2 19:83:2 22:86:2 24:84:2 26:83:2 28:79:3 32:81:2 35:84:2 38:88:2 40:91:3 44:88:2 46:84:2 48:83:2 50:86:2 52:83:2 54:79:2 56:81:4 60:76:3'),
    leadV:{ type:'square', vol:0.04, cut:2600, dur:0.18 },
    drums:{ k:'x...x...x...x...', s:'....x.......x...', h:'..x...x...x...x.', p:'.x.x.x.x.x.x.x.x', soft:0.8 }, lv:{ drums:0, lead:0.35 } },
  // dark & tense — gets busier as waves get harder
  zombie:{ bpm:86, prog:[[52,55,59],[48,52,55],[57,60,64],[59,63,66]], roots:[40,36,33,35],
    bass:[0,R,R,0,R,R,0,R,0,R,0,R,R,R,7,R], bassV:{ type:'sawtooth', vol:0.12, dur:0.3, cut:420 },
    arp:[R,R,R,R,2,R,R,R,R,R,R,R,1,R,R,R], arpV:{ type:'sine', vol:0.06, dur:0.5, cut:2000, oct:12 },
    pad:{ type:'sawtooth', vol:0.03, att:0.7, cut:520 },
    lead:melody('0:76:6 8:79:3 12:78:3 16:76:8 24:71:6 32:72:6 38:76:3 42:75:4 48:71:8 56:74:3 60:75:4'),
    leadV:{ type:'triangle', vol:0.06, cut:1800, dur:0.5 },
    drums:{ k:'x.......x..x....', s:'........x.......', h:'x.x.x.x.x.x.x.x.', soft:0.8 }, lv:{ drums:0.25, lead:0.55 } },
  // energetic, cheerful
  fitkids:{ bpm:140, prog:[[60,64,67],[55,59,62],[57,60,64],[53,57,60]], roots:[36,43,33,41],
    bass:[0,R,12,R,0,R,12,R,0,R,12,R,0,12,R,7], bassV:{ type:'square', vol:0.07, dur:0.14, cut:900 },
    arp:[0,1,2,3,2,1,2,1,0,1,2,3,4,3,2,1], arpV:{ type:'triangle', vol:0.07, dur:0.1, cut:3000 },
    pad:{ type:'triangle', vol:0.03, att:0.1, cut:1000 },
    lead:melody('0:84:2 2:84:2 4:88:2 6:86:2 8:84:3 12:79:3 16:83:2 18:83:2 20:86:2 22:84:2 24:83:3 28:79:3 32:81:2 34:84:2 36:88:2 38:91:3 40:88:3 44:84:3 48:81:2 50:84:2 52:86:2 54:84:2 56:79:3 60:84:3'),
    leadV:{ type:'square', vol:0.04, cut:3200, dur:0.16 },
    drums:{ k:'x...x...x...x...', s:'....x.......x.x.', h:'xxxxxxxxxxxxxxxx', p:'..x...x...x...xx', soft:0.7 }, lv:{ drums:0, lead:0.2 } },
  // calm, warm, unhurried
  // bouncy & curious — Shape Fit
  shape:{ bpm:108, prog:[[57,60,64],[52,55,59],[53,57,60],[55,59,62]], roots:[45,40,41,43],
    bass:[0,R,R,0,R,R,12,R,0,R,R,0,R,7,R,R], bassV:{ type:'triangle', vol:0.12, dur:0.2, cut:800 },
    arp:[0,2,1,2,0,2,1,3,0,2,1,2,3,2,1,2], arpV:{ type:'square', vol:0.028, dur:0.1, cut:2400 },
    pad:{ type:'triangle', vol:0.03, att:0.3, cut:900 },
    lead:melody('0:81:2 4:84:2 6:88:2 8:86:4 14:84:2 16:83:2 20:86:2 22:91:2 24:88:4 30:86:2 32:84:2 36:81:2 38:84:2 40:88:4 46:86:2 48:83:3 52:79:3 56:81:6'),
    leadV:{ type:'triangle', vol:0.07, cut:3000, dur:0.18 },
    drums:{ k:'x.....x.x.....x.', s:'....x.......x...', h:'x.x.x.x.x.x.x.x.', soft:0.6 }, lv:{ drums:0, lead:0.2 } },
  // sparkly, sleigh-bell-bright — Penguin Slide
  penguin:{ bpm:122, prog:[[60,64,67],[57,60,64],[53,57,60],[55,59,62]], roots:[48,45,41,43],
    bass:[0,R,12,R,0,R,12,R,0,R,12,R,7,R,12,R], bassV:{ type:'triangle', vol:0.12, dur:0.18, cut:800 },
    arp:[0,2,1,3,0,2,1,3,0,2,1,3,2,1,0,1], arpV:{ type:'square', vol:0.026, dur:0.09, cut:2600 },
    pad:{ type:'triangle', vol:0.03, att:0.3, cut:900 },
    lead:melody('0:84:2 2:88:2 4:91:3 8:88:2 10:84:2 12:86:4 16:84:2 18:81:2 20:84:3 24:86:2 26:88:2 28:84:4 32:79:2 34:84:2 36:88:3 40:86:2 42:83:2 44:79:4 48:81:2 50:84:2 52:88:3 56:86:2 58:84:2 60:83:4'),
    leadV:{ type:'triangle', vol:0.075, cut:3200, dur:0.16 },
    drums:{ k:'x...x...x...x...', s:'....x.......x...', h:'x.x.x.x.x.x.x.xx', soft:0.6 }, lv:{ drums:0, lead:0.2 } },
  // bright, bouncy, call-and-response — Simon Says (kept sparse so the note melody stands out)
  simon:{ bpm:104, prog:[[60,64,67],[65,69,72],[67,71,74],[60,64,67]], roots:[48,53,55,48],
    bass:[0,R,R,R,7,R,R,R,0,R,R,R,7,R,R,R], bassV:{ type:'triangle', vol:0.1, dur:0.2, cut:700 },
    arp:[0,R,2,R,1,R,2,R,0,R,2,R,1,R,3,R], arpV:{ type:'triangle', vol:0.03, dur:0.12, cut:2200 },
    pad:{ type:'triangle', vol:0.03, att:0.3, cut:900 },
    lead:melody('0:79:3 4:76:3 8:72:3 12:76:3 16:77:3 20:81:3 24:79:3 28:76:3 32:74:3 36:77:3 40:79:3 44:83:3 48:84:4 56:79:4'),
    leadV:{ type:'sine', vol:0.05, cut:2800, dur:0.2 },
    drums:{ k:'x.......x.......', s:'....x.......x...', h:'..x...x...x...x.', soft:0.5 }, lv:{ drums:0, lead:0.2 } },
  // taiko-flavoured, driving — Boxing Dojo
  boxing:{ bpm:136, prog:[[57,60,64],[57,60,64],[53,57,60],[55,59,62]], roots:[45,45,41,43],
    bass:[0,R,0,0,R,0,12,R,0,R,0,0,R,7,R,5], bassV:{ type:'sawtooth', vol:0.1, dur:0.14, cut:520 },
    arp:[0,R,R,2,R,R,3,R,0,R,R,2,R,R,3,R], arpV:{ type:'square', vol:0.02, dur:0.07, cut:2000 },
    pad:{ type:'sawtooth', vol:0.014, att:0.4, cut:600 },
    lead:melody('0:81:2 3:84:1 4:81:2 8:79:2 11:81:1 12:76:3 16:81:2 19:84:1 20:88:2 24:86:2 27:84:1 28:81:3 32:81:2 35:84:1 36:81:2 40:79:2 43:77:1 44:76:3 48:77:2 50:79:2 52:81:2 54:84:2 56:88:4'),
    leadV:{ type:'square', vol:0.045, cut:2400, dur:0.12 },
    drums:{ k:'x..x..x.x..x..x.', s:'....x.......x..x', h:'x.x.x.x.x.x.xxx.', soft:0.7 }, lv:{ drums:0, lead:0.2 } },
  // happy, poppy, fast — Balloon Burst
  balloon:{ bpm:128, prog:[[62,66,69],[59,62,66],[55,59,62],[57,61,64]], roots:[50,47,43,45],
    bass:[0,R,R,0,R,12,R,0,R,R,0,R,12,R,7,R], bassV:{ type:'triangle', vol:0.12, dur:0.16, cut:850 },
    arp:[0,1,2,1,0,1,2,3,0,1,2,1,2,3,2,1], arpV:{ type:'square', vol:0.026, dur:0.08, cut:2800 },
    pad:{ type:'triangle', vol:0.03, att:0.25, cut:950 },
    lead:melody('0:86:2 2:90:2 4:93:2 6:90:2 8:86:3 12:90:3 16:88:2 18:91:2 20:95:2 22:91:2 24:88:3 28:86:3 32:83:2 34:86:2 36:90:2 38:86:2 40:83:3 44:81:3 48:85:2 50:88:2 52:92:2 54:88:2 56:85:3 60:81:3'),
    leadV:{ type:'triangle', vol:0.075, cut:3300, dur:0.14 },
    drums:{ k:'x...x...x...x...', s:'....x.......x.x.', h:'xxxxxxxxxxxxxxxx', soft:0.55 }, lv:{ drums:0, lead:0.2 } },
  fitsenior:{ bpm:80, prog:[[53,57,60],[53,58,62],[55,60,64],[53,57,60]], roots:[29,34,36,29],
    bass:[0,R,R,R,R,R,R,R,0,R,R,R,7,R,R,R], bassV:{ type:'sine', vol:0.12, dur:0.6, cut:500 },
    arp:[0,R,1,R,2,R,1,R,0,R,1,R,2,R,1,R], arpV:{ type:'sine', vol:0.065, dur:0.35, cut:2400 },
    pad:{ type:'triangle', vol:0.04, att:0.5, cut:900 },
    lead:melody('0:77:6 8:81:6 16:84:6 24:81:6 32:82:4 36:79:4 40:77:6 48:79:4 52:81:4 56:77:8'),
    leadV:{ type:'triangle', vol:0.055, cut:2200, dur:0.7 },
    drums:{ k:'x.......x.......', p:'..x...x...x...x.', soft:0.5 }, lv:{ drums:0.3, lead:0 } },
};

const Music = {
  name:null, cur:null, step:0, next:0, timer:null, level:1, tempo:1, vol:1, appliedVol:-1,
  muted: store.get('mp-music', '1') === '0', bus:null, duckG:null, master:null,
  init(){
    if (!actx || this.master) return;
    this.master = actx.createGain(); this.master.gain.value = this.muted ? 0 : 0.6; this.master.connect(actx.destination);
    this.duckG = actx.createGain(); this.duckG.connect(this.master);
    this.bus = actx.createGain(); this.bus.connect(this.duckG);
    this.timer = setInterval(() => this.tick(), 25);
  },
  play(name){
    if (name === this.name) return;
    this.name = name; this.cur = name ? TRACKS[name] : null; this.step = 0; this.next = 0; this.level = 1; this.tempo = 1;
  },
  setLevel(v){ this.level = clamp(v, 0, 1); },
  setTempo(v){ this.tempo = clamp(v, 0.8, 1.35); },
  duck(amount = 0.3, secs = 0.6){
    if (!this.duckG) return; const t = actx.currentTime;
    this.duckG.gain.cancelScheduledValues(t); this.duckG.gain.setTargetAtTime(amount, t, 0.02); this.duckG.gain.setTargetAtTime(1, t + secs, 0.25);
  },
  toggle(){
    this.muted = !this.muted; store.set('mp-music', this.muted ? '0' : '1');
    if (this.master) this.master.gain.setTargetAtTime(this.muted ? 0 : 0.6, actx.currentTime, 0.05);
    toast(this.muted ? 'Music off' : 'Music on', 1200);
  },
  tick(){
    if (!this.cur || !audioOk() || !this.bus) return;
    if (this.appliedVol !== this.vol) { this.appliedVol = this.vol; this.bus.gain.setTargetAtTime(this.vol, actx.currentTime, 0.15); }
    const sd = 60 / (this.cur.bpm * this.tempo) / 4, now = actx.currentTime;
    if (this.next < now - 0.2 || this.next === 0) this.next = now + 0.06;
    let guard = 0;
    while (this.next < now + 0.16 && guard++ < 8) { this.playStep(this.cur, this.step, this.next, sd); this.next += sd; this.step++; }
  },
  playStep(T, step, t, sd){
    const s = step % 16, bar = Math.floor(step / 16) % T.prog.length, ch = T.prog[bar], L = this.level, d = T.drums;
    const chordNote = i => ch[i % ch.length] + 12 * Math.floor(i / ch.length);
    if (s === 0) for (const m of ch) this.voice(m, t, sd * 15.5, T.pad.type, T.pad.vol, T.pad.cut, T.pad.att);
    const b = T.bass[s]; if (b !== null) this.voice(T.roots[bar] + b, t, sd * 16 * T.bassV.dur / 1.6, T.bassV.type, T.bassV.vol, T.bassV.cut, 0.004);
    const a = T.arp[s]; if (a !== null) this.voice(chordNote(a) + (T.arpV.oct || 0), t, sd * 16 * T.arpV.dur / 1.6, T.arpV.type, T.arpV.vol, T.arpV.cut, 0.004);
    if (L >= T.lv.lead) { const n = T.lead[step % 64]; if (n) this.voice(n[0], t, sd * n[1] * 0.95, T.leadV.type, T.leadV.vol, T.leadV.cut, 0.01); }
    if (L >= T.lv.drums) {
      const v = d.soft, hit = (str, fn, g = 1) => { const c = str && str[s]; if (c === 'x') fn(t, v * g); else if (c === 'o') fn(t, v * g * 0.5); };
      hit(d.k, (tt, vv) => this.kick(tt, vv)); hit(d.s, (tt, vv) => this.snare(tt, vv)); hit(d.h, (tt, vv) => this.hat(tt, vv), s % 4 === 2 ? 1 : 0.6); hit(d.p, (tt, vv) => this.shaker(tt, vv));
    }
  },
  voice(m, t, dur, type, vol, cut, att){
    const o = actx.createOscillator(), g = actx.createGain(), f = actx.createBiquadFilter();
    o.type = type; o.frequency.value = mtof(m); f.type = 'lowpass'; f.frequency.setValueAtTime(cut || 2400, t);
    dur = Math.max(0.05, dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + (att || 0.005)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(f); f.connect(g); g.connect(this.bus); o.start(t); o.stop(t + dur + 0.05);
  },
  kick(t, v){
    const o = actx.createOscillator(), g = actx.createGain();
    o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.12);
    g.gain.setValueAtTime(0.5 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
    o.connect(g); g.connect(this.bus); o.start(t); o.stop(t + 0.25);
  },
  noiseHit(t, dur, vol, type, freq){
    if (!noiseBuf) return;
    const s = actx.createBufferSource(), f = actx.createBiquadFilter(), g = actx.createGain();
    s.buffer = noiseBuf; f.type = type; f.frequency.value = freq;
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f); f.connect(g); g.connect(this.bus); s.start(t, Math.random() * 0.8, dur + 0.05);
  },
  snare(t, v){ this.noiseHit(t, 0.14, 0.22 * v, 'bandpass', 1900); const o = actx.createOscillator(), g = actx.createGain(); o.frequency.setValueAtTime(200, t); o.frequency.exponentialRampToValueAtTime(120, t + 0.08); g.gain.setValueAtTime(0.14 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.1); o.connect(g); g.connect(this.bus); o.start(t); o.stop(t + 0.12); },
  hat(t, v){ this.noiseHit(t, 0.04, 0.09 * v, 'highpass', 7500); },
  shaker(t, v){ this.noiseHit(t, 0.06, 0.1 * v, 'bandpass', 5500); },
};

// Browsers only allow sound after a touch/click/key. The first one of those anywhere switches the music on.
for (const ev of ['pointerdown', 'keydown', 'touchstart', 'click']) window.addEventListener(ev, () => { unlockAudio(); Music.init(); }, { passive:true });

// More sound effects (the originals live up top)
Object.assign(SFX, {
  // juicy slice: wet squelch + bright snick whose pitch climbs with the combo
  juice(n = 1){ noise(0.1, 0.22, 'highpass', 3200); noise(0.16, 0.14, 'bandpass', 900); tone(520 + Math.min(n, 8) * 90, 0.08, 'triangle', 0.07, 1500); setTimeout(() => tone(180, 0.1, 'sine', 0.09, 90), 25); },
  boing(){ tone(190, 0.28, 'sine', 0.16, 620); setTimeout(() => tone(620, 0.16, 'triangle', 0.07, 960), 120); },
  land(){ tone(140, 0.08, 'sine', 0.12, 70); noise(0.06, 0.1, 'lowpass', 500); },
  waveClear(){ Music.duck(0.35, 1.4); [523, 659, 784, 1047, 784, 1047, 1319].forEach((f, i) => setTimeout(() => { tone(f, 0.22, 'triangle', 0.11); tone(f / 2, 0.22, 'square', 0.03); }, i * 95)); },
  heart(){ [660, 880, 1320].forEach((f, i) => setTimeout(() => tone(f, 0.14, 'sine', 0.1), i * 80)); },
  spit(){ noise(0.18, 0.2, 'bandpass', 1200); tone(300, 0.2, 'sawtooth', 0.04, 120); },
  armor(){ tone(1400, 0.05, 'square', 0.07, 900); noise(0.05, 0.14, 'highpass', 4500); },
  boom(){ noise(0.5, 0.4, 'lowpass', 500); tone(80, 0.4, 'sine', 0.22, 35); },
  rep(){ tone(880, 0.07, 'triangle', 0.1); setTimeout(() => tone(1175, 0.1, 'triangle', 0.1), 55); },
  tick(){ tone(1000, 0.025, 'square', 0.035); },
  setDone(){ Music.duck(0.4, 1.0); [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => tone(f, 0.18, 'triangle', 0.1), i * 80)); },
  boostAppear(){ [880, 1175].forEach((f, i) => setTimeout(() => tone(f, 0.12, 'triangle', 0.08), i * 90)); },
  boost(){ [523, 659, 784, 1047, 1319].forEach((f, i) => setTimeout(() => tone(f, 0.18, 'sawtooth', 0.07), i * 60)); },
  star(){ [1047, 1319, 1568, 2093].forEach((f, i) => setTimeout(() => tone(f, 0.2, 'sine', 0.09), i * 120)); },
  fanfare(){ Music.duck(0.3, 2.2); [392, 392, 392, 523, 659, 523, 659, 784].forEach((f, i) => setTimeout(() => { tone(f, 0.26, 'triangle', 0.1); tone(f * 2, 0.2, 'sine', 0.04); }, i * 140)); },
  swoosh(){ noise(0.25, 0.14, 'bandpass', 700); tone(300, 0.25, 'sine', 0.04, 900); },
  nope(){ tone(200, 0.18, 'square', 0.05, 150); },
});
