/* =====================================================================
   TWO PLAYERS — Lane Runner, Zombie Siege and Shape Fit can be played side by side.
   The screen is split in half. Player 1 (left of the camera picture) plays on the left half, Player 2 on the right.
   Both get the very same course / waves / poses. Last one standing wins and gets 50 coins.
   How it works: each half runs its own copy of the normal game scene, drawn into a half-width window,
   with withPlayer() swapping in that player's hands / body so the game code doesn't need to know.
   ===================================================================== */
const PCOL = ['#4db8ff', '#ff9a3f'];          // player 1 = blue, player 2 = orange
const PL_SWAP = ['present', 'warn', 'lane', 'duck', 'up', 'cal', 'jumpHeld', 'jumpPressed', 'hands', 'sk', 'ex'];

// Run fn as player i (0 or 1): the shared input object I temporarily holds that player's data.
function withPlayer(i, fn){
  const keepChar = CHAR; CHAR = charOf(i);                     // each half draws its own player's runner
  try { return withPlayerInput(i, fn); } finally { CHAR = keepChar; }
}
function withPlayerInput(i, fn){
  if (i === 0) return fn();
  const keep = {}; for (const k of PL_SWAP) { keep[k] = I[k]; I[k] = I2[k]; }
  const kb = I.kb, mouse = I.mouse, gren = I.kbGrenade, segs = I.segments;
  I.kb = { active:false, lane:0, duck:false, lastUse:0 };       // keyboard & mouse belong to player 1
  I.mouse = { x:0, y:0, px:0, py:0, seen:-1e9, speed:0, trail:[], lt:0 };
  I.kbGrenade = false; I.segments = [];
  try { return fn(); }
  finally {
    for (const k of PL_SWAP) { I2[k] = I[k]; I[k] = keep[k]; }
    I.kb = kb; I.mouse = mouse; I.kbGrenade = gren; I.segments = segs;
  }
}
// Draw fn inside one half of the screen (W is halved while it runs, so scenes lay themselves out in the half)
function inHalf(side, fn){
  const fullW = W;
  ctx.save(); ctx.beginPath(); ctx.rect(side * fullW / 2, 0, fullW / 2, H); ctx.clip(); ctx.translate(side * fullW / 2, 0);
  W = fullW / 2;
  try { fn(); } finally { W = fullW; ctx.restore(); }
}
const fmtTime = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const GAME_NAMES = { runner:'Lane Runner', zombie:'Zombie Siege', shape:'Shape Fit', penguin:'Penguin Slide' };

/* ---------- 1 player or 2? ---------- */
scenes.players = {
  hint:'Hold a hand over 1 Player or 2 Players',
  enter(d){
    this.game = (d && d.game) || 'runner'; this.focus = 1;
    const card = i => () => { const w = Math.min(W * 0.3, H * 0.62), h = w * 0.95, gap = W * 0.04; return [W / 2 - w - gap / 2 + i * (w + gap), H * 0.26, w, h]; };
    this.buttons = [
      HoverButton('1 Player', 'Play on your own', card(0), () => go(this.game), '#4fd27a', { draw:(x, y, w, h) => this.icon(x, y, w, h, 1) }),
      HoverButton('2 Players', 'Side by side · last one standing wins ● 50', card(1), () => go('versus', { game:this.game }), '#ff8a3d', { draw:(x, y, w, h) => this.icon(x, y, w, h, 2) }),
      HoverButton('◀  Back', '', () => [W * 0.03, H * 0.88, Math.min(W * 0.14, H * 0.3), H * 0.08], () => go('menu'), '#5b8cff'),
    ];
  },
  icon(x, y, w, h, n){
    const P = coachPose('jacks', sceneT, false);
    if (n === 1) drawCoach(x + w / 2, y + h * 0.66, h * 0.5, P, COACH_STYLE.kids);
    else { drawCoach(x + w * 0.3, y + h * 0.66, h * 0.46, P, COACH_STYLE.kids); drawCoach(x + w * 0.7, y + h * 0.66, h * 0.46, coachPose('jacks', sceneT + 0.4, false), COACH_STYLE.senior || COACH_STYLE.kids); }
  },
  keys(k){
    if (k === 'ArrowLeft') this.focus = 0; if (k === 'ArrowRight') this.focus = 1; if (k === 'ArrowDown') this.focus = 2; if (k === 'ArrowUp') this.focus = 1;
    if (k === 'Enter') { SFX.select(); this.buttons[this.focus].action(); }
  },
  update(dt){ this.buttons.forEach((b, i) => b.focus = I.kb.active && i === this.focus); updateButtons(this.buttons, dt, sceneT); },
  draw(){
    ctx.drawImage(cachedLayer('menu', g => { const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#1b1f4a'); gr.addColorStop(1, '#0b0e1f'); g.fillStyle = gr; g.fillRect(0, 0, W, H); }), 0, 0);
    drawGhost(0.12);
    text(GAME_NAMES[this.game] || '', W / 2, H * 0.11, H * 0.08, '#fff');
    text('How many players?', W / 2, H * 0.19, H * 0.04, '#c9d2ff', 'center', 600);
    drawButtons(this.buttons);
    text('2 players: stand side by side, Player 1 on the left, Player 2 on the right', W / 2, H * 0.9, H * 0.028, '#9aa6d8', 'center', 600);
  },
};

/* ---------- the 2-player match ---------- */
scenes.versus = {
  game:true, ownCursors:true, ownHands:true, players:2,
  hint:'Player 1 on the left, Player 2 on the right',
  music:d => d && d.game === 'zombie' ? 'zombie' : d && d.game === 'shape' ? 'shape' : d && d.game === 'penguin' ? 'penguin' : 'runner',
  enter(d){
    bgCache = {};
    Object.assign(this, { kind:(d && d.game) || 'runner', state:'ready', stateT:0, seed:(Math.random() * 1e9) | 0, insts:null, dead:[null, null], winner:null, finished:false,
      okT:0, votes:[[], []], legsOK:[true, true], seq:[], waveCache:{}, count:3, parts:[] });
    this.buttons = [HoverButton('Back', '', () => [W * 0.02, H * 0.9, Math.min(W * 0.1, H * 0.2), H * 0.065], () => go('menu'), '#5b8cff', { dwell:1.3 })];
    Music.setLevel(0.6);
  },
  exit(){ if (this.insts) this.insts.forEach(o => o.exit && o.exit()); this.insts = null; bgCache = {}; Music.setLevel(1); Music.setTempo(1); },
  keys(k){ if (k === 'Enter' && this.state === 'ready') this.okT = 99; },

  // the same waves / poses for both players
  waveList(n){
    if (!this.waveCache[n]) { const old = Math.random; Math.random = mulberry32(this.seed + n * 7919); try { this.waveCache[n] = scenes.zombie.buildWave.call({}, n); } finally { Math.random = old; } }
    return this.waveCache[n].slice();
  },
  poseAt(n){
    while (this.seq.length <= n) {
      const k = this.seq.length, R = mulberry32(this.seed * 31 + k * 977), maxTier = k < 3 ? 0 : k < 8 ? 1 : 2, legs = this.legsOK[0] && this.legsOK[1];
      let pool = SHAPE_POSES.filter(q => q.tier <= maxTier && (!q.legs || legs));
      if (k >= 3) { const hard = pool.filter(q => q.tier >= 1); if (hard.length && R() < 0.6) pool = hard; }
      const alt = pool.filter(q => q !== this.seq[k - 1]); if (alt.length) pool = alt;
      this.seq.push(pool[Math.floor(R() * pool.length)]);
    }
    return this.seq[n];
  },
  makeInstances(){
    const Base = scenes[this.kind], host = this;
    this.insts = [0, 1].map(i => {
      const o = Object.create(Base);
      o.vs = { pl:i, seed:this.seed, legsOK:this.legsOK, wave:n => host.waveList(n), pose:n => host.poseAt(n), onDead:(inst, res) => host.onDead(i, inst, res) };
      inHalf(i, () => withPlayer(i, () => o.enter()));
      return o;
    });
  },
  onDead(i, inst, res){
    if (this.dead[i]) return;
    this.dead[i] = { t:inst.t || 0, res };
    SFX.hurt();
  },

  update(dt){
    const now = performance.now();
    this.stateT += dt; this.parts = stepParts(this.parts, dt);
    if (this.state === 'ready') {
      const both = motionLive() && I.present && I2.present;
      this.okT = both ? this.okT + dt : (this.okT >= 99 ? 99 : 0);
      if (this.okT > 1.2) { this.state = 'cal'; this.stateT = 0; this.votes = [[], []]; if (motionLive()) sendTracker({ t:'calibrate' }); }
      updateButtons(this.buttons, dt, sceneT);
      return;
    }
    if (this.state === 'cal') {
      for (let i = 0; i < 2; i++) withPlayer(i, () => { if (I.ex && motionLive()) this.votes[i].push(exF(I.ex).legs); });
      if (this.stateT >= (motionLive() ? 3.6 : 0.4)) {
        for (let i = 0; i < 2; i++) { const v = this.votes[i]; this.legsOK[i] = !motionLive() || (v.length > 5 && v.reduce((a, b) => a + b, 0) / v.length > 0.5); }
        this.state = 'count'; this.stateT = 0; this.count = 3;
      }
      return;
    }
    if (this.state === 'count') {
      const c = 3 - Math.floor(this.stateT); if (c !== this.count && c > 0) { this.count = c; SFX.beep(); }
      if (this.stateT >= 3) { this.state = 'play'; this.stateT = 0; SFX.go(); this.makeInstances(); Music.setLevel(0.8); }
      return;
    }
    if (this.state === 'play') {
      for (let i = 0; i < 2; i++) {
        const inst = this.insts[i]; if (inst.dead) continue;
        inHalf(i, () => withPlayer(i, () => { updateHands(now, dt); inst.update(dt); I.segments.length = 0; I.jumpPressed = false; I.kbGrenade = false; }));
      }
      if (this.dead[0] || this.dead[1]) {
        this.winner = this.dead[0] && this.dead[1] ? -1 : this.dead[0] ? 1 : 0;
        this.state = 'end'; this.stateT = 0; SFX.fanfare();
      }
      return;
    }
    if (this.state === 'end') {
      if (this.stateT > 2.8) this.finish();
    }
  },
  finish(){
    if (this.finished) return; this.finished = true;
    const bonus = this.winner >= 0 ? 50 : 25; earnCoins(bonus);
    const players = [0, 1].map(i => ({ t:(this.insts[i].t || 0), res:(this.dead[i] && this.dead[i].res) || null, inst:this.insts[i] }));
    const detail = i => { const o = players[i].inst, r = players[i].res; return r ? r.detail : (this.kind === 'runner' ? `${Math.floor(o.dist)} m · ${o.coinN} coins` : this.kind === 'zombie' ? `Wave ${o.wave} · ${o.kills} zombies` : `${o.passed} walls cleared`); };
    const score = i => { const o = players[i].inst; return players[i].res ? players[i].res.score : (o.score !== undefined ? o.score : Math.floor(o.dist || 0)); };
    go('over2', { game:this.kind, winner:this.winner, bonus, players:players.map((p, i) => ({ t:p.t, detail:detail(i), score:score(i) })) });
  },

  draw(){
    const now = performance.now();
    if (this.state !== 'play' && this.state !== 'end') return this.drawLobby();
    for (let i = 0; i < 2; i++) inHalf(i, () => withPlayer(i, () => this.insts[i].draw(now)));
    // frames, tags and the "OUT" overlays
    for (let i = 0; i < 2; i++) {
      const x0 = i * W / 2, w = W / 2, d = this.dead[i];
      if (d) { ctx.fillStyle = 'rgba(8,10,28,0.62)'; ctx.fillRect(x0, 0, w, H); text(this.winner === i ? 'WINNER' : 'OUT', x0 + w / 2, H * 0.42, H * 0.12, this.winner === i ? '#ffe14a' : '#ff6b7a'); text(`survived ${fmtTime(d.t)}`, x0 + w / 2, H * 0.54, H * 0.04, '#c9d2ff', 'center', 600); }
      ctx.strokeStyle = PCOL[i]; ctx.lineWidth = 6; ctx.globalAlpha = 0.55; ctx.strokeRect(x0 + 3, 3, w - 6, H - 6); ctx.globalAlpha = 1;
      roundRect(x0 + 12, H - H * 0.075, H * 0.09, H * 0.05, 12); ctx.fillStyle = PCOL[i]; ctx.fill();
      text('P' + (i + 1), x0 + 12 + H * 0.045, H - H * 0.05, H * 0.032, '#0b0e1f');
    }
    ctx.fillStyle = '#0b0e1f'; ctx.fillRect(W / 2 - 4, 0, 8, H);
    if (this.state === 'end' && this.stateT > 0.5) {
      const k = Math.min(1, (this.stateT - 0.5) / 0.4);
      ctx.globalAlpha = k; text(this.winner < 0 ? 'DRAW!' : `PLAYER ${this.winner + 1} WINS!`, W / 2, H * 0.2, H * 0.1 * (0.8 + 0.2 * k), this.winner < 0 ? '#fff' : PCOL[this.winner]); ctx.globalAlpha = 1;
    }
    drawParts(this.parts);
  },
  drawLobby(){
    ctx.fillStyle = '#10143a'; ctx.fillRect(0, 0, W, H);
    for (let i = 0; i < 2; i++) {
      inHalf(i, () => withPlayer(i, () => {
        const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, i ? '#3a2410' : '#12304a'); g.addColorStop(1, '#0b0e1f'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
        text(`PLAYER ${i + 1}`, W / 2, H * 0.13, H * 0.075, PCOL[i]);
        const bh = H * 0.56, box = [W / 2 - bh / 1.03 / 2, H * 0.2, bh / 1.03, bh];
        roundRect(box[0], box[1], box[2], box[3], H * 0.03); ctx.fillStyle = 'rgba(255,255,255,0.05)'; ctx.fill();
        drawGhost(0.9, box, PCOL[i]);
        const ok = motionLive() && I.present;
        text(ok ? '✓ I can see you' : motionLive() ? 'Step into view' : 'No tablet', W / 2, H * 0.82, H * 0.04, ok ? '#4fd27a' : '#ffc24a');
      }));
    }
    ctx.fillStyle = '#0b0e1f'; ctx.fillRect(W / 2 - 4, 0, 8, H);
    text(GAME_NAMES[this.kind] + '  ·  2 players', W / 2, H * 0.045, H * 0.04, '#fff');
    if (this.state === 'ready') {
      text(motionLive() ? 'Stand side by side in front of the tablet — it starts when both can be seen' : 'Press Enter to start (keyboard test: Player 1 only)', W / 2, H * 0.925, H * 0.03, '#ffe9a8', 'center', 700);
      if (motionLive()) text(`Tablet sees ${I.seen || 0} ${I.seen === 1 ? 'person' : 'people'}  ·  P1 ${I.present ? '✓' : '✗'}  P2 ${I2.present ? '✓' : '✗'}${I.np === 1 ? '  ·  switching to 2-player mode…' : (I.seen === 1 && this.stateT > 4 ? '  ·  step back so BOTH of you fit in the picture' : '')}`, W / 2, H * 0.875, H * 0.026, '#cfe0ff', 'center', 600);
      drawButtons(this.buttons);
    } else if (this.state === 'cal') {
      text('Hold still…', W / 2, H * 0.5, H * 0.07, '#fff');
    } else if (this.state === 'count') {
      const k = 1 - (this.stateT % 1); ctx.globalAlpha = 0.4 + k * 0.6; text(String(Math.max(1, 3 - Math.floor(this.stateT))), W / 2, H * 0.52, H * (0.2 + 0.08 * k), '#fff'); ctx.globalAlpha = 1;
      text('Longest survivor wins  ● 50', W / 2, H * 0.2, H * 0.04, '#ffe14a');
    }
  },
};

/* ---------- results ---------- */
scenes.over2 = {
  hint:'Hold a hand over Rematch or Menu',
  enter(d){
    this.d = d; this.focus = 0; this.parts = [];
    SFX.combo();
    if (d.winner >= 0) for (let i = 0; i < 6; i++) burst(this.parts, W * (d.winner ? 0.65 : 0.35) + rand(-0.15, 0.15) * W, H * rand(0.15, 0.4), 18, ['#ffe14a', '#4fd27a', '#5b8cff', '#ff6b5a'], H * 0.8, H * 0.01, 1.4, 0.6);
    const r = i => () => { const w = Math.min(W * 0.26, H * 0.5), h = H * 0.14, gap = W * 0.04; return [W / 2 - w - gap / 2 + i * (w + gap), H * 0.82, w, h]; };
    this.buttons = [HoverButton('Rematch', '', r(0), () => go('versus', { game:d.game }), '#4fd27a'), HoverButton('Menu', '', r(1), () => go('menu'), '#5b8cff')];
  },
  keys(k){ if (k === 'ArrowLeft') this.focus = 0; if (k === 'ArrowRight') this.focus = 1; if (k === 'Enter') { SFX.select(); this.buttons[this.focus].action(); } },
  update(dt){ this.parts = stepParts(this.parts, dt); this.buttons.forEach((b, i) => b.focus = I.kb.active && i === this.focus); updateButtons(this.buttons, dt, sceneT); },
  draw(){
    const d = this.d;
    ctx.fillStyle = '#12163a'; ctx.fillRect(0, 0, W, H);
    text(d.winner < 0 ? 'It’s a draw!' : `Player ${d.winner + 1} wins!`, W / 2, H * 0.14, H * 0.1, d.winner < 0 ? '#fff' : PCOL[d.winner]);
    text(`${GAME_NAMES[d.game]}  ·  ${d.winner < 0 ? '● +' + d.bonus + ' coins' : '● +' + d.bonus + ' coins for Player ' + (d.winner + 1)}   (wallet ● ${WALLET.coins})`, W / 2, H * 0.235, H * 0.032, '#ffd23f', 'center', 700);
    for (let i = 0; i < 2; i++) {
      const cx = W * (0.3 + i * 0.4), win = d.winner === i, p = d.players[i];
      roundRect(cx - W * 0.17, H * 0.31, W * 0.34, H * 0.46, 24); ctx.fillStyle = win ? 'rgba(255,225,70,0.12)' : 'rgba(255,255,255,0.05)'; ctx.fill();
      ctx.strokeStyle = PCOL[i]; ctx.lineWidth = win ? 8 : 4; ctx.stroke();
      text(`PLAYER ${i + 1}`, cx, H * 0.38, H * 0.05, PCOL[i]);
      text(win ? '👑 WINNER' : d.winner < 0 ? '' : 'OUT', cx, H * 0.45, H * 0.04, win ? '#ffe14a' : '#ff6b7a');
      text(fmtTime(p.t), cx, H * 0.56, H * 0.09, '#fff');
      text('survived', cx, H * 0.61, H * 0.026, '#9aa6d8', 'center', 600);
      text(p.detail, cx, H * 0.69, H * 0.032, '#c9d2ff', 'center', 600);
      text(`score ${p.score}`, cx, H * 0.735, H * 0.028, '#9aa6d8', 'center', 600);
    }
    drawParts(this.parts);
    drawButtons(this.buttons);
  },
};
