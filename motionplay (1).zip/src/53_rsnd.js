/* =====================================================================
   LANE RUNNER — SOUND (v12): footsteps that change with the ground, whooshes, chimes, train horns,
   crashes, a cheering checkpoint and live ambience for each world. All synthesised in the browser.
   ===================================================================== */
const rSnd = {
  vol:1, pan:0,                                   // set per player before each update (2-player: quieter, panned to that half)
  P(p){ return clamp(this.pan + (p || 0), -1, 1); },
  step(surf, side){
    const v = this.vol, p = this.P(side * 0.12), r = rand(0.9, 1.1);
    zTone(95 * r, 0.07, 'sine', 0.07 * v, { to:48, att:0.002, pan:p });
    if (surf === 0) zNoiseBurst(0.06, 0.035 * v, 'bandpass', 1500 * r, { q:1.4, att:0.002, pan:p });                                                       // rubber track
    else if (surf === 1) { zNoiseBurst(0.035, 0.05 * v, 'highpass', 3000 * r, { att:0.001, pan:p }); zTone(180 * r, 0.04, 'triangle', 0.025 * v, { to:90, att:0.001, pan:p }); }   // pavement tap
    else if (surf === 2) { zNoiseBurst(0.1, 0.06 * v, 'bandpass', 3400 * r, { q:0.7, att:0.004, pan:p }); zNoiseBurst(0.07, 0.03 * v, 'highpass', 6000, { att:0.003, delay:0.015, pan:p }); }   // sand crunch
    else zNoiseBurst(0.08, 0.04 * v, 'bandpass', 4800 * r, { to:2200, q:1.1, att:0.002, pan:p });                                                           // wet asphalt
  },
  lane(dir){ const v = this.vol, p = this.P(dir * 0.6); zNoiseBurst(0.2, 0.12 * v, 'bandpass', 800, { to:3200, q:1.4, att:0.012, pan:p }); zNoiseBurst(0.08, 0.04 * v, 'highpass', 5000, { att:0.004, delay:0.04, pan:p }); zTone(rand(1900, 2300), 0.05, 'sine', 0.012 * v, { to:2600, delay:0.03, pan:p }); },
  jump(){ const v = this.vol, p = this.P(0); zTone(240, 0.28, 'sine', 0.11 * v, { to:780, att:0.004, pan:p }); zTone(480, 0.2, 'triangle', 0.03 * v, { to:1300, att:0.004, pan:p }); zNoiseBurst(0.32, 0.08 * v, 'bandpass', 700, { to:3000, q:1, att:0.02, pan:p }); for (let k = 0; k < 3; k++) zNoiseBurst(0.04, 0.03 * v, 'lowpass', 900, { delay:0.05 + k * 0.05, att:0.003, pan:p }); },
  land(surf){ const v = this.vol, p = this.P(0); zTone(110, 0.16, 'sine', 0.15 * v, { to:45, att:0.002, pan:p }); zNoiseBurst(0.16, 0.12 * v, 'lowpass', 1000, { att:0.002, pan:p }); this.step(surf, 0); },
  duck(){ const v = this.vol, p = this.P(0); zNoiseBurst(0.34, 0.09 * v, 'bandpass', 3200, { to:900, q:1.2, att:0.01, pan:p }); zTone(1700, 0.09, 'sine', 0.015 * v, { to:2300, delay:0.02, pan:p }); zTone(320, 0.18, 'triangle', 0.04 * v, { to:160, pan:p }); },
  coin(n){
    const sc = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24], f = 1046 * Math.pow(2, sc[clamp(n - 1, 0, sc.length - 1)] / 12), v = this.vol, p = this.P(0);
    zTone(f, 0.12, 'triangle', 0.06 * v, { att:0.002, pan:p }); zTone(f * 1.5, 0.2, 'sine', 0.04 * v, { delay:0.045, att:0.002, pan:p }); zTone(f * 2, 0.26, 'sine', 0.02 * v, { delay:0.09, att:0.002, pan:p }); zNoiseBurst(0.1, 0.02 * v, 'highpass', 8000, { att:0.002, pan:p });
  },
  combo(){ const v = this.vol, p = this.P(0); [0, 4, 7, 12, 16].forEach((s, i) => zTone(784 * Math.pow(2, s / 12), 0.3, 'triangle', 0.045 * v, { delay:i * 0.05, att:0.003, pan:p })); zNoiseBurst(0.5, 0.03 * v, 'highpass', 6000, { att:0.05, pan:p }); },
  hit(type){
    const v = this.vol, p = this.P(0);
    zTone(120, 0.35, 'sine', 0.22 * v, { to:40, att:0.002, pan:p }); zNoiseBurst(0.4, 0.28 * v, 'lowpass', 900, { att:0.002, pan:p });
    if (type === 'block') { zNoiseBurst(0.6, 0.12 * v, 'highpass', 3500, { att:0.002, pan:p }); for (let k = 0; k < 7; k++) zTone(rand(2500, 6000), 0.12, 'sine', 0.02 * v, { delay:0.02 + k * 0.035, to:rand(1500, 3000), pan:this.P(rand(-0.5, 0.5)) }); [523, 1187, 1789].forEach(f => zTone(f, 0.7, 'triangle', 0.03 * v, { att:0.002, pan:p })); }   // glass + metal
    else if (type === 'high') [380, 931, 1520, 2380].forEach((f, i) => zTone(f, 0.9 - i * 0.15, 'triangle', 0.045 * v, { att:0.002, vib:[f * 0.01, 7], pan:p }));   // steel beam clang
    else { for (let k = 0; k < 5; k++) zNoiseBurst(0.06, 0.08 * v, 'bandpass', rand(900, 2200), { q:2, delay:k * 0.06 + rand(0, 0.02), att:0.002, pan:this.P(rand(-0.4, 0.4)) }); zTone(700, 0.15, 'square', 0.02 * v, { to:200, delay:0.02, pan:p }); }   // plastic barrier clatter
    zVoice(330, 0.26, 0.05 * v, { to:220, a1:750, b1:600, a2:1300, b2:1100, vr:9, vd:0.03, att:0.01, pan:p });   // "oof"
  },
  nice(lane){ const v = this.vol, p = this.P(lane * 0.4); zNoiseBurst(0.22, 0.06 * v, 'bandpass', 2400, { to:900, q:1.5, att:0.005, pan:p }); zTone(1568, 0.25, 'sine', 0.025 * v, { delay:0.05, att:0.003, pan:p }); zTone(2093, 0.3, 'sine', 0.018 * v, { delay:0.1, att:0.003, pan:p }); },
  pass(pan){ zNoiseBurst(0.3, 0.07 * this.vol, 'bandpass', 2600, { to:500, q:1.4, att:0.03, pan:this.P(pan) }); },
  horn(pan, near){ const v = this.vol * near, p = this.P(pan); for (const f of [277, 349, 415]) zTone(f, 1.1, 'sawtooth', 0.022 * v, { path:[[0.8, f], [1, f * 0.93]], att:0.05, filt:['lowpass', 1600, 1], pan:p }); },
  rumble(pan){ const v = this.vol, p = this.P(pan); zNoiseBurst(1.0, 0.16 * v, 'lowpass', 300, { att:0.06, pan:p }); zTone(55, 0.9, 'sawtooth', 0.04 * v, { filt:['lowpass', 200, 1], att:0.05, pan:p }); for (let k = 0; k < 4; k++) zNoiseBurst(0.05, 0.1 * v, 'bandpass', 500, { q:2, delay:0.1 + k * 0.17, att:0.002, pan:p }); zNoiseBurst(0.7, 0.06 * v, 'bandpass', 2000, { to:600, q:1, att:0.1, pan:p }); },
  warn(pan){ for (let k = 0; k < 2; k++) zTone(1240, 0.07, 'square', 0.018 * this.vol, { delay:k * 0.14, att:0.002, filt:['lowpass', 3000, 1], pan:this.P(pan) }); },
  check(){
    const v = this.vol, p = this.P(0);
    [[523, 0], [659, 0.08], [784, 0.16], [1047, 0.26]].forEach(([f, d]) => { zTone(f, 0.9, 'sawtooth', 0.03 * v, { delay:d, att:0.02, filt:['lowpass', 2400, 1], pan:p }); zTone(f * 2, 0.6, 'sine', 0.015 * v, { delay:d, att:0.01, pan:p }); });   // brass fanfare
    zNoiseBurst(2.2, 0.08 * v, 'bandpass', 1300, { q:0.5, att:0.3, pan:p });                                                                                                                  // crowd cheer
    for (let k = 0; k < 6; k++) zNoiseBurst(0.08, 0.06 * v, 'bandpass', rand(1000, 3000), { delay:0.4 + k * rand(0.12, 0.3), q:1.5, att:0.002, pan:this.P(rand(-0.8, 0.8)) });              // claps
    for (let k = 0; k < 4; k++) { const d = 0.6 + k * 0.35; zTone(rand(300, 600), 0.25, 'sine', 0.06 * v, { to:60, delay:d, att:0.002, pan:this.P(rand(-0.8, 0.8)) }); zNoiseBurst(0.6, 0.04 * v, 'highpass', 5000, { delay:d + 0.02, att:0.01, pan:this.P(rand(-0.8, 0.8)) }); }   // fireworks
  },
  heart(){ [0, 4, 7, 12].forEach((s, i) => zTone(880 * Math.pow(2, s / 12), 0.4, 'sine', 0.04 * this.vol, { delay:0.5 + i * 0.07, att:0.003, pan:this.P(0) })); },
  zone(){ const v = this.vol; zNoiseBurst(1.4, 0.08 * v, 'bandpass', 400, { to:4000, q:0.8, att:0.5, pan:this.P(0) }); [0, 7, 12, 19, 24].forEach((s, i) => zTone(523 * Math.pow(2, s / 12), 0.9, 'sine', 0.03 * v, { delay:0.3 + i * 0.08, att:0.01, pan:this.P(0) })); },
  count(){ const v = this.vol; zTone(660, 0.16, 'triangle', 0.09 * v, { att:0.003 }); zTone(1320, 0.12, 'sine', 0.03 * v, { att:0.003 }); },
  go(){ const v = this.vol; [523, 659, 784, 1047].forEach(f => zTone(f, 0.5, 'sawtooth', 0.025 * v, { att:0.01, filt:['lowpass', 3000, 1] })); zTone(1320, 0.35, 'sine', 0.05 * v, { vib:[40, 12], att:0.01 }); zNoiseBurst(0.6, 0.08 * v, 'bandpass', 600, { to:3000, att:0.02 }); },
  amb(zone){
    const r = Math.random(), p = rand(-0.9, 0.9);
    if (zone === 0) { const f = rand(2800, 3800), n = 2 + (Math.random() * 4 | 0); for (let k = 0; k < n; k++) zTone(f * rand(0.9, 1.1), 0.07, 'sine', 0.012, { path:[[0.4, f * 1.25], [1, f * 0.85]], delay:k * rand(0.08, 0.14), att:0.004, pan:p }); }   // birdsong
    else if (zone === 1) {
      if (r < 0.4) { zTone(rand(380, 440), 0.22, 'square', 0.008, { filt:['lowpass', 1200, 1], pan:p }); zTone(rand(470, 520), 0.22, 'square', 0.006, { filt:['lowpass', 1200, 1], pan:p, delay:0.01 }); }   // distant car horn
      else if (r < 0.8) zNoiseBurst(2.4, 0.03, 'bandpass', 500, { to:1400, q:0.8, att:1, pan:p });                                                                                         // traffic passing
      else zTone(720, 2.4, 'sine', 0.006, { path:[[0.25, 950], [0.5, 720], [0.75, 950], [1, 720]], att:0.3, pan:p });                                                                     // far siren
    } else if (zone === 2) {
      if (r < 0.45) zNoiseBurst(3.5, 0.04, 'bandpass', 350, { to:900, q:2, att:1.4, pan:p });                                // desert wind howl
      else if (r < 0.8) zTone(2600, 0.7, 'sine', 0.012, { path:[[0.15, 3000], [1, 1800]], vib:[60, 18], att:0.02, pan:p }); // hawk cry
      else zNoiseBurst(0.8, 0.012, 'bandpass', 6000, { q:3, att:0.05, pan:p });                                              // rattle in the brush
    } else {
      if (r < 0.6) { for (let k = 0; k < 6; k++) { zTone(4400, 0.03, 'sine', 0.006, { delay:k * 0.05, att:0.002, pan:p }); zTone(4400, 0.03, 'sine', 0.006, { delay:0.6 + k * 0.05, att:0.002, pan:p }); } }   // crickets
      else if (r < 0.85) { zTone(392, 0.35, 'sine', 0.02, { to:370, att:0.06, pan:p }); zTone(392, 0.5, 'sine', 0.02, { to:350, delay:0.45, att:0.06, pan:p }); }                                      // owl
      else zTone(rand(500, 800), 1.6, 'sine', 0.01, { to:rand(150, 300), att:0.05, pan:p });                                                                                                           // shooting-star swoosh
    }
  },
};
// wind + air rush that rise with your speed (uses the same looping-noise engine as Penguin Slide)
function rRunLoop(sc){
  const L = pSlideLoop(sc, true); if (!L) return;
  const now = actx.currentTime, sp = clamp((sc.speed - 11) / 16, 0, 1), air = sc.jumpT >= 0, vk = sc.vs ? 0.55 : 1;
  L.seen = performance.now();
  L.wind.gn.gain.setTargetAtTime((0.016 + sp * 0.034 + (air ? 0.018 : 0)) * vk, now, 0.12); L.wind.fl.frequency.setTargetAtTime(350 + sp * 600 + (air ? 300 : 0), now, 0.15);
  L.slide.gn.gain.setTargetAtTime((0.003 + sp * 0.014 + (air ? 0.01 : 0)) * vk, now, 0.1); L.slide.fl.frequency.setTargetAtTime(3500 + sp * 2500, now, 0.2);
}
