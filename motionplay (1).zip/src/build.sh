#!/bin/bash
# Joins the parts (in filename order) into the single tv.html the TV loads.
cd "$(dirname "$0")" && cat 00_core.html 20_music.js 30_menu.js 40_fruit.js 50_runner.js 60_penguin.js 65_balloon.js 67_simon.js 68_boxing.js 69_zart.js 69b_zenv.js 70_zombie.js 80_fit.js 85_shape.js 86_versus.js 90_over.js 99_main.html > ../tv.html && echo "built ../tv.html ($(wc -c < ../tv.html) bytes)"
