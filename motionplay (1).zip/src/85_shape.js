/* =====================================================================
   SHAPE FIT — human-shaped holes come rushing at you down a corridor.
   Strike the matching pose for a moment as the wall arrives, or lose a life (3 lives).
   Poses are judged from the same body measurements as Fit Zone (I.ex → exF), in torso lengths.
   If a pose is too hard / too easy to hit, change its numbers in SHAPE_POSES below.
   ===================================================================== */
const SHAPE_DEF = { aL:8, aR:8, kL:0, kR:0, spread:3, up:0, dx:0, lean:0, squat:0, circ:null, clap:0 };
const fullP = P => Object.assign({}, SHAPE_DEF, P);
const absn = Math.abs;
// tier 0 = easy · 1 = medium · 2 = needs legs in view.  "left" = the left side of the SCREEN (like the on-screen figure).
const SHAPE_POSES = [
  { id:'stand', tier:0, name:'Stand tall',            P:{ aL:8, aR:8 },                         test:(f) => f.wly > 0.45 && f.wry > 0.45 && absn(f.wlx) < 0.6 && absn(f.wrx) < 0.6 },
  { id:'T',     tier:0, name:'T-pose',                P:{ aL:90, aR:90 },                       test:(f) => absn(f.wlx) > 0.9 && absn(f.wrx) > 0.9 && absn(f.wly) < 0.5 && absn(f.wry) < 0.5 },
  { id:'Y',     tier:0, name:'Arms up in a Y',        P:{ aL:150, aR:150 },                     test:(f) => f.wly < -0.5 && f.wry < -0.5 && absn(f.wlx - f.wrx) > 0.75 },
  { id:'up',    tier:0, name:'Hands together overhead', P:{ aL:172, aR:172, clap:0.9 },         test:(f) => f.wly < -0.6 && f.wry < -0.6 && absn(f.wlx - f.wrx) < 0.5 },
  { id:'A',     tier:0, name:'A-frame',               P:{ aL:45, aR:45 },                       test:(f) => f.wly > 0.15 && f.wly < 1.2 && f.wry > 0.15 && f.wry < 1.2 && absn(f.wlx) > 0.45 && absn(f.wrx) > 0.45 && absn(f.wlx) < 1.6 && absn(f.wrx) < 1.6 },
  { id:'L',     tier:1, name:'Left arm up',           P:{ aL:172, aR:8 },                       test:(f) => f.wly < -0.55 && f.wry > 0.3 },
  { id:'R',     tier:1, name:'Right arm up',          P:{ aL:8, aR:172 },                       test:(f) => f.wry < -0.55 && f.wly > 0.3 },
  { id:'squat', tier:1, name:'Squat down',            P:{ squat:1, aL:50, aR:50, spread:9 },    test:(f, S) => S.drop > 0.22 },
  { id:'leanR', tier:1, name:'Lean right, arms up',   P:{ lean:18, aL:165, aR:165, dx:-0.5 },   test:(f) => f.lean > 0.2 && f.wly < -0.3 && f.wry < -0.3 },
  { id:'leanL', tier:1, name:'Lean left, arms up',    P:{ lean:-18, aL:165, aR:165, dx:0.5 },   test:(f) => f.lean < -0.2 && f.wly < -0.3 && f.wry < -0.3 },
  { id:'star',  tier:2, legs:true, name:'Star jump shape', P:{ aL:145, aR:145, spread:20, up:0.3 }, test:(f) => f.wly < -0.45 && f.wry < -0.45 && absn(f.wlx - f.wrx) > 0.75 && f.sep > 1.3 },
  { id:'flamL', tier:2, legs:true, name:'Flamingo — left knee up',  P:{ kL:0.9, aL:90, aR:90 }, test:(f) => f.kuL > 0.28 && absn(f.wlx) > 0.8 && absn(f.wrx) > 0.8 },
  { id:'flamR', tier:2, legs:true, name:'Flamingo — right knee up', P:{ kR:0.9, aL:90, aR:90 }, test:(f) => f.kuR > 0.28 && absn(f.wlx) > 0.8 && absn(f.wrx) > 0.8 },
];

// A thick silhouette of a pose (same skeleton as the coach figure), drawn onto any 2D context.
function drawSil(g, cx, fy, h, P0, col, pad = 0){
  const P = fullP(P0), FAT = 1.3;
  const u = h / 10, up = P.up * u * 1.1, hipY = fy - 4.6 * u * (1 - 0.3 * P.squat) - up, hipX = cx + P.dx * u;
  const tr = P.lean * Math.PI / 180, rot = (x, y) => [hipX + x * Math.cos(tr) - y * Math.sin(tr), hipY + x * Math.sin(tr) + y * Math.cos(tr)];
  g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = col; g.fillStyle = col;
  const limb = (x1, y1, x2, y2, w) => { g.lineWidth = w * FAT + pad; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); };
  for (const s of [-1, 1]) {
    const k = s < 0 ? P.kL : P.kR, hx = hipX + s * 0.55 * u, hy = hipY + 0.2 * u;
    const ax = hipX + s * (0.75 * u + Math.sin(P.spread * Math.PI / 180) * 4.2 * u) + s * P.squat * 0.4 * u, ay = fy - up - k * 2.6 * u;
    const [kx, ky] = ik(hx, hy, ax, ay, 2.3 * u, 2.3 * u, -s);
    limb(hx, hy, kx, ky, u * 1.05); limb(kx, ky, ax, ay, u * 0.95);
    g.beginPath(); g.ellipse(ax + s * 0.25 * u, ay + 0.1 * u, u * 0.85 + pad / 2, u * 0.42 + pad / 2, 0, 0, TAU); g.fill();
  }
  const [tx, ty] = rot(0, -3.2 * u), [bx, by] = rot(0, 0.2 * u);
  limb(bx, by, tx, ty, u * 2.5); limb(bx, by + u * 0.1, bx, by + u * 0.1, u * 2.6);
  for (const s of [-1, 1]) {
    const [sx, sy] = rot(s * 1.35 * u, -2.7 * u), a = (s < 0 ? P.aL : P.aR) * Math.PI / 180;
    let ex = sx + s * Math.sin(a) * 3.2 * u, ey = sy + Math.cos(a) * 3.2 * u; if (P.clap > 0.5) ex -= s * u * 0.25 * P.clap;
    limb(sx, sy, ex, ey, u * 0.85);
    g.beginPath(); g.arc(ex, ey, u * 0.65 * FAT + pad / 2, 0, TAU); g.fill();
  }
  const [nx, ny] = rot(0, -3.5 * u), hr = u * 1.15, hx = nx + Math.sin(tr) * 0.3 * u, hy2 = ny - hr * 0.95;
  limb(tx, ty, nx, ny, u * 0.9);
  g.beginPath(); g.arc(hx, hy2, hr * 1.12 + pad / 2, 0, TAU); g.fill();
}

const SHAPE_WALLS = [['#5b6bd6', '#2c3585'], ['#d65b8a', '#852c52'], ['#3fb58a', '#1f6a52'], ['#e0913a', '#8a521a'], ['#8f5bd6', '#4c2c85']];
const shapeTexCache = {};
const SHAPE_TW = 880, SHAPE_TH = 640;
function shapeTexture(pose, idx){
  const key = pose.id + (idx % SHAPE_WALLS.length);
  if (shapeTexCache[key]) return shapeTexCache[key];
  const c = document.createElement('canvas'); c.width = SHAPE_TW; c.height = SHAPE_TH; const g = c.getContext('2d');
  const [c1, c2] = SHAPE_WALLS[idx % SHAPE_WALLS.length];
  const gr = g.createLinearGradient(0, 0, 0, SHAPE_TH); gr.addColorStop(0, c1); gr.addColorStop(1, c2);
  roundRect2(g, 0, 0, SHAPE_TW, SHAPE_TH, 26); g.fillStyle = gr; g.fill();
  g.save(); roundRect2(g, 0, 0, SHAPE_TW, SHAPE_TH, 26); g.clip();
  g.strokeStyle = 'rgba(0,0,0,0.16)'; g.lineWidth = 3;
  for (let y = 0; y < SHAPE_TH; y += 64) { g.beginPath(); g.moveTo(0, y); g.lineTo(SHAPE_TW, y); g.stroke(); for (let x = ((y / 64) % 2) * 80; x < SHAPE_TW; x += 160) { g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + 64); g.stroke(); } }
  g.restore();
  g.strokeStyle = 'rgba(255,255,255,0.55)'; g.lineWidth = 10; roundRect2(g, 5, 5, SHAPE_TW - 10, SHAPE_TH - 10, 24); g.stroke();
  const fy = SHAPE_TH * 0.94, h = SHAPE_TH * 0.8;
  drawSil(g, SHAPE_TW / 2, fy, h, pose.P, 'rgba(255,255,255,0.85)', 22);    // bright rim round the hole
  g.globalCompositeOperation = 'destination-out'; drawSil(g, SHAPE_TW / 2, fy, h, pose.P, '#000', 0); g.globalCompositeOperation = 'source-over';
  shapeTexCache[key] = c; return c;
}
function roundRect2(g, x, y, w, h, r){ g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

scenes.shape = {
  game:true, music:'shape', hint:'Make the shape of the hole in the wall with your whole body!',
  enter(){
    Object.assign(this, { state:'check', stateT:0, walls:[], parts:[], pops:[], lives:3, score:0, combo:0, bestCombo:0, passed:0, t:0, shake:0, flash:0, red:0, spawnT:0, legsOK:true, legsVotes:[],
      dropBase:0, S:{ drop:0 }, kbT:0, sinceMatch:9, lastPose:null, hit:null, best:+store.get('mp-best-shape', 0), msg:null, count:3, dist:0,
      wave:1, waveWalls:0, waveMiss:0, perfectRun:0, coinsEarned:0, spawnN:0, dead:false });
    this.buttons = [
      HoverButton('Start', '', () => [W * 0.5 - Math.min(W * 0.2, H * 0.4) * 0.7, H * 0.82, Math.min(W * 0.2, H * 0.4) * 1.4, H * 0.1], () => this.beginCal(), '#4fd27a'),
      HoverButton('Back', '', () => [W * 0.03, H * 0.88, Math.min(W * 0.14, H * 0.3), H * 0.08], () => go('menu'), '#5b8cff'),
    ];
    this.quit = HoverButton('Quit', '', () => [W * 0.97 - Math.min(W * 0.1, H * 0.2), H * 0.9, Math.min(W * 0.1, H * 0.2), H * 0.065], () => go('menu'), '#ff6b6b', { dwell:1.4 });
    if (!this.vs) { sendTracker({ t:'mode', fb:false }); Music.setLevel(0.5); }
    else { this.state = 'play'; this.stateT = 0; this.legsOK = this.vs.legsOK[this.vs.pl]; this.spawn(); this.spawnT = 4.2; }
  },
  exit(){ Music.setLevel(1); Music.setTempo(1); },
  beginCal(){
    if (this.state !== 'check') return;
    this.state = 'cal'; this.stateT = 0; this.legsVotes = [];
    if (motionLive()) sendTracker({ t:'calibrate' });
  },
  pool(){
    const n = this.passed, maxTier = n < 3 ? 0 : n < 8 ? 1 : 2;
    let p = SHAPE_POSES.filter(q => q.tier <= maxTier && (!q.legs || this.legsOK));
    if (n >= 3) { const hard = p.filter(q => q.tier >= 1); if (hard.length && Math.random() < 0.6) p = hard; }
    const alt = p.filter(q => q !== this.lastPose); return alt.length ? alt : p;
  },
  spawn(){
    const n = this.spawnN++, pose = this.vs ? this.vs.pose(n) : pick(this.pool()); this.lastPose = pose;
    this.walls.push({ z:46, pose, tex:this.vs ? n % SHAPE_WALLS.length : Math.floor(rand(0, SHAPE_WALLS.length)), done:null, hold:0, good:-9, since:0, maxHold:0, fade:0, born:this.t });
  },
  matched(pose){
    if (!motionLive()) return this.kbT > 0;
    if (!I.ex || !I.present) return false;
    return !!pose.test(exF(I.ex), this.S);
  },
  keys(k){
    if (k === 'Enter' && this.state === 'check') this.beginCal();
    if (k === ' ' || k === 'p' || k === 'P') this.kbT = 0.45;
    if (k === 'q' || k === 'Q') go('menu');
  },
  update(dt){
    this.stateT += dt; this.parts = stepParts(this.parts, dt); this.pops = stepPops(this.pops, dt);
    this.shake = Math.max(0, this.shake - dt * 2); this.flash = Math.max(0, this.flash - dt * 2); this.red = Math.max(0, this.red - dt * 1.6); this.kbT = Math.max(0, this.kbT - dt);
    if (this.msg) { this.msg.age += dt; if (this.msg.age > 1.8) this.msg = null; }
    if (this.msgBig) { this.msgBig.age += dt; if (this.msgBig.age > 2.4) this.msgBig = null; }
    const f = I.ex && motionLive() ? exF(I.ex) : null;
    if (f) { if (absn(f.drop - this.dropBase) < 0.1) this.dropBase += (f.drop - this.dropBase) * 0.01; this.S.drop = f.drop - this.dropBase; } else this.S.drop = 0;
    if (this.state === 'check') { updateButtons(this.buttons, dt, sceneT); return; }
    if (this.state === 'cal') {
      if (f) this.legsVotes.push(f.legs);
      const need = motionLive() ? 3.6 : 0.6;
      if (this.stateT >= need) {
        const v = this.legsVotes; this.legsOK = !motionLive() || (v.length > 5 && v.reduce((a, b) => a + b, 0) / v.length > 0.5);
        this.dropBase = 0; this.state = 'count'; this.stateT = 0; this.count = 3; Music.setLevel(0.7);
      } return;
    }
    if (this.state === 'count') {
      const c = 3 - Math.floor(this.stateT); if (c !== this.count && c > 0) { this.count = c; SFX.beep(); }
      if (this.stateT >= 3) { this.state = 'play'; this.stateT = 0; SFX.go(); this.spawn(); this.spawnT = 4.2; }
      return;
    }
    // ---- playing ----
    this.t += dt;
    const v = Math.min(26, 13 + this.t * 0.2); this.dist += v * dt;
    if (!this.vs) Music.setTempo(0.95 + (v - 13) / 13 * 0.3);
    this.spawnT -= dt;
    if (this.spawnT <= 0 && this.walls.filter(w => !w.done).length < 3) { this.spawn(); this.spawnT = Math.max(2.4, 4.2 - this.t * 0.018); }
    for (const w of this.walls) w.z -= v * dt;
    const cur = this.walls.filter(w => !w.done).sort((a, b) => a.z - b.z)[0];
    this.cur = cur || null;
    if (cur) {
      const m = cur.z < 34 ? this.matched(cur.pose) : false;
      this.sinceMatch = m ? 0 : this.sinceMatch + dt;
      if (m) { cur.hold += dt; cur.since = 0; cur.maxHold = Math.max(cur.maxHold, cur.hold); if (cur.hold >= 0.2) cur.good = this.t; if (cur.hold >= 0.2 && !cur.ding) { cur.ding = true; SFX.tick(); } }
      else { cur.hold = 0; cur.since += dt; }
      cur.matching = m;
      if (cur.z <= 0) this.judge(cur);
    }
    for (const w of this.walls) if (w.done) w.fade += dt;
    this.walls = this.walls.filter(w => !w.done || w.fade < 0.7);
    if (this.lives <= 0 && this.state === 'play') { this.state = 'dead'; this.stateT = 0; }
    if (!this.vs) updateButtons([this.quit], dt, sceneT);
  },
  judge(w){
    const ok = (this.t - w.good) < 0.3;
    const cx = W / 2, cy = H * 0.42;
    if (ok) {
      w.done = 'pass'; this.passed++; this.combo++; this.bestCombo = Math.max(this.bestCombo, this.combo);
      const perfect = w.maxHold >= 0.9, pts = 100 + Math.min(10, this.combo - 1) * 20 + (perfect ? 50 : 0);
      this.score += pts; this.flash = 0.35; SFX.fanfare();
      pop(this.pops, cx, cy, perfect ? `PERFECT!  +${pts}` : `+${pts}`, perfect ? '#ffe14a' : '#4fd27a', 0.07, 1.3);
      if (perfect) { this.perfectRun++; if (this.perfectRun >= 5) { this.perfectRun = 0; this.coinsEarned += earnCoins(15); SFX.coin(); pop(this.pops, cx, cy + H * 0.12, '5 PERFECT IN A ROW!  ● +15', '#ffd23f', 0.055, 1.6); } } else this.perfectRun = 0;
      if (this.combo >= 3 && this.combo % 3 === 0) { SFX.combo(); pop(this.pops, cx, cy - H * 0.12, `${this.combo} in a row!`, '#ff9a3f', 0.06, 1.3); }
      for (let i = 0; i < 3; i++) burst(this.parts, cx + rand(-0.2, 0.2) * W, cy + rand(-0.1, 0.2) * H, 16, ['#ffe14a', '#4fd27a', '#5b8cff', '#ff6b9a', '#fff'], H * 0.8, H * 0.009, 1.0, 0.6);
    } else {
      w.done = 'fail'; this.lives--; this.combo = 0; this.shake = 1; this.red = 1; SFX.hurt(); this.perfectRun = 0; this.waveMiss++;
      this.msg = { text:`Missed!  That was: ${w.pose.name}`, age:0 };
      for (let i = 0; i < 3; i++) burst(this.parts, cx + rand(-0.3, 0.3) * W, cy + rand(-0.2, 0.2) * H, 18, ['#ff5d6c', '#c9d2ff', '#7a7f99'], H * 0.9, H * 0.012, 1.0, 0.8);
    }
    this.waveWalls++;
    if (this.waveWalls >= 5 && this.lives > 0) {      // a wave = 5 walls
      const flawless = this.waveMiss === 0, wc = earnCoins(10 + (flawless ? 10 : 0)); this.coinsEarned += wc;
      this.msgBig = { text:`Wave ${this.wave} cleared!  ● +${wc}${flawless ? '  (flawless!)' : ''}`, age:0 };
      SFX.waveClear(); SFX.coin(); this.wave++; this.waveWalls = 0; this.waveMiss = 0;
    }
  },
  // ----- drawing -----
  drawBG(){
    const HOR = H * 0.4;
    ctx.drawImage(cachedLayer('shapebg', g => {
      const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#0b0e2e'); gr.addColorStop(0.4, '#232a6b'); gr.addColorStop(0.4, '#1a1f4f'); gr.addColorStop(1, '#0a0c24');
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
      const rg = g.createRadialGradient(W / 2, HOR, 0, W / 2, HOR, W * 0.5); rg.addColorStop(0, 'rgba(160,190,255,0.35)'); rg.addColorStop(1, 'rgba(160,190,255,0)'); g.fillStyle = rg; g.fillRect(0, 0, W, H);
      g.strokeStyle = 'rgba(150,170,255,0.25)'; g.lineWidth = 2;
      for (let i = -7; i <= 7; i++) { g.beginPath(); g.moveTo(W / 2 + i * W * 0.012, HOR); g.lineTo(W / 2 + i * W * 0.2, H); g.stroke(); }
      for (const sd of [-1, 1]) { g.beginPath(); g.moveTo(W / 2 + sd * W * 0.012, HOR); g.lineTo(W / 2 + sd * W * 0.75, 0); g.stroke(); }
    }), 0, 0);
    ctx.strokeStyle = 'rgba(150,170,255,0.3)'; ctx.lineWidth = 2;
    for (let k = 0; k < 14; k++) { const z = ((k * 4 - this.dist % 4) + 4) % 56, s = 1 / (1 + z * 0.09), y = HOR + (H * 0.97 - HOR) * s; ctx.globalAlpha = Math.min(1, s * 1.4); ctx.beginPath(); ctx.moveTo(W / 2 - W * 0.8 * s, y); ctx.lineTo(W / 2 + W * 0.8 * s, y); ctx.stroke(); }
    ctx.globalAlpha = 1;
  },
  drawWall(w){
    const s = w.z >= 0 ? 1 / (1 + w.z * 0.09) : 1 + (-w.z) * 0.09, HOR = H * 0.4;
    const fk = Math.min(1, W * 0.96 / (H * 0.86 * SHAPE_TW / SHAPE_TH)), bh = H * 0.86 * s * fk, bw = bh * SHAPE_TW / SHAPE_TH, bottom = w.z >= 0 ? HOR + (H * 0.97 - HOR) * s : H * 0.97 + (-w.z) * H * 0.05;
    const x = W / 2 - bw / 2, y = bottom - bh;
    let a = 1; if (w.done) a = clamp(1 - w.fade / 0.7, 0, 1); else if (w.z > 40) a = clamp((50 - w.z) / 10, 0, 1);
    ctx.globalAlpha = a;
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(W / 2, bottom, bw * 0.5, bh * 0.03, 0, 0, TAU); ctx.fill();
    ctx.drawImage(shapeTexture(w.pose, w.tex), x, y, bw, bh);
    if (!w.done && w === this.cur && w.z < 34) {   // outline glows green while you are matching
      ctx.lineWidth = Math.max(3, 8 * s); ctx.strokeStyle = w.matching ? '#4fd27a' : 'rgba(255,255,255,0.35)'; roundRect(x, y, bw, bh, 26 * s); ctx.stroke();
    }
    if (w.done === 'pass') { ctx.fillStyle = 'rgba(79,210,122,0.25)'; roundRect(x, y, bw, bh, 26 * s); ctx.fill(); }
    if (w.done === 'fail') { ctx.fillStyle = 'rgba(255,60,80,0.35)'; roundRect(x, y, bw, bh, 26 * s); ctx.fill(); }
    ctx.globalAlpha = 1;
  },
  draw(){
    ctx.save();
    if (this.shake > 0) ctx.translate(rand(-1, 1) * this.shake * H * 0.012, rand(-1, 1) * this.shake * H * 0.012);
    this.drawBG();
    if (this.state === 'check') this.drawCheck();
    else if (this.state === 'cal') this.drawCal();
    else {
      for (const w of [...this.walls].sort((a, b) => b.z - a.z)) this.drawWall(w);
      // your own body, in front of the wall, so you can see how you are fitting
      const fk = Math.min(1, W * 0.96 / (H * 0.86 * SHAPE_TW / SHAPE_TH)), bh = H * 0.86 * fk, box = [W / 2 - bh / 1.03 / 2, H * 0.97 - bh, bh / 1.03, bh];
      ctx.globalCompositeOperation = 'lighter'; drawGhost(0.35, box, '#7ab8ff'); ctx.globalCompositeOperation = 'source-over'; drawGhost(0.9, box, '#ffffff');
      if (!(motionLive() && I.present)) text(motionLive() ? 'I can’t see you' : 'Keyboard mode: tap SPACE to hold the pose', W / 2, H * 0.55, H * 0.03, '#ffc24a', 'center', 700);
      this.drawHUD();
    }
    drawParts(this.parts); drawPops(this.pops);
    ctx.restore();
    if (this.red) { const v = ctx.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, W * 0.7); v.addColorStop(0, 'rgba(255,0,0,0)'); v.addColorStop(1, `rgba(200,0,0,${0.55 * this.red})`); ctx.fillStyle = v; ctx.fillRect(0, 0, W, H); }
    if (this.flash) { ctx.fillStyle = `rgba(255,255,255,${this.flash * 0.35})`; ctx.fillRect(0, 0, W, H); }
    if (this.state === 'check') drawButtons(this.buttons);
    if (this.state === 'play' && !this.vs) drawButtons([this.quit]);
  },
  drawHUD(){
    text(String(this.score), W * 0.04, H * 0.07, H * 0.07, '#fff', 'left');
    text('Best ' + Math.max(this.best, this.score), W * 0.04, H * 0.135, H * 0.03, '#c9d2ff', 'left', 700);
    text(`Wave ${this.wave}  ·  ${this.waveWalls}/5`, W * 0.04, H * 0.18, H * 0.03, '#ffe14a', 'left', 700);
    if (this.combo >= 2) text(`🔥 ${this.combo} in a row`, W * 0.04, H * 0.225, H * 0.032, '#ff9a3f', 'left', 800);
    for (let i = 0; i < 3; i++) text('♥', W * (0.86 + i * 0.045), H * 0.07, H * 0.065, i < this.lives ? '#ff3b6b' : 'rgba(255,255,255,0.4)');
    const c = this.cur;
    if (c && c.z < 40) {
      text(c.pose.name, W / 2, H * 0.065, Math.min(H * 0.058, W * 0.055), c.matching ? '#4fd27a' : '#fff');
      const k = clamp(c.hold / 0.2, 0, 1), bw = W * 0.24, bx = W / 2 - bw / 2, by = H * 0.105;
      roundRect(bx, by, bw, H * 0.016, H * 0.008); ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fill();
      roundRect(bx, by, Math.max(H * 0.016, bw * k), H * 0.016, H * 0.008); ctx.fillStyle = c.matching ? '#4fd27a' : '#ffc24a'; ctx.fill();
      text(c.matching ? (k >= 1 ? 'Hold it!' : '…') : 'Make the shape!', W / 2, H * 0.145, H * 0.028, '#d6defc', 'center', 700);
    }
    if (this.msg) { ctx.globalAlpha = clamp(1.8 - this.msg.age, 0, 1); text(this.msg.text, W / 2, H * 0.93, Math.min(H * 0.04, W * 0.045), '#ff8a8a', 'center', 800); ctx.globalAlpha = 1; }
    if (this.msgBig) { ctx.globalAlpha = clamp(2.4 - this.msgBig.age, 0, 1); text(this.msgBig.text, W / 2, H * 0.3, Math.min(H * 0.055, W * 0.06), '#4fd27a', 'center', 800); ctx.globalAlpha = 1; }
    if (this.state === 'dead') { /* handled below */ }
  },
  drawCheck(){
    text('Shape Fit', W / 2, H * 0.1, H * 0.08, '#fff');
    this.wrap2('Walls with a human-shaped hole fly towards you. Strike the same pose — arms, legs, lean — before the wall arrives, or you lose a life. You have 3 lives.', W / 2, H * 0.17, W * 0.62, H * 0.03, '#d6defc');
    // cycle through a few of the poses so the player knows what to expect
    const demos = SHAPE_POSES.filter(p => !p.legs), n = 4, t = Math.floor(sceneT / 1.4);
    for (let i = 0; i < n; i++) {
      const p = demos[(t + i) % demos.length], cx = W * (0.2 + i * 0.2), fy = H * 0.6, h = H * 0.25;
      roundRect(cx - h * 0.62, fy - h * 1.15, h * 1.24, h * 1.3, H * 0.02); ctx.fillStyle = 'rgba(8,12,40,0.45)'; ctx.fill();
      drawCoach(cx, fy, h, fullP(p.P), COACH_STYLE.kids);
      text(p.name, cx, fy + h * 0.1, H * 0.024, '#ffe14a', 'center', 700);
    }
    this.wrap2(motionLive() ? 'Stand back so the camera sees your whole body. Some poses use your legs, so a bit of space helps!' : 'No tablet connected — keyboard test mode: press SPACE to “hold” a pose.', W / 2, H * 0.74, W * 0.62, H * 0.028, '#fff1c9');
  },
  drawCal(){
    text(motionLive() ? 'Stand still in the middle…' : 'Get ready…', W / 2, H * 0.14, H * 0.07, '#fff');
    const bh = H * 0.7, box = [W / 2 - bh / 1.03 / 2, H * 0.22, bh / 1.03, bh];
    roundRect(box[0], box[1], box[2], box[3], H * 0.025); ctx.fillStyle = 'rgba(8,12,40,0.4)'; ctx.fill();
    drawGhost(0.9, box, '#ffffff');
    const k = clamp(this.stateT / (motionLive() ? 3.6 : 0.6), 0, 1);
    roundRect(W * 0.3, H * 0.94, W * 0.4, H * 0.014, H * 0.007); ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fill();
    roundRect(W * 0.3, H * 0.94, Math.max(H * 0.014, W * 0.4 * k), H * 0.014, H * 0.007); ctx.fillStyle = '#4fd27a'; ctx.fill();
  },
  wrap2(str, x, y, maxW, size, col){
    const words = str.split(' '); let line = '', yy = y; ctx.font = `600 ${size}px system-ui, sans-serif`;
    for (const w of words) { const t = line ? line + ' ' + w : w; if (ctx.measureText(t).width > maxW && line) { text(line, x, yy, size, col, 'center', 600); yy += size * 1.35; line = w; } else line = t; }
    if (line) text(line, x, yy, size, col, 'center', 600);
  },
};
// count-in + game over drawn on top of the play view
(function(){
  const baseDraw = scenes.shape.draw, baseUpdate = scenes.shape.update;
  scenes.shape.draw = function(){
    baseDraw.call(this);
    if (this.state === 'count') { const k = 1 - (this.stateT % 1); ctx.globalAlpha = 0.4 + k * 0.6; text(String(Math.max(1, 3 - Math.floor(this.stateT))), W / 2, H * 0.5, H * (0.2 + 0.08 * k), '#fff'); ctx.globalAlpha = 1; text('Get ready to pose!', W / 2, H * 0.22, H * 0.05, '#ffe14a'); }
  };
  scenes.shape.update = function(dt){
    baseUpdate.call(this, dt);
    if (this.state === 'dead' && this.stateT > (this.vs ? 0 : 1.2)) {
      const res = { game:'shape', score:this.score, detail:`${this.passed} walls cleared · best streak ${this.bestCombo}`, coins:this.coinsEarned };
      if (this.vs) { if (!this.dead) { this.dead = true; this.vs.onDead(this, res); } } else go('over', res);
    }
  };
})();
