# MotionPlay — tablet camera → body tracking → games on the TV

Three plain web pages and no server code. (The TV page is built from the parts in `src/` by `src/build.sh`; you only need `tv.html`.)

| File | Runs on | Job |
|---|---|---|
| `tracker.html` | Samsung Tab A8 (Chrome) | Camera → MediaPipe pose tracking → filtering, calibration, gestures → sends motion to the TV |
| `tv.html` | TV browser, or a laptop plugged into the TV | Shows a pairing code, receives motion, runs the games |
| `index.html` | Either | Simple "which device is this?" chooser |

## Updating your GitHub copy

When you get a new version, open your `motionplay` repo → **Add file → Upload files**, drag in the new `tracker.html` and `tv.html` (they replace the old ones), and click **Commit changes**. Wait a minute, then reload the page on the TV **and** the tablet.

## How it works

```
Tablet camera ──► MediaPipe Pose (33 body points, on-device)
              ──► One Euro filter (steady when still, almost no lag when moving fast)
              ──► gestures: lane, jump, duck, hands-up + 2 hand cursors (with motion-blur coasting)
              ──► WebRTC data channel (PeerJS) over your Wi-Fi, every frame, timestamped
              ──► TV page: predicts the cursor slightly ahead to hide Wi-Fi delay ──► games
```

## The games

**Fruit Slash** – Your hands are glowing blades with trails. A quick swipe slices a fruit (12 kinds now: banana, strawberry, pineapple, grapes, dragon fruit and more).
- ❄ **Ice** slows time · ★ **Star** = 5 points · ♥ **Heart** gives back a life · ⚡ **Frenzy** = 7 seconds of a fruit storm with double points
- **Giant melon** takes 3 cuts for a big bonus, but costs a life if it escapes
- Slice 10 in a row without a miss for **×2**, 20 for ×3, 30 for ×4
- Every 45 seconds the scene changes: Dojo → Cherry Blossom Garden → Lantern Night Market, each with its own floating details
- Bombs and missed fruit each cost one of your 3 lives

**Lane Runner** – Stand still in the middle for the countdown. Step to change lanes, jump over red-and-white barriers, squat under yellow-and-black bars, dodge trains.
- Four worlds every 500 m: Sunny Meadow, Skyline City, Desert Sunset, Starry Night (with clouds, birds, trees, lamps, cacti…)
- **Checkpoint arches** every **1000 m** give +10 coins and +1 life (if you are missing one), and the world changes at each one
- **Coins are kept between games** (saved on the TV). Spend them in the **Shop** (locker → Shop, tablet button "Coin shop", or the game-over screen). Coins only, no real money. Hover an item to try it on; hold to buy and wear it.
  Trails: Confetti 100, Galaxy 200, Lightning 300, Aurora 400 · Hats: Cat ears 150, Ninja band 200, Wizard hat 300, Crown 400, Space helmet 500 · Gear: Gold cape 350, Jetpack 500, Aura 600, Angel wings 800 · Suits: Shadow 250, Gold 350, Neon 450. Prices are the `SHOP` list near the top of the runner code.
- **Customize** (menu, game-over screen, tablet button, or key C): skin, hair colour, hair/hat style, jacket, trousers, gadget (headphones, scarf, cape, backpack, halo) and a trail (sparkles, fire, rainbow, hearts). Saved on the TV.

**Zombie Siege** – Your hands aim two blasters; hovering a crosshair over a zombie fires.
- Aim is steadier now: it filters your hand more when you slow down to aim, keeps a lock for a moment if your hand wobbles, and gently pulls the crosshair onto a zombie when you are close.
- From wave 2 some zombies **come in from the left and right** (red arrows warn you).
- New zombies: **Crawler** (small, fast), **Spitter** (stays back and lobs acid — shoot the acid ball down), **Armoured** (helmet: headshots are not double), **Bloater** (pops in a blast that hurts the zombies around it). Plus the walkers, runners, brutes and bosses from before.
- Raise both hands above your head for a grenade; hover a medkit to heal.
- **Boost** (very rare yellow lightning icon): hover over it to get 5 seconds of double damage. Body shots do 2x, headshots 4x (normally 1x and 2x). A timer bar shows how long is left. The music gets busier as the waves do.

**Shape Fit** – walls with a human-shaped hole rush at you down a corridor. Strike the same pose (arms up, T-pose, one arm, squat, lean, star shape, flamingo) before the wall reaches you, or lose 1 of 3 lives. It speeds up and gets harder (legs poses appear later, only if the camera sees your legs). Hold the pose for about a fifth of a second as the wall arrives; holding it early gives a PERFECT bonus. Keyboard test mode: SPACE counts as holding the pose. Key **5** or the tablet button "Shape Fit" starts it. The pose rules are `SHAPE_POSES` in the Shape Fit section of `tv.html`, in torso lengths like Fit Zone.

**Fit Zone** – a guided workout. Choose **Kids** or **Seniors**, and Quick (4 moves) / Normal (6) / Long (8).
- The TV checks the camera can see your whole body, calibrates, then shows a coach demonstrating each move. Your reps are counted from your body and shown in a big ring with stars, effects and a mascot.
- **Kids**: jumping jacks, high knees, big jumps, side dashes, frog squats, reaching, clapping, wipers, windmill arms, super sprint, flamingo balance.
- **Seniors**: always standing, no sitting, only a tiny toe bounce — marching, reach-ups, arm lifts, slow arm circles, gentle side bends, side steps, clapping, balance hold (with a "hold a chair" reminder). Longer rests, no time pressure, calmer music.
- If the camera cannot see your legs, leg moves are counted by how much you are moving (arm moves still work normally).

**Music & sounds** – every game has its own tune (menu, fruit, runner, zombie, kids workout, seniors workout), all made live in the browser. Slicing, jumping and clearing a wave have their own sound effects. **Browsers only allow sound after one touch or key press**, so the first click/OK-button press on the TV turns sound on. Press **N** (or the ♪ Music button on the tablet) to turn music off or on.

All games **pause automatically** when you step out of the camera's view, and resume with a 3-2-1 countdown.

## Testing without the tablet

On a laptop, open `tv.html` and press **K**. Then:
- **← →** change lanes, **↑** jumps, **↓** ducks.
- Use the mouse to slice or aim.
- **G** throws a grenade.
- **1/2/3/4** pick a game, **C** customize runner, **N** music on/off
- In Fit Zone: **R** counts a rep, **S** skips, **Q** quits, **P** pauses, **M** opens the menu, **F** goes full screen.
- **D** shows the TV's frame rate.

## Tuning (top of `tracker.html`, the `CFG` block)

| Setting | Change it if… |
|---|---|
| `laneOn` / `laneOff` | lane changes trigger too easily (raise) or need too big a step (lower) |
| `jumpOn`, `jumpVel` | small bounces count as jumps (raise) or real jumps are missed (lower) |
| `duckOn` | ducking needs too deep a squat (lower) |
| `reachX`, `reachTop`, `reachH` | hand cursors can't reach the screen edges (lower) or feel too twitchy (raise) |
| `handFilter.beta` | cursor lags behind fast swipes (raise) |
| `handFilter.minCutoff` | cursor wobbles when your hand is still (lower) |
| `handHoldMs` | hands vanish mid-swipe (raise) |
| **Accurate mode** checkbox | uses the bigger "full" model: steadier tracking, lower fps on the A8 |
| **Precise hands** checkbox | loads an extra finger-tracking model for steadier aim (slower; the model is fetched from Google at start, if it cannot load the game carries on normally) |
| **Hide preview** checkbox | stops drawing the camera on the tablet, giving a few extra fps |

The **Delay** number on the tablet shows how long motion takes to reach the TV. Under about 80 ms feels instant.

On the TV side, `SLICE_SPEED` (how fast a swipe must be) and `GUN_RATE` (seconds between shots) are near the top of `tv.html`.

## Adding your own game

Each game is one object in `tv.html` under `scenes`, with `enter()`, `update(dt)` and `draw()` methods. Read the player through the shared input helpers:

- `cursors()` → hand positions in screen pixels, with `hd.speed`
- `I.segments` → hand movements this frame, as line segments with speed
- `laneInput()`, `takeJump()`, `duckInput()`, `I.up` (both hands above head)
- `I.sk` → all 33 body points mapped to the screen
- Add `game:true` to get auto-pause for free

## Notes

- Libraries load from CDNs, so both devices need internet. The tablet needs Wi-Fi, but no SIM.
- If the TV's browser struggles, the page automatically lowers its internal resolution to keep the game smooth.

## Tuning the exercises

Pose rules for Shape Fit are in `SHAPE_POSES`. Exercise counting thresholds are in the `FITCFG` block at the top of the Fit Zone section of `tv.html` (search for `FITCFG`), in torso lengths. If a move is not being counted, lower its number a little; if it counts too easily, raise it. They were tested against simulated body poses, not real people, so expect to tweak them once.

## v5 changes

### 2-player mode (Lane Runner, Zombie Siege, Shape Fit)
- Tap a game → choose **1 Player** or **2 Players**. Stand side by side in front of the tablet camera: the person on the **left is Player 1 (blue)**, the person on the **right is Player 2 (orange)**.
- The TV splits in two. Both players get the **same course / waves / poses**, so it is fair.
- **Whoever stays alive longer wins +50 coins.** If both fall in the same moment it is a draw (+25 coins each round to the wallet).
- Tablet note: 2-player tracking is heavier. If it feels slow, stand a bit further back with both of you fully in view.

### New ways to earn coins
- **Zombie Siege:** every cleared wave pays coins (8 + 2 per wave), bosses +10.
- **Shape Fit:** every 5 walls is a wave (+10 coins, +20 if flawless). **5 PERFECT shapes in a row = +15 coins.**

### Fix: character too small
The tracker now continuously adapts to how big you appear to the camera (grows fast, shrinks slowly), so your on-screen reach is always a consistent medium size in Fruit Ninja, Fit Zone and everything else, without having to visit Lane Runner first.

### Upload
Upload BOTH `tv.html` and `tracker.html` (same names) to GitHub, then hard-refresh the tablet and TV.

## v6 changes
- **Two runners:** the Locker and the Shop now have **Player 1 / Player 2** buttons (top left). Each player has their own saved look, and in 2-player games each half shows that player's runner. Coins and owned items are shared.
- **~35 new shop items:** 8 new trails (Bubbles, Snow, Blossoms, Pixel party, Gold dust, Toxic, Blue flame, Comet), 10 hats (Party, Chef, Bunny ears, Santa, Flower crown, Top hat, Pirate, Viking, Devil horns, Unicorn horn), 9 gear items (Sunglasses, Mustache, Gold medal, Rainbow cape, Orbit stars, Fire/Ice aura, Butterfly/Dragon wings), 8 suits (Camo, Royal, Ruby, Ocean, Ice, Lava, Galaxy, Rainbow). The shop has pages now. A few free skin, hair and trouser colours were added too.
- **Coins in single player:** Lane Runner coins, Zombie Siege wave clears and Shape Fit waves / 5-perfect streaks all pay into the wallet. Zombie Siege also gives +2 coins per 10 kills. Rewards stay small compared with the 50-coin 2-player win.

## v6.1 – 2-player detection fix
The tablet now rebuilds its motion model for exactly 2 people only when a 2-player game starts (and back to 1 person everywhere else). The TV re-sends the player count every 2 seconds so it can't get lost. Upload BOTH tv.html and tracker.html, then reload the tablet page too.

## v7 – Game 6: Penguin Slide 🐧
- Belly-slide down an icy mountain. **Lean** to change lane (the ice is slippery, so you skid), **jump** over rocks, **squat** under ice arches, dodge ice walls, and **raise both hands (or press Z) for a FLAP-DASH** that smashes snowmen (+2 fish). Dash recharges in a few seconds.
- Three worlds: Snowy Slope → Ice Caves → Aurora Night (every 600 m). 3 hearts.
- **Coins (small on purpose):** 1 coin per 3 fish + 1 coin per 150 m. In **2 players** (same mountain, split screen) the longest slider gets +50 coins.
- Menu key 6, tablet button "Penguin Slide". Upload tv.html AND tracker.html.

## v7.1 – Game 7: Balloon Burst 🎈
- Balloons float up from the bottom. **Reach up and touch them with either hand** to pop them. Normal = 10 points, **golden = 50**, **spiky (angry face) = lose a heart**. 3 hearts.
- It speeds up as you go; after ~25 seconds a **wind** starts and slowly gets stronger, pushing balloons sideways. The sky changes every minute.
- **Chains:** pop balloons within 1.4 s of each other. Every 10 in a row raises your multiplier (×2, ×3, ×4) and **pays coins**: 1 coin at chain 10, 2 at 20, 3 at 30… up to 5 per milestone.
- Menu key 7, tablet button "Balloon Burst". Upload tv.html AND tracker.html.

## v8 – Game 8: Simon Says Moves
TV shows a sequence (Simon cue + coach demo, ~2 s each, each move plays a note); copy it in order. Each round adds a move, window shrinks, harder moves appear. Miss = free retry once, then lose a heart; 3 hearts. Modes: Classic, Kids (adds Wave, Spin), Seniors (standing moves only). Uses Fit Zone pose tests (`exF`, FITCFG) with a short hold. Keyboard: Space counts the current move. Key 8.

## v9 – Game 9: Boxing Dojo
Punch glowing pads (left/centre/right) on the sensei, block his mid attacks (both hands up at face), duck his overhead swings; he feints from round 2 (reacting to a feint resets your combo). 42–60 s rounds, combos (alternating hands bonus), KO ends round early, health +30 between rounds. Punch = arm straightening fast / fist moving toward camera (tracker `ex[18..21]`), refractory + armed check to ignore arm swings; tuning in `BOXCFG` (68_boxing.js). Keyboard: A/S/D punch, B block, ↓ duck. Key 9. New tracker features `ex[15..21]` (elbow offsets, shoulder-width ratio, arm extension, forward reach) – upload BOTH tv.html and tracker.html.
Note: tested only with simulated poses; punch/block/spin thresholds need real-body tuning.

## v9.1 – Smoother, more reliable tracking
- Tracker: joints the camera barely sees hold their last position; one-frame "teleports" (model grabbing a chair/shadow) are ignored for up to 3 frames; a 0.35 s grace period keeps you on screen through brief dropouts. Tunable: `CFG.graceMs`, `holdVis`, `jumpMax`.
- TV: the 22 body numbers (`ex`) go through a 3-frame median, removing single-frame spikes (phantom jumps/punches/pose flicker) with ~1 frame of delay.
- Upload BOTH tv.html and tracker.html.

## v10 – Zombie Siege visual & sound overhaul (gameplay unchanged)
- **Art** (`src/69_zart.js`): every zombie is a shaded, lit sprite (sunken glowing eyes, teeth, torn flesh, ribs, claws, hair, per-type gear), cached per walk frame so it stays fast; live effects (eye glow, boss aura, bloater pulse, acid charge, wounds as they take damage); soft ground shadows and depth haze; new two-handed gun sprites with sleeves/gloves, laser sight, muzzle flash, smoke and ejected brass; 3D medkit and an energy-core boost pickup; glossy HUD, grenade icon; planked barricade with barbed wire.
- **World** (`src/69b_zenv.js`): six moods — Blood Moon, Thunderstorm, Toxic Dusk, Burning Night, Dead Fog, Black Eclipse. A new random one fades in after every wave (same sequence for both players in 2P). Each has its own sky, clouds, skyline, graveyard, fences, fires, weather (rain/ash/spores/dust), crows/bats, lightning, vignette and film grain.
- **Sound**: formant-voiced grunts per zombie type (moan, snarl, brute roar, boss roar, crawler hiss, spitter/bloater gurgle) panned to where they are; layered gunshots, flesh hits, death rattles, barricade crack, grenade; ambient bed and one-shots per mood (wind, rain, thunder, wolf, crow, owl, bell, siren, crackle, drone…).
- Tuning: `ZENVS` (moods), `zSnd.*` (sounds), `ZU` (sprite resolution; lower = less memory on weak TVs).
